//------------------------------------------------------------------------------
#include <stdio.h>
#include <vcl.h>
#pragma hdrstop

#include "conv.h"
//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TConvertForm* ConvertForm;
//------------------------------------------------------------------------------
__fastcall TConvertForm::TConvertForm(TComponent* Owner): TForm(Owner)
{
}

//------------------------------------------------------------------------------
void __fastcall TConvertForm::CancelButtonClick(TObject* Sender)
{
  Close();
}

//------------------------------------------------------------------------------
void __fastcall TConvertForm::SelectButtonClick(TObject* Sender)
{
  char outfile[MAX_PATH+1];
  char* pos;

  if (OpenDialog1->Execute()) {
    Edit1->Text = OpenDialog1->FileName;
    Edit1->Text = LowerCase(Edit1->Text);
    strcpy(outfile, Edit1->Text.c_str());
    pos = strstr(outfile, ".lmb");
    *pos = 0;
    strcat(outfile, ".txt");
    Edit2->Text = AnsiString(outfile);
  }
}

//------------------------------------------------------------------------------
void __fastcall TConvertForm::ConvertButtonClick(TObject* Sender)
{
  FILE* fin;
  FILE* fout;
  char i, c, b[65536], temp[128];
  char *pb, *pe;
  size_t pos = 0;
  int offset = 5;
  int count = 0;

  Memo1->Clear();
  memset(b, 0, sizeof(b));
  if ( FileExists(Edit1->Text) ) {
    fin = fopen(Edit1->Text.c_str(), "rb");
    if (fin) {
      // Skip "LMB" header
      for (i = 0; i < 4; i++)
        fread(&c, 1, 1, fin);

      while (fread(&c, 1, 1, fin) == 1) {
        if ((c >= 32) && (c < 127) && (c != '$')) {
          b[pos] = c;
          pos++;
        }
        if (c == '$') {
          c = ' ';
          b[pos] = c;
          pos++;
        }
      }
      fclose(fin);
    }
    fout = fopen(Edit2->Text.c_str(), "wt");
    if (fout) {
      pb = (char*)strstr(b, "PBE2");
      while (pb) {
        memset(temp, 0, sizeof(temp));
        pe = (char*)strstr(pb+1, "PBE2");
        if (pe) {
          strncpy(temp, pb + offset, pe - pb - offset);
          temp[pe - pb] = 0;
        }
        else if (pb) {
          strcpy(temp, pb + offset);
        }
        Memo1->Lines->Add(temp); // Skip extra bytes voor enumeratie na "PBE2"
        fprintf(fout, "%s\n", temp);
        count++;
        if (count > 32)
          offset = 7;
        if (count > 125)
          offset = 5;
        pb = pe;
      }
      fclose(fout);
    }
    Application->MessageBox("Ready.", Application->Title.c_str(), MB_OK);
  }
}

//------------------------------------------------------------------------------

