//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("lmbconv.res");
USEFORM("conv.cpp", ConvertForm);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    try
    {
        Application->Initialize();
        Application->CreateForm(__classid(TConvertForm), &ConvertForm);
        Application->Run();
    }
    catch (Exception &exception)
    {
        Application->ShowException(&exception);
    }
    return 0;
}
//---------------------------------------------------------------------------
