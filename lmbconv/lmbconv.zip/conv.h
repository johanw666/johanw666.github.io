//---------------------------------------------------------------------------
#ifndef convH
#define convH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TConvertForm : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel1;
    TMemo *Memo1;
    TPanel *Panel2;
    TButton *SelectButton;
    TButton *CancelButton;
    TButton *ConvertButton;
    TOpenDialog *OpenDialog1;
    TEdit *Edit2;
    TEdit *Edit1;
    void __fastcall SelectButtonClick(TObject *Sender);
    void __fastcall ConvertButtonClick(TObject *Sender);
    void __fastcall CancelButtonClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TConvertForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TConvertForm *ConvertForm;
//---------------------------------------------------------------------------
#endif
