*****************************************
*					*
*	      DeCSS 1.2b		*
*					*
*****************************************
* 1.2.1b:				*
* - Fixed an integer divide by zero bug	*
*					*
* 1.2b:					*
*  - Added multiple selection of files	*
*  - Transfer Rate and ETA		*
*  - Checks if you have enough hd space	*
*  - You can now merge vob files	*
*  - "Integer division by 0"-bug fixed	*
*					*
* 1.1b:					*
*  - First public release		*
*					*
#########################################
# - ASPI Problems			#
#########################################
# If you get an error message saying:	#
# "Could not load aspi layer", then try #
# the aspi layer included with DeCSS.	#
#					#
# wnaspi32.w98.dll: Use this for Win98	#
# wnaspi32.w2k.dll: Use this for NT/2K	#
#					#
# Remember to rename it to wnaspi32.dll #
#					#
#########################################
# - How do I select audio stream?	#
#########################################
#					#
# You don't. DeCSS is just a decryptor,	#
# nothing else. Copy all the files to a	#
# video_ts folder on your hd, and then	#
# try playing the movie.		#
#					#
#########################################
# - The aspect radio is weird?!		#
#########################################
#					#
#   Same reason as above.		#
#					#
#########################################
|					|
| Credits/Greetings (in no part. order) |
| [ Canman, S0upaFr0g ]			|
|		  			|
| - Authors of DeCSS			|
| 10/09/99 - 18:22  			|
|		  			|
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~