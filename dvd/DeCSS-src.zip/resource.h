//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DeCSS.rc
//
#define IDD_DECSS                       128
#define IDC_DRIVES                      1003
#define IDC_FILES                       1004
#define IDC_GETKEYS                     1005
#define IDC_SECTOR                      1007
#define IDC_STATUS                      1008
#define IDC_FOLDER                      1009
#define IDC_TRANSFER                    1010
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
