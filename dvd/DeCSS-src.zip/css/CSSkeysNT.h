#ifndef __CSSkeysNT_H__
#define __CSSkeysNT_H__

extern int CSSgetdiskkey(char n,unsigned char *key);
extern int CSSgettitlekey(char n,unsigned int LBA,unsigned char *key);

#endif