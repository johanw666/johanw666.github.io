#ifndef __CSSscramble_h_
#define __CSSscramble_h_

extern void CSSdecrypttitlekey(unsigned char *tkey,unsigned char *dkey);
extern void CSStitlekey1(unsigned char *key,unsigned char *im);
extern void CSStitlekey2(unsigned char *key,unsigned char *im);
extern void CSSdescramble(unsigned char *sector,unsigned char *key);

#endif
