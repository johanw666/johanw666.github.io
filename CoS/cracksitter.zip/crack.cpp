//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "crack.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1* Form1;

//---------------------------------------------------------------------------
//  Constructor
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
: TForm(Owner)
{
  key         = 0xDEADL;
  OpenDialog1 = new TOpenDialog(Form1);
  SaveDialog1 = new TSaveDialog(Form1);
  inFile      = NULL;
}

//---------------------------------------------------------------------------
//  Destructor
//---------------------------------------------------------------------------
__fastcall TForm1::~TForm1()
{
  delete OpenDialog1;
  delete SaveDialog1;
}

//---------------------------------------------------------------------------
//  Exit
//---------------------------------------------------------------------------
void __fastcall TForm1::Exit1Click(TObject* Sender)
{
  Form1->Close();
}

//---------------------------------------------------------------------------
//  Move the buttons and labels when resizing
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject* Sender)
{
  Button1->Top = ClientHeight - 2*Button1->Height + 10;
  Label1->Top = Button1->Top + 2;
  Label2->Top = Button1->Top + 2;
  ListBox1->Height = ClientHeight - 50;
}

//---------------------------------------------------------------------------
//  Load input file button pressed
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject* Sender)
{
  char systemDir[128]; // Name of windows system dir, e.g. C:\WINDOWS\SYSTEM
  char currDir[128];   // Name of current directory
  GetSystemDirectory(systemDir, sizeof(systemDir));
  GetCurrentDirectory(sizeof(currDir), currDir);
  // Set current dir to windows system dir
  SetCurrentDirectory(systemDir);

  OpenDialog1->Title = "File to get the censor strings from?";
  OpenDialog1->Filter = "Scientology DLL's (d32l.dll, n32l.dll, p32l.dll)|d32l.dll;n32l.dll;p32l.dll;|DLL files (*.dll)|*.dll;|All files (*.*)|*.*";
  OpenDialog1->FileName = "";
  OpenDialog1->Execute();

  if ( !OpenDialog1->FileName.IsEmpty() )
  {
    inFile = fopen(OpenDialog1->FileName.c_str(), "rb");
    if ( !inFile )
    {
      AnsiString errMsg = "Error opening file" + OpenDialog1->FileName;
      Application->MessageBox(errMsg.c_str(), "Error", MB_OK);
    }
    else
    {
      // Reset the key
      key = 0xDEADL;
      // Clear screen
      ListBox1->Clear();
      // Set label
      Label2->Caption = OpenDialog1->FileName.c_str();

      while( ReadIt(inBuff, inFile) )
      {
        DecryptLine(inBuff, outBuff);
        ListBox1->Items->Add(AnsiString(outBuff));
      }
      fclose(inFile);
    }
  }
  // Reset the current directory
  SetCurrentDirectory(currDir);
}

//---------------------------------------------------------------------------
//  Remove all items from the screen and reset filenames, etc.
//---------------------------------------------------------------------------
void __fastcall TForm1::ClearScreen1Click(TObject *Sender)
{
  ListBox1->Clear();
  Label2->Caption = "None";
  OpenDialog1->FileName = "";
  SaveDialog1->FileName = "";
}

//---------------------------------------------------------------------------
//  Load a textfile and display its contents
//---------------------------------------------------------------------------
void __fastcall TForm1::LoadTextFile1Click(TObject* Sender)
{
  char* k;
  char  line[512];

  OpenDialog1->Title = "Textfile to get the test censor strings from?";
  OpenDialog1->Filter = "Text files (*.txt)|*.txt;|All files (*.*)|*.*";
  OpenDialog1->Execute();

  if ( !OpenDialog1->FileName.IsEmpty() )
  {
    inFile = fopen(OpenDialog1->FileName.c_str(), "rt");
    if ( !inFile )
    {
      AnsiString errMsg = "Error opening file" + OpenDialog1->FileName;
      Application->MessageBox(errMsg.c_str(), "Error", MB_OK);
    }
    else
    {
      // Clear screen
      ListBox1->Clear();
      // Set label
      Label2->Caption = OpenDialog1->FileName.c_str();

      do
      {
        // Set line to 0 first
        memset(line, 0, sizeof(line));
        k = fgets(line, sizeof(line), inFile);
        // The read lines are terminated with \n, replace it by 0:
        MakeZString(line, sizeof(line));
        ListBox1->Items->Add(AnsiString(line));
      } while ( k );
      fclose(inFile);
    }
  }
}

//---------------------------------------------------------------------------
//  Make a 0-terminated string from a \n terminated string. We can safely
//  assume that there is no \n in the trailing garbage after the read line
//  because this is set to all 0 first.
//---------------------------------------------------------------------------
void __fastcall TForm1::MakeZString(char* inLine, size_t lineLength)
{
  for (int i = lineLength; i >= 0; i--)
  {
    if ( *(inLine + i) == '\n' )
    {
      *(inLine + i) = 0;
    }
    break;
  }
}

//---------------------------------------------------------------------------
//  Save encrypted output
//---------------------------------------------------------------------------
void __fastcall TForm1::SaveasDLL1Click(TObject* Sender)
{
  if ( ListBox1->Items->Count < 1 ) // Nothing to save
  {
    Application->MessageBox("No output to save", "Error", MB_OK);
    return;
  }

  bool deleteFile = true;

  SaveDialog1->Title = "File to save list in Encrypted DLL format";
  SaveDialog1->Filter = "Scientology DLL's (d32l.dll, n32l.dll, p32l.dll)|d32l.dll;n32l.dll;p32l.dll;|DLL files (*.dll)|*.dll;|All files (*.*)|*.*";
  SaveDialog1->Execute();

  if ( !SaveDialog1->FileName.IsEmpty() )
  {
    // test if file exists
    FILE* outFile = fopen(SaveDialog1->FileName.c_str(), "r");
    if ( outFile )
    {
      switch(Application->MessageBox("File already exists, do you want to overwrite it?", "Warning", MB_YESNO))
      {
        case ID_NO:
          deleteFile = false;
          break;

        case ID_YES:
          deleteFile = true;
          break;

        default:
          deleteFile = false;
          break;
      }
      fclose(outFile);
    }
    // File did not exist or overwrite was selected
    if ( deleteFile )
    {
      key = 0xDEADL; // Reset the key
      outFile = fopen(SaveDialog1->FileName.c_str(), "wt");
      for (int i = 0; i < ListBox1->Items->Count; i++)
      {
        EncryptLine(ListBox1->Items->Strings[i].c_str(), outBuff);
        fprintf(outFile, "%s\n", outBuff);
      }
      fclose(outFile);
    }
  }
}

//---------------------------------------------------------------------------
//  Save output in a textfile
//---------------------------------------------------------------------------
void __fastcall TForm1::Save1Click(TObject* Sender)
{
  if ( ListBox1->Items->Count < 1 ) // Nothing to save
  {
    Application->MessageBox("No output to save", "Error", MB_OK);
    return;
  }

  bool deleteFile = true;

  SaveDialog1->Title = "File to save list in text format";
  OpenDialog1->Filter = "All files (*.*)|*.*";
  SaveDialog1->Execute();
  if ( !SaveDialog1->FileName.IsEmpty() )
  {
    // test if file exists
    FILE* outFile = fopen(SaveDialog1->FileName.c_str(), "r");
    if ( outFile )
    {
      switch(Application->MessageBox("File already exists, do you want to overwrite it?", "Warning", MB_YESNO))
      {
        case ID_NO:
          deleteFile = false;
          break;

        case ID_YES:
          deleteFile = true;
          break;

        default:
          deleteFile = false;
          break;
      }
      fclose(outFile);
    }
    // File did not exist or overwrite was selected
    if ( deleteFile )
    {
      outFile = fopen(SaveDialog1->FileName.c_str(), "wt");
      for (int i = 0; i < ListBox1->Items->Count; i++)
      {
        fprintf(outFile, "%s\n", ListBox1->Items->Strings[i]);
      }
      fclose(outFile);
    }
  }
}

//---------------------------------------------------------------------------
//  Copy selected strings to clipboard
//---------------------------------------------------------------------------
void __fastcall TForm1::Copy1Click(TObject* Sender)
{
  DWORD   size = 0;
  HGLOBAL hMem;
  char*   pMem;

  if ( ListBox1->SelCount > 0 ) // No use doing something is nothing is selected
  {
    // See how many items are selected and how much space they require.
    // Each item needs space for its string length plus an ending \r\n
    for (int i = 0; i < ListBox1->Items->Count; i++)
    {
      if ( ListBox1->Selected[i] )
      {
        size += strlen(ListBox1->Items->Strings[i].c_str()) + 2;
      }
    }
    // Allocate memory and lock it, 1 byte extra for terminating 0
    hMem = GlobalAlloc(GHND | GMEM_DDESHARE, size + 1);
    if ( hMem )
    {
      pMem = (char*)GlobalLock(hMem);
      // Fill it
      char* index = pMem;
      for (int i = 0; i < ListBox1->Items->Count; i++)
      {
        if ( ListBox1->Selected[i] )
        {
          strcpy(index, ListBox1->Items->Strings[i].c_str());
          index += strlen(ListBox1->Items->Strings[i].c_str());
          *index = '\r';
          *(index + 1) = '\n';
          index += 2;
        }
      }
      *(index + 1) = 0; // terminate it
      GlobalUnlock(hMem);
      // Set clipboard data
      if ( OpenClipboard(ListBox1->Handle) )
      {
        EmptyClipboard();
        SetClipboardData(CF_TEXT, hMem); // CF_TEXT means each line ends with
        CloseClipboard();                // \r\n, 0 means end of data
      }
    }
    else // Unable to locate enough global memory: pMem == NULL
    {
      GlobalUnlock(hMem);
      Application->MessageBox("Could not copy selected items to clipboard", "Error", MB_OK);
    }
  }
}

//---------------------------------------------------------------------------
//  Paste strings from the clipboard
//---------------------------------------------------------------------------
void __fastcall TForm1::Paste1Click(TObject* Sender)
{
  HGLOBAL hGin;
  char*   pGin;
  char*   index;
  char    c[2];
  char    tempString[128];

  if ( OpenClipboard(ListBox1->Handle) )
  {
    hGin = GetClipboardData(CF_TEXT);
    if ( hGin )
    {
      pGin = (char*)GlobalLock(hGin);
      index = pGin;
      memset(tempString, 0, sizeof(tempString));
      c[1] = 0; // Make 0-terminated string from c[]

      // Now copy the lines in the listbox.
      while ( *index )
      {
        if ( strncmp(index, "\r\n", 2) )
        {
          *c = *index;
          strcat(tempString, c);
          index++;
        }
        else // reached end of line
        {
          ListBox1->Items->Add(AnsiString(tempString));
          memset(tempString, 0, sizeof(tempString));
          index += 2;
        }
      }
      // Add string also if the final string did not end with \r\n
      if ( strlen(tempString) ) ListBox1->Items->Add(AnsiString(tempString));
      GlobalUnlock(hGin);
    }
    CloseClipboard();
  }
}

//---------------------------------------------------------------------------
//  Read the encrypted file
//---------------------------------------------------------------------------
bool __fastcall TForm1::ReadIt(char* inbuff, FILE* infile)
{
  int count, c;
  count = 0;
  for ( ; ; )
  {
    c = fgetc(infile);
    if ( c < 0 )
    {
      if ( count == 0 )
        return false;
      break;
    }
    if ( c == '\n' || c == '\r' )
    {
      if ( count == 0 )
        continue;
      break;
    }
    *inbuff++ = c;
    count++;
  }
  *inbuff = 0;
  return true;
}

//---------------------------------------------------------------------------
//  Decrypt a single line
//---------------------------------------------------------------------------
void __fastcall TForm1::DecryptLine(char* inbuff, char* outbuff)
{
  int           in_count, out_count = 0;
  unsigned char ch1, ch2;
  unsigned long subkey1, subkey2;
  int           len = strlen(inbuff)/2;

  for (in_count = 0; in_count < len; in_count++)
  {
    subkey1 = key;
    subkey1 = (subkey1 >> 4) & 0x1fL;
    subkey2 = key;
    subkey2 = (subkey2 >> 8) & 0x1fL;
    ch2 = *(inbuff+in_count*2 + 1);
    ch2 ^= subkey2;
    ch2 = (ch2 & 0x0f) << 4;
    ch1 = *(inbuff + in_count*2);
    ch1 ^= subkey1;
    ch1 &= 0x0f;
    ch1 |= ch2;
    outbuff[out_count] = ch1;
    key += 0x100L - (unsigned long)ch1;
    ++out_count;
  }
  outbuff[out_count] = 0;
}

//---------------------------------------------------------------------------
//  Encrypt a line
//---------------------------------------------------------------------------
void __fastcall TForm1::EncryptLine(char* inbuff, char* outbuff)
{
  int           in_count, out_count = 0;
  unsigned char c, ch1, ch2;
  unsigned long subkey1, subkey2;
  int           len = strlen(inbuff);

  for (in_count = 0; in_count < len; in_count++)
  {
    c = *(inbuff + in_count);
    ch1 = c & 0x0f;
    ch2 = c & 0xf0;

    subkey1 = key;
    subkey1 = (subkey1 >> 4) & 0x1fL;
    subkey2 = key;
    subkey2 = (subkey2 >> 8) & 0x1fL;

    ch2 = (ch2 >> 4) | 0x60;
    ch2 ^= subkey2;

    ch1 ^= subkey1;
    ch1 |= 0x30;
    if (( ch2 & 0x01 ) == 0 ) // if ch2 is even
    {
      ch1 &= 0x2F;
    }
    else
    {
      ch1 &= 0x3F;
    }
    outbuff[out_count] = ch1;
    ++out_count;
    outbuff[out_count] = ch2;
    ++out_count;

    key += 0x100L - (unsigned long)c;
  }
  outbuff[out_count] = 0;
}

//---------------------------------------------------------------------------
//  Show product information
//---------------------------------------------------------------------------
void __fastcall TForm1::ProductInformation1Click(TObject* Sender)
{
  Application->MessageBox("CrackSitter: a windows GUI program that\n"
                          "Shows the lists of words, websites and newsgroups\n"
                          "that scientology does not want you to see by decrypting\n"
                          "their censorware.\n\n"
                          "Works also for CyberSitter censorware.\n\n"
                          "Also gives the option to save a list of words to an encrypted\n"
                          "list to test the CyberSitter software with custom lists.\n\n"
                          "(C) 1998 by J.C.A. Wevers (johanw@vulcan.xs4all.nl)\n"
                          "Decryption routines by by Bobban / DFR Research & Engineering\n"
                          "Encryption routines by Cornelius Krasel.\n\n"
                          "May be freely used and copied."
                          , "Product Information", MB_OK);
}

//---------------------------------------------------------------------------
//  Show helptext
//---------------------------------------------------------------------------
void __fastcall TForm1::Helptext1Click(TObject* Sender)
{
  Application->MessageBox("Select a file to decrypt the information from.\n"
                          "The texts, newsgroups and websites censored by\n"
                          "scientology are stored in the files\n\n"
                          "\td32l.dll\n"
                          "\tn32l.dll\n"
                          "\tp32l.dll\n\n"
                          "Which are by deafult installed in the windows system directory.\n\n"
                          "Select one of them to show its contents.\n"
                          "Use File->Save  as Text to save the contents to a text file.\n"
                          "Use File->Save  as DLL to save the contents encrypted a file.\n"
                          "Use Edit->Copy  to copy all selected items to the clipboard.\n"
                          "Use Edit->Paste to paste lines from the clipboard into the listbox.\n"
                          , "Help", MB_OK);
}

//---------------------------------------------------------------------------

