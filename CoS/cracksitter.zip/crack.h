//---------------------------------------------------------------------------
#ifndef crackH
#define crackH

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:
  TPanel*      Panel1;
  TListBox*    ListBox1;
  TButton*     Button1;
  TLabel*      Label1;
  TLabel*      Label2;
  TMainMenu*   MainMenu1;
  TMenuItem*   File1;
  TMenuItem*   LoadTextFile1;
  TMenuItem*   Open1;
  TMenuItem*   ClearScreen1;
  TMenuItem*   Save1;
  TMenuItem*   SaveasDLL1;
  TMenuItem*   Exit1;
  TMenuItem*   Edit1;
  TMenuItem*   Copy1;
  TMenuItem*   Paste1;
  TMenuItem*   Help1;
  TMenuItem*   Helptext1;
  TMenuItem*   ProductInformation1;
  TOpenDialog* OpenDialog1;
  TSaveDialog* SaveDialog1;

  void __fastcall Button1Click(TObject* Sender);
  void __fastcall ProductInformation1Click(TObject* Sender);
  void __fastcall Helptext1Click(TObject* Sender);
  void __fastcall Exit1Click(TObject* Sender);
  void __fastcall Save1Click(TObject* Sender);
  void __fastcall SaveasDLL1Click(TObject* Sender);
  void __fastcall FormResize(TObject* Sender);
  void __fastcall Copy1Click(TObject* Sender);
  void __fastcall LoadTextFile1Click(TObject* Sender);
  void __fastcall Paste1Click(TObject* Sender);
  void __fastcall ClearScreen1Click(TObject* Sender);

private:
  FILE*         inFile;
  unsigned long key;
  char          inBuff[400];
  char          outBuff[800];

  // Read one line from binary file
  bool __fastcall ReadIt(char* inbuff, FILE* infile);
  // Decryps one line
  void __fastcall DecryptLine(char* inbuff, char* outbuff);
  // Encryps one line
  void __fastcall EncryptLine(char* inbuff, char* outbuff);
  // Make a 0-terminated string from a \n terminated string
  void __fastcall MakeZString(char* inLine, size_t lineLength);

public:
  __fastcall TForm1(TComponent* Owner);
  __fastcall ~TForm1();
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1* Form1;
//---------------------------------------------------------------------------
#endif // crackH
//---------------------------------------------------------------------------

