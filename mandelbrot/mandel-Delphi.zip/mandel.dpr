program mandel;

uses
  Forms,
  drawform in 'drawform.pas' {MandelForm};

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TMandelForm, MandelForm);
  Application.Run;
end.
