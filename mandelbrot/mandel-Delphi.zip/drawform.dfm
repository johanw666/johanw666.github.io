object MandelForm: TMandelForm
  Left = 189
  Top = 135
  BorderStyle = bsSingle
  Caption = 'Mandelbrot Fractal'
  ClientHeight = 514
  ClientWidth = 819
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesktopCenter
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object Panel1: TPanel
    Left = 0
    Top = 482
    Width = 819
    Height = 32
    Align = alBottom
    BevelOuter = bvNone
    TabOrder = 0
    object Gauge1: TGauge
      Left = 64
      Top = 6
      Width = 465
      Height = 20
      ForeColor = clGreen
      Progress = 0
    end
    object Label4: TLabel
      Left = 8
      Top = 10
      Width = 48
      Height = 13
      Caption = '% Done:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clNavy
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object Panel3: TPanel
      Left = 577
      Top = 0
      Width = 242
      Height = 32
      Align = alRight
      BevelOuter = bvNone
      TabOrder = 0
      object DrawButton: TButton
        Left = 8
        Top = 4
        Width = 75
        Height = 25
        Caption = '&Draw'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'MS Sans Serif'
        Font.Style = [fsBold]
        ParentFont = False
        TabOrder = 0
        OnClick = DrawButtonClick
      end
      object BitBtn1: TBitBtn
        Left = 164
        Top = 4
        Width = 75
        Height = 25
        Caption = '&Close'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'MS Sans Serif'
        Font.Style = [fsBold]
        ModalResult = 1
        ParentFont = False
        TabOrder = 1
        OnClick = BitBtn1Click
        Glyph.Data = {
          DE010000424DDE01000000000000760000002800000024000000120000000100
          0400000000006801000000000000000000001000000000000000000000000000
          80000080000000808000800000008000800080800000C0C0C000808080000000
          FF0000FF000000FFFF00FF000000FF00FF00FFFF0000FFFFFF00388888888877
          F7F787F8888888888333333F00004444400888FFF444448888888888F333FF8F
          000033334D5007FFF4333388888888883338888F0000333345D50FFFF4333333
          338F888F3338F33F000033334D5D0FFFF43333333388788F3338F33F00003333
          45D50FEFE4333333338F878F3338F33F000033334D5D0FFFF43333333388788F
          3338F33F0000333345D50FEFE4333333338F878F3338F33F000033334D5D0FFF
          F43333333388788F3338F33F0000333345D50FEFE4333333338F878F3338F33F
          000033334D5D0EFEF43333333388788F3338F33F0000333345D50FEFE4333333
          338F878F3338F33F000033334D5D0EFEF43333333388788F3338F33F00003333
          4444444444333333338F8F8FFFF8F33F00003333333333333333333333888888
          8888333F00003333330000003333333333333FFFFFF3333F00003333330AAAA0
          333333333333888888F3333F00003333330000003333333333338FFFF8F3333F
          0000}
        NumGlyphs = 2
      end
      object StopButton: TBitBtn
        Left = 86
        Top = 4
        Width = 75
        Height = 25
        Caption = '&Stop'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'MS Sans Serif'
        Font.Style = [fsBold]
        ModalResult = 3
        ParentFont = False
        TabOrder = 2
        OnClick = StopButtonClick
        Glyph.Data = {
          DE010000424DDE01000000000000760000002800000024000000120000000100
          0400000000006801000000000000000000001000000000000000000000000000
          80000080000000808000800000008000800080800000C0C0C000808080000000
          FF0000FF000000FFFF00FF000000FF00FF00FFFF0000FFFFFF00333333333333
          333333333333333333333333000033338833333333333333333F333333333333
          0000333911833333983333333388F333333F3333000033391118333911833333
          38F38F333F88F33300003339111183911118333338F338F3F8338F3300003333
          911118111118333338F3338F833338F3000033333911111111833333338F3338
          3333F8330000333333911111183333333338F333333F83330000333333311111
          8333333333338F3333383333000033333339111183333333333338F333833333
          00003333339111118333333333333833338F3333000033333911181118333333
          33338333338F333300003333911183911183333333383338F338F33300003333
          9118333911183333338F33838F338F33000033333913333391113333338FF833
          38F338F300003333333333333919333333388333338FFF830000333333333333
          3333333333333333333888330000333333333333333333333333333333333333
          0000}
        NumGlyphs = 2
      end
    end
  end
  object Panel2: TPanel
    Left = 0
    Top = 0
    Width = 646
    Height = 482
    Align = alClient
    BevelOuter = bvLowered
    TabOrder = 1
    object FractalImage: TImage
      Left = 1
      Top = 1
      Width = 644
      Height = 480
      Align = alClient
    end
  end
  object Panel4: TPanel
    Left = 646
    Top = 0
    Width = 173
    Height = 482
    Align = alRight
    BevelOuter = bvLowered
    TabOrder = 2
    object ColorGroupBox: TGroupBox
      Left = 1
      Top = 168
      Width = 171
      Height = 313
      Align = alBottom
      Caption = ' Colors '
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clNavy
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ParentFont = False
      TabOrder = 0
      object ColorPanel0: TPanel
        Left = 8
        Top = 16
        Width = 153
        Height = 15
        Caption = 'Color 0'
        TabOrder = 0
        OnClick = ColorPanelClick
      end
      object ColorPanel1: TPanel
        Left = 8
        Top = 32
        Width = 153
        Height = 15
        Caption = 'Color 1'
        TabOrder = 1
        OnClick = ColorPanelClick
      end
      object ColorPanel2: TPanel
        Left = 8
        Top = 48
        Width = 153
        Height = 15
        Caption = 'Color 2'
        TabOrder = 2
        OnClick = ColorPanelClick
      end
      object ColorPanel3: TPanel
        Left = 8
        Top = 64
        Width = 153
        Height = 15
        Caption = 'Color 3'
        TabOrder = 3
        OnClick = ColorPanelClick
      end
      object ColorPanel4: TPanel
        Left = 8
        Top = 80
        Width = 153
        Height = 15
        Caption = 'Color 4'
        TabOrder = 4
        OnClick = ColorPanelClick
      end
      object ColorPanel5: TPanel
        Left = 8
        Top = 96
        Width = 153
        Height = 15
        Caption = 'Color 5'
        TabOrder = 5
        OnClick = ColorPanelClick
      end
      object ColorPanel6: TPanel
        Left = 8
        Top = 112
        Width = 153
        Height = 15
        Caption = 'Color 6'
        TabOrder = 6
        OnClick = ColorPanelClick
      end
      object ColorPanel7: TPanel
        Left = 8
        Top = 128
        Width = 153
        Height = 15
        Caption = 'Color 7'
        TabOrder = 7
        OnClick = ColorPanelClick
      end
      object ColorPanel8: TPanel
        Left = 8
        Top = 144
        Width = 153
        Height = 15
        Caption = 'Color 8'
        TabOrder = 8
        OnClick = ColorPanelClick
      end
      object ColorPanel9: TPanel
        Left = 8
        Top = 160
        Width = 153
        Height = 15
        Caption = 'Color 9'
        TabOrder = 9
        OnClick = ColorPanelClick
      end
      object ColorPanel10: TPanel
        Left = 8
        Top = 176
        Width = 153
        Height = 15
        Caption = 'Color 10'
        TabOrder = 10
        OnClick = ColorPanelClick
      end
      object ColorPanel11: TPanel
        Left = 8
        Top = 192
        Width = 153
        Height = 15
        Caption = 'Color 11'
        TabOrder = 11
        OnClick = ColorPanelClick
      end
      object ColorPanel12: TPanel
        Left = 8
        Top = 208
        Width = 153
        Height = 15
        Caption = 'Color 12'
        TabOrder = 12
        OnClick = ColorPanelClick
      end
      object ColorPanel13: TPanel
        Left = 8
        Top = 224
        Width = 153
        Height = 15
        Caption = 'Color 13'
        TabOrder = 13
        OnClick = ColorPanelClick
      end
      object ColorPanel14: TPanel
        Left = 8
        Top = 240
        Width = 153
        Height = 15
        Caption = 'Color 14'
        TabOrder = 14
        OnClick = ColorPanelClick
      end
      object ColorPanel15: TPanel
        Left = 8
        Top = 256
        Width = 153
        Height = 15
        Caption = 'Color 15'
        TabOrder = 15
        OnClick = ColorPanelClick
      end
      object ColorPanel16: TPanel
        Left = 8
        Top = 272
        Width = 153
        Height = 15
        Caption = 'Color 16'
        TabOrder = 16
        OnClick = ColorPanelClick
      end
      object ColorPanel17: TPanel
        Left = 8
        Top = 288
        Width = 153
        Height = 15
        Caption = 'Color 17'
        TabOrder = 17
        OnClick = ColorPanelClick
      end
    end
    object ImageGroupBox: TGroupBox
      Left = 1
      Top = 1
      Width = 171
      Height = 96
      Align = alTop
      Caption = ' Image '
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clNavy
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ParentFont = False
      TabOrder = 1
      object Label1: TLabel
        Left = 8
        Top = 16
        Width = 81
        Height = 13
        Caption = 'Magnification:'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clNavy
        Font.Height = -11
        Font.Name = 'MS Sans Serif'
        Font.Style = [fsBold]
        ParentFont = False
      end
      object Label2: TLabel
        Left = 8
        Top = 44
        Width = 27
        Height = 13
        Caption = 'Area'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clNavy
        Font.Height = -11
        Font.Name = 'MS Sans Serif'
        Font.Style = [fsBold]
        ParentFont = False
      end
      object Label3: TLabel
        Left = 8
        Top = 72
        Width = 53
        Height = 13
        Caption = 'Hor. shift'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clNavy
        Font.Height = -11
        Font.Name = 'MS Sans Serif'
        Font.Style = [fsBold]
        ParentFont = False
      end
      object ShiftEdit: TMaskEdit
        Left = 96
        Top = 68
        Width = 57
        Height = 21
        TabOrder = 0
        Text = '-0.65'
      end
      object AreaEdit: TMaskEdit
        Left = 96
        Top = 40
        Width = 57
        Height = 21
        TabOrder = 1
        Text = '1.76'
      end
      object MagEdit: TMaskEdit
        Left = 96
        Top = 12
        Width = 41
        Height = 21
        TabOrder = 2
        Text = '1'
      end
    end
    object ColorUsageRadioGroup: TRadioGroup
      Left = 1
      Top = 97
      Width = 171
      Height = 71
      Align = alClient
      Caption = ' Color usage '
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clNavy
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ItemIndex = 2
      Items.Strings = (
        'Discrete fixed colors'
        'Continuous scheme 1'
        'Continuous scheme 2')
      ParentFont = False
      TabOrder = 2
    end
  end
  object ColorDialog1: TColorDialog
    Ctl3D = True
    Left = 776
    Top = 184
  end
end
