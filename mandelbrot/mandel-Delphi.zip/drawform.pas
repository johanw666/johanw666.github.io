unit drawform;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  Buttons, StdCtrls, ExtCtrls, Mask, Gauges;

type
  TMandelForm = class(TForm)
    Panel1: TPanel;
    Panel2: TPanel;
    Panel3: TPanel;
    DrawButton: TButton;
    BitBtn1: TBitBtn;
    StopButton: TBitBtn;
    FractalImage: TImage;
    Panel4: TPanel;
    ColorGroupBox: TGroupBox;
    ImageGroupBox: TGroupBox;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    ShiftEdit: TMaskEdit;
    AreaEdit: TMaskEdit;
    MagEdit: TMaskEdit;
    ColorPanel0: TPanel;
    ColorDialog1: TColorDialog;
    ColorPanel1: TPanel;
    ColorPanel2: TPanel;
    ColorPanel3: TPanel;
    ColorPanel4: TPanel;
    ColorPanel5: TPanel;
    ColorPanel6: TPanel;
    ColorPanel7: TPanel;
    ColorPanel8: TPanel;
    ColorPanel9: TPanel;
    ColorPanel10: TPanel;
    ColorPanel11: TPanel;
    ColorPanel12: TPanel;
    ColorPanel13: TPanel;
    ColorPanel14: TPanel;
    ColorPanel15: TPanel;
    ColorPanel16: TPanel;
    ColorPanel17: TPanel;
    Gauge1: TGauge;
    Label4: TLabel;
    ColorUsageRadioGroup: TRadioGroup;
    procedure DrawButtonClick(Sender: TObject);
    procedure StopButtonClick(Sender: TObject);
    procedure BitBtn1Click(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure ColorPanelClick(Sender: TObject);
  private
    cont: boolean;
    procedure DrawMandelbrot;
    procedure ClearImage;
    function ComposeColor(x, y, xmax, ymax, iter: integer): TColor;
  public

  end;

const
  nrOfColors = 18;
  maxIterations = 100;

var
  MandelForm: TMandelForm;
  Colors: array[0..nrOfColors-1] of TColor;
  ColorPanels: array[0..nrOfColors-1] of TPanel;

implementation

{$R *.DFM}

procedure TMandelForm.FormShow(Sender: TObject);
var
  i: integer;
begin
  ColorPanels[0] := ColorPanel0;
  ColorPanels[1] := ColorPanel1;
  ColorPanels[2] := ColorPanel2;
  ColorPanels[3] := ColorPanel3;
  ColorPanels[4] := ColorPanel4;
  ColorPanels[5] := ColorPanel5;
  ColorPanels[6] := ColorPanel6;
  ColorPanels[7] := ColorPanel7;
  ColorPanels[8] := ColorPanel8;
  ColorPanels[9] := ColorPanel9;
  ColorPanels[10] := ColorPanel10;
  ColorPanels[11] := ColorPanel11;
  ColorPanels[12] := ColorPanel12;
  ColorPanels[13] := ColorPanel13;
  ColorPanels[14] := ColorPanel14;
  ColorPanels[15] := ColorPanel15;
  ColorPanels[16] := ColorPanel16;
  ColorPanels[17] := ColorPanel17;

  for i := 0 to nrOfColors-1 do begin
    ColorPanels[i].Color := Colors[i];
  end;
end;

procedure TMandelForm.DrawButtonClick(Sender: TObject);
begin
  cont := true;
  Gauge1.Progress := 0;
  ClearImage;
  DrawMandelbrot;
end;

procedure TMandelForm.StopButtonClick(Sender: TObject);
begin
  cont := false;
end;

procedure TMandelForm.BitBtn1Click(Sender: TObject);
begin
  cont := false;
  Close;
end;

procedure TMandelForm.ClearImage;
begin
  FractalImage.Canvas.Brush.Color := clWhite;
  FractalImage.Canvas.Brush.Style := bsSolid;
  FractalImage.Canvas.FillRect(Rect(0, 0, FractalImage.Width, FractalImage.Height));
end;

procedure TMandelForm.DrawMandelbrot;
var
  magnification: integer;
  cl: TColor;
  xm, ym, i, j, n1, n2, k: integer;
  xcurr: integer; // Current position
  delv, delh, ac, a, b, x, y, z, s: double;
  temp_dec_sep: char;
begin
  temp_dec_sep := DecimalSeparator;
  DecimalSeparator := '.';

  magnification := StrToInt(MagEdit.Text);
  if ( magnification = 0 ) then begin
    magnification := 1;
    MagEdit.Text := '1';
  end;
  xm := FractalImage.Width div 2;
  ym := FractalImage.Height div 2;
  try
    // delh bepaalt het afgebeelde gebied
    delh := StrToFloat(AreaEdit.Text);
  except
    delh := 1.76;
    AreaEdit.Text := Format('%f', [delh]);
  end;
  delv := delh * ym / xm;
  try
    // ac bepaalt de horizontale verschuiving
    ac := StrToFloat(ShiftEdit.Text);
  except
    ac := -0.65;
    ShiftEdit.Text := Format('%f', [ac]);
  end;
  n1 := xm div magnification; // Bepaalt de grootte van de afbeelding
  n2 := round(n1 * delv / delh);
  for i := -n1 to n1 do begin
    a := ac + i * delh / n1;
    for j := 0 to n2 do begin // Neem de x-as als symmetrieas
      b := j * delv / n2;
      x := a;
      y := b;
      k := 0;
      repeat
        z := x;
        x := sqr(x) - sqr(y) + a;
        y := 2 * z * y + b;
        s := sqr(x) + sqr(y);
        k := k + 1;
      until (s > 500) or (k = maxIterations);
      xcurr := n1 + i;
      Gauge1.Progress := round(50 * xcurr / n1);
      if ( ColorUsageRadioGroup.ItemIndex = 0 ) then begin
        FractalImage.Canvas.Pixels[xcurr, n2 - j] := Colors[k mod nrOfColors];
        FractalImage.Canvas.Pixels[xcurr, n2 + j] := Colors[k mod nrOfColors];
      end else begin
        cl := ComposeColor(xcurr, j, 2 * n1, n2, k);
        FractalImage.Canvas.Pixels[xcurr, n2 - j] := cl;
        FractalImage.Canvas.Pixels[xcurr, n2 + j] := cl;
      end;
    end;
    Application.ProcessMessages;
    if not cont then break;
  end;
  DecimalSeparator := temp_dec_sep;
end;


function TMandelForm.ComposeColor(x, y, xmax, ymax, iter: integer): TColor;
var
  i1, x1, y1: integer;
begin
  if ( ColorUsageRadioGroup.ItemIndex = 1 ) then begin
    i1 := iter mod 255;
    x1 := (xmax - x) mod 255;
    y1 := (ymax - y) mod 255;
    Result := i1 + // Red
              256 * (x1 - i1) + // Green
              256 * 256 * (y1 - i1); // Blue
  end else begin
//    i1 := Trunc(iter / maxIterations) * 255;
//    i1 := (maxIterations - iter) * 255;
    i1 := Trunc(iter / maxIterations) * 255 ;
    x1 := (xmax - x) mod 255;
    y1 := (ymax - y) mod 255;
    Result := i1 + // Red
              256 * (x1 - i1) + // Green
              256 * 256 * (y1 - i1); // Blue
  end;
end;

procedure TMandelForm.ColorPanelClick(Sender: TObject);
var
  i: integer;
begin
  if ( ColorDialog1.Execute ) then begin
    TPanel(Sender).Color := ColorDialog1.Color;
  end;
  i := StrToInt(PChar(TPanel(Sender).Name) + 10);
  Colors[i] := ColorDialog1.Color;
end;


initialization
  Colors[0] := clOlive;
  Colors[1] := clMaroon;
  Colors[2] := clGreen;
  Colors[3] := clLime;
  Colors[4] := clNavy;
  Colors[5] := clPurple;
  Colors[6] := clTeal;
  Colors[7] := clRed;
  Colors[8] := clBlue;
  Colors[9] := clFuchsia;
  Colors[10] := clBlack;
  Colors[11] := clYellow;
  Colors[12] := clWhite;
  Colors[13] := clSilver;
  Colors[14] := clDkGray;
  Colors[15] := clGray;
  Colors[16] := clLime;
  Colors[17] := clAqua;

end.

