//------------------------------------------------------------------------------
#ifndef logfileH
#define logfileH
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>

#include "scc.h"
//------------------------------------------------------------------------------
class TViewLogFileForm: public TForm
{
__published:
  TMemo* LogFileMemo;
  TPanel* Panel1;
  TPanel* Panel2;
  TButton* CloseButton;
  TButton* RefreshButton;
  TTimer* RefreshTimer;
  TTimer* SetCursorTimer;
  void __fastcall CloseButtonClick(TObject* Sender);
  void __fastcall RefreshText(TObject* Sender);
  void __fastcall CloseButtonKeyDown(TObject* Sender, WORD& Key, TShiftState Shift);
  void __fastcall SetCursorTimerTimer(TObject* Sender);
  void __fastcall FormClose(TObject* Sender, TCloseAction& Action);
private:
  bool fDeCrypt;
  __fastcall TViewLogFileForm(TComponent* Owner);
  void __fastcall SetCursorPos(void);
  AnsiString LogFileName;
public:
  TMainForm* mainForm; // Needed for SendMessage of the close notification.
                       // We can't simply cast Owner to a TMainForm* since
                       // mainForm can be NULL and setting Owner to NULL causes
                       // problems.
  TMenuItem* windowMenuItem;
  __fastcall TViewLogFileForm(TComponent* Owner,
                              AnsiString aLogFileName,
                              int aLogRefreshTime,
                              bool autoRefresh,
                              bool deCrypt);
};
//------------------------------------------------------------------------------
#endif
