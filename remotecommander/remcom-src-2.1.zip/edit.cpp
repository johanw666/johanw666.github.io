//------------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "edit.h"
#include "scc.h"
#include "common.h"

//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
//------------------------------------------------------------------------------
// Default constructor, not to be used.
//------------------------------------------------------------------------------
__fastcall TEditForm::TEditForm(TComponent* Owner): TForm(Owner)
{
}

//------------------------------------------------------------------------------
// Constructor, gets passed a filename.
//------------------------------------------------------------------------------
__fastcall TEditForm::TEditForm(TComponent* Owner, AnsiString aFileName): TForm(Owner)
{
  AnsiString log;

  // Position the form
  if ( Owner ) {
    Top = ((TForm*)Owner)->Top + (((TForm*)Owner)->Height - Height);
    if ( Top < 0 ) Top = 0;
    Left = ((TForm*)Owner)->Left + 0.5 * (((TForm*)Owner)->Width - Width);
  } else Position = poScreenCenter;
  fFileName = aFileName;
  FilenameLabel->Caption = "Service command file: " + fFileName;
  ServiceCommandLabel->Caption = "Command to execute by service: (maximal " + IntToStr(MAX_COMMAND_LENGTH - 1) + " characters)";
  // Read the inifile
  TIniFile* ServiceIniFile = new TIniFile(fFileName);
  if ( ServiceIniFile ) {
    CommandEdit->Text = AnsiString(DecryptWithRC5(
                          ServiceIniFile->ReadString(ServiceSection, ServiceCommand, "").c_str(),
                          EncryptionPassword, MAX_COMMAND_LENGTH));
    log = ServiceIniFile->ReadString(ServiceSection, ServiceLog, "0");
    if ( log == "1" )
      ServiceLogCheckBox->Checked = true;
    else
      ServiceLogCheckBox->Checked = false;
  } else {
    ShowErrorMessage("Unable to open service inifile", NULL);
  }
}

//------------------------------------------------------------------------------
void __fastcall TEditForm::FormShow(TObject* Sender)
{
  CommandEdit->SetFocus();
}

//------------------------------------------------------------------------------
void __fastcall TEditForm::CancelButtonClick(TObject* Sender)
{
  ModalResult = mrCancel;
}

//------------------------------------------------------------------------------
// Save changes
//------------------------------------------------------------------------------
void __fastcall TEditForm::SaveButtonClick(TObject* Sender)
{
  char* buffer = EncryptWithRC5(CommandEdit->Text.c_str(), EncryptionPassword, MAX_COMMAND_LENGTH);
  if ( !WritePrivateProfileString(ServiceSection, ServiceCommand, buffer, fFileName.c_str()) )
    ShowErrorMessage("Unable to write to service inifile", NULL);
  // Log
  if ( !WritePrivateProfileString(ServiceSection, ServiceLog, ServiceLogCheckBox->Checked ? "1" : "0", fFileName.c_str()) )
    ShowErrorMessage("Unable to write to service inifile", NULL);

  ModalResult = mrOk;
}

//------------------------------------------------------------------------------
// A key is pressed in the edit. Save if it is enter, else close.
//------------------------------------------------------------------------------
void __fastcall TEditForm::CommandEditKeyDown(TObject* Sender, WORD& Key, TShiftState Shift)
{
  if ( Key == VK_ESCAPE ) CancelButtonClick(Sender);
  else if ( Key == VK_RETURN ) SaveButtonClick(Sender);
}

//------------------------------------------------------------------------------

