//------------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("remcom.res");
USEFORM("scc.cpp", MainForm);
USEFORM("defsetup.cpp", DefaultsForm);
USEFORM("addpc.cpp", AddComputerForm);
USEFORM("config.cpp", ConfigForm);
USEFORM("about.cpp", AboutForm);
USEFORM("help.cpp", HelpForm);
USEFORM("edit.cpp", EditForm);
USEFORM("account.cpp", AccountForm);
USEFORM("logfile.cpp", ViewLogFileForm);
USEFORM("password.cpp", PasswordForm);
USEFORM("settings.cpp", SettingsForm);
USEFORM("dirsel.cpp", DirSelForm);
USEUNIT("sccclass.cpp");
USEUNIT("common.cpp");
USEUNIT("base64.cpp");
USEUNIT("DCPcrypt.pas");
USEUNIT("RC5.pas");
USEUNIT("SHA1.pas");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
  try
  {
    Application->Title = "Remote Commander";
    Application->Initialize();
    Application->CreateForm(__classid(TMainForm), &MainForm);
    Application->CreateForm(__classid(TAboutForm), &AboutForm);
    Application->Run();
  }
  catch (Exception &exception)
  {
    Application->ShowException(&exception);
  }
  return 0;
}
//------------------------------------------------------------------------------

