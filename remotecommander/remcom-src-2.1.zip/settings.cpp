//------------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "settings.h"
#include "scc.h" // for tracefile
//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

//------------------------------------------------------------------------------
// Standatrd constructor, not to be used. Private.
//------------------------------------------------------------------------------
__fastcall TSettingsForm::TSettingsForm(TComponent* Owner): TForm(Owner)
{
}

//------------------------------------------------------------------------------
// Constructor
//------------------------------------------------------------------------------
__fastcall TSettingsForm::TSettingsForm(TComponent* Owner, ProgramCfg* pcfg): TForm(Owner)
{
  // Store pointer to program settings
  newPcfg = pcfg;
  // Set controls
  FindComputers1->Checked       = pcfg->readNetworkNamesAfterStart;
  UpdateStatusOnStart1->Checked = pcfg->updateStatusAfterStart;
  Minimizetosystray1->Checked   = pcfg->minimizeToSystray;
  ScanOnlyForNT->Checked        = pcfg->addOnlyNTMachines;
  DebugCheckBox->Checked        = pcfg->writeDebugMessages;
  LocalCheckBox->Checked        = pcfg->allowNonDomain;
  ScanOutsideDomainCheckBox->Checked = pcfg->scanOutsideDomain;
  DefaultPasswordCheckBox->Checked = !pcfg->useSecureCipher;
  Selectline1->Checked          = pcfg->selectWholeLine;
  AutoRefreshLogs1->Checked = pcfg->autoRefreshLogs;
  WaitTimeEdit->Text = IntToStr(pcfg->MaxWaitTime);
  LogRefreshEdit->Text = IntToStr(pcfg->LogRefreshTime);
  // Position the form
  if ( Owner ) {
    Top = ((TForm*)Owner)->Top + (((TForm*)Owner)->Height - Height);
    if ( Top < 0 ) Top = 0;
    Left = ((TForm*)Owner)->Left + 0.5 * (((TForm*)Owner)->Width - Width);
  } else Position = poScreenCenter;
  // Name logfile:
  DebugCheckBox->Caption = "Write debug messages in " + ExtractFileName(AnsiString(tracefile));
}

//------------------------------------------------------------------------------
// Change the maximun time the program waits for a service to reach a certain
// status. If the desired status is not reached after this time a timeout error
// is given.
//------------------------------------------------------------------------------
void __fastcall TSettingsForm::WaitTimeEditExit(TObject* Sender)
{
  try {
    StrToInt(WaitTimeEdit->Text);
  } catch ( ... ) {
    Application->MessageBox("You can only enter numbers here", Application->Title.c_str(), MB_OK);
    WaitTimeEdit->Text = "5";
    WaitTimeEdit->SetFocus();
  }
}

//------------------------------------------------------------------------------
// Change the refresh rate for the logfiles.
//------------------------------------------------------------------------------
void __fastcall TSettingsForm::LogRefreshEditExit(TObject* Sender)
{
  try {
    StrToInt(LogRefreshEdit->Text);
  } catch ( ... ) {
    Application->MessageBox("You can only enter numbers here", Application->Title.c_str(), MB_OK);
    LogRefreshEdit->Text = "60";
    LogRefreshEdit->SetFocus();
  }
}

//------------------------------------------------------------------------------
// Close form without saving
//------------------------------------------------------------------------------
void __fastcall TSettingsForm::CancelButtonClick(TObject* Sender)
{
  Close();
}

//------------------------------------------------------------------------------
// Close form and store the data
//------------------------------------------------------------------------------
void __fastcall TSettingsForm::OKButtonClick(TObject* Sender)
{
  newPcfg->readNetworkNamesAfterStart = FindComputers1->Checked;
  newPcfg->updateStatusAfterStart     = UpdateStatusOnStart1->Checked;
  newPcfg->minimizeToSystray          = Minimizetosystray1->Checked;
  newPcfg->addOnlyNTMachines          = ScanOnlyForNT->Checked;
  newPcfg->writeDebugMessages         = DebugCheckBox->Checked;
  newPcfg->allowNonDomain             = LocalCheckBox->Checked;
  newPcfg->scanOutsideDomain          = ScanOutsideDomainCheckBox->Checked; 
  newPcfg->selectWholeLine            = Selectline1->Checked;
  newPcfg->useSecureCipher            = !DefaultPasswordCheckBox->Checked;
  newPcfg->autoRefreshLogs            = AutoRefreshLogs1->Checked;
  newPcfg->MaxWaitTime                = StrToInt(WaitTimeEdit->Text);
  newPcfg->LogRefreshTime             = StrToInt(LogRefreshEdit->Text);
  Close();
}

//------------------------------------------------------------------------------

