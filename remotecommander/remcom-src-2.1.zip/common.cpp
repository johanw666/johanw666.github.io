//------------------------------------------------------------------------------
// Common defines for remote commander and remote service.
// This file implements the Remote commander version of the routines.
//------------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "common.h"
#include "Base64.h"
// Delphi crypto modules
#include "DCPcrypt.hpp"
#include "RC5.hpp"
#include "SHA1.hpp"

//------------------------------------------------------------------------------
// Common defines for remote commander and remote service
//------------------------------------------------------------------------------
// Names of the sections in the service inifile
const char* ServiceSection = "G";
const char* ServiceCommand = "C";
const char* ServiceLog     = "L";
// Password used by the service to encrypt the service commandfile and logfile
char* EncryptionPassword = "remotecontrol";
// Service name
char* ServiceName = "remsrv";

//------------------------------------------------------------------------------
// Encrypt a string with RC5 and password. Returns a base64 encoded encrypted string.
//------------------------------------------------------------------------------
char* EncryptWithRC5(char input[], char password[], int size)
{
  TDCP_rc5* Cipher;
  char CryptBuffer[2*MAX_COMMAND_LENGTH];
  static char Base64Buffer[2*MAX_COMMAND_LENGTH];
  char PasswordHash[20];

  if ( size > 2*MAX_COMMAND_LENGTH )
    throw Exception("EncryptWithRC5: buffersize too large.");

  if ( strlen(input) ) {
    try {
      // Initialise the output buffer
      memset(Base64Buffer, 0, sizeof(Base64Buffer));
      // Create an instance of the RC5 class
      Cipher = new TDCP_rc5(NULL);
      // Initialise the RC5 cipher with the password
      GetHashFromPassword(EncryptionPassword, PasswordHash, sizeof(PasswordHash));
      Cipher->Init(PasswordHash, sizeof(PasswordHash) * 8, NULL);  // remember key size is in BITS
      // Encrypt input string
      memset(CryptBuffer, 0, sizeof(CryptBuffer));
      Cipher->EncryptCBC(input, CryptBuffer, size);
      CryptBuffer[MAX_COMMAND_LENGTH] = 0; // Zero-terminate string
      Base64Encode(CryptBuffer, Base64Buffer, MAX_COMMAND_LENGTH, sizeof(Base64Buffer));
      Cipher->Burn();
      delete Cipher;
    } catch (Exception& exception) {
      Application->ShowException(&exception);
      memset(Base64Buffer, 0, sizeof(Base64Buffer)); // Make result sane
      delete Cipher;
    }
  } else {
    memset(Base64Buffer, 0, sizeof(Base64Buffer));
  }
  return Base64Buffer;
}

//------------------------------------------------------------------------------
// Decrypt a base64 encoded string with RC5 and password. buffer should be at
// least MAX_COMMAND_LENGTH chars large.
//------------------------------------------------------------------------------
char* DecryptWithRC5(char input[], char password[], int size)
{
  TDCP_rc5* Cipher;
  char CryptBuffer[2*MAX_COMMAND_LENGTH];
  static char DecrypBuffer[2*MAX_COMMAND_LENGTH];
  char PasswordHash[20];

  if ( size > 2*MAX_COMMAND_LENGTH )
    throw Exception("DecryptWithRC5: buffersize too large.");

  if ( strlen(input) ) {
    try {
      // Initialise the buffer
      memset(DecrypBuffer, 0, sizeof(DecrypBuffer));
      // Create an instance of the RC5 class
      Cipher = new TDCP_rc5(NULL);
      // Initialise the RC5 cipher with the password
      GetHashFromPassword(EncryptionPassword, PasswordHash, sizeof(PasswordHash));
      Cipher->Init(PasswordHash, sizeof(PasswordHash) * 8, NULL);  // remember key size is in BITS
      // Command
      memset(CryptBuffer, 0, sizeof(CryptBuffer));
      Base64Decode(input, CryptBuffer, strlen(input), sizeof(CryptBuffer));
      Cipher->DecryptCBC(CryptBuffer, DecrypBuffer, size);
      Cipher->Burn();
      delete Cipher;
    } catch (Exception& exception) {
      Application->ShowException(&exception);
      memset(DecrypBuffer, 0, sizeof(DecrypBuffer)); // Make result sane
      delete Cipher;
    }
  } else { // No input
    memset(DecrypBuffer, 0, sizeof(DecrypBuffer));
  }
  return DecrypBuffer;
}

//------------------------------------------------------------------------------
// Get a SHA1 hash from the password to use as password ofor the RC5 cipher.
// This is more secure. buffsize contains the size of aPasswordHash.
//------------------------------------------------------------------------------
void __fastcall GetHashFromPassword(char aPassword[], char aPasswordHash[], size_t buffsize)
{
  memset(aPasswordHash, 0, buffsize);
  TDCP_sha1* Hash = new TDCP_sha1(NULL);
  if ( Hash ) {
    Hash->Init();
    Hash->Update(aPassword, strlen(aPassword));
    Hash->Final(aPasswordHash);
    delete Hash;
  }
}

//------------------------------------------------------------------------------

