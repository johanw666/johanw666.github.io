//------------------------------------------------------------------------------
#include <vcl.h>
#include <stdio.h>
#pragma hdrstop

#include "defsetup.h"
#include "edit.h"
#include "dirsel.h"
#include "common.h"
//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

//------------------------------------------------------------------------------
// Default constructor, not to be used.
//------------------------------------------------------------------------------
__fastcall TDefaultsForm::TDefaultsForm(TComponent* Owner): TForm(Owner)
{
}

//------------------------------------------------------------------------------
// Constructor. Sets the controls depending on the passed configuration data.
//------------------------------------------------------------------------------
__fastcall TDefaultsForm::TDefaultsForm(TComponent* Owner, ServiceParams* aCfg): TForm(Owner)
{
  CfgData = aCfg;
  // Set defaults
  ExeNameEdit->Text = CfgData->ExeFrom;
  IniNameEdit->Text = CfgData->IniFrom;
  ExtraNameEdit->Text = CfgData->ExtraFrom;
  RemotePathEdit->Text = CfgData->DirectoryTo;
  RemoteNameEdit->Text = CfgData->RemoteName;
  DisplayNameEdit->Text = CfgData->DisplayName;
  ServiceNameEdit->Text = CfgData->ServiceName;
  // Set caption
  Caption = "Remote Service Default setup";
  // Startup
  StartAfterInstallCheckBox->Checked = CfgData->StartOnInstall;
  if ( CfgData->StartOnBoot ) AutoRadioButton->Checked = true;
  else ManualRadioButton->Checked = true;
  // Interaction with desktop
  InteractCheckBox->Checked = CfgData->InteractWithDesktop;
  // Position the form
  if ( Owner ) {
    Top = ((TForm*)Owner)->Top + (((TForm*)Owner)->Height - Height);
    if ( Top < 0 ) Top = 0;
    Left = ((TForm*)Owner)->Left + 0.5 * (((TForm*)Owner)->Width - Width);
  } else Position = poScreenCenter;
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::OKButtonClick(TObject* Sender)
{
  CopySettings();
  Close();
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::CancelButtonClick(TObject* Sender)
{
  Close();
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::SetTitle(AnsiString aTitle)
{
  Caption = aTitle;
}

//------------------------------------------------------------------------------
// Save the form data in the configuration data.
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::CopySettings()
{
  strncpy(CfgData->ExeFrom, ExeNameEdit->Text.c_str(), sizeof(CfgData->ExeFrom) - 1);
  strncpy(CfgData->IniFrom, IniNameEdit->Text.c_str(), sizeof(CfgData->IniFrom) - 1);
  strncpy(CfgData->ExtraFrom, ExtraNameEdit->Text.c_str(), sizeof(CfgData->ExtraFrom) - 1);
  strncpy(CfgData->DirectoryTo, RemotePathEdit->Text.c_str(), sizeof(CfgData->DirectoryTo) - 1);
  strncpy(CfgData->RemoteName, RemoteNameEdit->Text.c_str(), sizeof(CfgData->RemoteName) - 1);
  strncpy(CfgData->DisplayName, DisplayNameEdit->Text.c_str(), sizeof(CfgData->DisplayName) - 1);
  strncpy(CfgData->ServiceName, ServiceNameEdit->Text.c_str(), sizeof(CfgData->ServiceName) - 1);
  // Startup data
  CfgData->StartOnInstall = StartAfterInstallCheckBox->Checked;
  CfgData->StartOnBoot = AutoRadioButton->Checked;
  CfgData->InteractWithDesktop = InteractCheckBox->Checked;
}

//------------------------------------------------------------------------------
// Browse for the default exe file
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::BrowseExeButtonClick(TObject* Sender)
{
  FileOpenDialog->Filter = "Executable files (*.exe)|*.exe";
  FileOpenDialog->FileName = "";
  FileOpenDialog->Options.Clear();
  FileOpenDialog->Options << ofFileMustExist << ofPathMustExist;
  if ( FileOpenDialog->Execute() ) {
    if ( FileExists(FileOpenDialog->FileName) ) ExeNameEdit->Text = FileOpenDialog->FileName;
  }
}

//------------------------------------------------------------------------------
// Browse for the default ini file
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::BrowseIniButtonClick(TObject* Sender)
{
  FileOpenDialog->Filter = "Inifiles (*.ini)|*.ini";
  FileOpenDialog->FileName = "";
  FileOpenDialog->Options.Clear();
  FileOpenDialog->Options << ofFileMustExist << ofPathMustExist;
  if ( FileOpenDialog->Execute() ) {
    if ( FileExists(FileOpenDialog->FileName) ) IniNameEdit->Text = FileOpenDialog->FileName;
  }
}

//------------------------------------------------------------------------------
// Edit a new inifile
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::EditIniButtonClick(TObject* Sender)
{
  // If there is no file filled here but the service executable is known,
  // Derive the name. Create the file if it does not exist.
  if ( !IniNameEdit->Text.Length() && FileExists(ExeNameEdit->Text) ) {
    AnsiString fName = ExeNameEdit->Text;
    char* c = strrchr(fName.c_str(), '.');
    if ( c ) *c = 0;
    strcat(fName.c_str(), ".ini");
    IniNameEdit->Text = fName;
  }
  // Now there is always an inifile defined. Create an empty one if the file
  // does not exist.
  if ( !FileExists(IniNameEdit->Text) ) {
    FILE* f = fopen(IniNameEdit->Text.c_str(), "wt");
    if ( f ) { // Create empty file
      fprintf(f, "[%s]\n", ServiceSection);
      fprintf(f, "%s=\n", ServiceCommand);
      fprintf(f, "%s=1\n", ServiceLog);
      fclose(f);
    }
  }
  // If there is a filename now, it eiter existed or is just created, so edit it:
  if ( IniNameEdit->Text.Length() ) {
    TEditForm* EditForm = new TEditForm(this, IniNameEdit->Text.c_str());
    if ( EditForm ) {
      EditForm->ShowModal();
      delete EditForm;
    }
  }
  // If no service executable is defined AND no file defined here, warn.
  else Application->MessageBox("Enter a filename or select a service executable first.", Application->Title.c_str(), MB_OK);
}

//------------------------------------------------------------------------------
// Browse for the default directory on the remote system
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::BrowsePathButtonClick(TObject *Sender)
{
  TModalResult mrRes;

  TDirSelForm* DirSelForm = new TDirSelForm(this, RemotePathEdit->Text);
  if ( DirSelForm ) {
    mrRes = DirSelForm->ShowModal();
    if ( mrRes == mrOk ) {
      RemotePathEdit->Text = DirSelForm->DirectoryListBox1->Directory;
      if ( RemotePathEdit->Text.c_str()[strlen(RemotePathEdit->Text.c_str()) - 1] != '\\' )
        RemotePathEdit->Text = RemotePathEdit->Text + "\\";
    }
    delete DirSelForm;
  }
}

//------------------------------------------------------------------------------
// Browse for the optional extra file
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::BrowseExtraButtonClick(TObject* Sender)
{
  FileOpenDialog->Filter = "";
  FileOpenDialog->FileName = "";
  FileOpenDialog->Options.Clear();
  FileOpenDialog->Options << ofFileMustExist << ofPathMustExist;
  if ( FileOpenDialog->Execute() ) {
    if ( FileExists(FileOpenDialog->FileName) ) ExtraNameEdit->Text = FileOpenDialog->FileName;
  }
}

//------------------------------------------------------------------------------
// Make sure the entered path is correct
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::RemotePathEditExit(TObject *Sender)
{
  // Assures the remote path ends with a '\'
  if ( RemotePathEdit->Text.c_str()[strlen(RemotePathEdit->Text.c_str()) - 1] != '\\' )
    RemotePathEdit->Text = RemotePathEdit->Text + "\\";

  if ( RemotePathEdit->Text.c_str()[1] != ':' ) {
    Application->MessageBox("Path should be of the form <driveletter>:\\directory", Application->Title.c_str(), MB_OK);
    RemotePathEdit->SetFocus();
  }
}

//------------------------------------------------------------------------------
// Allow editing of the service name
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::EditNameCheckBoxClick(TObject* Sender)
{
  if ( EditNameCheckBox->Checked ) {
    Application->MessageBox("Warning: changing the service name can result in a disfunctioning setup!", Application->Title.c_str(), MB_OK|MB_ICONWARNING);
    ServiceNameEdit->Enabled = true;
  } else
    ServiceNameEdit->Enabled = false;
}

//------------------------------------------------------------------------------
// Resize the form. We move the buttons and make the edit controls wider.
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::FormResize(TObject* Sender)
{
  BrowseExeButton->Left   = Panel3->Width - 4 - BrowseExeButton->Width; 
  BrowseIniButton->Left   = BrowseExeButton->Left;
  EditIniButton->Left     = BrowseExeButton->Left + 42;
  BrowsePathButton->Left  = BrowseExeButton->Left;
  BrowseExtraButton->Left = BrowseExeButton->Left;
  ExeNameEdit->Width      = BrowseExeButton->Left - ExeNameEdit->Left - 4;
  IniNameEdit->Width      = ExeNameEdit->Width;
  RemotePathEdit->Width   = ExeNameEdit->Width;
  ExtraNameEdit->Width    = ExeNameEdit->Width;
  AutoRadioButton->Top    = StartupRadioGroup->Top + 20;
  ManualRadioButton->Top  = AutoRadioButton->Top;
  StartAfterInstallCheckBox->Top = AutoRadioButton->Top;
}

//------------------------------------------------------------------------------

