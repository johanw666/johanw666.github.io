//------------------------------------------------------------------------------
#include <vcl.h>
#include <string.h>
#include <windows.h>
#pragma hdrstop

#include "account.h"
#include "scc.h"
//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
//------------------------------------------------------------------------------
__fastcall TAccountForm::TAccountForm(TComponent* Owner): TForm(Owner)
{
}


__fastcall TAccountForm::TAccountForm(TComponent* Owner,
                                      char* aUserName,
                                      char* aDomain,
                                      char* aPassword,
                                      size_t usrSize,
                                      size_t domSize,
                                      size_t pwdSize,
                                      bool* aSwitchUserID,
                                      bool* aChange): TForm(Owner)
{
  Panel4->Color = (TColor)0x00E1FFFF;
  fSwitchUserID = aSwitchUserID; // Switch on program start
  if ( *fSwitchUserID )
    SwitchRadioButton->Checked = true;

  fChange = aChange; // config has not yet changed
  *fChange = false;

  fUsername = aUserName;
  fDomain   = aDomain;
  fPassword = aPassword;

  UserSize     = usrSize;
  DomainSize   = domSize;
  PasswordSize = pwdSize;

  AccountEdit->Text = fUsername;
  DomainEdit->Text = fDomain;
  PasswordEdit->Text = fPassword;

  if ( ((TMainForm*)Owner)->Requires_SeTcbPrivilege() ) {
    bool hasSeTcbNameRight = HandlePrivs();
    if ( hasSeTcbNameRight ) { // Hide the warning panel
      Height = Height - Panel4->Height;
      Panel4->Align = alNone;
      Panel4->Height = 0;
    }
  } else { // XP/2003, no SeTcbPrivilege required
    Height = Height - Panel4->Height;
    Panel4->Align = alNone;
    Panel4->Height = 0;
  }
  // Position the form. We need to do this last since only here we know if we
  // show the warning panel or not.
  if ( Owner ) {
    Top = ((TForm*)Owner)->Top + (((TForm*)Owner)->Height - Height);
    Left = ((TForm*)Owner)->Left + 0.5 * (((TForm*)Owner)->Width - Width);
  } else Position = poScreenCenter;
}

//------------------------------------------------------------------------------
// Handle any missing privileges
//------------------------------------------------------------------------------
bool __fastcall TAccountForm::HandlePrivs()
{
  // See if the current user has SE_TCB_NAME (act as part of the OS)
  bool hasSeTcbNameRight = CheckAccountPrivilege("SeTcbPrivilege");
  // We first check if we can add this privilege. To add it we require
  // admin rights. We assume only admins have SeTakeOwnershipPrivilege.
  bool hasAdminRights = CheckAccountPrivilege("SeTakeOwnershipPrivilege");

  if ( !hasSeTcbNameRight ) {
    if ( !hasAdminRights ) {
      MessageBox(NULL, "Your current account has insufficient rights to change the user context this program runs under!\nTo change this you should allow the current user to run as part of the operating system.\nTo add this privilege you require administrative rights, which you currently don't have.", Application->Title.c_str(), MB_OK|MB_ICONWARNING);
    } else if ( MessageBox(NULL, "Your current account has insufficient rights to change the account this program runs under!\nTo change this you should allow the current user to run as part of the operating system.\nShall I try to add this privilege to your account now?", Application->Title.c_str(), MB_YESNO|MB_ICONWARNING) == IDYES ) {
      hasSeTcbNameRight = AddAccountSeTcbPrivilege();
    }
  }
  return hasSeTcbNameRight;
}

//------------------------------------------------------------------------------
// Checks if the curent account has the asked privilege
//------------------------------------------------------------------------------
bool __fastcall TAccountForm::CheckAccountPrivilege(char privilegeName[])
{
  bool result = false;
  HANDLE hToken;
  LUID setcbnameValue;
  TOKEN_PRIVILEGES tkp;
  char InfoBuffer[1000];
  PTOKEN_PRIVILEGES ptgPrivileges = (PTOKEN_PRIVILEGES)InfoBuffer;
  DWORD dwInfoBufferSize;
  char ucPrivilegeName[500];
  char ucDisplayName[500];
  DWORD dwPrivilegeNameSize;
  DWORD dwDisplayNameSize;
  DWORD dwLangId;
  UINT i;
  // Check if the current account has sufficient priviliges (SE_TCB_NAME)
  // to call LogonUser
  if ( !OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES|TOKEN_QUERY, &hToken) ) {
    ShowErrorMessage("OpenProcessToken", NULL);
  }
  GetTokenInformation(hToken, TokenPrivileges, InfoBuffer, sizeof InfoBuffer, &dwInfoBufferSize);
  // enumerate currently held privs (NOTE: not *enabled* privs, just the
  // ones you _could_ enable as in the last part)
  for (i = 0; i < ptgPrivileges->PrivilegeCount; i++)	{
    dwPrivilegeNameSize = sizeof(ucPrivilegeName);
    dwDisplayNameSize = sizeof(ucDisplayName);
    LookupPrivilegeName(NULL, &ptgPrivileges->Privileges[i].Luid, ucPrivilegeName, &dwPrivilegeNameSize);
    LookupPrivilegeDisplayName(NULL, ucPrivilegeName, ucDisplayName, &dwDisplayNameSize, &dwLangId);
    // Check if it is the asked privilege
    if ( !strncmp(ucPrivilegeName, privilegeName, strlen(ucPrivilegeName)) )
      result = true;
  }
  // enable SeTcbPrivilege if we have it. This wil fail silently
  // if we don't have this privilege.
  if ( !LookupPrivilegeValue(NULL, privilegeName, &setcbnameValue) )
    ShowErrorMessage("LookupPrivilegeValue", NULL);

  tkp.PrivilegeCount = 1;
  tkp.Privileges[0].Luid = setcbnameValue;
  tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

  if ( !AdjustTokenPrivileges(hToken, FALSE, &tkp, sizeof(tkp), NULL, NULL) )
    ShowErrorMessage("AdjustTokenPrivileges", NULL);

  return result;
}

//------------------------------------------------------------------------------
// Add the SeTcbPrivilege to the current account.
//------------------------------------------------------------------------------
bool __fastcall TAccountForm::AddAccountSeTcbPrivilege()
{
  bool result = false;
  // Get SID of current account. This method allocates the memory to hold
  // this SID so it should be freed later.
  if ( GetCurrentSID(&fSid) ) {
    if ( !AddTcbPrivilege(fSid) ) {
      MessageBox(NULL, "The program failed to add the required privilege to your account.", Application->Title.c_str(), MB_OK);
    } else {
      result = true;
      MessageBox(NULL, "The program added the required privilege to your account.\n\nYou need to logoff and login again or to reboot to make the changes take effect.", Application->Title.c_str(), MB_OK);
    }
  }
  // Free memory allocated for SID.
  if( fSid )
    HeapFree(GetProcessHeap(), 0, fSid);

  return result;
}

//------------------------------------------------------------------------------
// Gets the SID from the user currently calling the program.
// This method allocates the memory to hold this SID.
//------------------------------------------------------------------------------
bool __fastcall TAccountForm::GetCurrentSID(PSID* Sid)
{
  char accountName[64];
  char foundDomain[64];
  DWORD buffSize = sizeof(accountName);
  DWORD domSize = sizeof(foundDomain);
  SID_NAME_USE eUse;
  DWORD errCode;
  bool retVal = true;
  DWORD sidSize = 128; // Size at initial allocation attempt

  if ( !GetUserName(accountName, &buffSize) ) {
    ShowErrorMessage("GetUserName", NULL);
    return false;
  }
  // initial memory allocation
  *Sid = HeapAlloc(GetProcessHeap(), 0, sidSize);
  if ( !Sid ) {
    ShowErrorMessage("HeapAlloc", NULL);
    return false;
  }
  // Try to find the SID
  while ( !LookupAccountName(NULL, accountName, *Sid, &sidSize, foundDomain, &domSize, &eUse) ) {
    errCode = GetLastError();
    if ( errCode == ERROR_INSUFFICIENT_BUFFER ) {
      // reallocate memory if necessary
      if((*Sid = HeapReAlloc(GetProcessHeap(), 0, *Sid, sidSize)) == NULL)
        break; // Can't allocate more memory, stop trying to get a SID
    } else { // Other error, stop trying to get a SID
      ShowErrorMessage("LookupAccountName", &errCode);
      retVal = false;
      break;
    }
  }
  return retVal;
}

//------------------------------------------------------------------------------
// Add the SeTcbPrivilege to the user account. For this method to succeed the
// caller requires administrative rights.
//------------------------------------------------------------------------------
bool __fastcall TAccountForm::AddTcbPrivilege(void* psid)
{
  NTSTATUS result = -1;
  LSA_HANDLE hPolicy = 0;
  LSA_UNICODE_STRING usPriv;
  wchar_t str[32];

  memset(str, 0, sizeof(str));
  wcscpy(str, L"SeTcbPrivilege");
  USHORT strLen = (USHORT)wcslen(str);

  usPriv.Buffer = str;
  usPriv.Length = (USHORT)(strLen * sizeof(wchar_t));
  usPriv.MaximumLength = (USHORT)((strLen + 1) * sizeof(wchar_t));

  LSA_OBJECT_ATTRIBUTES oa;
  memset(&oa, 0, sizeof(oa));

  DynamicLsaOpenPolicy(NULL, &oa, POLICY_LOOKUP_NAMES | POLICY_CREATE_ACCOUNT, &hPolicy);
  if ( hPolicy ) {
    result = DynamicLsaAddAccountRights(hPolicy, psid, &usPriv, 1);
    DynamicLsaClose(hPolicy);
  }
  return (result == STATUS_SUCCESS);
}

//------------------------------------------------------------------------------
// OK button pressed, try to change user ID if selected.
//------------------------------------------------------------------------------
void __fastcall TAccountForm::OKButtonClick(TObject* Sender)
{
  if ( SwitchRadioButton->Checked && AccountEdit->Text.Length() )
    *fChange = true;
  else
    *fChange = false;
    
  *fSwitchUserID = SwitchRadioButton->Checked;
  // Store account data
  strncpy(fUsername, AccountEdit->Text.c_str(), UserSize - 1);
  strncpy(fDomain, DomainEdit->Text.c_str(), DomainSize - 1);
  strncpy(fPassword, PasswordEdit->Text.c_str(), PasswordSize - 1);
  Close();
}

//------------------------------------------------------------------------------
// Close the form without saving the information.
//------------------------------------------------------------------------------
void __fastcall TAccountForm::CancelButtonClick(TObject* Sender)
{
  Close();
}

//------------------------------------------------------------------------------
// If something changes, we assume the user wants to start under that account
// so we change the radiobutton.
//------------------------------------------------------------------------------
void __fastcall TAccountForm::EditChange(TObject* Sender)
{
  if ( Visible ) { // We don't already switch at formshow.
    SwitchRadioButton->Checked = true;
    *fChange = true;
  }
  if ( Visible && AccountEdit->Text.Length() == 0 ) {
    SwitchRadioButton->Checked = false;
    NoSwitchRadioButton->Checked = true;
  }
}

//------------------------------------------------------------------------------
void __fastcall TAccountForm::AccountEditKeyPress(TObject* Sender, char& Key)
{
  if ( Key == VK_RETURN ) PasswordEdit->SetFocus();
}

//------------------------------------------------------------------------------
void __fastcall TAccountForm::PasswordEditKeyPress(TObject* Sender, char& Key)
{
  if ( Key == VK_RETURN ) DomainEdit->SetFocus();
}

//------------------------------------------------------------------------------
void __fastcall TAccountForm::DomainEditKeyPress(TObject* Sender, char& Key)
{
  if ( Key == VK_RETURN ) OKButtonClick(Sender);
}

//------------------------------------------------------------------------------
void __fastcall TAccountForm::FormShow(TObject* Sender)
{
  AccountEdit->SetFocus();
}
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Functions dynamically loaded from ADVAPI32.DLL
//------------------------------------------------------------------------------
ULONG DynamicLsaNtStatusToWinError(NTSTATUS Status)
{
  NTSTATUS result;
  HINSTANCE LsaSecLib = LoadLibrary("ADVAPI32.DLL");
  if (LsaSecLib) {
    pLsaNtStatusToWinError pFunction;
    (FARPROC)pFunction = GetProcAddress(LsaSecLib, "LsaNtStatusToWinError");
    if ( pFunction ) {
      result = pFunction(Status);
    } else
      ShowErrorMessage("Could not get a handle to LsaNtStatusToWinError", NULL);
    FreeLibrary("ADVAPI32.DLL");
  }
  return result;
}

//------------------------------------------------------------------------------
NTSTATUS DynamicLsaClose(IN LSA_HANDLE ObjectHandle)
{
  NTSTATUS result;
  ULONG errCode = 0;
  HINSTANCE LsaSecLib = LoadLibrary("ADVAPI32.DLL");
  if (LsaSecLib) {
    pLsaClose pFunction;
    (FARPROC)pFunction = GetProcAddress(LsaSecLib, "LsaClose");
    if ( pFunction ) {
      result = pFunction(ObjectHandle);
      if ( result != STATUS_SUCCESS ) {
        errCode = DynamicLsaNtStatusToWinError(result);
        ShowErrorMessage("LsaAddAccountRights", &errCode);
      }
    } else
      ShowErrorMessage("Could not get a handle to LsaClose", NULL);
    FreeLibrary("ADVAPI32.DLL");
  }
  return result;
}

//------------------------------------------------------------------------------
NTSTATUS DynamicLsaOpenPolicy(
    IN PLSA_UNICODE_STRING SystemName OPTIONAL,
    IN PLSA_OBJECT_ATTRIBUTES ObjectAttributes,
    IN ACCESS_MASK DesiredAccess,
    IN OUT PLSA_HANDLE PolicyHandle)
{
  NTSTATUS result;
  ULONG errCode = 0;
  HINSTANCE LsaSecLib = LoadLibrary("ADVAPI32.DLL");
  if (LsaSecLib) {
    pLsaOpenPolicy pFunction;
    (FARPROC)pFunction = GetProcAddress(LsaSecLib, "LsaOpenPolicy");
    if ( pFunction ) {
      result = pFunction(SystemName, ObjectAttributes, DesiredAccess, PolicyHandle);
      if ( result != STATUS_SUCCESS ) {
        errCode = DynamicLsaNtStatusToWinError(result);
        ShowErrorMessage("LsaAddAccountRights", &errCode);
      }
    } else
      ShowErrorMessage("Could not get a handle to LsaOpenPolicy", NULL);
    FreeLibrary("ADVAPI32.DLL");
  }
  return result;
}

//------------------------------------------------------------------------------
NTSTATUS DynamicLsaAddAccountRights(
    IN LSA_HANDLE PolicyHandle,        // open policy handle
    IN PSID AccountSid,                // SID to grant privilege to
    IN PLSA_UNICODE_STRING UserRights, // privilege to grant (Unicode)
    IN ULONG CountOfRights)            // privilege count
{
  NTSTATUS result = 0;
  ULONG errCode = 0;
  HINSTANCE LsaSecLib = LoadLibrary("ADVAPI32.DLL");
  if (LsaSecLib) {
    pLsaAddAccountRights pFunction;
    (FARPROC)pFunction = GetProcAddress(LsaSecLib, "LsaAddAccountRights");
    if ( pFunction ) {
      result = pFunction(PolicyHandle, AccountSid, UserRights, CountOfRights);
      if ( result != STATUS_SUCCESS ) {
        errCode = DynamicLsaNtStatusToWinError(result);
        ShowErrorMessage("LsaAddAccountRights", &errCode);
      }
    } else
      ShowErrorMessage("Could not get a handle to LsaAddAccountRights", NULL);
    FreeLibrary("ADVAPI32.DLL");
  }
  return result;
}

//------------------------------------------------------------------------------

