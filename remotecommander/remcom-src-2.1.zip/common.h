//------------------------------------------------------------------------------
// Common defines for remote commander and remote service
//------------------------------------------------------------------------------
#ifndef commonH
#define commonH
#include <windows.h>
//------------------------------------------------------------------------------
// Signals that can be sent to remote clients via ControlService
const DWORD SERVICE_CONTROL_RELOAD_CONFIG = 0x80;
const DWORD SERVICE_CONTROL_RUNCOMMAND    = 0x81;
const DWORD SERVICE_CONTROL_REMOVELOGFILE = 0x82;
const DWORD SERVICE_CONTROL_CAPSSTAT      = 0x84;
// The following is standard in Win2000 but does not work in NT4
#ifndef SERVICE_CONTROL_PARAMCHANGE
const DWORD SERVICE_CONTROL_PARAMCHANGE = 0x06;
#endif

// Maximum size of a command
#define MAX_COMMAND_LENGTH 512
// Maximum size of a logline (length time field + MAX_COMMAND_LENGTH) 
#define LOGLINE_LENGTH 536

//------------------------------------------------------------------------------
// Encrypt/decrypt a line with RC5
char* EncryptWithRC5(char input[], char password[], int size);
char* DecryptWithRC5(char input[], char password[], int size);
void __fastcall GetHashFromPassword(char aPassword[], char aPasswordHash[], size_t buffsize);

// Names of the sections in the service inifile
extern const char* ServiceSection;
extern const char* ServiceCommand;
extern const char* ServiceLog;
// Maximum size of a command
extern const int MaxCommandLength;
// Password used by the service to encrypt the service commandfile and logfile
extern char* EncryptionPassword;
// Service name
extern char* ServiceName;
//------------------------------------------------------------------------------
#endif
