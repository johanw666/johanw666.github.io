//------------------------------------------------------------------------------
// This file is part of Remote Commander by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: addpc.h
//------------------------------------------------------------------------------
#ifndef addpcH
#define addpcH
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <CheckLst.hpp>
#include <comctrls.hpp>
//------------------------------------------------------------------------------
class TAddComputerForm: public TForm
{
__published:
  TPanel* Panel1;
  TButton* OKButton;
  TButton* CancelButton;
  TPanel* Panel2;
  TLabel* ComputerNameLabel;
  TEdit* ComputerNameEdit;
  void __fastcall OKButtonClick(TObject* Sender);
  void __fastcall FormShow(TObject* Sender);
  void __fastcall ComputerNameEditKeyPress(TObject* Sender, char& Key);
private:
  char* fComputerName;
  size_t fBuffLength;
  __fastcall TAddComputerForm(TComponent* Owner);
public:
  __fastcall TAddComputerForm(TComponent* Owner, char* computerName, size_t buffLength);
};

//------------------------------------------------------------------------------
#endif

