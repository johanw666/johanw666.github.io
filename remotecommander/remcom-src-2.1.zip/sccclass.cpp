//------------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "sccclass.h"
#include "defsetup.h"
#include "password.h"
#include "common.h"
#include "Base64.h"
// Delphi crypto modules
#include "DCPcrypt.hpp"
#include "RC5.hpp"
#include "SHA1.hpp"

// Default password if none chosen.
const char DefaultPassword[] = "remotecommander";
// Inifile keys
const AnsiString ComputerNamesIniSection = "Computers";
const AnsiString SwitchUser = "SwitchUser";
const AnsiString ProgramIniSection = "General";
const AnsiString ReadNetworkIdent = "ReadNetwork";
const AnsiString DestinationKey = "DestinationKey";
const AnsiString DestinationSection = "DestinationSection";
const AnsiString UpdateAfterStart = "UpdateAfterStart";
const AnsiString ServiceStartUp = "ServiceStartUp";
const AnsiString MaxWaitTime = "MaxWaitTime";
const AnsiString LogRefreshTime = "LogRefreshTime";
const AnsiString MinimizeToSystray = "MinimizeToSysTray";
const AnsiString AutoRefreshLogs = "AutoRefreshLogs";
const AnsiString ShowButtons = "ShowButtons";
const AnsiString SelectWholeLine = "SelectWholeLine";
const AnsiString ShowSettings = "ShowSettings";
const AnsiString UseSecureCipher = "UseSecureCipher";
const AnsiString AddOnlyNTMachines = "AddOnlyNTMachines";
const AnsiString AllowNonDomain = "AllowNonDomain";
const AnsiString ScanOutsideDomain = "ScanOutsideDomain";
const AnsiString WriteDebugMessages = "WriteDebugMessages";
const AnsiString TopPos = "FormTop";
const AnsiString LeftPos = "FormLeft";
const AnsiString FormHeight = "FormHeight";
const AnsiString FormWidth = "FormWidth";
const AnsiString NameColumnWidth = "NameColumnWidth";
const AnsiString StatusColumnWidth = "StatusColumnWidth";
const AnsiString PathColumnWidth = "PathColumnWidth";
const AnsiString VersionColumnWidth = "VersionColumnWidth";
const AnsiString CommandColumnWidth = "CommandColumnWidth";
const AnsiString LogColumnWidth = "LogColumnWidth";
const AnsiString InteractColumnWidth = "InteractColumnWidth";

//------------------------------------------------------------------------------
// ServiceParams methods.
//------------------------------------------------------------------------------
__fastcall ServiceParams::ServiceParams()
{
}

__fastcall ServiceParams::~ServiceParams()
{
}

//------------------------------------------------------------------------------
// Assignment operator.
//------------------------------------------------------------------------------
const ServiceParams& __fastcall ServiceParams::operator=(const ServiceParams& cfg2)
{
  ServiceParams& from = (ServiceParams&)cfg2;
  // Copy the contents of the "from" object to the receiving object.
  strcpy(IniSection, from.IniSection);
  strcpy(ExeFrom, from.ExeFrom);
  strcpy(IniFrom, from.IniFrom);
  strcpy(ExtraFrom, from.ExtraFrom);
  strcpy(DirectoryTo, from.DirectoryTo);
  strcpy(RemoteName, from.RemoteName);
  strcpy(ServiceName, from.ServiceName);
  strcpy(DisplayName, from.DisplayName);
  StartOnInstall = from.StartOnInstall;
  StartOnBoot = from.StartOnBoot;
  InteractWithDesktop = from.InteractWithDesktop;
  return *this;
}

//------------------------------------------------------------------------------
bool __fastcall ServiceParams::operator==(const ServiceParams& cfg2) const
{
  return Compare(cfg2);
}

//------------------------------------------------------------------------------
bool __fastcall ServiceParams::operator!=(const ServiceParams& cfg2) const
{
  return !Compare(cfg2);
}

//------------------------------------------------------------------------------
// Comparing function for operator== and !=. Returns true if equal, false if not.
//------------------------------------------------------------------------------
bool __fastcall ServiceParams::Compare(const ServiceParams& cfg2) const
{
  return(
  !strcmp(IniSection, cfg2.IniSection) &&
  !strcmp(ExeFrom, cfg2.ExeFrom) &&
  !strcmp(IniFrom, cfg2.IniFrom) &&
  !strcmp(ExtraFrom, cfg2.ExtraFrom) &&
  !strcmp(DirectoryTo, cfg2.DirectoryTo) &&
  !strcmp(RemoteName, cfg2.RemoteName) &&
  !strcmp(ServiceName, cfg2.ServiceName) &&
  !strcmp(DisplayName, cfg2.DisplayName) &&
  (StartOnInstall == cfg2.StartOnInstall) &&
  (StartOnBoot == cfg2.StartOnBoot) &&
  (InteractWithDesktop == cfg2.InteractWithDesktop) );
}

//------------------------------------------------------------------------------
// Write settings to a defined inifile.
//------------------------------------------------------------------------------
void __fastcall ServiceParams::SaveSettings(TIniFile* file)
{
  if ( file && strlen(IniSection) ) {
    file->WriteString(IniSection, "ExeFrom", ExeFrom);
    file->WriteString(IniSection, "IniFrom", IniFrom);
    file->WriteString(IniSection, "ExtraFrom", ExtraFrom);
    file->WriteString(IniSection, "DirectoryTo", DirectoryTo);
    file->WriteString(IniSection, "RemoteName", RemoteName);
    file->WriteString(IniSection, "ServiceName", ServiceName);
    file->WriteString(IniSection, "DisplayName", DisplayName);
    // Startup values
    file->WriteBool(IniSection, "StartOnInstall", StartOnInstall);
    file->WriteBool(IniSection, "StartOnBoot", StartOnBoot);
    file->WriteBool(IniSection, "InteractWithDesktop", InteractWithDesktop);
  }
}

//------------------------------------------------------------------------------
// Read settings from inifile.
//------------------------------------------------------------------------------
void __fastcall ServiceParams::ReadSettings(TIniFile* file)
{
  if ( file && strlen(IniSection) ) {
    strcpy(ExeFrom, file->ReadString(IniSection, "ExeFrom", "").c_str());
    strcpy(IniFrom, file->ReadString(IniSection, "IniFrom", "").c_str());
    strcpy(ExtraFrom, file->ReadString(IniSection, "ExtraFrom", "").c_str());
    strcpy(DirectoryTo, file->ReadString(IniSection, "DirectoryTo", "").c_str());
    strcpy(RemoteName, file->ReadString(IniSection, "RemoteName", "").c_str());
    strcpy(ServiceName, file->ReadString(IniSection, "ServiceName", "").c_str());
    strcpy(DisplayName, file->ReadString(IniSection, "DisplayName", "").c_str());
    // Startup values
    StartOnInstall = file->ReadBool(IniSection, "StartOnInstall", true);
    StartOnBoot = file->ReadBool(IniSection, "StartOnBoot", true);
    InteractWithDesktop = file->ReadBool(IniSection, "InteractWithDesktop", false);
  }
}

//------------------------------------------------------------------------------
// This method checks if there is sufficient information available to create a service
//------------------------------------------------------------------------------
bool ServiceParams::IsSufficientDataAvailable()
{
  char errMsg[1024];

  if ( !strlen(DirectoryTo) || !strlen(ExeFrom) || !strlen(IniFrom) ||
       !strlen(RemoteName)  || !strlen(ServiceName) || !strlen(DisplayName) ) {
    strcpy(errMsg, "Some of the required parameters for this operation are not defined:\n\n");
    if ( !strlen(ExeFrom) )     strcat(errMsg, " - Executable to use\n");
    if ( !strlen(IniFrom) )     strcat(errMsg, " - Inifile to use\n");
    if ( !strlen(DirectoryTo) ) strcat(errMsg, " - Destination path on remote computer\n");
    if ( !strlen(DisplayName) ) strcat(errMsg, " - Service display name\n");
    if ( !strlen(ServiceName) ) strcat(errMsg, " - Service name");
    if ( !strlen(RemoteName) )  strcat(errMsg, " - Program executable name on remote computer\n");
    strcat(errMsg, "\nSelect \"Default setup\" to set them.");
    if ( Application->MessageBox(errMsg, "Insufficient data available to create the service", MB_YESNO) == IDYES ) {
      TDefaultsForm* DefaultsForm = new TDefaultsForm(NULL, this);
      if ( DefaultsForm ) {
        DefaultsForm->ShowModal();
        delete DefaultsForm;
      }
    }
    return false;
  }
  else return true;
}

//------------------------------------------------------------------------------
// End of ServiceParams methods.
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// ProgramCfg methods.
//------------------------------------------------------------------------------
__fastcall ProgramCfg::ProgramCfg()
{
  // Initialise the login info with 0
  memset(Username, 0, sizeof(Username));
  memset(Domain, 0, sizeof(Domain));
  memset(Password, 0, sizeof(Password));
  memset(ProgramPassword, 0, sizeof(ProgramPassword));
  // List to store the computer names in
  computerNameList = new TStringList;
}

//------------------------------------------------------------------------------
__fastcall ProgramCfg::~ProgramCfg()
{
  // Clear the login info
  memset(Username, 0, sizeof(Username));
  memset(Domain, 0, sizeof(Domain));
  memset(Password, 0, sizeof(Password));
  memset(ProgramPassword, 0, sizeof(ProgramPassword));
  delete computerNameList;
}

//------------------------------------------------------------------------------
// Assignment operator.
//------------------------------------------------------------------------------
const ProgramCfg& __fastcall ProgramCfg::operator=(const ProgramCfg& cfg2)
{
  int i;

  ProgramCfg& from = (ProgramCfg&)cfg2;
  // Copy the contents of the "from" object to the receiving object.
  readNetworkNamesAfterStart = from.readNetworkNamesAfterStart;
  updateStatusAfterStart = from.updateStatusAfterStart;
  scanOutsideDomain = from.scanOutsideDomain;
  allowNonDomain = from.allowNonDomain;
  minimizeToSystray = from.minimizeToSystray;
  MaxWaitTime = from.MaxWaitTime;
  LogRefreshTime = from.LogRefreshTime;
  SwitchUserID = from.SwitchUserID;
  useSecureCipher = from.useSecureCipher;
  autoRefreshLogs = from.autoRefreshLogs;
  showButtons = from.showButtons;
  showSettings = from.showSettings;
  selectWholeLine = from.selectWholeLine;
  addOnlyNTMachines = from.addOnlyNTMachines;
  writeDebugMessages = from.writeDebugMessages;
  // Login data
  strncpy(Username, from.Username, sizeof(Username) - 1);
  strncpy(Domain, from.Domain, sizeof(Domain) - 1);
  strncpy(Password, from.Password, sizeof(Password) - 1);
  strcpy(ProgramPassword, from.ProgramPassword);
  // Computer names
  computerNameList->Clear();
  for (i = 0; i < from.computerNameList->Count; i++) {
    computerNameList->Add(from.computerNameList->Strings[i]);
    computerNameList->Objects[i] = from.computerNameList->Objects[i];
  }
  return *this;
}

//------------------------------------------------------------------------------
// operator==. Returns true if both are equal, false if unequal.
//------------------------------------------------------------------------------
bool __fastcall ProgramCfg::operator==(const ProgramCfg& cfg2) const
{
  return Compare(cfg2);
}

//------------------------------------------------------------------------------
// operator!=. Returns true if both are unequal, false if equal.
//------------------------------------------------------------------------------
bool __fastcall ProgramCfg::operator!=(const ProgramCfg& cfg2) const
{
  return !Compare(cfg2);
}

//------------------------------------------------------------------------------
// Comparing function for operator== and !=. Returns true if both are equal,
// false if not.
//------------------------------------------------------------------------------
bool __fastcall ProgramCfg::Compare(const ProgramCfg& cfg2) const
{
  int i;
  bool computerCmp = true;
  // Compare the stored computer names.
  // Check if both configs have an equal number of names.
  if ( computerNameList->Count != cfg2.computerNameList->Count ) {
    computerCmp = false;
  } else { // If so, check if they are equal
    for (i = 0; i < computerNameList->Count; i++) {
      if ((computerNameList->Strings[i] != cfg2.computerNameList->Strings[i]) ||
          (computerNameList->Objects[i] != cfg2.computerNameList->Objects[i])) {
        computerCmp = false;
        break;
      }
    }
  }
  return(computerCmp &&
  (readNetworkNamesAfterStart == cfg2.readNetworkNamesAfterStart) &&
  (updateStatusAfterStart == cfg2.updateStatusAfterStart) &&
  (scanOutsideDomain == cfg2.scanOutsideDomain) &&
  (allowNonDomain == cfg2.allowNonDomain) &&
  (minimizeToSystray == cfg2.minimizeToSystray) &&
  (MaxWaitTime == cfg2.MaxWaitTime) &&
  (LogRefreshTime == cfg2.LogRefreshTime) &&
  (SwitchUserID == cfg2.SwitchUserID) &&
  (useSecureCipher == cfg2.useSecureCipher) &&
  (autoRefreshLogs == cfg2.autoRefreshLogs) &&
  (showButtons == cfg2.showButtons) &&
  (showSettings == cfg2.showSettings) &&
  (selectWholeLine == cfg2.selectWholeLine) &&
  (addOnlyNTMachines == cfg2.addOnlyNTMachines) &&
  (writeDebugMessages == cfg2.writeDebugMessages) &&
  !strcmp(ProgramPassword, cfg2.ProgramPassword) &&
  !strncmp(Username, cfg2.Username, sizeof(Username) - 1) &&
  !strncmp(Domain, cfg2.Domain, sizeof(Domain) - 1) &&
  !strncmp(Password, cfg2.Password, sizeof(Password) - 1));
}

//------------------------------------------------------------------------------
// Write settings to inifile.  When RC5 encryption is used, we
// also store the SHA1 hash of the login data.
//------------------------------------------------------------------------------
void __fastcall ProgramCfg::SaveSettings(TIniFile* aIniFile)
{
  TPasswordForm* PwdForm;
  TDCP_rc5* Cipher;
  TDCP_sha1* Hash;
  char CryptBuffer[256], Base64Buffer[256];
  char HashBuffer[256], PasswordHash[20];
  char Digest[21]; // Digest is 21 chars for terminating 0 since Base64Encode needs a string.

  // Program behaviour
  aIniFile->WriteBool(ProgramIniSection, ReadNetworkIdent, readNetworkNamesAfterStart);
  aIniFile->WriteBool(ProgramIniSection, UpdateAfterStart, updateStatusAfterStart );
  aIniFile->WriteBool(ProgramIniSection, ScanOutsideDomain, scanOutsideDomain);
  aIniFile->WriteBool(ProgramIniSection, AllowNonDomain, allowNonDomain);
  aIniFile->WriteBool(ProgramIniSection, MinimizeToSystray, minimizeToSystray);
  aIniFile->WriteBool(ProgramIniSection, ShowButtons, showButtons);
  aIniFile->WriteBool(ProgramIniSection, ShowSettings, showSettings);
  aIniFile->WriteBool(ProgramIniSection, SelectWholeLine, selectWholeLine);
  aIniFile->WriteBool(ProgramIniSection, AutoRefreshLogs, autoRefreshLogs);
  // Do we want to run the program as a different user?
  aIniFile->WriteBool(ProgramIniSection, SwitchUser, SwitchUserID);
  aIniFile->WriteBool(ProgramIniSection, AddOnlyNTMachines, addOnlyNTMachines);
  aIniFile->WriteBool(ProgramIniSection, WriteDebugMessages, writeDebugMessages);
  // How do we want to encrypt the login data
  aIniFile->WriteBool(ProgramIniSection, UseSecureCipher, useSecureCipher);
  // Encrypt the user data
  if ( !useSecureCipher ) { // Use a fixed password
    strcpy(ProgramPassword, DefaultPassword);
  } else { // Encrypt login data with RC5
    // Ask for password if none set
    if ( !strlen(ProgramPassword) || !strcmp(ProgramPassword, DefaultPassword) ) {
      PwdForm = new TPasswordForm(NULL, ProgramPassword, sizeof(ProgramPassword) - 1, true);
      if ( PwdForm ) {
        PwdForm->ShowModal();
        delete PwdForm;
      }
    }
  }
  if ( strlen(Username) ) { // If account data used
    // Create an instance of the RC5 class
    Cipher = new TDCP_rc5(NULL);
    // Initialise the RC5 cipher with the password
    GetHashFromPassword(ProgramPassword, PasswordHash, sizeof(PasswordHash));
    Cipher->Init(PasswordHash, sizeof(PasswordHash) * 8, NULL);  // remember key size is in BITS
    // Username
    memset(CryptBuffer, 0, sizeof(CryptBuffer));
    Cipher->EncryptCBC(Username, CryptBuffer, sizeof(Username));
    CryptBuffer[sizeof(Username)] = 0; // Zero-terminate string
    Base64Encode(CryptBuffer, Base64Buffer, sizeof(Username), sizeof(Base64Buffer));
    aIniFile->WriteString(ProgramIniSection, "Account", Base64Buffer);
    // Password
    memset(CryptBuffer, 0, sizeof(CryptBuffer));
    Cipher->EncryptCBC(Password, CryptBuffer, sizeof(Password));
    CryptBuffer[sizeof(Password)] = 0; // Zero-terminate string
    Base64Encode(CryptBuffer, Base64Buffer, sizeof(Password), sizeof(Base64Buffer));
    aIniFile->WriteString(ProgramIniSection, "Password", Base64Buffer);
    // Domain
    memset(CryptBuffer, 0, sizeof(CryptBuffer));
    Cipher->EncryptCBC(Domain, CryptBuffer, sizeof(Domain));
    CryptBuffer[sizeof(Domain)] = 0; // Zero-terminate string
    Base64Encode(CryptBuffer, Base64Buffer, sizeof(Domain), sizeof(Base64Buffer));
    aIniFile->WriteString(ProgramIniSection, "Domain", Base64Buffer);
    Cipher->Burn();
    delete Cipher;
    // Save a hashed value of the login data:
    memset(HashBuffer, 0, sizeof(HashBuffer));
    memset(Digest, 0, sizeof(Digest));
    strcpy(HashBuffer, Username);
    strcat(HashBuffer, Password);
    strcat(HashBuffer, Domain);
    Hash = new TDCP_sha1(NULL);
    Hash->Init();
    Hash->Update(HashBuffer, strlen(HashBuffer));
    Hash->Final(Digest); // Get hash value of the login data
    Base64Encode(Digest, Base64Buffer, sizeof(Digest), sizeof(Base64Buffer));
    aIniFile->WriteString(ProgramIniSection, "Check", Base64Buffer);
    delete Hash;
  } else { // Empty the login strings
    aIniFile->WriteString(ProgramIniSection, "Account", "");
    aIniFile->WriteString(ProgramIniSection, "Password", "");
    aIniFile->WriteString(ProgramIniSection, "Domain", "");
    aIniFile->WriteString(ProgramIniSection, "Check", "");
    useSecureCipher = false;
    aIniFile->WriteBool(ProgramIniSection, UseSecureCipher, useSecureCipher);
  }
  // Store the computer names
  WriteComputerNames(aIniFile);
}

//------------------------------------------------------------------------------
// Writes the stored computernames to the program inifile
//------------------------------------------------------------------------------
void __fastcall ProgramCfg::WriteComputerNames(TIniFile* aIniFile)
{
  int i;
  // First delete all computer names
  aIniFile->EraseSection(ComputerNamesIniSection);
  // Now write them out again
  for (i = 0; i < computerNameList->Count; i++)
    aIniFile->WriteInteger(ComputerNamesIniSection, computerNameList->Strings[i], (int)computerNameList->Objects[i]);
}

//------------------------------------------------------------------------------
// Read settings from inifile. When RC5 encryption is used, we check
// if the stored SHA1 hash of the login data matches.
//------------------------------------------------------------------------------
void __fastcall ProgramCfg::ReadSettings(TIniFile* aIniFile)
{
  AnsiString AccountCheck;
  bool askForPassword;
  int i;

  TPasswordForm* PwdForm;
  // Read all computernames from the ini file
  aIniFile->ReadSection(ComputerNamesIniSection, computerNameList);
  // Read if they are checked or not. Store this in the Object part of the StringList.
  for (i = 0; i < computerNameList->Count; i++)
    computerNameList->Objects[i] = (TObject*)aIniFile->ReadInteger(ComputerNamesIniSection, computerNameList->Strings[i], 0);
  // Check if we should read network names. Default is false.
  readNetworkNamesAfterStart = aIniFile->ReadBool(ProgramIniSection, ReadNetworkIdent, false);
  // Check how the program should minimize
  minimizeToSystray = aIniFile->ReadBool(ProgramIniSection, MinimizeToSystray, false);
  // Do we want logfiles to auto-refresh?
  autoRefreshLogs = aIniFile->ReadBool(ProgramIniSection, AutoRefreshLogs, true);
  // Do we want to see the buttonpanel and settingspanel
  showButtons = aIniFile->ReadBool(ProgramIniSection, ShowButtons, true);
  showSettings = aIniFile->ReadBool(ProgramIniSection, ShowSettings, true);
  selectWholeLine = aIniFile->ReadBool(ProgramIniSection, SelectWholeLine, true);
  // Maximum time we wait on the service to obtain a certain state
  MaxWaitTime = aIniFile->ReadInteger(ProgramIniSection, MaxWaitTime, 5);
  // Refreshtime for the logfile
  LogRefreshTime = aIniFile->ReadInteger(ProgramIniSection, LogRefreshTime, 60);
  // See if we want to switch to another accocunt. Default is we don't.
  SwitchUserID = aIniFile->ReadBool(ProgramIniSection, SwitchUser, false);
  // See if we update the statusinfo after start.
  updateStatusAfterStart = aIniFile->ReadBool(ProgramIniSection, UpdateAfterStart, true);
  // Do we allow local machines not in domain?
  allowNonDomain = aIniFile->ReadBool(ProgramIniSection, AllowNonDomain, false);
  // Do we allow scanning the network outside the local domain?
  scanOutsideDomain = aIniFile->ReadBool(ProgramIniSection, ScanOutsideDomain, false);
  // What do we want to see in "rescan network"?
  addOnlyNTMachines = aIniFile->ReadBool(ProgramIniSection, AddOnlyNTMachines, true);
  // Do we want to write debug messages?
  writeDebugMessages =  aIniFile->ReadBool(ProgramIniSection, WriteDebugMessages, false);
  // See how we want to encrypt the login data
  useSecureCipher = aIniFile->ReadBool(ProgramIniSection, UseSecureCipher, false);
  // Read account data if stored.
  AccountCheck = aIniFile->ReadString(ProgramIniSection, "Account", "");
  try {
    if ( AccountCheck.Length() ) {
      if ( !useSecureCipher ) { // Use default password
        strcpy(ProgramPassword, DefaultPassword);
          ReadEncryptedLoginData(aIniFile);
      } else {
        // Ask for password first. Continue asking until the user pressed no or the
        // correct password is entered.
        askForPassword = true;
        do {
          PwdForm = new TPasswordForm(NULL, ProgramPassword, sizeof(ProgramPassword) - 1, false);
          if ( PwdForm ) {
            PwdForm->ShowModal();
            delete PwdForm;
          }
          if ( !ReadEncryptedLoginData(aIniFile) ) { // Wrong password
            if ( Application->MessageBox("Wrong password entered, retry?", Application->Title.c_str(), MB_YESNO) == ID_NO ) {
              askForPassword = false;
              Application->MessageBox("Incorrect password, this program will not run as another user.", Application->Title.c_str(), MB_OK);
              // Clear the login data
              memset(Username, 0, sizeof(Username));
              memset(Domain, 0, sizeof(Domain));
              memset(Password, 0, sizeof(Password));
              memset(ProgramPassword, 0, sizeof(ProgramPassword));
              SwitchUserID = false;
              useSecureCipher = false;
              strcpy(ProgramPassword, DefaultPassword);
            }
          } else { // Good password entered
            askForPassword = false;
          }
        } while ( askForPassword );
      }
    }
  } catch (Exception& exception) { // Error in Base64 stuff
    // Clear the login data
    memset(Username, 0, sizeof(Username));
    memset(Domain, 0, sizeof(Domain));
    memset(Password, 0, sizeof(Password));
    memset(ProgramPassword, 0, sizeof(ProgramPassword));
    SwitchUserID = false;
    useSecureCipher = false;
    // Set default password
    strcpy(ProgramPassword, DefaultPassword);
    Application->ShowException(&exception);
  }
}

//------------------------------------------------------------------------------
// Read the encrypted login data. Returns true if the decrypted data matches
// the stored hash.
//------------------------------------------------------------------------------
bool __fastcall ProgramCfg::ReadEncryptedLoginData(TIniFile* aIniFile)
{
  AnsiString readText, storedHashString;
  TDCP_rc5* Cipher;
  TDCP_sha1* Hash;
  char CryptBuffer[256], Base64Buffer[256];
  char HashBuffer[256], PasswordHash[20];
  char Digest[21]; // Digest is 21 chars for terminating 0 since Base64Encode needs a string.

  // Read the account data with RC5
  Cipher = new TDCP_rc5(NULL); // Create an instance of the RC5 class
  // Initialise the RC5 cipher with the password
  GetHashFromPassword(ProgramPassword, PasswordHash, sizeof(PasswordHash));
  Cipher->Init(PasswordHash, sizeof(PasswordHash) * 8, NULL);  // remember key size is in BITS
  // Username
  memset(CryptBuffer, 0, sizeof(CryptBuffer));
  readText = aIniFile->ReadString(ProgramIniSection, "Account", "");
  Base64Decode(readText.c_str(), CryptBuffer, readText.Length(), sizeof(CryptBuffer));
  Cipher->DecryptCBC(CryptBuffer, Username, sizeof(Username));
  // Password
  memset(CryptBuffer, 0, sizeof(CryptBuffer));
  readText = aIniFile->ReadString(ProgramIniSection, "Password", "");
  Base64Decode(readText.c_str(), CryptBuffer, readText.Length(), sizeof(CryptBuffer));
  Cipher->DecryptCBC(CryptBuffer, Password, sizeof(Password));
  // Domain
  memset(CryptBuffer, 0, sizeof(CryptBuffer));
  readText = aIniFile->ReadString(ProgramIniSection, "Domain", "");
  Base64Decode(readText.c_str(), CryptBuffer, readText.Length(), sizeof(CryptBuffer));
  Cipher->DecryptCBC(CryptBuffer, Domain, sizeof(Domain));
  Cipher->Burn();
  delete Cipher;
  // Check the hash of the CRC of the login info:
  storedHashString = aIniFile->ReadString(ProgramIniSection, "Check", "");
  memset(HashBuffer, 0, sizeof(HashBuffer));
  memset(Digest, 0, sizeof(Digest));
  // Hashbuffer is of the form loginpassworddomain
  strcpy(HashBuffer, Username);
  strcat(HashBuffer, Password);
  strcat(HashBuffer, Domain);
  Hash = new TDCP_sha1(NULL);
  Hash->Init();
  Hash->Update(HashBuffer, strlen(HashBuffer));
  Hash->Final(Digest);
  delete Hash;
  Base64Encode(Digest, Base64Buffer, sizeof(Digest), sizeof(Base64Buffer));
  if ( storedHashString != AnsiString(Base64Buffer) )
    return false; // They do not match
  else
    return true;
}

//------------------------------------------------------------------------------
// End of ProgramCfg methods.
//------------------------------------------------------------------------------

