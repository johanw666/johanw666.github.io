//------------------------------------------------------------------------------
#ifndef editH
#define editH
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//------------------------------------------------------------------------------
class TEditForm: public TForm
{
__published:
  TPanel* Panel1;
  TPanel* Panel2;
  TButton* SaveButton;
  TButton* CancelButton;
  TPanel* Panel3;
  TLabel* ServiceCommandLabel;
  TCheckBox* ServiceLogCheckBox;
  TEdit* CommandEdit;
  TLabel* FilenameLabel;
  void __fastcall CancelButtonClick(TObject* Sender);
  void __fastcall SaveButtonClick(TObject* Sender);
  void __fastcall FormShow(TObject* Sender);
  void __fastcall CommandEditKeyDown(TObject* Sender, WORD& Key, TShiftState Shift);
private:
  AnsiString fFileName;
  AnsiString CommandToExecute;
  __fastcall TEditForm(TComponent* Owner);
public:
  __fastcall TEditForm(TComponent* Owner, AnsiString aFileName);
};
//------------------------------------------------------------------------------
#endif

