//------------------------------------------------------------------------------
#ifndef accountH
#define accountH
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Mask.hpp>

//------------------------------------------------------------------------------
// Local Security Authority (LSA) functions.
// Some of these things are copied from Microsofts NTSecAPI.h. This file is part
// of the SDK, but I include the things required for rscc here so rscc can be
// compiled without the SDK installed.
//------------------------------------------------------------------------------
#define POLICY_VIEW_LOCAL_INFORMATION      0x00000001L
#define POLICY_VIEW_AUDIT_INFORMATION      0x00000002L
#define POLICY_GET_PRIVATE_INFORMATION     0x00000004L
#define POLICY_TRUST_ADMIN                 0x00000008L
#define POLICY_CREATE_ACCOUNT              0x00000010L
#define POLICY_CREATE_SECRET               0x00000020L
#define POLICY_CREATE_PRIVILEGE            0x00000040L
#define POLICY_SET_DEFAULT_QUOTA_LIMITS    0x00000080L
#define POLICY_SET_AUDIT_REQUIREMENTS      0x00000100L
#define POLICY_AUDIT_LOG_ADMIN             0x00000200L
#define POLICY_SERVER_ADMIN                0x00000400L
#define POLICY_LOOKUP_NAMES                0x00000800L
#define POLICY_NOTIFICATION                0x00001000L

typedef PVOID LSA_HANDLE, *PLSA_HANDLE;

typedef struct _LSA_UNICODE_STRING {
    USHORT Length;
    USHORT MaximumLength;
    PWSTR  Buffer;
} LSA_UNICODE_STRING, *PLSA_UNICODE_STRING;

typedef struct _LSA_STRING {
    USHORT Length;
    USHORT MaximumLength;
    PCHAR Buffer;
} LSA_STRING, *PLSA_STRING;

typedef struct _LSA_OBJECT_ATTRIBUTES {
    ULONG Length;
    HANDLE RootDirectory;
    PLSA_UNICODE_STRING ObjectName;
    ULONG Attributes;
    PVOID SecurityDescriptor;       // Points to type SECURITY_DESCRIPTOR
    PVOID SecurityQualityOfService; // Points to type SECURITY_QUALITY_OF_SERVICE
} LSA_OBJECT_ATTRIBUTES, *PLSA_OBJECT_ATTRIBUTES;

//------------------------------------------------------------------------------
// Local Security Policy - Miscellaneous API function prototypes
//------------------------------------------------------------------------------
typedef LONG NTSTATUS, *PNTSTATUS;
#define STATUS_SUCCESS  ((NTSTATUS)0x00000000L)

//------------------------------------------------------------------------------
// Pointers to functions that will be loaded from ADVAPI32.DLL
//------------------------------------------------------------------------------
typedef NTSTATUS (__stdcall * pLsaClose) (IN LSA_HANDLE ObjectHandle);

typedef NTSTATUS (__stdcall * pLsaOpenPolicy) (
    IN PLSA_UNICODE_STRING SystemName OPTIONAL,
    IN PLSA_OBJECT_ATTRIBUTES ObjectAttributes,
    IN ACCESS_MASK DesiredAccess,
    IN OUT PLSA_HANDLE PolicyHandle);

typedef NTSTATUS (__stdcall * pLsaAddAccountRights) (
    IN LSA_HANDLE PolicyHandle,
    IN PSID AccountSid,
    IN PLSA_UNICODE_STRING UserRights,
    IN ULONG CountOfRights);

typedef ULONG (__stdcall * pLsaNtStatusToWinError) (NTSTATUS Status);

//------------------------------------------------------------------------------
// Functions that call the API calls dynamically from ADVAPI32.DLL.
//------------------------------------------------------------------------------
NTSTATUS DynamicLsaClose(IN LSA_HANDLE ObjectHandle);

NTSTATUS DynamicLsaOpenPolicy(
    IN PLSA_UNICODE_STRING SystemName OPTIONAL, // System name, NULL == local machine
    IN PLSA_OBJECT_ATTRIBUTES ObjectAttributes,
    IN ACCESS_MASK DesiredAccess,
    IN OUT PLSA_HANDLE PolicyHandle);

NTSTATUS DynamicLsaAddAccountRights(
    IN LSA_HANDLE PolicyHandle,        // open policy handle
    IN PSID AccountSid,                // SID to grant privilege to
    IN PLSA_UNICODE_STRING UserRights, // privilege to grant (Unicode)
    IN ULONG CountOfRights);           // privilege count

ULONG DynamicLsaNtStatusToWinError(NTSTATUS Status);

//------------------------------------------------------------------------------
// Class TAccountForm
//------------------------------------------------------------------------------
class TAccountForm: public TForm
{
__published:
  TPanel* Panel1;
  TPanel* Panel2;
  TButton* CancelButton;
  TButton* OKButton;
    TPanel *Panel5;
    TGroupBox *AccountGroupBox;
    TPanel *Panel3;
    TLabel *DomainLabel;
    TLabel *PasswordLabel;
    TLabel *AccountLabel;
    TRadioButton *SwitchRadioButton;
    TRadioButton *NoSwitchRadioButton;
    TEdit *AccountEdit;
    TMaskEdit *PasswordEdit;
    TEdit *DomainEdit;
    TPanel *Panel4;
    TLabel *DescriptionLabel;
  void __fastcall OKButtonClick(TObject* Sender);
  void __fastcall CancelButtonClick(TObject* Sender);
  void __fastcall EditChange(TObject* Sender);
  void __fastcall AccountEditKeyPress(TObject* Sender, char& Key);
  void __fastcall PasswordEditKeyPress(TObject* Sender, char& Key);
  void __fastcall DomainEditKeyPress(TObject* Sender, char& Key);
  void __fastcall FormShow(TObject* Sender);
private:
  bool* fSwitchUserID; // Do we want to switch user ID after startup?
  bool* fChange;       // Do we want to switch it now?
  char* fUsername; // string that specifies the user name
  char* fDomain;   // string that specifies the domain or server
  char* fPassword; // string that specifies the password
  size_t UserSize;
  size_t DomainSize;
  size_t PasswordSize;
  PSID fSid;
  __fastcall TAccountForm(TComponent* Owner);
  bool __fastcall CheckAccountPrivilege(char privilegeName[]);
  bool __fastcall AddAccountSeTcbPrivilege(void);
  bool __fastcall AddTcbPrivilege(void* psid);
  bool static __fastcall GetCurrentSID(PSID* Sid);
public:
  bool __fastcall HandlePrivs(void);
   __fastcall TAccountForm(TComponent* Owner,
                           char* aUserName, char* aDomain, char* aPassword,
                           size_t usrSize, size_t domSize, size_t pwdSize,
                           bool* aSwitchUserID, bool* aChange);
};

//------------------------------------------------------------------------------
#endif

