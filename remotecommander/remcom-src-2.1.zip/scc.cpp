//------------------------------------------------------------------------------
#include <vcl.h>
#include <FileCtrl.hpp>
#include <shellapi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <lm.h>  // LAN manager API for NetServerGetInfo
#pragma hdrstop

#include "scc.h"
#include "common.h"
#include "defsetup.h"
#include "addpc.h"
#include "config.h"
#include "about.h"
#include "help.h"
#include "edit.h"
#include "account.h"
#include "logfile.h"
#include "password.h"
#include "settings.h"
//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMainForm* MainForm;

//------------------------------------------------------------------------------
// Program constants
//------------------------------------------------------------------------------
// Listview indices
const int lStatusIndex   = 0; // Service status
const int lPathIndex     = 1; // Service path
const int lVersionIndex  = 2; // program version
const int lCommandIndex  = 3; // service command
const int lLogIndex      = 4; // service logs
const int lInteractIndex = 5; // servcie interaction with desktop
// Error constant
const int NO_SERVICEMANAGER_FOUND = 0x21;
const int COMPUTERNAME_NOT_FOUND  = 0x22;
//------------------------------------------------------------------------------
// Default column sizes
const int defaultNameColumnWidth     = 110;
const int defaultStatusColumnWidth   = 120;
const int defaultPathColumnWidth     = 200;
const int defaultVersionColumnWidth  =  90;
const int defaultCommandColumnWidth  = 135;
const int defaultLogColumnWidth      =  30;
const int defaultInteractColumnWidth =  48;
// Default form sizes
const int defaultTopPos     = 0;
const int defaultLeftPos    = 0;
const int defaultFormHeight = 400;
const int defaultFormWidth  = 765;
// Name of the logfile, if used
AnsiString tracefile;

//------------------------------------------------------------------------------
// Show error string. This method is either passed the address of an error code
// or, when NULL is passed, will call GetLastError().
//------------------------------------------------------------------------------
void __fastcall ShowErrorMessage(char aHeaderText[], DWORD* errCode)
{
  LPVOID lpMsgBuf; // For error info text
  DWORD errorCode; // For error code if required.
  // If pointer is NULL, get errorcode from windows
  if ( !errCode ) errorCode = GetLastError();
  else errorCode = *errCode;

  FormatMessage(
    FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
    NULL,
    errorCode,
    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
    (LPTSTR)&lpMsgBuf, 0, NULL);
  // Display the message.
  Application->MessageBox((char*)lpMsgBuf, aHeaderText, MB_OK|MB_ICONWARNING);
  // Free the buffer.
  LocalFree(lpMsgBuf);
}

//------------------------------------------------------------------------------
// Get the errormessage and return it in buffer.
//------------------------------------------------------------------------------
void __fastcall GetErrormessage(DWORD* errCode, char* buffer, size_t buffSize)
{
  LPVOID lpMsgBuf; // For error info text
  DWORD errorCode; // For error code if required.
  // If pointer is NULL, get errorcode from windows
  if ( !errCode ) errorCode = GetLastError();
  else errorCode = *errCode;

  FormatMessage(
    FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
    NULL,
    errorCode,
    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
    (LPTSTR)&lpMsgBuf, 0, NULL);

  strncpy(buffer, (char*)lpMsgBuf, buffSize);
  strcat(buffer, "\n");
  // Free the buffer.
  LocalFree(lpMsgBuf);
}

//------------------------------------------------------------------------------
// Returns the type of a remote machine. NetServerGetInfo called on level 101
// rewuires no special privileges.
// returns 400 for win95, 410 for win98, 490 for WinME,
// 2000+350 for NT3.5, 2000+400 for NT4, 2000+500 for NT 5 etc.
// Returns 0 if machine is neither WinNT or Win9x.
//------------------------------------------------------------------------------
long __fastcall GetRemotePlatformType(char* servername)
{
  long ver = 0;
  LPSERVER_INFO_101 si = NULL;
  // Function NetServerGetInfo() requires unicode input.
  wchar_t uServerName[(2*MAX_COMPUTERNAME_LENGTH) + 2];
  AnsiToUnicode(servername, uServerName, sizeof(uServerName));
  // CBuilder 3 and 5 require different code here.
#if defined(__BORLANDC__) && (__BORLANDC__ <= 0x530) // CBuilder 3
  if (NetServerGetInfo((LPTSTR)uServerName, 101, (LPBYTE*)&si) == 0) {
#else
  if (NetServerGetInfo((wchar_t*)uServerName, 101, (LPBYTE*)&si) == 0) {
#endif
    if ((si->sv101_type & (SV_TYPE_NT | SV_TYPE_WINDOWS)) != 0 ) {
      ver = (si->sv101_version_major * 100) + (si->sv101_version_minor);
      if ( (si->sv101_type & SV_TYPE_NT) != 0 ) ver += 2000;
    }
  }
  if (si) NetApiBufferFree(si);
  return ver;
}

//------------------------------------------------------------------------------
// Converts the unicode string ustr to ANSI. The string may not contain more
// than 511 unicode characters.
//------------------------------------------------------------------------------
const char* UnicodeToAnsi(const void* ustr, char* outbuf, size_t bufflen)
{
  if (ustr) {
    if (WideCharToMultiByte(CP_ACP, 0, (LPCWSTR)ustr, -1, outbuf, bufflen, NULL, NULL) > 0) {
      outbuf[bufflen-1] = 0;
      return outbuf;
    }
  }
  return "";
}

//------------------------------------------------------------------------------
// Converts the ANSI string astr to unicode. The string may not contain more
// than 511 ANSI characters.
//------------------------------------------------------------------------------
LPCWSTR AnsiToUnicode(const char* astr, wchar_t* outbuf, size_t bufflen)
{
  if (astr) {
    if (MultiByteToWideChar(CP_ACP, 0, (LPCSTR)astr, -1, (LPWSTR)&outbuf[0], bufflen) > 0) {
      outbuf[bufflen-2] = 0;
      outbuf[bufflen-1] = 0;
      return (LPCWSTR)&outbuf[0];
    }
  }
  return L"";
}

//------------------------------------------------------------------------------
// Debug functions. if writedebuginfo == true they write debug info to the logfile.
//------------------------------------------------------------------------------
// Debug version of ControlService()
//------------------------------------------------------------------------------
BOOL TMainForm::RSCC_ControlService(SC_HANDLE hService, DWORD dwControl, LPSERVICE_STATUS lpServiceStatus, bool writedebuginfo, char* computername)
{
  BOOL retVal = ControlService(hService, dwControl, lpServiceStatus);
  // Store old errorcode in case something gets wrong here
  DWORD errCode = GetLastError();

  if ( writedebuginfo ) {
    char msgStr[2048];
    sprintf(msgStr, "Controlservice() call to %s.\nSent code %s (0x%x).\nSERVICE_STATUS after call:\ndwServiceType:\t\t%d\ndwCurrentState:\t\t%d\ndwControlsAccepted:\t%d\ndwWin32ExitCode:\t\t%d\ndwServiceSpecificExitCode:\t%d\ndwCheckPoint:\t\t%d\ndwWaitHint:\t\t%d\nReturn code: %s",
            computername,
            ControlcodeDescription(dwControl).c_str(),
            dwControl,
            lpServiceStatus->dwServiceType,
            lpServiceStatus->dwCurrentState,
            lpServiceStatus->dwControlsAccepted,
            lpServiceStatus->dwWin32ExitCode,
            lpServiceStatus->dwServiceSpecificExitCode,
            lpServiceStatus->dwCheckPoint,
            lpServiceStatus->dwWaitHint,
            retVal == TRUE? "TRUE" : "FALSE");
    if ( !retVal ) {
      char errStr[512];
      GetErrormessage(NULL, errStr, sizeof(errStr));
      strcat(msgStr, "; Error message: ");
      strncat(msgStr, errStr, sizeof(msgStr) - strlen(msgStr) - 2);
      strcat(msgStr, "\n");
    } else
      strcat(msgStr, "\n");

    WriteDebugString(tracefile.c_str(), msgStr);
  }
  // Set the last errorcode back
  SetLastError(errCode);
  return retVal;
}

//------------------------------------------------------------------------------
// Debug version of StartService()
//------------------------------------------------------------------------------
BOOL TMainForm::RSCC_StartService(SC_HANDLE hService, DWORD dwNumServiceArgs, LPCTSTR* lpServiceArgVectors, bool writedebuginfo, char* computername)
{
  BOOL retVal = StartService(hService, dwNumServiceArgs, lpServiceArgVectors);
  // Store old errorcode in case something gets wrong here
  DWORD errCode = GetLastError();

  if ( writedebuginfo ) {
    char msgStr[128];
    sprintf(msgStr, "StartService call to %s\nReturn code: %s", computername, retVal == TRUE? "TRUE" : "FALSE");
    if ( !retVal ) {
      char errStr[512];
      GetErrormessage(NULL, errStr, sizeof(errStr));
      strcat(msgStr, "; Error message: ");
      strncat(msgStr, errStr, sizeof(msgStr) - strlen(msgStr) - 2);
      strcat(msgStr, "\n");
    } else
      strcat(msgStr, "\n");

    WriteDebugString(tracefile.c_str(), msgStr);
  }
  // Set the last errorcode back
  SetLastError(errCode);
  return retVal;
}

//------------------------------------------------------------------------------
// Debug version of CopyFile()
//------------------------------------------------------------------------------
BOOL TMainForm::RSCC_CopyFile(LPCTSTR lpExistingFileName, LPCTSTR lpNewFileName, BOOL bFailIfExists, bool writedebuginfo)
{
  BOOL retVal = CopyFile(lpExistingFileName, lpNewFileName, bFailIfExists);
  // Store old errorcode in case something gets wrong here
  DWORD errCode = GetLastError();

  if ( writedebuginfo ) {
    char msgStr[128];
    sprintf(msgStr, "CopyFile(%s, %s, %s)\nReturn code: %s",
            lpExistingFileName, lpNewFileName,
            bFailIfExists == TRUE? "TRUE" : "FALSE",
            retVal == TRUE? "TRUE" : "FALSE");
    if ( !retVal ) {
      char errStr[512];
      GetErrormessage(NULL, errStr, sizeof(errStr));
      strcat(msgStr, "; Error message: ");
      strncat(msgStr, errStr, sizeof(msgStr) - strlen(msgStr) - 2);
      strcat(msgStr, "\n");
    } else
      strcat(msgStr, "\n");

    WriteDebugString(tracefile.c_str(), msgStr);
  }
  // Set the last errorcode back
  SetLastError(errCode);
  return retVal;
}

//------------------------------------------------------------------------------
// Debug version of DeleteFile()
//------------------------------------------------------------------------------
BOOL TMainForm::RSCC_DeleteFile(LPCTSTR lpFileName, bool writedebuginfo)
{
  BOOL retVal = DeleteFile(lpFileName);
  // Store old errorcode in case something gets wrong here
  DWORD errCode = GetLastError();

  if ( writedebuginfo ) {
    char msgStr[128];
    sprintf(msgStr, "DeleteFile(%s)\nReturn code: %s", lpFileName, retVal == TRUE? "TRUE" : "FALSE");
    if ( !retVal ) {
      char errStr[512];
      GetErrormessage(NULL, errStr, sizeof(errStr));
      strcat(msgStr, "; Error message: ");
      strncat(msgStr, errStr, sizeof(msgStr) - strlen(msgStr) - 2);
      strcat(msgStr, "\n");
    } else
      strcat(msgStr, "\n");

    WriteDebugString(tracefile.c_str(), msgStr);
  }
  // Set the last errorcode back
  SetLastError(errCode);
  return retVal;
}

//------------------------------------------------------------------------------
// Debug version of MoveFileEx()
//------------------------------------------------------------------------------
BOOL TMainForm::RSCC_MoveFileEx(LPCTSTR lpExistingFileName, LPCTSTR lpNewFileName, DWORD dwFlags, bool writedebuginfo)
{
  BOOL retVal = MoveFileEx(lpExistingFileName, lpNewFileName, dwFlags);
  // Store old errorcode in case something gets wrong here
  DWORD errCode = GetLastError();

  if ( writedebuginfo ) {
    char msgStr[128];
    sprintf(msgStr, "MoveFileEx(%s, %s, 0x%x)\nReturn code: %s",
            lpExistingFileName, lpNewFileName, dwFlags,
            retVal == TRUE? "TRUE" : "FALSE");
    if ( !retVal ) {
      char errStr[512];
      GetErrormessage(NULL, errStr, sizeof(errStr));
      strcat(msgStr, "; Error message: ");
      strncat(msgStr, errStr, sizeof(msgStr) - strlen(msgStr) - 2);
      strcat(msgStr, "\n");
    } else
      strcat(msgStr, "\n");

    WriteDebugString(tracefile.c_str(), msgStr);
  }
  // Set the last errorcode back
  SetLastError(errCode);
  return retVal;
}

//------------------------------------------------------------------------------
// Write the message in the logfile.
//------------------------------------------------------------------------------
void __fastcall WriteDebugString(char* fileName, char* msg)
{
  FILE* file = fopen(fileName, "at");
  if ( file ) {
    DWORD ms = GetTickCount();
    SYSTEMTIME timeStruct;
    GetSystemTime(&timeStruct); // Get time in UTC
    fprintf(file, "%04d-%02d-%02d %02d:%02d:%02d:%03d (%05d.%03d): %s",
                  timeStruct.wYear,
                  timeStruct.wMonth,
                  timeStruct.wDay,
                  timeStruct.wHour,
                  timeStruct.wMinute,
                  timeStruct.wSecond,
                  timeStruct.wMilliseconds,
                  (int)ms/1000, (int)(ms%1000), msg);
    fflush(file);
    fclose(file);
  }
}

//------------------------------------------------------------------------------
// Check if a given computername still exists on the network and if it can run a
// SCM (NT/2000/XP)
//------------------------------------------------------------------------------
bool __fastcall TMainForm::IsComputerOnlineAndNT(const char* lpMachineName)
{
  LPSERVER_INFO_101 si = NULL;
  LPSERVER_INFO_101 tmpsi;
  DWORD level = 101;
  DWORD entriesRead = 0;
  DWORD totalEntries = 0;
  DWORD resumeHandle = 0;
  NET_API_STATUS testVal;
  unsigned i;
  char ComputerName[MAX_COMPUTERNAME_LENGTH + 1];
  long ver = 0;
  bool retVal = false;

  testVal = NetServerEnum(NULL,
                          level,
                          (LPBYTE*)(&si),
                          MAX_PREFERRED_LENGTH,
                          &entriesRead,
                          &totalEntries,
                          SV_TYPE_WORKSTATION,
                          NULL,
                          &resumeHandle);

  if ((testVal == NERR_Success) || (testVal == ERROR_MORE_DATA)) {
    if ((tmpsi = si) != NULL) {
      // Now add all servers c.q. all NT machines to the listviews.
      for (i = 0; i < entriesRead; i++) {
        if (!tmpsi) {
          ShowErrorMessage("NetServerEnum", NULL);
          break;
        }
        UnicodeToAnsi(tmpsi->sv101_name, ComputerName, sizeof(ComputerName));
        if ((tmpsi->sv101_type & (SV_TYPE_NT | SV_TYPE_WINDOWS)) != 0 ) {
          ver = (tmpsi->sv101_version_major * 100) + (tmpsi->sv101_version_minor);
          if ( (tmpsi->sv101_type & SV_TYPE_NT) != 0 ) ver += 2000;
        }
        if (ver >= 2000) {
          // NetServerEnum() returns names in uppercase so case conversion is required
          if (LowerCase(ComputerName) == LowerCase(lpMachineName)) {
            // Computer name found in list
            retVal = true;
            break;
          }
        }
        tmpsi++;
      }
    }
    if (testVal == ERROR_MORE_DATA) ShowErrorMessage("NetServerEnum", NULL);
  }
  else
    ShowErrorMessage("NetServerEnum", NULL);

  if (si) NetApiBufferFree(si);
  return retVal;
}

//------------------------------------------------------------------------------
// Version of OpenSCManager that first checks if the computername extsts in the
// network and if it is of type NT. This is implemented to prevent long delays,
// for example when a machine is switched off. Just calling RSCC_RSCC_RSCC_OpenSCManager()
// would hang the program for 30 seconds.
//------------------------------------------------------------------------------
SC_HANDLE TMainForm::RSCC_OpenSCManager(LPCTSTR lpMachineName,
                                        LPCTSTR lpDatabaseName,
                                        DWORD dwDesiredAccess)
{
  SC_HANDLE retVal = 0;
  // if true, do the real OpenSCManager() call
  if (pcfg.allowNonDomain || pcfg.scanOutsideDomain || IsComputerOnlineAndNT(lpMachineName))
    retVal = OpenSCManager(lpMachineName, lpDatabaseName, dwDesiredAccess);

  return retVal;
}

//------------------------------------------------------------------------------
//  Constructor.
//------------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner): TForm(Owner)
{
  char* p;

  // System tray icon
  TrayIcon = new Graphics::TIcon;
  TrayIcon->Handle = LoadImage(HInstance, "MAINICON", IMAGE_ICON, 0, 0, 0);
  // Set the event handlers for minimizing/restoring from the system tray
  Application->OnMinimize = AppOnMinimize;
  Application->OnRestore  = AppOnRestore;
  // Find inifilename
  iniFileName = ParamStr(0);
  p = strrchr(iniFileName.c_str(), '.');
  if ( p ) *p = 0;
  strcat(iniFileName.c_str(), ".ini");
  // Create inifile for settings
  ProgramSettingsFile = new TIniFile(iniFileName);
  // Find logfilename
  tracefile = ParamStr(0);
  p = strrchr(tracefile.c_str(), '.');
  if ( p ) *p = 0;
  strcat(tracefile.c_str(), ".log");
  viewLogFilesChildren = new TList();  
}

//------------------------------------------------------------------------------
//  Set program defaults.
//------------------------------------------------------------------------------
void __fastcall TMainForm::FormShow(TObject* Sender)
{
  char* domainName;
  AnsiString versionString;
  char versionNr[256];
  DWORD errCode;
  char errMsg[512], msg[1024];

  // Default reason why FormClose is called
  prgCloseReason = PRG_CLOSE_OTHER;
  // Get the windows type. The program only runs on winNT.
  if ( GetWin32Platform(versionNr, sizeof(versionNr)) != VER_PLATFORM_WIN32_NT ) {
    versionString = "Windows " + AnsiString(versionNr) + " detected.\nThis program requires Windows NT, 2000 or XP.";
    Application->MessageBox(versionString.c_str(), "Incorrect windows version", MB_OK|MB_ICONSTOP);
    Application->Terminate();
  }
  AboutForm->WindowsVersionLabel->Caption = "Running on Windows " + AnsiString(versionNr);
  // Read inifile settings
  ReadIniSettings();
  // Login as specified user and get its priviliges
  if ( pcfg.SwitchUserID && strlen(pcfg.Username) ) {
    // Domain name need not be specified
    if ( pcfg.Domain && strlen(pcfg.Domain) ) domainName = pcfg.Domain;
    else domainName = NULL;

    if ( !LogonUser(pcfg.Username, domainName, pcfg.Password,
                    LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, &hToken) ) {
      errCode = GetLastError();
      GetErrormessage(&errCode, errMsg, sizeof(errMsg));
      strcpy(msg, "Remote Commander wanted to login as another user but failed. The error was:\n");
      strcat(msg, errMsg);
      strcat(msg, "\nDo you want to edit the login data now?");
      if ( MessageBox(NULL, msg, Application->Title.c_str(), MB_YESNO) == IDYES ) {
        SwitchAccountButtonClick(Sender);
        // Don't try to login now, probably the required privilege was not found
        // so a logoff/logon is necessary anyway.
      }
    }
    if ( hToken ) {
      if ( !ImpersonateLoggedOnUser(hToken) )
        ShowErrorMessage("ImpersonateLoggedOnUser", NULL);
    }
  }
  // No thread is currently running
  NetworkScanThreadIsRunning = false;
  // Read the computer names stored in the inifile and scan the network if
  // this is configured:
  ComputersListView->Items->Clear();
  ReadComputerNames();
  // Store the computer names so we can see if the configuration has changed
  // when we close.
  StoreComputerNames();
  // Select the first computer in the list:
  if ( ComputersListView->Items->Count > 0 )
    ComputersListView->Items->Item[0]->Selected = true;
}

//------------------------------------------------------------------------------
// Destructor.
//------------------------------------------------------------------------------
__fastcall TMainForm::~TMainForm()
{
  // Remove the system tray icon
  RemoveIcon();
  delete TrayIcon;
  // Delete settingsfile
  delete ProgramSettingsFile;
  // Delete list of logfiles.
  delete viewLogFilesChildren;
}

//------------------------------------------------------------------------------
// Saves the settings and deletes the inifile. Doing this in the destructor
// gives access violations so we do it in the OnClose event.
//------------------------------------------------------------------------------
void __fastcall TMainForm::FormClose(TObject* Sender, TCloseAction& Action)
{
  int i;
  bool saveSettings = false;

  // Make sure the computernames in pcfg and the GUI match.
  StoreComputerNames();
  // Save settings if necessary.
  switch ( prgCloseReason ) {
    case PRG_CLOSE_CANCEL:
         saveSettings = false;
         break;
    case PRG_CLOSE_EXIT:
         saveSettings = true;
         break;
    default:
      if ((orgpcfg != pcfg) || (orgServiceData != serviceData) ) {
        switch ( Application->MessageBox("Settings have changed, save changes?", Application->Title.c_str(), MB_YESNOCANCEL) ) {
          case IDYES: // Save
               saveSettings = true;
               break;
          case IDCANCEL: // Don't close the form
               Action = caNone;
               prgCloseReason = PRG_CLOSE_OTHER; // Reset reason
               saveSettings = false;
               break;
          default: break; // Don't save
        }

      }
  }
  if ( Action != caNone ) {
    // Drop priviliges. This is done here to prevent access right errors writing
    // the config files. It is assumed that the calling user has the right to
    // write to the program's ini file.
    if (hToken && !CloseHandle(hToken) ) ShowErrorMessage("CloseHandle", NULL);
    if ( pcfg.SwitchUserID && !RevertToSelf() ) ShowErrorMessage("RevertToSelf", NULL);
    // run through the list of open logfile viewer child windows,
    // Close all and free memory.
    // The childlist itself is deleted in the destructor.
    for (i = 0; i < viewLogFilesChildren->Count; i++) {
      TViewLogFileForm* f = (TViewLogFileForm*)viewLogFilesChildren->Items[i];
      // prevent the child form to send its WM_CLOSE_VIEW_LOGFILE notification,
      // since we are already closing and freeing it and dont need it here
      f->mainForm = NULL;
      // Delete the menuitem
      delete f->windowMenuItem;
      f->Close();
      delete f;
    }
  }
  if ( saveSettings ) SaveIniSettings();
}

//------------------------------------------------------------------------------
// this method is called on WM_CLOSE_VIEW_LOGFILE sent by the
// TViewLogFileForm when closing.
//------------------------------------------------------------------------------
void __fastcall TMainForm::WMCloseViewLog(TMessage& Message)
{
  // find the window in the child list by pointer
  int i = viewLogFilesChildren->IndexOf((TObject*)Message.WParam);

  if (i >= 0) {
    TViewLogFileForm* f = (TViewLogFileForm*)viewLogFilesChildren->Items[i];
    viewLogFilesChildren->Delete(i);
    // Delete corresponding menuitem
    delete (TMenuItem*)Message.LParam;
    // Delete the logfile form
    delete f;
  }
}

//------------------------------------------------------------------------------
// Save settings and close the form
//------------------------------------------------------------------------------
void __fastcall TMainForm::ExitButtonClick(TObject* Sender)
{
  prgCloseReason = PRG_CLOSE_EXIT;
  Close();
}

//------------------------------------------------------------------------------
// Close without saving.
//------------------------------------------------------------------------------
void __fastcall TMainForm::CancelButtonClick(TObject* Sender)
{
  prgCloseReason = PRG_CLOSE_CANCEL;
  Close();
}

//------------------------------------------------------------------------------
// Check all computers
//------------------------------------------------------------------------------
void __fastcall TMainForm::Checkallcomputers1Click(TObject *Sender)
{
  for (int i = 0; i < ComputersListView->Items->Count; i++)
    ComputersListView->Items->Item[i]->Checked = true;
}

//------------------------------------------------------------------------------
// Uncheck all computers
//------------------------------------------------------------------------------
void __fastcall TMainForm::Uncheckallcomputers1Click(TObject *Sender)
{
  for (int i = 0; i < ComputersListView->Items->Count; i++)
    ComputersListView->Items->Item[i]->Checked = false;
}

//------------------------------------------------------------------------------
// Save the program settings to the inifile.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Savesettings1Click(TObject* Sender)
{
  SaveIniSettings();
}

//------------------------------------------------------------------------------
// Store the computer names so we can see if the configuration has changed
//------------------------------------------------------------------------------
void __fastcall TMainForm::StoreComputerNames()
{
  int i;
  pcfg.computerNameList->Clear();
  for (i = 0; i < ComputersListView->Items->Count; i++) {
    pcfg.computerNameList->Add(ComputersListView->Items->Item[i]->Caption);
    pcfg.computerNameList->Objects[i] = (TObject*)ComputersListView->Items->Item[i]->Checked;
  }
}

//------------------------------------------------------------------------------
// Read the settings from the inifile.
//------------------------------------------------------------------------------
void __fastcall TMainForm::ReadIniSettings()
{
  // Required data, not to be changed by the user interface
  strcpy(serviceData.IniSection, "Service");
  // Read program settings
  pcfg.ReadSettings(ProgramSettingsFile);
  // Store old settings so we can later check if they have changed.
  orgpcfg = pcfg;
  // Read the defaults for service data. If the inifile does not exist it will return defaults.
  serviceData.ReadSettings(ProgramSettingsFile);
  // Store old settings so we can later check if they have changed.
  orgServiceData = serviceData;
  // See if we want to see the buttons and settings panel
  ShowButtons1->Checked = pcfg.showButtons;
  ButtonPanel->Visible = pcfg.showButtons;
  ShowSettings1->Checked = pcfg.showSettings;
  SettingsPanel->Visible = pcfg.showSettings;
  ComputersListView->RowSelect = pcfg.selectWholeLine;
  // Set defaults if not filled.
  SetServiceDataDefaults();
  // Read the form position and sizes
  Top  = ProgramSettingsFile->ReadInteger(ProgramIniSection, TopPos, defaultTopPos);
  Left = ProgramSettingsFile->ReadInteger(ProgramIniSection, LeftPos, defaultLeftPos);
  Height = ProgramSettingsFile->ReadInteger(ProgramIniSection, FormHeight, defaultFormHeight);
  Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, FormWidth, defaultFormWidth);
  ComputersListView->Columns->Items[0]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, NameColumnWidth, defaultNameColumnWidth);
  ComputersListView->Columns->Items[1]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, StatusColumnWidth, defaultStatusColumnWidth);
  ComputersListView->Columns->Items[2]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, PathColumnWidth, defaultPathColumnWidth);
  ComputersListView->Columns->Items[3]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, VersionColumnWidth, defaultVersionColumnWidth);
  ComputersListView->Columns->Items[4]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, CommandColumnWidth, defaultCommandColumnWidth);
  ComputersListView->Columns->Items[5]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, LogColumnWidth, defaultLogColumnWidth);
  ComputersListView->Columns->Items[6]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, InteractColumnWidth, defaultInteractColumnWidth);
  // See if we want to switch to another accocunt. Default is we don't.
  hToken = NULL;
  // See how we want to encrypt the login data
  DefaultPassword1->Checked = !pcfg.useSecureCipher;
  Password1->Enabled = pcfg.useSecureCipher;
}

//------------------------------------------------------------------------------
// Default service info when starting up remcom. We first try to read it from
// the inifile, if there is no configuration information found we check if the
// service is installed on the local system and copy the information from the
// SCM database. If the client is not installed on the local system we use
// hard-coded default values.
//------------------------------------------------------------------------------
void __fastcall TMainForm::SetServiceDataDefaults()
{
  // First set the service name. If this one is not read from the inifile
  // we need a hard-coded value to connect with the local machine.
  if ( !strlen(serviceData.ServiceName) )
    strcpy(serviceData.ServiceName, ServiceName);
  // If the other info is not known, obtain them rom the SCM database:
  if ( !strlen(serviceData.ExeFrom) || !strlen(serviceData.IniFrom) || !strlen(serviceData.DirectoryTo) )
    if ( SetServiceDefaults(&serviceData) )
      Application->MessageBox("Copied default service configuration data from the locally installed service", Application->Title.c_str(), MB_OK | MB_ICONINFORMATION);
  // Set these values if they are not yet set.
  if ( !strlen(serviceData.DisplayName) )
    strcpy(serviceData.DisplayName, "Remote control service");
  if ( !strlen(serviceData.RemoteName) )
    strcpy(serviceData.RemoteName, "remsrv");
  if ( !strlen(serviceData.DirectoryTo) )
    strcpy(serviceData.DirectoryTo, "C:\\WINNT\\");
  // Check if directories last char is "\\", add it if not so:
  if ( serviceData.DirectoryTo[strlen(serviceData.DirectoryTo) - 1] != '\\' )
    strcat(serviceData.DirectoryTo, "\\");
}

//------------------------------------------------------------------------------
// Get default service settings from the local SCM database, if present.
//------------------------------------------------------------------------------
bool __fastcall TMainForm::SetServiceDefaults(ServiceParams* spars)
{
  char buffer[2048];
  unsigned int i, n;
  char* c;
  char remoteMachineName[MAX_COMPUTERNAME_LENGTH + 1];
  char tempFileName[MAX_PATH];
  DWORD remoteMachineNameSize = sizeof(remoteMachineName);
  // Config params
  DWORD dwStartType;
  DWORD bytesNeeded;
  char lpBinaryPathName[MAX_PATH];
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  bool retVal = false;

  if ( GetComputerName(remoteMachineName, &remoteMachineNameSize) ) {
    if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_CONNECT)) == 0 )
      hscManager = NULL;

    if ( hscManager ) {
      if ( (hService = OpenService(hscManager, spars->ServiceName, SERVICE_QUERY_CONFIG)) == NULL )
        hService = NULL;

      if ( hService ) {
        if ( QueryServiceConfig(hService, (QUERY_SERVICE_CONFIG*)buffer, sizeof(buffer), &bytesNeeded) )
          retVal = true; // We got information
        // Save the data
        dwStartType = ((QUERY_SERVICE_CONFIG*)buffer)->dwStartType;
        if ( dwStartType == SERVICE_AUTO_START )
          spars->StartOnBoot = true;
        else
          spars->StartOnBoot = false;

        strcpy(lpBinaryPathName, ((QUERY_SERVICE_CONFIG*)buffer)->lpBinaryPathName);
        // Remove possible quotes from the name (could happen on existing installs)
        for (n = 0, i = 0; i < strlen(lpBinaryPathName); i++) {
          if ( lpBinaryPathName[i] != '\"' ) {
            tempFileName[n] = lpBinaryPathName[i];
            n++;
          }
        }
        tempFileName[n] = 0;
        // The directory the service files should be copied to
        strncpy(spars->DirectoryTo, ExtractFilePath(tempFileName).c_str(), sizeof(spars->DirectoryTo) - 1);
        strcpy(spars->ExeFrom, tempFileName);
        c = strrchr(tempFileName, '.');
        if ( c ) *c = 0;
        strcpy(spars->RemoteName, ExtractFileName(tempFileName).c_str());
        strcat(tempFileName, ".ini");
        strcpy(spars->IniFrom, tempFileName);
        // Display name
        strcpy(spars->DisplayName, ((QUERY_SERVICE_CONFIG*)buffer)->lpDisplayName);
        if ( !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
      }
      if ( !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
    }
  }
  return retVal;
}

//------------------------------------------------------------------------------
// Save the program settings to the inifile.
//------------------------------------------------------------------------------
void __fastcall TMainForm::SaveIniSettings()
{
  serviceData.SaveSettings(ProgramSettingsFile);
  // Write program settings. Store current computernames first.
  StoreComputerNames();
  pcfg.SaveSettings(ProgramSettingsFile);
  // Save the form position
  ProgramSettingsFile->WriteInteger(ProgramIniSection, TopPos, Top);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, LeftPos, Left);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, FormHeight, Height);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, MaxWaitTime, pcfg.MaxWaitTime);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, LogRefreshTime, pcfg.LogRefreshTime);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, FormWidth, Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, NameColumnWidth, ComputersListView->Columns->Items[0]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, StatusColumnWidth, ComputersListView->Columns->Items[1]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, PathColumnWidth, ComputersListView->Columns->Items[2]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, VersionColumnWidth, ComputersListView->Columns->Items[3]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, CommandColumnWidth, ComputersListView->Columns->Items[4]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, LogColumnWidth, ComputersListView->Columns->Items[5]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, InteractColumnWidth, ComputersListView->Columns->Items[6]->Width);
  // Set the stored settings to the saved ones
  orgpcfg = pcfg;
  orgServiceData = serviceData;
}

//------------------------------------------------------------------------------
// Restore on double click on the tray icon.
//------------------------------------------------------------------------------
void __fastcall TMainForm::WMTrayNotify(TMessage& Msg)
{
  POINT p;
  // The LPARAM of the message identifies the type of mouse message.
  if ( Msg.LParam == WM_LBUTTONDBLCLK ) Application->Restore();
  // Right button pressed: show popup menu
  else if ( Msg.LParam == WM_RBUTTONDOWN ) {
    SetForegroundWindow(Handle);
    GetCursorPos(&p);
    TrayPopupMenu->Popup(p.x, p.y);
    PostMessage(Handle, WM_NULL, 0, 0); // Done to bypass a bug in windows
  }
}

//------------------------------------------------------------------------------
// Use the Shell_NotifyIcon API function to add the icon to the system tray.
//------------------------------------------------------------------------------
void __fastcall TMainForm::AddIcon()
{
  NOTIFYICONDATA IconData;
  IconData.cbSize = sizeof(NOTIFYICONDATA);
  IconData.uID    = IDC_TRAY1;
  IconData.hWnd   = Handle;
  IconData.uFlags = NIF_MESSAGE|NIF_ICON|NIF_TIP;
  IconData.uCallbackMessage = WM_TRAYNOTIFY;
  lstrcpy(IconData.szTip, "Remote commander");
  IconData.hIcon  = TrayIcon->Handle;
  Shell_NotifyIcon(NIM_ADD, &IconData);
}

//------------------------------------------------------------------------------
// Remove the icon from the system tray
//------------------------------------------------------------------------------
void __fastcall TMainForm::RemoveIcon()
{
  NOTIFYICONDATA IconData;
  IconData.cbSize = sizeof(NOTIFYICONDATA);
  IconData.uID    = IDC_TRAY1;
  IconData.hWnd   = Handle;
  IconData.hIcon  = TrayIcon->Handle;
  Shell_NotifyIcon(NIM_DELETE, &IconData);
}

//------------------------------------------------------------------------------
// Minimize to the system tray if required
//------------------------------------------------------------------------------
void __fastcall TMainForm::AppOnMinimize(TObject* Sender)
{
  if ( pcfg.minimizeToSystray ) {
    AddIcon();
    ShowWindow(Application->Handle, SW_HIDE);
  }
}

//------------------------------------------------------------------------------
// Restore from the system tray if required
//------------------------------------------------------------------------------
void __fastcall TMainForm::AppOnRestore(TObject* Sender)
{
  if ( pcfg.minimizeToSystray ) {
    RemoveIcon();
    ShowWindow(Application->Handle, SW_SHOW);
    SetForegroundWindow(Application->Handle);
  }
}

//------------------------------------------------------------------------------
// Restore from the system tray if the restore popup menu item clicked.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Restore3Click(TObject* Sender)
{
  Application->Restore();
}

//------------------------------------------------------------------------------
// The delete button also deletes computers from the list
//------------------------------------------------------------------------------
void __fastcall TMainForm::ComputersListViewKeyDown(TObject* Sender, WORD& Key, TShiftState Shift)
{
  if ( Key == VK_DELETE ) RemPCButtonClick(Sender);
  CurrActiveItem = NULL;
}

//------------------------------------------------------------------------------
// See if we want to hide the buttons
//------------------------------------------------------------------------------
void __fastcall TMainForm::ShowButtons1Click(TObject* Sender)
{
  ShowButtons1->Checked = !ShowButtons1->Checked;
  pcfg.showButtons = ShowButtons1->Checked;
  ButtonPanel->Visible = pcfg.showButtons;
}

//------------------------------------------------------------------------------
// See if we want to hide the settings panel
//------------------------------------------------------------------------------
void __fastcall TMainForm::ShowSettings1Click(TObject* Sender)
{
  ShowSettings1->Checked = !ShowSettings1->Checked;
  pcfg.showSettings = ShowSettings1->Checked;
  SettingsPanel->Visible = pcfg.showSettings;
}

//------------------------------------------------------------------------------
// If checked, use a default password for the RC5 encryption for login data.
// Else use a user-supplied password.
//------------------------------------------------------------------------------
void __fastcall TMainForm::DefaultPassword1Click(TObject* Sender)
{
  DefaultPassword1->Checked = !DefaultPassword1->Checked;
  pcfg.useSecureCipher = !DefaultPassword1->Checked;
  Password1->Enabled = !DefaultPassword1->Checked;
  // Set default password if not secure
  if ( !pcfg.useSecureCipher ) strcpy(pcfg.ProgramPassword, DefaultPassword);
  // Ask for password if none set or password == defaultpassword
  if ( pcfg.useSecureCipher && (!strlen(pcfg.ProgramPassword) || !strcmp(pcfg.ProgramPassword, DefaultPassword)) )
    Password1Click(Sender);
}

//------------------------------------------------------------------------------
// Set the program password used to encrypt the login information with RC5.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Password1Click(TObject* Sender)
{
  TModalResult mrRes;
  char OldProgramPassword[128];

  strcpy(OldProgramPassword, pcfg.ProgramPassword);
  TPasswordForm* PwdForm = new TPasswordForm(this, pcfg.ProgramPassword, sizeof(pcfg.ProgramPassword) - 1, true);
  if ( PwdForm ) {
    // We ask to save the settings if the password is changed AND used.
    mrRes = PwdForm->ShowModal();
    if (!strlen(pcfg.ProgramPassword) || (mrRes != mrOk)) { // Empty password means use insecure cipher
      pcfg.useSecureCipher = false;
      DefaultPassword1->Checked = true;
      Password1->Enabled = false;
      strcpy(pcfg.ProgramPassword, DefaultPassword); // Set default password
    } else if (mrRes == mrOk) {
      pcfg.useSecureCipher = true;
      DefaultPassword1->Checked = false;
      Password1->Enabled = true;
    }
    if ( (mrRes == mrOk) && strcmp(OldProgramPassword, pcfg.ProgramPassword) ) {
      if ( Application->MessageBox("Password has changed, save settings?", Application->Title.c_str(), MB_YESNO) == ID_YES)
        SaveIniSettings();
    }
    delete PwdForm;
    // Remove password from memory
    memset(OldProgramPassword, 0, sizeof(OldProgramPassword));
  }
}

//------------------------------------------------------------------------------
// Shows the settings form.
//------------------------------------------------------------------------------
void __fastcall TMainForm::settings1Click(TObject* Sender)
{
  bool lineSelect = ComputersListView->RowSelect;

  TSettingsForm* SettingsForm = new TSettingsForm(this, &pcfg);
  if ( SettingsForm ) {
    SettingsForm->ShowModal();
    delete SettingsForm;
  }
  // Secure cipher options:
  DefaultPassword1->Checked = !pcfg.useSecureCipher;
  Password1->Enabled = pcfg.useSecureCipher;
  // Set default password if not secure
  if ( !pcfg.useSecureCipher ) strcpy(pcfg.ProgramPassword, DefaultPassword);
  // Ask for password if none set or password == defaultpassword
  if ( pcfg.useSecureCipher && (!strlen(pcfg.ProgramPassword) || !strcmp(pcfg.ProgramPassword, DefaultPassword)) )
    Password1Click(Sender);
  // GUI
  if ( pcfg.selectWholeLine != lineSelect )
    ComputersListView->RowSelect = pcfg.selectWholeLine;
}

//------------------------------------------------------------------------------
// Shows the stored computernames in the listview.
//------------------------------------------------------------------------------
void __fastcall TMainForm::ReadComputerNames()
{
  int i;
  TListItem* L;

  // Add the listitems and see which ones need to be checked
  for (i = 0; i < pcfg.computerNameList->Count; i++) {
    L = ComputersListView->Items->Add();
    L->Caption = pcfg.computerNameList->Strings[i];
    if ( (int)pcfg.computerNameList->Objects[i] == 1 ) {
      L->Checked = true;
    }
    // Add item for status info
    L->SubItems->Add("");
    // Add item for service path
    L->SubItems->Add("");
    // Add subitem for service version
    L->SubItems->Add("");
    // Add subitem for command
    L->SubItems->Add("");
    // Add subitem for logging
    L->SubItems->Add("");
    // Add subitem for interaction with desktop
    L->SubItems->Add("");
  }
  // Add all other computers from Network Neighborhood to the list and
  // update the status.
  if ( pcfg.readNetworkNamesAfterStart )
    GetNetworkComputerNames(false, pcfg.readNetworkNamesAfterStart);
  else if ( pcfg.updateStatusAfterStart ) {
    UpdateStatus(0, true, true);
  }
}

//------------------------------------------------------------------------------
// Create the thread to find the network computer names. If aRunUpdateAfterwards
// is true, the status information will be updated afterwards.
//------------------------------------------------------------------------------
void __fastcall TMainForm::GetNetworkComputerNames(bool waitForResult, bool aRunUpdateAfterwards)
{
  TNetworkScanThread* NetworkScanThread;

  // This prevents errors with indices
  ComputersListView->SortType = stNone;
  // We don't start the thread twice. We also don't start the update status
  // thread when scanning the network.
  if ( !NetworkScanThreadIsRunning ) {
    NetworkScanThreadIsRunning = true;
    try {
      // Show a form to indicate we're doing something. This form will be deleted
      // by the readthread
      // Create the readthread. This thread will delete itself when ready and
      // notice when the wait info panel can be hided.
      NetworkScanThread = new TNetworkScanThread(true, aRunUpdateAfterwards, pcfg.scanOutsideDomain, this);
      ShowThreadWaitInfo();
      if ( NetworkScanThread ) {
        NetworkScanThread->Resume();
        if ( waitForResult ) NetworkScanThread->WaitFor();
      } else {
        ShowErrorMessage("Error creating network scan thread", NULL);
        HideThreadWaitInfo();
        NetworkScanThreadIsRunning = false;
      }
    }
    catch (...) {
      HideThreadWaitInfo();
      NetworkScanThreadIsRunning = false;
    }
  }
}

//------------------------------------------------------------------------------
// Shows the wait info panel for the network scan thread.
//------------------------------------------------------------------------------
void __fastcall TMainForm::ShowThreadWaitInfo()
{
  WaitThreadPanel->Width = 300;
  WaitThreadPanel->Height = 110;
  WaitThreadPanel->Color = (TColor)0x00E1C00A;
  WaitThreadPanel->Left = (ComputersListView->Width - WaitThreadPanel->Width) / 2;
  WaitThreadPanel->Top = (ComputersListView->Height - WaitThreadPanel->Height) / 2;
  InfoThreadLabel->Caption = "";
  WaitThreadLabel->Caption = "";
  WaitThreadPanel->Visible = true;
}

//------------------------------------------------------------------------------
// Shows the wait info panel for the status update .
//------------------------------------------------------------------------------
void __fastcall TMainForm::ShowUpdateWaitInfo()
{
  WaitUpdatePanel->Width = 300;
  WaitUpdatePanel->Height = 110;
//  WaitUpdatePanel->Color = (TColor)0x00E1C00A;
  WaitUpdatePanel->Left = (ComputersListView->Width - WaitUpdatePanel->Width) / 2;
  WaitUpdatePanel->Top = (ComputersListView->Height - WaitUpdatePanel->Height) / 2;
  InfoUpdateLabel->Caption = "";
  WaitUpdateLabel->Caption = "";
  WaitUpdatePanel->Visible = true;
}

//------------------------------------------------------------------------------
// Hides the wait info panel for the network scan thread.
//------------------------------------------------------------------------------
void __fastcall TMainForm::HideThreadWaitInfo()
{
  InfoThreadLabel->Caption = "";
  WaitThreadLabel->Caption = "";
  WaitThreadPanel->Visible = false;
}

//------------------------------------------------------------------------------
// Hides the wait info panel for the status update .
//------------------------------------------------------------------------------
void __fastcall TMainForm::HideUpdateWaitInfo()
{
  InfoUpdateLabel->Caption = "";
  WaitUpdateLabel->Caption = "";
  WaitUpdatePanel->Visible = false;
}

//------------------------------------------------------------------------------
// Sets the label captions in the network scan thread wait info panel.
//------------------------------------------------------------------------------
void __fastcall TMainForm::SetThreadWaitText(AnsiString label, AnsiString info)
{
  WaitThreadLabel->Caption = label;
  InfoThreadLabel->Caption = info;
}

//------------------------------------------------------------------------------
// Sets the label captions in the status update wait info panel.
//------------------------------------------------------------------------------
void __fastcall TMainForm::SetUpdateWaitText(AnsiString label, AnsiString info)
{
  WaitUpdateLabel->Caption = label;
  InfoUpdateLabel->Caption = info;
}

//------------------------------------------------------------------------------
// Updates the status information for the selected computer and the executable
// path info. We can't do this in a separate thread: since we need access to
// network resources we would have to call the method synchronized (the TThread
// class does not pass security descriptors in its CreateThread call). This
// however can cause a deadlock when we waitfor the result. If we don't wait
// for the the thread to finish we can as well do it in the main thread.
// If alwaysUpdateVersionAndIni is true the version, and command and log info
// will always be updated, otherwise it will only be updated if one of those
// fields is empty.
//------------------------------------------------------------------------------
void __fastcall TMainForm::UpdateStatus(int index, bool updateAll, bool alwaysUpdateVersionAndIni)
{
  unsigned int k;
  int i, n, beginindex, endindex;
  char servicePath[MAX_PATH], serviceExe[MAX_PATH];
  // Client inifile variables
  char serviceIni[MAX_PATH], tempFileName[MAX_PATH], systemShare[MAX_PATH];
  char* shareBoundary;
  TIniFile* serviceIniFile;
  char* p;
  AnsiString clientCommand;
  bool doesInterActWithDesktop;
  // Version API stuff
  char* versionBlock;
  DWORD versionLength, versionNullHandle;
  unsigned int versionInfoLength;
  void* FileVersionInfoPtr;
  AnsiString formCaption = Caption;

  Screen->Cursor = crHourGlass;
  // Show the wait info panel
  ShowUpdateWaitInfo();
  SetUpdateWaitText("Updating status information...", "");
  // See which info we need to update
  if ( updateAll ) {
    beginindex = 0;
    endindex = ComputersListView->Items->Count - 1;
  } else {
    beginindex = index;
    endindex = index;
  }
  // Clear the fields
  for (i = beginindex; i <= endindex; i++) {
    ComputersListView->Items->Item[i]->SubItems->Strings[lStatusIndex] = "";
    ComputersListView->Items->Item[i]->SubItems->Strings[lPathIndex] = "";
  }
  Application->ProcessMessages(); // Make the changes visible
  // Get the new status info
  for (i = beginindex; i <= endindex; i++) {
    if ( ComputersListView->Items->Item[i]->Checked ) {
      // Show computername in caption
      SetUpdateWaitText("Updating status information...", ComputersListView->Items->Item[i]->Caption);
      memset(servicePath, 0, sizeof(servicePath));
      // Get service status and show it
      DWORD returnCode = GetServiceStatus(ComputersListView->Items->Item[i]->Caption.c_str(), &doesInterActWithDesktop);
      ComputersListView->Items->Item[i]->SubItems->Strings[lStatusIndex] = ServiceStateDescription(returnCode);
      if ( (returnCode != ERROR_SERVICE_DOES_NOT_EXIST) && (returnCode != NO_SERVICEMANAGER_FOUND) && (returnCode != COMPUTERNAME_NOT_FOUND) && doesInterActWithDesktop )
        ComputersListView->Items->Item[i]->SubItems->Strings[lInteractIndex] = "Yes";
      else if ((returnCode != ERROR_SERVICE_DOES_NOT_EXIST) && (returnCode != NO_SERVICEMANAGER_FOUND) && (returnCode != COMPUTERNAME_NOT_FOUND))
        ComputersListView->Items->Item[i]->SubItems->Strings[lInteractIndex] = "No";
      else
        ComputersListView->Items->Item[i]->SubItems->Strings[lInteractIndex] = "";
      // Get service path
      if ((returnCode != ERROR_SERVICE_DOES_NOT_EXIST) && (returnCode != NO_SERVICEMANAGER_FOUND) && (returnCode != COMPUTERNAME_NOT_FOUND)) {
        GetServicePath(ComputersListView->Items->Item[i]->Caption.c_str(), servicePath, sizeof(servicePath));
        if ( servicePath )
          ComputersListView->Items->Item[i]->SubItems->Strings[lPathIndex] = AnsiString(servicePath);
      } else
        ComputersListView->Items->Item[i]->SubItems->Strings[lPathIndex] = "";
      // See if we want to update the version, command and log info.
      if ( alwaysUpdateVersionAndIni ||
           (!ComputersListView->Items->Item[i]->SubItems->Strings[lVersionIndex].Length() ||
            !ComputersListView->Items->Item[i]->SubItems->Strings[lCommandIndex].Length() ||
            !ComputersListView->Items->Item[i]->SubItems->Strings[lLogIndex].Length() ) ) {
        ComputersListView->Items->Item[i]->SubItems->Strings[lVersionIndex] = "";
        ComputersListView->Items->Item[i]->SubItems->Strings[lCommandIndex] = "";
        ComputersListView->Items->Item[i]->SubItems->Strings[lLogIndex] = "";
        // Get service version
        if ((returnCode != ERROR_SERVICE_DOES_NOT_EXIST) && (returnCode != NO_SERVICEMANAGER_FOUND) && (returnCode != COMPUTERNAME_NOT_FOUND)) {
          // Find network path of the executable
          GetExecutableName(ComputersListView->Items->Item[i]->Caption.c_str(), servicePath, serviceExe);
          if ( FileExists(serviceExe) ) {
            // Find length of the version resource
            versionLength = GetFileVersionInfoSize(serviceExe, &versionNullHandle);
            // reserve storage for it
            versionBlock = new char[versionLength];
            if ( versionBlock ) {
              versionInfoLength = 0;
              if ( GetFileVersionInfo(serviceExe, NULL, versionLength, versionBlock) ) {
                VerQueryValue(versionBlock, TEXT("\\StringFileInfo\\040904E4\\ProductVersion"), &FileVersionInfoPtr, &versionInfoLength);
                if ( versionInfoLength > 0 ) { // If versioninfo found
                  ComputersListView->Items->Item[i]->SubItems->Strings[lVersionIndex] = (char*)FileVersionInfoPtr;
                } else { // No version info found
                  ComputersListView->Items->Item[i]->SubItems->Strings[lVersionIndex] = "Unavailable";
                }
              } else {
                ComputersListView->Items->Item[i]->SubItems->Strings[lVersionIndex] = "No version info found";
              }
              delete[] versionBlock;
            }
          } else {
            // Can be due to insufficient rights on the network, check this first
            strcpy(systemShare, serviceExe);
            shareBoundary = strchr(systemShare, '$');
            if ( shareBoundary ) *(shareBoundary + 1) = 0;
            if ( !DirectoryExists(systemShare) ) // Insufficient rights to access system share
              ComputersListView->Items->Item[i]->SubItems->Strings[lVersionIndex] = "Access denied";
            else // File really not found
              ComputersListView->Items->Item[i]->SubItems->Strings[lVersionIndex] = "File not found";
          }
          // Get command in service
          // Get inifilename of service
          strcpy(tempFileName, serviceExe);
          p = strrchr(tempFileName, '.');
          if ( p ) *p = 0;
          strcat(tempFileName, ".ini");
          // Remove possible quotes from the name (could happen on existing installs)
          memset(serviceIni, 0, sizeof(serviceIni));
          for (n = 0, k = 0; k < strlen(tempFileName); k++) {
            if ( tempFileName[k] != '\"' ) {
              serviceIni[n] = tempFileName[k];
              n++;
            }
          }
          if ( FileExists(serviceIni) ) {
            serviceIniFile = new TIniFile(serviceIni);
            if ( serviceIniFile ) {
              clientCommand = AnsiString(DecryptWithRC5(
                                serviceIniFile->ReadString(ServiceSection, ServiceCommand, "").c_str(),
                                EncryptionPassword, MAX_COMMAND_LENGTH));
              ComputersListView->Items->Item[i]->SubItems->Strings[lCommandIndex] = clientCommand;
              clientCommand = serviceIniFile->ReadString(ServiceSection, ServiceLog, "0");
              if ( clientCommand == "1" )
                ComputersListView->Items->Item[i]->SubItems->Strings[lLogIndex] = "Yes";
              else
                ComputersListView->Items->Item[i]->SubItems->Strings[lLogIndex] = "No";
              delete serviceIniFile;
            }
          }
        }
      }
    }
    Application->ProcessMessages();
  }
  Caption = formCaption;
  Screen->Cursor = crDefault;
  HideUpdateWaitInfo();
}

//------------------------------------------------------------------------------
// Returns the string that belongs to a service state.
//------------------------------------------------------------------------------
AnsiString __fastcall TMainForm::ServiceStateDescription(DWORD serviceState)
{
  AnsiString Result;

  switch ( serviceState ) {
    case SERVICE_STOPPED:
         Result = "Service not running";
         break;
    case SERVICE_START_PENDING:
         Result = "Service starting";
         break;
    case SERVICE_STOP_PENDING:
         Result = "Service stopping";
         break;
    case SERVICE_RUNNING:
         Result = "Service is running";
         break;
    case SERVICE_CONTINUE_PENDING:
         Result = "Continue pending";
         break;
    case SERVICE_PAUSE_PENDING:
         Result = "Pause pending";
         break;
    case SERVICE_PAUSED:
         Result = "Service paused";
         break;
    case ERROR_SERVICE_DOES_NOT_EXIST:
         Result = "Service is not installed";
         break;
    case NO_SERVICEMANAGER_FOUND:
         Result = "No service manager found";
         break;
    case COMPUTERNAME_NOT_FOUND:
         Result = "Computer not found";
         break;
    default:
         Result = "Unknown status";
  }
  return Result;
}

//------------------------------------------------------------------------------
// Gets the service executable name.
// The parameter servicePath contains a buffer to receive the service path. The
// size of this buffer is given by buffSize.
//------------------------------------------------------------------------------
void __fastcall TMainForm::GetServicePath(char computerName[], char* servicePathBuffer, size_t buffSize)
{
  char buffer[2048];
  DWORD bytesNeeded, errCode;
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;

  Screen->Cursor = crHourGlass;

  if ( (hscManager = RSCC_OpenSCManager(computerName, NULL, GENERIC_READ)) != 0 ) {
    // We only need to query the service so we need to open it with only
    // SERVICE_QUERY_CONFIG rights. This does not require admin access to
    // the service.
    if ( (hService = OpenService(hscManager, serviceData.ServiceName, SERVICE_QUERY_CONFIG)) == NULL ) {
      errCode = GetLastError();
      if ( errCode == ERROR_ACCESS_DENIED)
        strncpy(servicePathBuffer, "Access denied", buffSize);
      else
        ShowErrorMessage(computerName, &errCode);
    }
    // First stop the service. We check the return value separately because
    // we don't want an errormessage when the service is already stopped.
    if ( hService) {
      // Find out what executable the service uses
      QueryServiceConfig(hService, (QUERY_SERVICE_CONFIG*)buffer, sizeof(buffer), &bytesNeeded);
      strncpy(servicePathBuffer, ((QUERY_SERVICE_CONFIG*)buffer)->lpBinaryPathName, buffSize);
    }
    if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(computerName, NULL);
    if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(computerName, NULL);
  } else {
    errCode = GetLastError();
    if ( errCode == ERROR_ACCESS_DENIED)
      strncpy(servicePathBuffer, "Access denied", buffSize);
    else
      ShowErrorMessage(computerName, &errCode);
  }
  Screen->Cursor = crDefault;
}

//------------------------------------------------------------------------------
// Finds the network name of a executable name from a computername and a
// pathname. The result is stored in networkPath.
//------------------------------------------------------------------------------
void __fastcall TMainForm::GetExecutableName(char aComputerName[], char aPathName[], char networkPath[])
{
  unsigned int i;
  int n;
  char* p;
  char tempFileName[MAX_PATH];

  // Remove the option part from the executable name
  // Make it lowercase
  strcpy(tempFileName, "\\\\");
  // Add computer name
  strcat(tempFileName, aComputerName);
  strcat(tempFileName, "\\");
  strcat(tempFileName, aPathName);
  for (i = 0; i < strlen(tempFileName); i++) tempFileName[i] = (char)tolower(tempFileName[i]);
  p = strrchr(tempFileName, '.');
  if ( p ) *p = 0; // Remove commandline args
  strcat(tempFileName, ".exe");
  // Replace first : by $ to get network name
  for (i = 0; i < strlen(tempFileName); i++) {
    if ( tempFileName[i] == ':' ) {
      tempFileName[i] = '$';
      break;
    }
  }
  // Remove possible quotes from the name (could happen on existing installs)
  for (n = 0, i = 0; i < strlen(tempFileName); i++) {
    if ( tempFileName[i] != '\"' ) {
      networkPath[n] = tempFileName[i];
      n++;
    }
  }
  networkPath[n] = 0;
}

//------------------------------------------------------------------------------
// The read network names thread is ready, close the message window. If the
// message indicates so, update the status.
//------------------------------------------------------------------------------
void __fastcall TMainForm::CMScanThreadReady(TMessage& Message)
{
  HideThreadWaitInfo();
  NetworkScanThreadIsRunning = false;
  if ( Message.WParam == DO_UPDATE_STATUS )
    UpdateStatus(0, true, true);
}

//------------------------------------------------------------------------------
// Returns true if a name already exists in the list, otherwise false.
//------------------------------------------------------------------------------
bool __fastcall TMainForm::NameIsDouble(const char* name, TListView* view)
{
  int i;
  AnsiString temp = LowerCase(name);

  for (i = 0; i < view->Items->Count; i++) {
    if (temp == LowerCase(view->Items->Item[i]->Caption))
      return true;
  }
  return false;
}

//------------------------------------------------------------------------------
// Get the windows version. Returns the windows type it runs on.
//------------------------------------------------------------------------------
DWORD __fastcall TMainForm::GetWin32Platform(char* versionText, size_t buffSize)
{
  OSVERSIONINFO PlatformVersion;

  PlatformVersion.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
  GetVersionEx(&PlatformVersion);
  if ( PlatformVersion.dwPlatformId == VER_PLATFORM_WIN32s ) {
    strcpy(versionText, "Win32s");
  }
  if ( PlatformVersion.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS ) {
    if ( PlatformVersion.dwMajorVersion <= 4 )
      strcpy(versionText, "95 ");
    else if ( PlatformVersion.dwMajorVersion > 4 )
      strcpy(versionText, "98 ");

    strcat(versionText, IntToStr(PlatformVersion.dwMajorVersion).c_str());
    strcat(versionText, ".");
    strcat(versionText, IntToStr(PlatformVersion.dwMinorVersion).c_str());
    strcat(versionText, " build ");
    strcat(versionText, IntToStr(LOWORD(PlatformVersion.dwBuildNumber)).c_str());
    strcat(versionText, " ");
    strcat(versionText, PlatformVersion.szCSDVersion);
  }
  if ( PlatformVersion.dwPlatformId == VER_PLATFORM_WIN32_NT ) {
    if ( PlatformVersion.dwMajorVersion <= 4 )
      strcpy(versionText, "NT ");
    else if ((PlatformVersion.dwMajorVersion == 5) && (PlatformVersion.dwMinorVersion == 0))
      strcpy(versionText, "2000 ");
    else if (PlatformVersion.dwMajorVersion >= 5)
      strcpy(versionText, "XP ");

    strcat(versionText, IntToStr(PlatformVersion.dwMajorVersion).c_str());
    strcat(versionText, ".");
    strcat(versionText, IntToStr(PlatformVersion.dwMinorVersion).c_str());
    strcat(versionText, " build ");
    strcat(versionText, IntToStr(PlatformVersion.dwBuildNumber).c_str());
    strcat(versionText, " ");
    strcat(versionText, PlatformVersion.szCSDVersion);
  }
  return PlatformVersion.dwPlatformId;
}

//------------------------------------------------------------------------------
// Check if  we are dealing with an NT/2000 or XP/2003 since XP and 2003 have
// different privilige requirements for running processes as another user: the
// SeTcbPrivilege privilege is not required. For now, we assume that successors
// to XP also do not require it, if newer windows versions come out this function
// might need adaption.
//------------------------------------------------------------------------------
bool __fastcall TMainForm::Requires_SeTcbPrivilege()
{
  OSVERSIONINFO PlatformVersion;

  PlatformVersion.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
  GetVersionEx(&PlatformVersion);
  if ( PlatformVersion.dwPlatformId == VER_PLATFORM_WIN32_NT ) {
    if (PlatformVersion.dwMajorVersion >= 5) { // XP/2003 or newer
      return false;
    }
  }
  return true;
}

//------------------------------------------------------------------------------
// Returns true if we only want NT machines in the view, false otherwise
//------------------------------------------------------------------------------
bool __fastcall TMainForm::AddOnlyNTMachinesInView()
{
  return pcfg.addOnlyNTMachines;
}

//------------------------------------------------------------------------------
// Updates the statusinfo if a computer checkbox gets checked
//------------------------------------------------------------------------------
void __fastcall TMainForm::ComputersListViewClick(TObject* Sender)
{
  if ( CurrActiveItem ) {
    if ( CurrActiveItem->Checked )
      UpdateStatus(CurrActiveItem->Index, false, false);
    else {
      CurrActiveItem->SubItems->Strings[lStatusIndex] = "";
      CurrActiveItem->SubItems->Strings[lPathIndex] = "";
      CurrActiveItem->SubItems->Strings[lVersionIndex] = "";
      CurrActiveItem->SubItems->Strings[lCommandIndex] = "";
      CurrActiveItem->SubItems->Strings[lLogIndex] = "";
      CurrActiveItem->SubItems->Strings[lInteractIndex] = "";
    }
  }
  CurrActiveItem = NULL;
}

//------------------------------------------------------------------------------
// Minimizes the form to the system tray
//------------------------------------------------------------------------------
void __fastcall TMainForm::MinimizeButtonClick(TObject *Sender)
{
  // Set default to minimize to system tray
  pcfg.minimizeToSystray = true;
  Application->Minimize();
}

//------------------------------------------------------------------------------
// Returns the current status of the service. A computername is passed. If
// doesInterActWithDesktop != NULL then in this value we return wether the
// installed service can interact with the desktop.
//------------------------------------------------------------------------------
DWORD __fastcall TMainForm::GetServiceStatus(char computerName[], bool* doesInterActWithDesktop)
{
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  SERVICE_STATUS serviceStatus;
  DWORD result;

  // Now open the service manager and query the service
  if ( (hscManager = RSCC_OpenSCManager(computerName, NULL, SC_MANAGER_CONNECT)) != 0 ) {
    if ( (hService = OpenService(hscManager, serviceData.ServiceName, SERVICE_QUERY_STATUS)) != NULL ) {
      QueryServiceStatus(hService, &serviceStatus);
      result = serviceStatus.dwCurrentState;
      if ( doesInterActWithDesktop ) {
        if ( (serviceStatus.dwServiceType & SERVICE_INTERACTIVE_PROCESS) == SERVICE_INTERACTIVE_PROCESS )
          *doesInterActWithDesktop = true;
        else
          *doesInterActWithDesktop = false;
      }
    }
    else
      result = ERROR_SERVICE_DOES_NOT_EXIST;

    if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(computerName, NULL);
  } else { // Probably a win95/98/ME PC
    if (IsComputerOnlineAndNT(computerName)) result = NO_SERVICEMANAGER_FOUND;
    else result = COMPUTERNAME_NOT_FOUND;
  }
  if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(computerName, NULL);
  return result;
}

//------------------------------------------------------------------------------
// Returns true if the service exists, false if not or the status could
// not be obtained
//------------------------------------------------------------------------------
bool __fastcall TMainForm::IsServiceInstalled(char aComputername[])
{
  if ( GetServiceStatus(aComputername, NULL) != ERROR_SERVICE_DOES_NOT_EXIST )
    return true;
  else
    return false;
}

//------------------------------------------------------------------------------
// Checks if the service manager on the remote computer can be contacted. In
// practice this is kind of asking if the remote computer runs NT.
//------------------------------------------------------------------------------
bool __fastcall TMainForm::IsServiceManagerInstalled(char aComputername[])
{
  DWORD status = GetServiceStatus(aComputername, NULL);
  if ((status != NO_SERVICEMANAGER_FOUND) && (status != COMPUTERNAME_NOT_FOUND))
    return true;
  else
    return false;
}

//------------------------------------------------------------------------------
// Returns true if the service is running, false if not or the status could
// not be obtained
//------------------------------------------------------------------------------
bool __fastcall TMainForm::IsServiceRunning(char aComputername[])
{
  if ( GetServiceStatus(aComputername, NULL) == SERVICE_RUNNING )
    return true;
  else
    return false;
}

//------------------------------------------------------------------------------
// Wait for the status to reach the desired status. We assume that the SC manager
// and service handles are valid handles. This method returns true if the service
// reached the desired status, and false if a time-out occurred.
//------------------------------------------------------------------------------
bool __fastcall TMainForm::WaitForServiceToReachStatus(SC_HANDLE aHService, DWORD aServiceStatus, int max_wait_seconds, char aMachineName[])
{
  const int sleepTime = 100; // milliseconds
  int waitTime = 1000 * max_wait_seconds; // Time left to wait
  SERVICE_STATUS serviceStatus;

  QueryServiceStatus(aHService, &serviceStatus);
  while ( (serviceStatus.dwCurrentState != aServiceStatus) && (waitTime >= 0) ) {
    Sleep(sleepTime); // Non-busy sleep
    waitTime -= sleepTime;
    QueryServiceStatus(aHService, &serviceStatus);
  }
  if ( waitTime >= 0 ) return true;
  else {
    Application->MessageBox("Timed out waiting for status to reach state", aMachineName, MB_OK);
    return false;
  }
}

//------------------------------------------------------------------------------
// Installs the service on a remote computer. It only installs if this computer
// is both selected and checked.
//------------------------------------------------------------------------------
void __fastcall TMainForm::InstallButtonClick(TObject* Sender)
{
  int i;
  DWORD startType;
  DWORD dwServiceType;
  bool cont; // Set to false if we don't continue after an error
  char errMsg[256];
  char RemoteSystemShare[3];
  char RemoteCommand[MAX_PATH];
  char remoteMachineName[MAX_PATH];
  char remoteMachineDir[MAX_PATH];
  char remoteMachineBasePath[MAX_PATH];
  char remoteExePath[MAX_PATH], remoteIniPath[MAX_PATH], remoteExtraPath[MAX_PATH];
  char buffer[MAX_PATH];
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  // Number of selected computers
  int nrOfComputersSelected = ComputersListView->SelCount;

  if ( !ComputersListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    // We first check if sufficient data is available
    if ( serviceData.IsSufficientDataAvailable() ) {
      Screen->Cursor = crHourGlass;
      // We convert the dir to network shares without the machine name:
      // c:\temp becomes c$\temp.
      RemoteSystemShare[0] = serviceData.DirectoryTo[0];
      RemoteSystemShare[1] = '$';
      RemoteSystemShare[2] = 0;

      // The command to execute on the remote machine to start the service
      strcpy(RemoteCommand, serviceData.DirectoryTo);
      if ( RemoteCommand[strlen(RemoteCommand) - 1] != '\\' ) strcat(RemoteCommand, "\\");
      strcat(RemoteCommand, ExtractFileNameWithoutExt(serviceData.RemoteName, buffer, sizeof(buffer)));
      strcat(RemoteCommand, ".exe");

      for (i = 0; i < ComputersListView->Items->Count; i++) {
        // We only install if this computer is both selected and checked
        if ( ComputersListView->Items->Item[i]->Selected && ComputersListView->Items->Item[i]->Checked ) {
          cont = true;
          // Selected computer name
          strncpy(remoteMachineName, ComputersListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
          // Full path on remote computer. We can do this because exe and ini file
          // always reside in the same dir
          strcpy(remoteMachineDir, "\\\\");
          strncat(remoteMachineDir, ComputersListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineDir));
          strcat(remoteMachineDir, "\\");
          strcat(remoteMachineDir, RemoteSystemShare);
          // Check if we can access the system share.
          if ( DirectoryExists(remoteMachineDir) ) {
            strcat(remoteMachineDir, serviceData.DirectoryTo + 2); // +2 to skip the drive and ":"
            // Store the path
            strcpy(remoteMachineBasePath, remoteMachineDir);
            // Check if the directory exists, create it if not
            if ( !DirectoryExists(remoteMachineDir) ) {
              ForceDirectories(AnsiString(remoteMachineDir));
              if ( !DirectoryExists(remoteMachineDir) ) {
                strcpy(errMsg, "Computer: ");
                strcat(errMsg, remoteMachineName);
                strcat(errMsg, "\nUnable to create destination directory.\nThe service is not installed.");
                Application->MessageBox(errMsg, Application->Title.c_str(), MB_OK|MB_ICONWARNING);
                cont = false;
              }
              strcat(remoteMachineDir, "\\");
            }
            if ( cont ) {
              // Add the name of the remote executable
              strcat(remoteMachineBasePath, ExtractFileNameWithoutExt(serviceData.RemoteName, buffer, sizeof(buffer)));
              // First copy the files to the destination directory. We add the computer
              // names here.
              if ( FileExists(serviceData.ExeFrom) ) {
                strcpy(remoteExePath, remoteMachineBasePath);
                strcat(remoteExePath, ".exe");
                RSCC_CopyFile(serviceData.ExeFrom, remoteExePath, FALSE, pcfg.writeDebugMessages);
              } else {
                Application->MessageBox("The service executable could not be found.", Application->Title.c_str(), MB_OK);
              }
              if ( FileExists(serviceData.IniFrom) ) {
                strcpy(remoteIniPath, remoteMachineBasePath);
                strcat(remoteIniPath, ".ini");
                RSCC_CopyFile(serviceData.IniFrom, remoteIniPath, FALSE, pcfg.writeDebugMessages);
              } else {
                Application->MessageBox("The service inifile could not be found.", Application->Title.c_str(), MB_OK);
              }
              if ( strlen(serviceData.ExtraFrom) ) {
                if ( FileExists(serviceData.ExtraFrom) ) {
                  strcpy(remoteExtraPath, ExtractFilePath(remoteMachineBasePath).c_str());
                  strcat(remoteExtraPath, ExtractFileName(serviceData.ExtraFrom).c_str());
                  RSCC_CopyFile(serviceData.ExtraFrom, remoteExtraPath, FALSE, pcfg.writeDebugMessages);
                } else {
                  Application->MessageBox("There was an extra file defined but it could not be found.", Application->Title.c_str(), MB_OK);
                }
              }
              // Now open the service manager and install the service
              if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
                // Start type
                if ( serviceData.StartOnBoot ) startType = SERVICE_AUTO_START;
                else startType = SERVICE_DEMAND_START;
                // Interaction
                if ( serviceData.InteractWithDesktop )
                  dwServiceType = SERVICE_WIN32_OWN_PROCESS | SERVICE_INTERACTIVE_PROCESS;
                else
                  dwServiceType = SERVICE_WIN32_OWN_PROCESS;

                hService = CreateService(hscManager,
                                         serviceData.ServiceName,
                                         serviceData.DisplayName,
                                         SERVICE_ALL_ACCESS,
                                         dwServiceType,
                                         startType,
                                         SERVICE_ERROR_IGNORE,
                                         RemoteCommand,
                                         NULL, NULL, NULL, NULL, NULL);

                if ( !hService ) ShowErrorMessage(remoteMachineName, NULL);
                else {
                  if ( serviceData.StartOnInstall )
                    RSCC_StartService(hService, 0, NULL, pcfg.writeDebugMessages, remoteMachineName);
                  // If only one computer selected, update view immediately
                  if ( nrOfComputersSelected == 1 ) {
                    UpdateStatus(i, false, true);
                    if ( serviceData.StartOnInstall ) {
                      WaitForServiceToReachStatus(hService, SERVICE_RUNNING, pcfg.MaxWaitTime, remoteMachineName);
                      UpdateStatus(i, false, true);
                    }
                  } else {
                    if ( serviceData.StartOnInstall )
                      WaitForServiceToReachStatus(hService, SERVICE_RUNNING, pcfg.MaxWaitTime, remoteMachineName);
                  }
                }
                if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
                if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
              } else {
                ShowErrorMessage(remoteMachineName, NULL);
              }
            }
          } else { // Could not access system share
            strcpy(errMsg, "Computer: ");
            strcat(errMsg, remoteMachineName);
            strcat(errMsg, "\nUnable to access system share, you probably have insufficient access rights.\nThe service is not installed.");
            Application->MessageBox(errMsg, Application->Title.c_str(), MB_OK|MB_ICONWARNING);
          }
        }
      }
    }
    // Update view if more computers are selected
    if ( nrOfComputersSelected > 1 ) UpdateStatus(0, true, true);
    Screen->Cursor = crDefault;
  }
}

//------------------------------------------------------------------------------
// Skips a possible file extension, including the separating dot.
//------------------------------------------------------------------------------
char* __fastcall TMainForm::ExtractFileNameWithoutExt(const char* aFileName, char* buffer, size_t buffSize)
{
  strncpy(buffer, aFileName, buffSize - 1);
  buffer[buffSize] = 0;
  char* c = strrchr(buffer, '.');
  if ( c ) *c = 0;
  return buffer;
}

//------------------------------------------------------------------------------
// Removes the service from the selected computer. This method only removes
// the service from the selected computer if its chekcbox is also checked.
// The corresponding executable and ini file are also deleted.
//------------------------------------------------------------------------------
void __fastcall TMainForm::RemoveButtonClick(TObject* Sender)
{
  int i, n;
  unsigned int j;
  char* p;
  char tempFileName[MAX_PATH], networkPath[MAX_PATH];
  char remoteMachineName[MAX_PATH], ExePathName[MAX_PATH], IniPathName[MAX_PATH];
  char ExtraPathName[MAX_PATH], LogPathName[MAX_PATH];
  BOOL retVal;
  DWORD errCode;
  char errStr[256];
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  SERVICE_STATUS serviceStatus;
  // Number of selected computers
  int nrOfComputersSelected = ComputersListView->SelCount;

  if ( !ComputersListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    Screen->Cursor = crHourGlass;
    for (i = 0; i < ComputersListView->Items->Count; i++) {
      if ( ComputersListView->Items->Item[i]->Selected && ComputersListView->Items->Item[i]->Checked ) {
        strncpy(remoteMachineName, ComputersListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
        if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
          if ( (hService = OpenService(hscManager, serviceData.ServiceName, SERVICE_ALL_ACCESS)) == NULL ) {
            hService = NULL; // Reset hService
            ShowErrorMessage(remoteMachineName, NULL);
          }
          // First stop the service. We check the return value separately because
          // we don't want an errormessage when the service is already stopped.
          if ( hService) {
            // Find out what executable the service uses
            // We already have the exe name, now derive the ini filename:
            strcpy(tempFileName, "\\\\");
            // Add computer name
            strcat(tempFileName, ComputersListView->Items->Item[i]->Caption.c_str());
            strcat(tempFileName, "\\");
            // Add exe and path
            strcat(tempFileName, ComputersListView->Items->Item[i]->SubItems->Strings[lPathIndex].c_str());
            // Remove possible quotes from the name (could happen on existing installs)
            memset(networkPath, 0, sizeof(networkPath));
            for (n = 0, j = 0; j < strlen(tempFileName); j++) {
              if ( tempFileName[j] != '\"' ) {
                networkPath[n] = tempFileName[j];
                n++;
              }
            }
            networkPath[n] = 0;
            strcpy(tempFileName, networkPath);
            // Replace first : by $ to get network name
            for (j = 0; j < strlen(tempFileName); j++) {
              if ( tempFileName[j] == ':' ) {
                tempFileName[j] = '$';
                break;
              }
            }
            // Replace .exe by .ini. This also removes the bootparams part.
            p = strrchr(tempFileName, '.');
            if ( p ) *p = 0;
            strcpy(ExePathName, tempFileName);
            strcpy(IniPathName, tempFileName);
            strcpy(LogPathName, tempFileName);
            strcat(IniPathName, ".ini");
            strcat(ExePathName, ".exe");
            strcat(LogPathName, ".log");
            strcpy(ExtraPathName, ExtractFilePath(tempFileName).c_str());
            strcat(ExtraPathName, ExtractFileName(serviceData.ExtraFrom).c_str());
            // Now stop the service if it runs.
            retVal= RSCC_ControlService(hService, SERVICE_CONTROL_STOP, &serviceStatus, pcfg.writeDebugMessages, remoteMachineName);
            if ( !retVal) {
              errCode = GetLastError();
              if ( errCode != ERROR_SERVICE_NOT_ACTIVE )
                ShowErrorMessage(remoteMachineName, &errCode);
            }
          }
          // Wait until it has stopped
          WaitForServiceToReachStatus(hService, SERVICE_STOPPED, pcfg.MaxWaitTime, remoteMachineName);
          // Then delete the service entry
          if ( hService && !DeleteService(hService) ) ShowErrorMessage(remoteMachineName, NULL);
          if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
          if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
          // Now remove the executable, ini file, logfile and extra file
          if ( !RSCC_DeleteFile(ExePathName, pcfg.writeDebugMessages) ) {
            strcpy(errStr, "Error deleting old executable on machine: ");
            strcat(errStr, remoteMachineName);
            ShowErrorMessage(errStr, NULL);
          }
          if ( !RSCC_DeleteFile(IniPathName, pcfg.writeDebugMessages) ) {
            strcpy(errStr, "Error deleting old inifile on machine: ");
            strcat(errStr, remoteMachineName);
            ShowErrorMessage(errStr, NULL);
          }
          if ( FileExists(LogPathName) ) {
            if ( !RSCC_DeleteFile(LogPathName, pcfg.writeDebugMessages) ) {
              strcpy(errStr, "Error deleting old logfile on machine: ");
              strcat(errStr, remoteMachineName);
              ShowErrorMessage(errStr, NULL);
            }
          }
          if ( strlen(serviceData.ExtraFrom) ) {
            if ( !RSCC_DeleteFile(ExtraPathName, pcfg.writeDebugMessages) ) {
              strcpy(errStr, "Error deleting old extra file on machine: ");
              strcat(errStr, remoteMachineName);
              ShowErrorMessage(errStr, NULL);
            }
          }
        } else {
          ShowErrorMessage(remoteMachineName, NULL);
        }
        if ( nrOfComputersSelected == 1 ) UpdateStatus(i, false, true);
      }
    }
    if ( nrOfComputersSelected > 1 ) UpdateStatus(0, true, true);
    Screen->Cursor = crDefault;
  }
}

//------------------------------------------------------------------------------
// Reinstall the service: we first remove it, then we move the buffer files
// and then we install the service.
//------------------------------------------------------------------------------
void __fastcall TMainForm::ReinstallServiceButtonClick(TObject* Sender)
{
  int i, n;
  unsigned int j;
  char* p;
  char tempFileName[MAX_PATH], networkPath[MAX_PATH];
  char remoteMachineName[MAX_PATH], ExePathName[MAX_PATH], IniPathName[MAX_PATH], ExtraPathName[MAX_PATH];
  AnsiString DestPath; // Destination path
  BOOL retVal;
  DWORD errCode;
  char errStr[256];
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  SERVICE_STATUS serviceStatus;

  if ( !ComputersListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    Screen->Cursor = crHourGlass;
    for (i = 0; i < ComputersListView->Items->Count; i++) {
      if ( ComputersListView->Items->Item[i]->Selected && ComputersListView->Items->Item[i]->Checked ) {
        strncpy(remoteMachineName, ComputersListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
        if ( IsServiceInstalled(remoteMachineName) ) {
          if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
            if ( (hService = OpenService(hscManager, serviceData.ServiceName, SERVICE_ALL_ACCESS)) == NULL ) {
              hService = NULL; // Reset hService
              ShowErrorMessage(remoteMachineName, NULL);
            }
            // First stop the service. We check the return value separately because
            // we don't want an errormessage when the service is already stopped.
            if ( hService) {
              // Find out what executable the service uses
              // We already have the exe name, now derive the ini filename:
              strcpy(tempFileName, "\\\\");
              // Add computer name
              strcat(tempFileName, ComputersListView->Items->Item[i]->Caption.c_str());
              strcat(tempFileName, "\\");
              // Add exe and path
              strcat(tempFileName, ComputersListView->Items->Item[i]->SubItems->Strings[lPathIndex].c_str());
              // Remove possible quotes from the name (could happen on existing installs)
              memset(networkPath, 0, sizeof(networkPath));
              for (n = 0, j = 0; j < strlen(tempFileName); j++) {
                if ( tempFileName[j] != '\"' ) {
                  networkPath[n] = tempFileName[j];
                  n++;
                }
              }
              networkPath[n] = 0;
              strcpy(tempFileName, networkPath);
              // Replace first : by $ to get network name
              for (j = 0; j < strlen(tempFileName); j++) {
                if ( tempFileName[j] == ':' ) {
                  tempFileName[j] = '$';
                  break;
                }
              }
              // Replace .exe by .ini. This also removes the bootparams part.
              p = strrchr(tempFileName, '.');
              if ( p ) *p = 0;
              strcpy(ExePathName, tempFileName);
              strcpy(IniPathName, tempFileName);
              strcat(IniPathName, ".ini");
              strcat(ExePathName, ".exe");
              strcpy(ExtraPathName, ExtractFilePath(tempFileName).c_str());
              strcat(ExtraPathName, ExtractFileName(serviceData.ExtraFrom).c_str());
              // Now stop the service if it runs.
              retVal= RSCC_ControlService(hService, SERVICE_CONTROL_STOP, &serviceStatus, pcfg.writeDebugMessages, remoteMachineName);
              if ( !retVal) {
                errCode = GetLastError();
                if ( errCode != ERROR_SERVICE_NOT_ACTIVE )
                  ShowErrorMessage(remoteMachineName, &errCode);
              }
            }
            // Wait until it has stopped
            WaitForServiceToReachStatus(hService, SERVICE_STOPPED, pcfg.MaxWaitTime, remoteMachineName);
            // Then delete the service entry
            if ( hService && !DeleteService(hService) ) ShowErrorMessage(remoteMachineName, NULL);
            if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
            if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
            // Check if the directory exists, create it if not
            DestPath = "\\\\" + AnsiString(remoteMachineName) + "\\" + AnsiString(serviceData.DirectoryTo);
            for (int i = 0; i < DestPath.Length(); i++) {
              if ( DestPath.c_str()[i] == ':') {
                DestPath.c_str()[i] = '$'; // Make system share path
                break;
              }
            }
            if ( !DirectoryExists(DestPath) ) {
              ForceDirectories(DestPath);
              if ( !DirectoryExists(DestPath) ) {
                strcpy(errStr, "Computer: ");
                strcat(errStr, remoteMachineName);
                strcat(errStr, "\nunable to create destination directory.\nThe service is not installed.");
                Application->MessageBox(errStr, Application->Title.c_str(), MB_OK|MB_ICONWARNING);
                break;
              }
            }
            // Now remove the executable and ini file
            if ( !RSCC_DeleteFile(ExePathName, pcfg.writeDebugMessages) ) {
              strcpy(errStr, "Error deleting old executable on machine: ");
              strcat(errStr, remoteMachineName);
              ShowErrorMessage(errStr, NULL);
            }
            if ( !RSCC_DeleteFile(IniPathName, pcfg.writeDebugMessages) ) {
              strcpy(errStr, "Error deleting old inifile on machine: ");
              strcat(errStr, remoteMachineName);
              ShowErrorMessage(errStr, NULL);
            }
            if ( strlen(serviceData.ExtraFrom) ) {
              if ( !RSCC_DeleteFile(ExtraPathName, pcfg.writeDebugMessages) ) {
                strcpy(errStr, "Error deleting old extra file on machine: ");
                strcat(errStr, remoteMachineName);
                ShowErrorMessage(errStr, NULL);
              }
            }
          } else {
            ShowErrorMessage(remoteMachineName, NULL);
          }
        }
      }
    }
    Screen->Cursor = crDefault;
  }
  // Now re-install the service
  InstallButtonClick(Sender);
}

//------------------------------------------------------------------------------
// Update the service. We stop the service, copy new binaries to the location of
// the old binaries (need not be the installation dir from the default settings)
// and restart the service.
//------------------------------------------------------------------------------
void __fastcall TMainForm::UpdateServiceButtonClick(TObject* Sender)
{
  int i, n;
  unsigned int j;
  char* p;
  char tempFileName[MAX_PATH], networkPath[MAX_PATH];
  char remoteMachineName[MAX_PATH], ExePathName[MAX_PATH], IniPathName[MAX_PATH], ExtraPathName[MAX_PATH];
  BOOL retVal;
  DWORD errCode;
  char errStr[256];
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  SERVICE_STATUS serviceStatus;
  // Number of selected computers
  int nrOfComputersSelected = ComputersListView->SelCount;

  if ( !ComputersListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    Screen->Cursor = crHourGlass;
    for (i = 0; i < ComputersListView->Items->Count; i++) {
      if ( ComputersListView->Items->Item[i]->Selected && ComputersListView->Items->Item[i]->Checked ) {
        strncpy(remoteMachineName, ComputersListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
        // Reset hService
        hService = NULL;
        if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
          if ( (hService = OpenService(hscManager, serviceData.ServiceName, SERVICE_ALL_ACCESS)) == NULL ) {
            ShowErrorMessage(remoteMachineName, NULL);
          }
          // First stop the service. We check the return value separately because
          // we don't want an errormessage when the service is already stopped.
          if ( hService) {
            // Find out what executable the service uses
            // We already have the exe name, now derive the ini filename:
            strcpy(tempFileName, "\\\\");
            // Add computer name
            strcat(tempFileName, ComputersListView->Items->Item[i]->Caption.c_str());
            strcat(tempFileName, "\\");
            // Add exe and path
            strcat(tempFileName, ComputersListView->Items->Item[i]->SubItems->Strings[lPathIndex].c_str());
            // Remove possible quotes from the name (could happen on existing installs)
            memset(networkPath, 0, sizeof(networkPath));
            for (n = 0, j = 0; j < strlen(tempFileName); j++) {
              if ( tempFileName[j] != '\"' ) {
                networkPath[n] = tempFileName[j];
                n++;
              }
            }
            networkPath[n] = 0;
            strcpy(tempFileName, networkPath);
            // Replace first : by $ to get network name
            for (j = 0; j < strlen(tempFileName); j++) {
              if ( tempFileName[j] == ':' ) {
                tempFileName[j] = '$';
                break;
              }
            }
            // Replace .exe by .ini. This also removes the bootparams part.
            p = strrchr(tempFileName, '.');
            if ( p ) *p = 0;
            strcpy(ExePathName, tempFileName);
            strcpy(IniPathName, tempFileName);
            strcat(IniPathName, ".ini");
            strcat(ExePathName, ".exe");
            strcpy(ExtraPathName, ExtractFilePath(tempFileName).c_str());
            strcat(ExtraPathName, ExtractFileName(serviceData.ExtraFrom).c_str());
            // Now stop the service if it runs.
            retVal= RSCC_ControlService(hService, SERVICE_CONTROL_STOP, &serviceStatus, pcfg.writeDebugMessages, remoteMachineName);
            if ( !retVal) {
              errCode = GetLastError();
              if ( errCode != ERROR_SERVICE_NOT_ACTIVE )
                ShowErrorMessage(remoteMachineName, &errCode);
            }
            // Wait until it has stopped
            WaitForServiceToReachStatus(hService, SERVICE_STOPPED, pcfg.MaxWaitTime, remoteMachineName);
            if ( nrOfComputersSelected == 1 ) UpdateStatus(i, false, true);
            // Now remove the executable and ini file
            if ( !RSCC_DeleteFile(ExePathName, pcfg.writeDebugMessages) ) {
              strcpy(errStr, "Error deleting old executable on machine: ");
              strcat(errStr, remoteMachineName);
              ShowErrorMessage(errStr, NULL);
            }
            if ( !RSCC_DeleteFile(IniPathName, pcfg.writeDebugMessages) ) {
              strcpy(errStr, "Error deleting old inifile on machine: ");
              strcat(errStr, remoteMachineName);
              ShowErrorMessage(errStr, NULL);
            }
            if ( strlen(serviceData.ExtraFrom) ) {
              if ( !RSCC_DeleteFile(ExtraPathName, pcfg.writeDebugMessages) ) {
                strcpy(errStr, "Error deleting old extra file on machine: ");
                strcat(errStr, remoteMachineName);
                ShowErrorMessage(errStr, NULL);
              }
            }
            // Now copy the new files
            if ( !RSCC_CopyFile(serviceData.ExeFrom, ExePathName, FALSE, pcfg.writeDebugMessages) )
              ShowErrorMessage(remoteMachineName, NULL);
            if ( !RSCC_CopyFile(serviceData.IniFrom, IniPathName, FALSE, pcfg.writeDebugMessages) )
              ShowErrorMessage(remoteMachineName, NULL);
            if ( strlen(serviceData.ExtraFrom) )
              if ( !RSCC_CopyFile(serviceData.ExtraFrom, ExtraPathName, FALSE, pcfg.writeDebugMessages) )
                ShowErrorMessage(remoteMachineName, NULL);
            // Now restart the service
            if ( serviceData.StartOnInstall ) {
              if ( !RSCC_StartService(hService, 0, NULL, pcfg.writeDebugMessages, remoteMachineName) )
                ShowErrorMessage(remoteMachineName, NULL);
            }
          }
        } else {
          ShowErrorMessage(remoteMachineName, NULL);
        }
        // Only update status if we got a valid service handle.
        if ( hService && (nrOfComputersSelected == 1) ) {
          if ( serviceData.StartOnInstall )
            WaitForServiceToReachStatus(hService, SERVICE_RUNNING, pcfg.MaxWaitTime, remoteMachineName);
          UpdateStatus(i, false, true);
        }
        // Now close the service handle and service manager
        if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
        if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
      }
    }
    if ( nrOfComputersSelected > 1 ) UpdateStatus(0, true, true);
    Screen->Cursor = crDefault;
  }
}

//------------------------------------------------------------------------------
// Starts the service on the selected computer. The service is assumed to be
// already installed.
//------------------------------------------------------------------------------
void __fastcall TMainForm::StartButtonClick(TObject* Sender)
{
  int i;
  char remoteMachineName[MAX_PATH];
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  // Number of selected computers
  int nrOfComputersSelected = ComputersListView->SelCount;

  if ( !ComputersListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    Screen->Cursor = crHourGlass;
    for (i = 0; i < ComputersListView->Items->Count; i++) {
      if ( ComputersListView->Items->Item[i]->Selected && ComputersListView->Items->Item[i]->Checked ) {
        strncpy(remoteMachineName, ComputersListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
        if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
          if ( (hService = OpenService(hscManager, serviceData.ServiceName, SERVICE_ALL_ACCESS)) == NULL ) {
            hService = NULL; // Reset hService
            ShowErrorMessage(remoteMachineName, NULL);
          } else { // Service != NULL
            if ( !RSCC_StartService(hService, 0, NULL, pcfg.writeDebugMessages, remoteMachineName) )
              ShowErrorMessage(remoteMachineName, NULL);
            // Show service status
            if ( nrOfComputersSelected == 1 ) {
              UpdateStatus(i, false, false);
              WaitForServiceToReachStatus(hService, SERVICE_RUNNING, pcfg.MaxWaitTime, remoteMachineName);
              UpdateStatus(i, false, false);
            } else {
              WaitForServiceToReachStatus(hService, SERVICE_RUNNING, pcfg.MaxWaitTime, remoteMachineName);
            }
          }
          if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
          if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
        } else {
          ShowErrorMessage(remoteMachineName, NULL);
        }
      }
    }
    if ( nrOfComputersSelected > 1 ) UpdateStatus(0, true, false);
    Screen->Cursor = crDefault;
  }
}

//------------------------------------------------------------------------------
// Stops the service on the selected computer(s)
//------------------------------------------------------------------------------
void __fastcall TMainForm::StopButtonClick(TObject* Sender)
{
  SendStandardSignalToRemoteService(SERVICE_CONTROL_STOP);
}

//------------------------------------------------------------------------------
// Pauses the service on the selected computer(s)
//------------------------------------------------------------------------------
void __fastcall TMainForm::Pauseservice1Click(TObject* Sender)
{
  SendStandardSignalToRemoteService(SERVICE_CONTROL_PAUSE);
}

//------------------------------------------------------------------------------
// Continues the service on the selected computer(s)
//------------------------------------------------------------------------------
void __fastcall TMainForm::Continueservice1Click(TObject* Sender)
{
  SendStandardSignalToRemoteService(SERVICE_CONTROL_CONTINUE);
}

//------------------------------------------------------------------------------
// Tells the service to reload its configuration
//------------------------------------------------------------------------------
void __fastcall TMainForm::Reload1Click(TObject* Sender)
{
  SendSignalToRemoteService(SERVICE_CONTROL_RELOAD_CONFIG);
}

//------------------------------------------------------------------------------
// Tells the service to execute the command in its inifile.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Runcommand1Click(TObject* Sender)
{
  SendSignalToRemoteService(SERVICE_CONTROL_RUNCOMMAND);
}

//------------------------------------------------------------------------------
// Tell the service to remove its logfile. This is faster than removing it
// with deletefile.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Removelog1Click(TObject* Sender)
{
  SendSignalToRemoteService(SERVICE_CONTROL_REMOVELOGFILE);
}

//------------------------------------------------------------------------------
// Sends a standard control code to a remote service.
//------------------------------------------------------------------------------
void __fastcall TMainForm::SendStandardSignalToRemoteService(DWORD dwControl)
{
  int i;
  char remoteMachineName[MAX_PATH];
  bool retVal;
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  SERVICE_STATUS serviceStatus;
  // Number of selected computers
  int nrOfComputersSelected = ComputersListView->SelCount;
  DWORD endStatus = GetResultingStatusFromControlCode(dwControl);

  if ( !ComputersListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    Screen->Cursor = crHourGlass;
    for (i = 0; i < ComputersListView->Items->Count; i++) {
      if ( ComputersListView->Items->Item[i]->Selected && ComputersListView->Items->Item[i]->Checked ) {
        strncpy(remoteMachineName, ComputersListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
        if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
          if ( (hService = OpenService(hscManager, serviceData.ServiceName, SERVICE_ALL_ACCESS)) == NULL ) {
            hService = NULL; // Reset hService
            ShowErrorMessage(remoteMachineName, NULL);
          } else { // Service != NULL
            retVal = RSCC_ControlService(hService, dwControl, &serviceStatus, pcfg.writeDebugMessages, remoteMachineName);
            if ( !retVal ) ShowErrorMessage(remoteMachineName, NULL);
            // Show service status. We only do this if endStatus != 0.
            if ( nrOfComputersSelected == 1 && retVal && endStatus ) {
              UpdateStatus(i, false, false);
              WaitForServiceToReachStatus(hService, endStatus, pcfg.MaxWaitTime, remoteMachineName);
              UpdateStatus(i, false, false);
            } else if (retVal && endStatus) {
              WaitForServiceToReachStatus(hService, endStatus, pcfg.MaxWaitTime, remoteMachineName);
            }
          }
          if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
          if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
        } else {
          ShowErrorMessage(remoteMachineName, NULL);
        }
      }
    }
    if ( (nrOfComputersSelected > 1) && retVal && endStatus ) UpdateStatus(0, true, false);
    Screen->Cursor = crDefault;
  }
}

//------------------------------------------------------------------------------
// Sends an arbitrary control code to a remote service. If a non-standard code
// is to be sent then this code should be >= 0x80, others are reserved by NT.
// Win2000 has a control code SERVICE_CONTROL_PARAMCHANGE (0x00000006) but we
// do not use this since NT 4 cannot handle this code.
// We also do not wait for the service to reach a status or update the screen.
//------------------------------------------------------------------------------
void __fastcall TMainForm::SendSignalToRemoteService(DWORD dwControl)
{
  int i;
  char remoteMachineName[MAX_PATH];
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  SERVICE_STATUS serviceStatus;

  if ( !ComputersListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    Screen->Cursor = crHourGlass;
    for (i = 0; i < ComputersListView->Items->Count; i++) {
      if ( ComputersListView->Items->Item[i]->Selected && ComputersListView->Items->Item[i]->Checked ) {
        strncpy(remoteMachineName, ComputersListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
        if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
          if ( (hService = OpenService(hscManager, serviceData.ServiceName, SERVICE_ALL_ACCESS)) == NULL ) {
            hService = NULL; // Reset hService
            ShowErrorMessage(remoteMachineName, NULL);
          } else { // Service != NULL
            if ( !RSCC_ControlService(hService, dwControl, &serviceStatus, pcfg.writeDebugMessages, remoteMachineName) )
              ShowErrorMessage(remoteMachineName, NULL);
/*
            if ( !RSCC_ControlService(hService, SERVICE_CONTROL_CAPSSTAT, &serviceStatus, pcfg.writeDebugMessages, remoteMachineName) )
              ShowErrorMessage(remoteMachineName, NULL);
            // Check if the service did recognize the control code
            if ((dwControl >= 0x80) &&
                (serviceStatus.dwWin32ExitCode == ERROR_SERVICE_SPECIFIC_ERROR) &&
                !CheckResponseFromClient(dwControl, serviceStatus.dwCheckPoint)) {
              AnsiString serviceState = "The service did not recognize command \"" + ControlcodeDescription(dwControl) + "\"";
              Application->MessageBox(serviceState.c_str(), remoteMachineName, MB_OK);
            }
*/
          }
          if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
          if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
        } else {
          ShowErrorMessage(remoteMachineName, NULL);
        }
      }
    }
    Screen->Cursor = crDefault;
  }
}

//------------------------------------------------------------------------------
// Checks the response from the service when dwControl has been sent to it.
// The responsCode should be
// ((X)<<24)+(('M')<<16)+(('o')<<8)+(('o')<<0) "xMoo" where 'X'
// is a bitfield that you can use to determine which commands are
// currently in progress: 1<<(command_number - 0x80). This value
// would be set whenever serviceStatus.dwCurrentState == SERVICE_RUNNING
//------------------------------------------------------------------------------
bool __fastcall TMainForm::CheckResponseFromClient(DWORD dwControl, DWORD responseCode)
{
  // TEMPORARY CODE UNTIL THIS WORKS IN THE SERVICE
//  responseCode = ((dwControl - 0x80)<<24)+(('M')<<16)+(('o')<<8)+(('o')<<0);
  // END TEMPORARY CODE

  DWORD response = (responseCode >> 24) + 0x80; // No mask necessary
  bool Moo1 = (char)((responseCode & 0x00FF0000) >> 16) == 'M';
  bool Moo2 = (char)((responseCode & 0x0000FF00) >> 8) == 'o';
  bool Moo3 = (char)(responseCode & 0x000000FF) == 'o';
  return(Moo1 && Moo2 && Moo3 && (response == dwControl));
}

//------------------------------------------------------------------------------
// Returns the string that belongs to a service action.
//------------------------------------------------------------------------------
AnsiString __fastcall TMainForm::ControlcodeDescription(DWORD dwControl)
{
  AnsiString Result;
  switch ( dwControl ) {
    // Standard control codes
    case SERVICE_CONTROL_STOP:
         Result = "SERVICE_CONTROL_STOP";
         break;
    case SERVICE_CONTROL_PAUSE:
         Result = "SERVICE_CONTROL_PAUSE";
         break;
    case SERVICE_CONTROL_CONTINUE:
         Result = "SERVICE_CONTROL_CONTINUE";
         break;
    case SERVICE_CONTROL_INTERROGATE:
         Result = "SERVICE_CONTROL_INTERROGATE";
         break;
    case SERVICE_CONTROL_SHUTDOWN:
         Result = "SERVICE_CONTROL_SHUTDOWN";
         break;
    // Windows 2000 specific code
    case SERVICE_CONTROL_PARAMCHANGE:
         Result = "SERVICE_CONTROL_PARAMCHANGE";
         break;
    // User-defined control codes
    case SERVICE_CONTROL_RUNCOMMAND:
         Result = "SERVICE_CONTROL_RUNCOMMAND";
         break;
    case SERVICE_CONTROL_CAPSSTAT:
         Result = "SERVICE_CONTROL_CAPSSTAT";
         break;
    case SERVICE_CONTROL_RELOAD_CONFIG:
         Result = "SERVICE_CONTROL_RELOAD_CONFIG";
         break;
    case SERVICE_CONTROL_REMOVELOGFILE:
         Result = "SERVICE_CONTROL_REMOVELOGFILE";
         break;
    default:
      Result = "Unknown code";
  }
  return Result;
}

//------------------------------------------------------------------------------
// Gets the resulting status code that should result from the action dwControl.
//------------------------------------------------------------------------------
DWORD __fastcall TMainForm::GetResultingStatusFromControlCode(DWORD dwControl)
{
  switch ( dwControl ) {
    // Standard control codes
    case SERVICE_CONTROL_STOP:
         return SERVICE_STOPPED;
    case SERVICE_CONTROL_PAUSE:
         return SERVICE_PAUSED;
    case SERVICE_CONTROL_CONTINUE:
         return SERVICE_RUNNING;
    case SERVICE_CONTROL_INTERROGATE:
         return 0;
    case SERVICE_CONTROL_SHUTDOWN:
         return SERVICE_STOPPED;
    // Windows 2000 specific code
    case SERVICE_CONTROL_PARAMCHANGE:
         return 0;
    default:
      return 0;
    }
}

//------------------------------------------------------------------------------
// Shows the add computer form where a name can be entered.
//------------------------------------------------------------------------------
void __fastcall TMainForm::AddPCButtonClick(TObject* Sender)
{
  TListItem* L;
  bool addAnyWay = true; // Add a non-NT machine if add only NT machines is selected?
  char newName[64];
  TModalResult mrRes;
  TAddComputerForm* AddComputerForm;

  memset(newName, 0, sizeof(newName));
  AddComputerForm = new TAddComputerForm(this, newName, sizeof(newName));
  if ( AddComputerForm ) {
    mrRes = AddComputerForm->ShowModal();
    if ( mrRes == mrOk ) {
      // See if it is an NT machine if we want to add only NT machines
      if ( pcfg.addOnlyNTMachines ) {
        if ( GetRemotePlatformType((LPTSTR)newName) < 2000 ) {
          if ( Application->MessageBox("This machine appears not to be running windows NT or 2000, add anyway?", Application->Title.c_str(), MB_YESNO | MB_ICONWARNING) == ID_NO) {
            addAnyWay = false;
          }
        }
      }
      if ( addAnyWay ) {
        if ( !NameIsDouble(newName, ComputersListView) ) {
          // This prevents errors with indices
          ComputersListView->SortType = stNone;
          // Computername in listitem
          L = ComputersListView->Items->Add();
          L->Caption = AnsiString(newName);
          // Add subitem for status
          L->SubItems->Add("");
          // Add subitem for service path
          L->SubItems->Add("");
          // Add subitem for service version
          L->SubItems->Add("");
          // Add subitem for command
          L->SubItems->Add("");
          // Add subitem for log
          L->SubItems->Add("");
          // Add subitem for interact with desktop
          L->SubItems->Add("");
          // We check the new computer after adding
          L->Checked = true;
          // Update the status
          UpdateStatus(ComputersListView->Items->IndexOf(L), false, true);
        }
      }
    }
  }
  // Store the names in the configuration
  StoreComputerNames();
}

//------------------------------------------------------------------------------
// Removes the selected PC from the list.
//------------------------------------------------------------------------------
void __fastcall TMainForm::RemPCButtonClick(TObject* Sender)
{
  int i;

  for(i = 0; i < ComputersListView->Items->Count; i++) {
    if ( ComputersListView->Items->Item[i]->Selected ) {
      ComputersListView->Items->Item[i]->SubItems->Delete(lInteractIndex); // Delete service interaction
      ComputersListView->Items->Item[i]->SubItems->Delete(lLogIndex); // Delete service logging
      ComputersListView->Items->Item[i]->SubItems->Delete(lCommandIndex); // Delete service command
      ComputersListView->Items->Item[i]->SubItems->Delete(lVersionIndex); // Delete service version number
      ComputersListView->Items->Item[i]->SubItems->Delete(lPathIndex); // Delete service path
      ComputersListView->Items->Item[i]->SubItems->Delete(lStatusIndex); // Delete statusline
      ComputersListView->Items->Delete(i);                    // Delete computername
      // Go back since the ListBox count has now decreased
      i--;
    }
  }
  // Store the names in the configuration
  StoreComputerNames();
}

//------------------------------------------------------------------------------
// Get the status of the selected computer
//------------------------------------------------------------------------------
void __fastcall TMainForm::ConfigButtonClick(TObject* Sender)
{
  int i;
  char buffer[2048];
  char remoteMachineName[MAX_PATH];
  // Config params
  DWORD dwServiceType;
  DWORD dwStartType;
  char lpBinaryPathName[MAX_PATH];
  char lpServiceStartName[MAX_PATH];
  char lpDisplayName[MAX_PATH];
  char* lpServiceAccountName1;
  char* lpPassword1;
  DWORD bytesNeeded;
  TConfigForm* ConfigForm;
  bool doChangeConfig = false; // Is set to true when the config should be changed
  bool canChangeConfig; // Is set to false when we can't change the config
  ChangeServiceConfigData serviceConfigData;
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;

  if ( !ComputersListView->SelCount ) {
    Application->MessageBox("No computers are selected.", Application->Title.c_str(), MB_OK);
  } else {
    for (i = 0; i < ComputersListView->Items->Count; i++) {
      if ( ComputersListView->Items->Item[i]->Selected && ComputersListView->Items->Item[i]->Checked ) {
        strncpy(remoteMachineName, ComputersListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
        Screen->Cursor = crHourGlass;
        if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) == 0 ) {
          // We can't get SC_MANAGER_ALL_ACCESS, try SC_MANAGER_CONNECT for read only access.
          canChangeConfig = false;
          if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_CONNECT)) == 0 ) {
            // Set it explicitly to NULL since OpenSCManager doesn't reset it if it fails.
            hscManager = NULL;
          }
        } else canChangeConfig = true;
        if ( hscManager ) {
          if ( canChangeConfig ) { // Try to get a service handle with ALL_ACCESS
            if ( (hService = OpenService(hscManager, serviceData.ServiceName, SERVICE_ALL_ACCESS)) == NULL )
              hService = NULL; // Reset value. This is necessary since the OpenService calls does not reset it if it fails.
          } else { // Try to get a read-only service handle.
            if ( (hService = OpenService(hscManager, serviceData.ServiceName, SERVICE_QUERY_CONFIG)) == NULL )
              hService = NULL;
          }
          if ( hService ) {
            memset(serviceConfigData.lpPassword, 0, sizeof(serviceConfigData.lpPassword));
            QueryServiceConfig(hService, (QUERY_SERVICE_CONFIG*)buffer, sizeof(buffer), &bytesNeeded);
            // Save the data
            dwServiceType = ((QUERY_SERVICE_CONFIG*)buffer)->dwServiceType;
            dwStartType = ((QUERY_SERVICE_CONFIG*)buffer)->dwStartType;
            strcpy(lpBinaryPathName, ((QUERY_SERVICE_CONFIG*)buffer)->lpBinaryPathName);
            strcpy(lpServiceStartName, ((QUERY_SERVICE_CONFIG*)buffer)->lpServiceStartName);
            strcpy(lpDisplayName, ((QUERY_SERVICE_CONFIG*)buffer)->lpDisplayName);
            // Show configurationform
            ConfigForm = new TConfigForm(this,
                                         canChangeConfig,
                                         dwServiceType,
                                         dwStartType,
                                         lpBinaryPathName,
                                         lpServiceStartName,
                                         lpDisplayName,
                                         remoteMachineName,
                                         &doChangeConfig,
                                         &serviceConfigData);
            if ( ConfigForm ) {
              ConfigForm->ShowModal();
              delete ConfigForm;
            } else {
              ShowErrorMessage("Error creating form", NULL);
            }
            if ( doChangeConfig ) {
              // Check account data. NULL means no change in account.
              if ( strlen(serviceConfigData.lpServiceStartName) > 0 )
                lpServiceAccountName1 = serviceConfigData.lpServiceStartName;
              else
                lpServiceAccountName1 = NULL;
              // Check password data. NULL means no change.
              if ( strlen(serviceConfigData.lpPassword) > 0 )
                lpPassword1 = serviceConfigData.lpPassword;
              else if ( lpServiceAccountName1 )
                lpPassword1 = ""; // Empty password, we can't use NULL here
              else
                lpPassword1 = NULL;
              // Change the config
              if ( !ChangeServiceConfig(hService,
                                        serviceConfigData.dwServiceType,
                                        serviceConfigData.dwStartType,
                                        serviceConfigData.dwErrorControl,
                                        serviceConfigData.lpBinaryPathName,
                                        NULL, NULL, NULL,
                                        lpServiceAccountName1,
                                        lpPassword1,
                                        serviceConfigData.lpDisplayName) )
                ShowErrorMessage(remoteMachineName, NULL);
                // Update service status (interaction parameter could have changed)
                if ( ComputersListView->SelCount == 1 )
                  UpdateStatus(i, false, false);
            }
            Screen->Cursor = crDefault;
          } else {
            Screen->Cursor = crDefault;
            ShowErrorMessage(remoteMachineName, NULL);
          }
          if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
          if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
        } else {
          ShowErrorMessage(remoteMachineName, NULL);
        }
      }
    }
  }
  if ( ComputersListView->SelCount > 1) UpdateStatus(0, true, false);
  Screen->Cursor = crDefault;
}

//------------------------------------------------------------------------------
// Edit the inifile on the selected remote computer(s)
//------------------------------------------------------------------------------
void __fastcall TMainForm::EditCommandButtonClick(TObject* Sender)
{
  int i;
  unsigned int  j, k, n;
  char* p;
  char iniFileName[MAX_PATH], tempFileName[MAX_PATH], tempFileName2[MAX_PATH];
  char errMsg[MAX_PATH + 16];
  TEditForm* EditForm;

  if ( !ComputersListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    for (i = 0; i < ComputersListView->Items->Count; i++) {
      if ( ComputersListView->Items->Item[i]->Selected && ComputersListView->Items->Item[i]->Checked ) {
        // We already have the exe name, now derive the ini filename:
        strncpy(tempFileName, ComputersListView->Items->Item[i]->SubItems->Strings[lPathIndex].c_str(), sizeof(tempFileName) - 1);
        // Make filename lowercase
        for (k = 0; k < strlen(tempFileName); k++) tempFileName[k] = (char)tolower(tempFileName[k]);
        // Remove possible quotes from the name (could happen on existing installs)
        memset(tempFileName2, 0, sizeof(tempFileName2));
        for (n = 0, k = 0; k < strlen(tempFileName); k++) {
          if ( tempFileName[k] != '\"' ) {
            tempFileName2[n] = tempFileName[k];
            n++;
          }
        }
        strcpy(iniFileName, "\\\\");
        // Add computer name
        strcat(iniFileName, ComputersListView->Items->Item[i]->Caption.c_str());
        strcat(iniFileName, "\\");
        // Add filename part
        strcat(iniFileName, tempFileName2);
        // Replace .exe by .ini. This also removes the bootparams part.
        p = strrchr(iniFileName, '.');
        if ( p ) *p = 0;
        strcat(iniFileName, ".ini");
        // Replace first : by $ to get network name
        for (j = 0; j < strlen(iniFileName); j++) {
          if ( iniFileName[j] == ':' ) {
            iniFileName[j] = '$';
            break;
          }
        }
        if ( FileExists(iniFileName) ) {
          EditForm = new TEditForm(this, iniFileName);
          if ( EditForm ) {
            if ( EditForm->ShowModal() == mrOk ) UpdateStatus(i, false, true);
            delete EditForm;
          }
        } else {
          // Only warn if the service manager is present, the service is
          // installed and we STILL can't open the inifile.
          if ( IsServiceInstalled(ComputersListView->Items->Item[i]->Caption.c_str()) &&
                IsServiceManagerInstalled(ComputersListView->Items->Item[i]->Caption.c_str()) ) {
            strcpy(errMsg, "File not found: ");
            strcat(errMsg, iniFileName);
            Application->MessageBox(errMsg, Application->Title.c_str(), MB_OK);
          }
        }
      }
    }
  }
}

//------------------------------------------------------------------------------
// Update the status information for all computers which are checked
//------------------------------------------------------------------------------
void __fastcall TMainForm::UpdateButtonClick(TObject* Sender)
{
  UpdateStatus(0, true, true);
}

//------------------------------------------------------------------------------
//Creates and shows the settings form
//------------------------------------------------------------------------------
void __fastcall TMainForm::DefaultButtonClick(TObject* Sender)
{
  TDefaultsForm* DefaultsForm = new TDefaultsForm(this, &serviceData);
  DefaultsForm->ShowModal();
  delete DefaultsForm;
}

//------------------------------------------------------------------------------
// Add (new) network computers
//------------------------------------------------------------------------------
void __fastcall TMainForm::NetworkButtonClick(TObject* Sender)
{
  int i;
  int initialCount = ComputersListView->Items->Count;

  GetNetworkComputerNames(false, false);
  // See which checkboxes need to be checked
  for (i = initialCount; i < ComputersListView->Items->Count; i++) {
    if ( ProgramSettingsFile->ReadInteger(ComputerNamesIniSection, ComputersListView->Items->Item[i]->Caption, 0) == 1 )
      ComputersListView->Items->Item[i]->Checked = true;
  }
}

//------------------------------------------------------------------------------
// Edit the use account under which the program tries to run
//------------------------------------------------------------------------------
void __fastcall TMainForm::SwitchAccountButtonClick(TObject* Sender)
{
  char* domainName;
  bool Change = false;  

  TAccountForm* AccountForm = new TAccountForm(this,
                                               pcfg.Username,
                                               pcfg.Domain,
                                               pcfg.Password,
                                               sizeof(pcfg.Username),
                                               sizeof(pcfg.Domain),
                                               sizeof(pcfg.Password),
                                               &pcfg.SwitchUserID,
                                               &Change);
  if ( AccountForm ) {
    AccountForm->ShowModal();
    delete AccountForm;
  }
  if ( Change ) {
    // Drop priviliges
    if (hToken && !CloseHandle(hToken) ) ShowErrorMessage("CloseHandle", NULL);
    if ( pcfg.SwitchUserID && !RevertToSelf() ) ShowErrorMessage("RevertToSelf", NULL);
    // Domain name need not be specified
    if ( pcfg.Domain && strlen(pcfg.Domain) ) domainName = pcfg.Domain;
    else domainName = NULL;

    // The SE_TCB_NAME privilige is required for this call to work.
    if ( !LogonUser(pcfg.Username, domainName, pcfg.Password,
                    LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, &hToken) )
      ShowErrorMessage("LogonUser", NULL);

    if ( hToken ) {
      if ( !ImpersonateLoggedOnUser(hToken) ) {
        ShowErrorMessage("ImpersonateLoggedOnUser", NULL);
      } else
        UpdateStatus(0, true, true);
    }
  }
}

//------------------------------------------------------------------------------
// Show the helpform
//------------------------------------------------------------------------------
void __fastcall TMainForm::HelpButtonClick(TObject* Sender)
{
  THelpForm* HelpForm = new THelpForm(this);
  if ( HelpForm ) {
    HelpForm->ShowModal();
    delete HelpForm;
  }
}

//------------------------------------------------------------------------------
// Show program information
//------------------------------------------------------------------------------
void __fastcall TMainForm::AboutButtonClick(TObject* Sender)
{
  AboutForm->ShowModal();
}

//------------------------------------------------------------------------------
// See which computer is selected, store this in the computername menuitem caption.
//------------------------------------------------------------------------------
void __fastcall TMainForm::ComputersListViewMouseDown(TObject* Sender, TMouseButton Button, TShiftState Shift, int X, int Y)
{
  // Find the computer on which the mouse button was downed
  CurrActiveItem = ComputersListView->GetItemAt(X, Y);
  // Store this in the popup menu upper caption.
  if ( CurrActiveItem )
    Computername1->Caption = CurrActiveItem->Caption;
  else
    Computername1->Caption = "No computer selected";
}

//------------------------------------------------------------------------------
// Adapt the listbox: select ONLY the computer that is clicked on so all
// methods only work on this one.
//------------------------------------------------------------------------------
void __fastcall TMainForm::RsccPopupMenuPopup(TObject* Sender)
{
  int i;
  bool found = false;
  // Find out which computer is clicked on and select only that item
  for (i = 0; i < ComputersListView->Items->Count; i++) {
    if ( ComputersListView->Items->Item[i]->Caption != Computername1->Caption )
      ComputersListView->Items->Item[i]->Selected = false;
    else {
      ComputersListView->Items->Item[i]->Selected = true;
      found = true; // Fount at least one match
      break;
    }
  }
  // No computers selected
  if ( !found || !ComputersListView->Items->Item[i]->Checked ) {
    Installservice2->Enabled = false;
    Removeservice2->Enabled = false;
    Reinstallservice2->Enabled = false;
    Updateservice2->Enabled = false;
    Startservice2->Enabled = false;
    Stopservice2->Enabled = false;
    Reload2->Enabled = false;
    Runcommand2->Enabled = false;
    Removelog2->Enabled = false;
    Configureservice2->Enabled = false;
    EditIni2->Enabled = false;
    Logfile2->Enabled = false;
  // No service manager found
  } else if ( !IsServiceManagerInstalled(Computername1->Caption.c_str()) ) {
    Installservice2->Enabled = false;
    Removeservice2->Enabled = false;
    Reinstallservice2->Enabled = false;
    Updateservice2->Enabled = false;
    Startservice2->Enabled = false;
    Stopservice2->Enabled = false;
    Reload2->Enabled = false;
    Runcommand2->Enabled = false;
    Removelog2->Enabled = false;
    Configureservice2->Enabled = false;
    EditIni2->Enabled = false;
    Logfile2->Enabled = false;
  } else {
    // Not installed
    if ( !IsServiceInstalled(Computername1->Caption.c_str()) ) {
      Installservice2->Enabled = true;
      Removeservice2->Enabled = false;
      Reinstallservice2->Enabled = false;
      Updateservice2->Enabled = false;
      Startservice2->Enabled = false;
      Stopservice2->Enabled = false;
      Reload2->Enabled = false;
      Runcommand2->Enabled = false;
      Removelog2->Enabled = false;
      Configureservice2->Enabled = false;
      EditIni2->Enabled = false;
      Logfile2->Enabled = false;
    // Installed but not running
    } else if ( !IsServiceRunning(Computername1->Caption.c_str()) ) {
      Installservice2->Enabled = false;
      Removeservice2->Enabled = true;
      Reinstallservice2->Enabled = true;
      Updateservice2->Enabled = true;
      Startservice2->Enabled = true;
      Stopservice2->Enabled = false;
      Reload2->Enabled = false;
      Runcommand2->Enabled = false;
      Removelog2->Enabled = false;
      Configureservice2->Enabled = true;
      EditIni2->Enabled = true;
      Logfile2->Enabled = true;
    // Instaled and running
    } else {
      Installservice2->Enabled = false;
      Removeservice2->Enabled = true;
      Reinstallservice2->Enabled = true;
      Updateservice2->Enabled = true;
      Startservice2->Enabled = false;
      Stopservice2->Enabled = true;
      Reload2->Enabled = true;
      Runcommand2->Enabled = true;
      Removelog2->Enabled = true;
      Configureservice2->Enabled = true;
      EditIni2->Enabled = true;
      Logfile2->Enabled = true;
    }
  }
}

//------------------------------------------------------------------------------
// Sort the list depending on which column is clicked
//------------------------------------------------------------------------------
void __fastcall TMainForm::ComputersListViewColumnClick(TObject* Sender, TListColumn* Column)
{
  ColumnClicked = Column->Index;
  // Set to stNone to assure that the sorting routine will be called
  ComputersListView->SortType = stNone;
  ComputersListView->SortType = stText;
}

//------------------------------------------------------------------------------
// Compare 2 listview items
//------------------------------------------------------------------------------
void __fastcall TMainForm::ComputersListViewCompare(TObject* Sender, TListItem* Item1, TListItem* Item2, int Data, int& Compare)
{
  AnsiString s1, s2;

  // Alphabetical sorting
  if ( !ColumnClicked )
    Compare = strcmp(Item1->Caption.c_str(), Item2->Caption.c_str());
  else {
    s1 = Item1->SubItems->Strings[ColumnClicked - 1];
    s2 = Item2->SubItems->Strings[ColumnClicked - 1];
    Compare = strcmp(s1.c_str(), s2.c_str());
  }
}

//------------------------------------------------------------------------------
// Shows the logfile.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Logfile1Click(TObject* Sender)
{
  int i;
  unsigned int  j, k, n;
  char* p;
  char logFileName[MAX_PATH], tempFileName[MAX_PATH], tempFileName2[MAX_PATH];
  TViewLogFileForm* ViewLogFileForm;
  TViewLogFileForm* l;

  if ( !ComputersListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    for (i = 0; i < ComputersListView->Items->Count; i++) {
      // We only try to find logfiles if the computer is both selected AND checked.
      if ( ComputersListView->Items->Item[i]->Selected && ComputersListView->Items->Item[i]->Checked ) {
        // We already have the exe name, now derive the logfilename:
        strncpy(tempFileName, ComputersListView->Items->Item[i]->SubItems->Strings[lPathIndex].c_str(), sizeof(tempFileName) - 1);
        // Make filename lowercase
        for (k = 0; k < strlen(tempFileName); k++) tempFileName[k] = (char)tolower(tempFileName[k]);
        // Remove possible quotes from the name (could happen on existing installs)
        memset(tempFileName2, 0, sizeof(tempFileName2));
        for (n = 0, k = 0; k < strlen(tempFileName); k++) {
          if ( tempFileName[k] != '\"' ) {
            tempFileName2[n] = tempFileName[k];
            n++;
          }
        }
        strcpy(logFileName, "\\\\");
        // Add computer name
        strcat(logFileName, ComputersListView->Items->Item[i]->Caption.c_str());
        strcat(logFileName, "\\");
        // Add filename part
        strcat(logFileName, tempFileName2);
        // Replace .exe by .log. This also removes the bootparams part.
        p = strrchr(logFileName, '.');
        if ( p ) *p = 0;
        strcat(logFileName, ".log");
        // Replace first : by $ to get network name
        for (j = 0; j < strlen(logFileName); j++) {
          if ( logFileName[j] == ':' ) {
            logFileName[j] = '$';
            break;
          }
        }
        if ( FileExists(AnsiString(logFileName)) ) { // Find the logfile
          l = CheckForDoubleFile(logFileName);
          if ( !l ) {
            ViewLogFileForm = new TViewLogFileForm(
                    this,
                    logFileName,
                    1000 * pcfg.LogRefreshTime, // milliseconds
                    pcfg.autoRefreshLogs, true);
            if ( ViewLogFileForm ) {
              // Add new window to child list for closing and deleting on app termination
              AddNode(viewLogFilesChildren, ViewLogFileForm, logFileName);
              // Set main form for beeing able to call SendMessage there
              ViewLogFileForm->mainForm = this;
              // Show the window non-modal
              ViewLogFileForm->Show();
            }
          } else {
            if ( l->WindowState == wsMinimized ) l->WindowState = wsNormal;
            l->SetFocus();
          }
        } else {
          AnsiString errorMsg = "Could not find logfile " + AnsiString(logFileName);
          Application->MessageBox(errorMsg.c_str(), Application->Title.c_str(), MB_OK);
        }
      }
    }
  }
}

//------------------------------------------------------------------------------
// View the debug file
//------------------------------------------------------------------------------
void __fastcall TMainForm::ViewDebugFile1Click(TObject* Sender)
{
  if ( FileExists(tracefile) ) {
    TViewLogFileForm* l = CheckForDoubleFile(tracefile);
    if ( !l ) {
      TViewLogFileForm* ViewLogFileForm = new TViewLogFileForm(this, tracefile, 10000, false, false);
      if ( ViewLogFileForm ) {
        // Add new window to child list for closing and deleting on app termination
        AddNode(viewLogFilesChildren, ViewLogFileForm, tracefile);
        // Set main form for beeing able to call SendMessage there
        ViewLogFileForm->mainForm = this;
        // Show the window non-modal
        ViewLogFileForm->Show();
      }
    } else {
      if ( l->WindowState == wsMinimized ) l->WindowState = wsNormal;
      l->SetFocus();
    }
  } else {
    AnsiString errMsg = "File \"" + tracefile + "\" with debug information not found";
    Application->MessageBox(errMsg.c_str(), Application->Title.c_str(), MB_OK);
  }
}

//------------------------------------------------------------------------------
// Adds a pointer to a form to the list of open screens, and adds a menuitem
// to the window menu. This is only done if the file is not yet opened. If it
// is already open, the open window is shown.
//------------------------------------------------------------------------------
void __fastcall TMainForm::AddNode(TList* l, TObject* o, AnsiString caption)
{
  TMenuItem* item = new TMenuItem(RsccMainMenu);
  ((TViewLogFileForm*)o)->windowMenuItem = item;
  item->Caption = caption;
  item->OnClick = WindowClick;
  item->Tag = (int)o; // Store the pointer to the form so we can easily access
                      // it when the menuitem is clicked.
  Window1->Add(item);
  l->Add(o);
}

//------------------------------------------------------------------------------
// A menuitem in the window menu is clicked. Bring the corresponding form to
// the foreground.
//------------------------------------------------------------------------------
void __fastcall TMainForm::WindowClick(TObject* Sender)
{
  TViewLogFileForm* l = (TViewLogFileForm*)((TMenuItem*)Sender)->Tag;
  if (l) {
    if (l->WindowState == wsMinimized) l->WindowState = wsNormal;
    l->SetFocus();
  }
}

//------------------------------------------------------------------------------
// Checks is a logfileform with the given caption already exists in the list.
// If it does, it returns a pointer to it. Else it returns NULL.
//------------------------------------------------------------------------------
TViewLogFileForm* __fastcall TMainForm::CheckForDoubleFile(AnsiString caption)
{
  for (int i = 0; i < viewLogFilesChildren->Count; i++) {
    if (((TViewLogFileForm*)viewLogFilesChildren->Items[i])->windowMenuItem->Caption == caption)
      return (TViewLogFileForm*)viewLogFilesChildren->Items[i];
  }
  return NULL;
}

//------------------------------------------------------------------------------
// TNetworkScanThread methods
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Constructor. Stores the owner.
//------------------------------------------------------------------------------
__fastcall TNetworkScanThread::TNetworkScanThread(bool createSuspended,
                                                  bool aRunUpdateAfterwards,
                                                  bool aScanOutsideDomain,
                                                  TMainForm* Owner): TThread(createSuspended)
{
  OwnerForm = Owner;
  fRunUpdateAfterwards = aRunUpdateAfterwards;
  fScanOutsideDomain = aScanOutsideDomain;
  FreeOnTerminate = true; // So we don't have to delete the thread explicitly
}

//------------------------------------------------------------------------------
// Destructor
//------------------------------------------------------------------------------
__fastcall TNetworkScanThread::~TNetworkScanThread()
{
}

//------------------------------------------------------------------------------
// Execute method. Tries to run the thread.
//------------------------------------------------------------------------------
void __fastcall TNetworkScanThread::Execute()
{
  AnsiString errText;

  try {
    OwnerForm->SetThreadWaitText("Initializing...", "");
    if (fScanOutsideDomain)
      FindNetworkComputerNames(NULL);
    else
      FindNetworkComputerNames();

    if ( fRunUpdateAfterwards )
      SendMessage(OwnerForm->Handle, WM_SCAN_THREAD_READY, DO_UPDATE_STATUS, 0);
    else
      SendMessage(OwnerForm->Handle, WM_SCAN_THREAD_READY, DO_NOT_UPDATE_STATUS, 0);
  }
  catch (Exception& exception) {
    errText = "Error running network scan thread: " + exception.Message;
    MessageBox(NULL, errText.c_str(), Application->Title.c_str(), MB_OK);
  }
}

//------------------------------------------------------------------------------
// Find the network computer names and add them to the listview.
//------------------------------------------------------------------------------
void __fastcall TNetworkScanThread::FindNetworkComputerNames(LPNETRESOURCE lpnr)
{
  DWORD ResultEnum;
  HANDLE hEnum;
  DWORD cbBuffer = 16384;        // 16K is a good size
  DWORD i, entries = 0xFFFFFFFF; // enumerate all possible entries
  LPNETRESOURCE lpnrLocal;       // pointer to enumerated structures
  char ComputerName[64];
  bool addMachine;
  TListItem* L;

  if ( WNetOpenEnum(RESOURCE_GLOBALNET, RESOURCETYPE_ANY, 0, lpnr, &hEnum) != NO_ERROR ) {
    ShowErrorMessage("WNetOpenEnum", NULL);
    return;
  }
  do {
    // Allocate memory for NETRESOURCE structures.
    lpnrLocal = (LPNETRESOURCE)GlobalAlloc(GPTR, cbBuffer);
    if ( !lpnrLocal ) {
      ShowErrorMessage("GlobalAlloc", NULL);
    } else {
      ResultEnum = WNetEnumResource(hEnum, &entries, lpnrLocal, &cbBuffer);
      if (ResultEnum == NO_ERROR) {
        for (i = 0; i < entries; i++) {
          // We add only computer names
          if ( (lpnrLocal[i].lpRemoteName) && (lpnrLocal[i].lpRemoteName[0] == '\\') ) {
            strncpy(ComputerName, lpnrLocal[i].lpRemoteName + 2, sizeof(ComputerName) - 1);
            OwnerForm->SetThreadWaitText("Reading computer names...", AnsiString(ComputerName).LowerCase());
            if ( !OwnerForm->NameIsDouble(ComputerName, OwnerForm->ComputersListView) ) {
              if ( OwnerForm->AddOnlyNTMachinesInView() ) {
                addMachine = (GetRemotePlatformType((LPTSTR)ComputerName) >= 2000);
              } else {
                addMachine = true;
              }
              if ( addMachine ) {
                // Add the computer name listitem
                L = OwnerForm->ComputersListView->Items->Add();
                L->Caption = LowerCase(ComputerName);
                // Add subitem for status
                L->SubItems->Add("");
                // Add subitem for service path
                L->SubItems->Add("");
                // Add subitem for service version
                L->SubItems->Add("");
                // Add subitem for command version
                L->SubItems->Add("");
                // Add subitem for logging
                L->SubItems->Add("");
                // Add subitem for interaction with desktop
                L->SubItems->Add("");
              }
            }
          }
          // If this NETRESOURCE is a container AND it is not a directory,
          // call the function recursively. We also check on the existence
          // of lpnrLocal[i].lpRemoteName - it is sometimes NULL.
          if ( (RESOURCEUSAGE_CONTAINER == (lpnrLocal[i].dwUsage & RESOURCEUSAGE_CONTAINER)) &&
               (lpnrLocal[i].lpRemoteName) && (lpnrLocal[i].lpRemoteName[0] != '\\') ) {
            FindNetworkComputerNames(&lpnrLocal[i]);
          }
        }
      }
      else if (ResultEnum != ERROR_NO_MORE_ITEMS) {
        ShowErrorMessage("WNetEnumResource", NULL);
        GlobalFree((HGLOBAL)lpnrLocal);
        break;
      }
      GlobalFree((HGLOBAL)lpnrLocal);
    }
  }
  while( ResultEnum != ERROR_NO_MORE_ITEMS && !Terminated );

  if ( WNetCloseEnum(hEnum) != NO_ERROR ) ShowErrorMessage("WNetCloseEnum", NULL);
  return;
}


//------------------------------------------------------------------------------
// Find the network computer names in the local domain and add them to the
// listview(s).
//------------------------------------------------------------------------------
void __fastcall TNetworkScanThread::FindNetworkComputerNames()
{
  LPSERVER_INFO_101 si = NULL;
  LPSERVER_INFO_101 tmpsi;
  DWORD level = 101;
  DWORD entriesRead = 0;
  DWORD totalEntries = 0;
  DWORD resumeHandle = 0;
  NET_API_STATUS retVal;
  unsigned i;
  char ComputerName[MAX_COMPUTERNAME_LENGTH + 1];
  bool addMachine;
  long ver = 0;
  TListItem* L;

  retVal = NetServerEnum(NULL,
                         level,
                         (LPBYTE*)(&si),
                         MAX_PREFERRED_LENGTH,
                         &entriesRead,
                         &totalEntries,
                         SV_TYPE_WORKSTATION,
                         NULL,
                         &resumeHandle);

  if ((retVal == NERR_Success) || (retVal == ERROR_MORE_DATA)) {
    if ((tmpsi = si) != NULL) {
      // Now add all servers c.q. all NT machines to the listviews.
      for (i = 0; i < entriesRead; i++) {
        if (!tmpsi) {
          ShowErrorMessage("NetServerEnum", NULL);
          break;
        }
        if ( OwnerForm->AddOnlyNTMachinesInView() ) {
          if ((tmpsi->sv101_type & (SV_TYPE_NT | SV_TYPE_WINDOWS)) != 0 ) {
            ver = (tmpsi->sv101_version_major * 100) + (tmpsi->sv101_version_minor);
            if ( (tmpsi->sv101_type & SV_TYPE_NT) != 0 ) ver += 2000;
          }
          addMachine = (ver >= 2000);
        } else {
          addMachine = true;
        }
        UnicodeToAnsi(tmpsi->sv101_name, ComputerName, sizeof(ComputerName));
        OwnerForm->SetThreadWaitText("Reading computer names...", LowerCase(ComputerName));
        if ( addMachine && !OwnerForm->NameIsDouble(ComputerName, OwnerForm->ComputersListView) ) {
          // Add the computer name listitem
          L = OwnerForm->ComputersListView->Items->Add();
          L->Caption = LowerCase(ComputerName);
          // Add subitem for status
          L->SubItems->Add("");
          // Add subitem for service path
          L->SubItems->Add("");
          // Add subitem for service version
          L->SubItems->Add("");
          // Add subitem for command version
          L->SubItems->Add("");
          // Add subitem for logging
          L->SubItems->Add("");
          // Add subitem for interaction with desktop
          L->SubItems->Add("");
        }
        tmpsi++;
      }
    }
    if (retVal == ERROR_MORE_DATA) ShowErrorMessage("NetServerEnum", NULL);
  }
  else
    ShowErrorMessage("NetServerEnum", NULL);

  if (si) NetApiBufferFree(si);
}

//------------------------------------------------------------------------------

