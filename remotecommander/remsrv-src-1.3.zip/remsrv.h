//------------------------------------------------------------------------------
#ifndef RemSrvH
#define RemSrvH
//------------------------------------------------------------------------------
void ServiceMain(DWORD argc, LPTSTR* argv);
void WriteErrorLine(char msg[]);
void WriteMessageToLog(char msg[]);
void GetErrormessage(DWORD* errCode, char* buffer, size_t buffSize);
DWORD ServiceExecutionThread(LPDWORD param);
bool StartServiceThread(void);
void ServiceCtrlHandler(DWORD controlCode);
bool UpdateSCMStatus(DWORD dwCurrentState, DWORD dwWin32ExitCode, DWORD dwServiceSpecificExitCode, DWORD dwCheckPoint, DWORD dwWaitHint);
void KillService(void);
void TerminateService(DWORD errCode);
void RunCommand(void);
void InstallService(void);
void UninstallService(void);
//------------------------------------------------------------------------------
#endif

