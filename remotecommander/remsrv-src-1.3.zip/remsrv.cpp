//------------------------------------------------------------------------------
#include <windows.h>
#include <stdio.h>
#include <dos.h>
#pragma hdrstop
#include "Base64.h"
// Delphi crypto modules
#include "DCPcrypt.hpp"
#include "RC5.hpp"
#include "SHA1.hpp"

#include "RemSrv.h"
#include "common.h"
//------------------------------------------------------------------------------
USERES("RemSrv.res");
USEUNIT("common.cpp");
USEUNIT("base64.cpp");
USEUNIT("SHA1.pas");
USEUNIT("RC5.pas");
USEUNIT("DCPcrypt.pas");
//---------------------------------------------------------------------------
SERVICE_STATUS_HANDLE serviceStatusHandle;
HANDLE killServiceEvent;
HANDLE threadHandle;
// Logfile name
char logfilename[MAX_PATH];
// Commandfile name
char inifilename[MAX_PATH];
// For bookkeeping
DWORD serviceCurrentStatus;
bool serviceRunning;
bool servicePaused;
bool writeToLogfile;

//------------------------------------------------------------------------------
// Main function
//------------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
  char* c;
  char readText[16];

  try {
    // Get the logfile name
    strcpy(logfilename, _argv[0]);
    c = strrchr(logfilename, '.');
    if ( c ) *c = 0;
    strcat(logfilename, ".log");
    // Get the command file name
    strcpy(inifilename, _argv[0]);
    c = strrchr(inifilename, '.');
    if ( c ) *c = 0;
    strcat(inifilename, ".ini");
    // See if we use the logfile
    GetPrivateProfileString(ServiceSection, ServiceLog, "0", readText, sizeof(readText), inifilename);
    if ( !strcmp(readText, "0") )
      writeToLogfile = false;
    else
      writeToLogfile = true;
    // See if we want to install or deinstall the service.
    if ( _argc >= 2 ) {
      if ( !strcmp(_argv[1], "-i") || !strcmp(_argv[1], "-install") ) {
        InstallService();
        return 0;
      }
      // Uninstall service
      else if ( !strcmp(_argv[1], "-u") || !strcmp(_argv[1], "-uninstall") ) {
        UninstallService();
        return 0;
      }
      // Run command
      else if ( !strcmp(_argv[1], "-r") || !strcmp(_argv[1], "-run") ) {
        RunCommand();
        return 0;
      }
    }

    SERVICE_TABLE_ENTRY serviceTable[] = {
     { ServiceName, (LPSERVICE_MAIN_FUNCTION)ServiceMain },
     { NULL, NULL }
    };
    // Register the service with the Service Control Manager
    bool success = StartServiceCtrlDispatcher(serviceTable);
    if (!success) {
      WriteErrorLine("StartServiceCtrlDispatcher fails!");
    }
  } catch (...) {  }
  return 0;
}

//------------------------------------------------------------------------------
// ServiceMain function.
// ServiceMain is called when the Service Control Manager wants to
// launch the service. It should not return until the service has
// stopped. To accomplish this, for this example, it waits blocking
// on an event just before the end of the function. That event gets
// set by the function which terminates the service above. Also, if
// there is an error starting the service, ServiceMain returns immediately
// without launching the main service thread, terminating the service.
//------------------------------------------------------------------------------
void ServiceMain(DWORD argc, LPTSTR* argv)
{
  DWORD errCode;
  // First we must call the Registration function
  serviceStatusHandle = RegisterServiceCtrlHandler(ServiceName, (LPHANDLER_FUNCTION)ServiceCtrlHandler);
  if (!serviceStatusHandle) {
    errCode = GetLastError();
    WriteErrorLine("No serviceStatusHandle created");
    TerminateService(errCode);
    return;
  }
  // Next Notify the Service Control Manager of progress
  if ( !UpdateSCMStatus(SERVICE_START_PENDING, NO_ERROR, 0, 1, 5000) ) {
    errCode = GetLastError();
    WriteErrorLine("UpdateSCMStatus failed");
    TerminateService(errCode);
    return;
  }
  // Now create the our service termination event to block on
  killServiceEvent = CreateEvent(0, TRUE, FALSE, 0);
  if (!killServiceEvent) {
    errCode = GetLastError();
    WriteErrorLine("no killServiceEvent created");
    TerminateService(errCode);
    return;
  }
  // Creation of the thread is commented out: it would do nothing anyway.
  // Notify the SCM of progress again
  if ( !UpdateSCMStatus(SERVICE_START_PENDING, NO_ERROR, 0, 2, 1000) ) {
    errCode = GetLastError();
    WriteErrorLine("UpdateSCMStatus failed");
    TerminateService(errCode);
    return;
  }
  // Start the service execution thread by calling our StartServiceThread function...
  if ( !StartServiceThread() ) {
    WriteErrorLine("StartServiceThread failed");
    return;
  }
  // The service is now running.  Notify the SCM of this fact.
  serviceCurrentStatus = SERVICE_RUNNING;
  if ( !UpdateSCMStatus(SERVICE_RUNNING, NO_ERROR, 0, 0, 0) ) {
    errCode = GetLastError();
    WriteErrorLine("UpdateSCMStatus failed");
    TerminateService(errCode);
  }
  // Now just wait for our killed service signal, and then exit, which
  // terminates the service!
  WaitForSingleObject(killServiceEvent, INFINITE);
  TerminateService(0);
}

//------------------------------------------------------------------------------
// Cleans up when the service stops.
//------------------------------------------------------------------------------
void TerminateService(DWORD errCode)
{
  UpdateSCMStatus(SERVICE_STOPPED, errCode, 0, 0, 1000);
}

//------------------------------------------------------------------------------
// This is the main thread of execution for the service while it is running.
// It does currently nothing because the service only does something if it
// receives a command.
//------------------------------------------------------------------------------
DWORD ServiceExecutionThread(LPDWORD param)
{
  while ( serviceRunning ) {
    Sleep(200);
  }
  return 0;
}

//------------------------------------------------------------------------------
// This starts the service by creating its execution thread.
//------------------------------------------------------------------------------
bool StartServiceThread()
{
  DWORD id;
  // Start the service's thread
  threadHandle = CreateThread(0, 0, (LPTHREAD_START_ROUTINE)ServiceExecutionThread, 0, 0, &id);
  if ( !threadHandle ) {
    return false;
  } else {
    serviceRunning = true;
    return true;
  }
}

//------------------------------------------------------------------------------
// This function updates the service status for the SCM
//------------------------------------------------------------------------------
bool UpdateSCMStatus(DWORD dwCurrentState,
                     DWORD dwWin32ExitCode,
                     DWORD dwServiceSpecificExitCode,
                     DWORD dwCheckPoint,
                     DWORD dwWaitHint)
{
  bool success;
  SERVICE_STATUS serviceStatus;
  // Fill in all of the SERVICE_STATUS fields
  serviceStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
  serviceStatus.dwCurrentState = dwCurrentState;
  // If in the process of something, then accept
  // no control events, else accept anything
  if (dwCurrentState == SERVICE_START_PENDING) {
    serviceStatus.dwControlsAccepted = 0;
  } else {
    serviceStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_PAUSE_CONTINUE | SERVICE_ACCEPT_SHUTDOWN;
  }
  // if a specific exit code is defined, set up the Win32 exit code properly
  if (dwServiceSpecificExitCode == 0) {
    serviceStatus.dwWin32ExitCode = dwWin32ExitCode;
  } else {
    serviceStatus.dwWin32ExitCode = ERROR_SERVICE_SPECIFIC_ERROR;
  }
  serviceStatus.dwServiceSpecificExitCode = dwServiceSpecificExitCode;
  serviceStatus.dwCheckPoint = dwCheckPoint;
  serviceStatus.dwWaitHint = dwWaitHint;
  // Pass the status record to the SCM
  success = SetServiceStatus(serviceStatusHandle, &serviceStatus);
  if ( !success ) {
    KillService();
  }
  return success;
}

//------------------------------------------------------------------------------
// Handles the events dispatched by the Service Control Manager.
//------------------------------------------------------------------------------
void ServiceCtrlHandler(DWORD controlCode)
{
  char readText[16];
  
  switch(controlCode) {
    // Reload configuration (currently only logging):
    case SERVICE_CONTROL_PARAMCHANGE:
    case SERVICE_CONTROL_RELOAD_CONFIG:
      GetPrivateProfileString(ServiceSection, ServiceLog, "0", readText, sizeof(readText), inifilename);
      if ( !strcmp(readText, "0") )
        writeToLogfile = false;
      else
        writeToLogfile = true;
      break;
    // There is no START option because ServiceMain gets called on a start
    // Pause the service
    case SERVICE_CONTROL_PAUSE:
      if (serviceRunning && !servicePaused) {
        // Tell the SCM we're about to Pause.
        UpdateSCMStatus(SERVICE_PAUSE_PENDING, NO_ERROR, 0, 1, 1000);
        servicePaused = true;
        SuspendThread(threadHandle);
        serviceCurrentStatus = SERVICE_PAUSED;
      }
      break;
      // Resume from a pause
      case SERVICE_CONTROL_CONTINUE:
        if (serviceRunning && servicePaused) {
          // Tell the SCM we're about to Resume.
          UpdateSCMStatus(SERVICE_CONTINUE_PENDING, NO_ERROR, 0, 1, 1000);
          servicePaused = false;
          ResumeThread(threadHandle);
          serviceCurrentStatus = SERVICE_RUNNING;
        }
        break;
      // Run the command in the inifile:
      case SERVICE_CONTROL_RUNCOMMAND:
        RunCommand();
        break;
      // Clear the logfile
      case SERVICE_CONTROL_REMOVELOGFILE:
        DeleteFile(logfilename);
        break;
      // Return status information
      case SERVICE_CONTROL_CAPSSTAT:
         break;
      // Update the current status for the SCM.
      case SERVICE_CONTROL_INTERROGATE:
        // This does nothing, here we will just fall through to the end
        // and send our current status.
        break;
      // For a shutdown, we can do cleanup but it must take place quickly
      // because the system will go down out from under us.
      // For this app we have time to stop here, which I do by just falling
      // through to the stop message.
      case SERVICE_CONTROL_SHUTDOWN:
      // Stop the service
      case SERVICE_CONTROL_STOP:
        // Tell the SCM we're about to Stop.
        serviceCurrentStatus = SERVICE_STOP_PENDING;
        UpdateSCMStatus(SERVICE_STOP_PENDING, NO_ERROR, 0, 1, 5000);
        KillService();
        return;
      default:
        break;
   }
   UpdateSCMStatus(serviceCurrentStatus, NO_ERROR, 0, 0, 0);
}

//------------------------------------------------------------------------------
// The killServiceEvent to allow ServiceMain to exit.
//------------------------------------------------------------------------------
void KillService()
{
  serviceRunning = false;
  // Set the event that is blocking ServiceMain so that ServiceMain can return
  SetEvent(killServiceEvent);
}

//------------------------------------------------------------------------------
// Get the errormessage and return it in buffer.
//------------------------------------------------------------------------------
void GetErrormessage(DWORD* errCode, char* buffer, size_t buffSize)
{
  LPVOID lpMsgBuf; // For error info text
  DWORD errorCode; // For error code if required.
  // If pointer is NULL, get errorcode from windows
  if ( !errCode ) errorCode = GetLastError();
  else errorCode = *errCode;

  FormatMessage(
    FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
    NULL,
    errorCode,
    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
    (LPTSTR)&lpMsgBuf, 0, NULL);

  strncpy(buffer, (char*)lpMsgBuf, buffSize);
  // Free the buffer.
  LocalFree(lpMsgBuf);
}

//------------------------------------------------------------------------------
// Write an error line encrypted in the logfile.
//------------------------------------------------------------------------------
void WriteErrorLine(char msg[])
{
  char errBuffer[256];
  char logline[1024];
  char cryptedlogline[1024];
  SYSTEMTIME timeStruct;
  FILE* f;

  if ( writeToLogfile ) {
    GetErrormessage(NULL, errBuffer, sizeof(errBuffer));
    GetSystemTime(&timeStruct);
    sprintf(logline, "%04d-%02d-%02d %02d:%02d:%02d:%03d: %s: %s",
            timeStruct.wYear,
            timeStruct.wMonth,
            timeStruct.wDay,
            timeStruct.wHour,
            timeStruct.wMinute,
            timeStruct.wSecond,
            timeStruct.wMilliseconds,
            msg,
            errBuffer);
    try {
      strncpy(cryptedlogline, EncryptWithRC5(logline, EncryptionPassword, LOGLINE_LENGTH), LOGLINE_LENGTH);
      cryptedlogline[LOGLINE_LENGTH] = 0;
    } catch (...) { }
    logline[sizeof(logline)] = 0;
    f = fopen(logfilename, "at");
    if ( f ) {
      fprintf(f, cryptedlogline);
      fprintf(f, "\n");
      fflush(f);
      fclose(f);
    }
  }
}

//------------------------------------------------------------------------------
// Write a message encrypted in the logfile.
//------------------------------------------------------------------------------
void WriteMessageToLog(char msg[])
{
  char logline[1024];
  char cryptedlogline[1024];
  SYSTEMTIME timeStruct;
  FILE* f;

  if ( writeToLogfile ) {
    GetSystemTime(&timeStruct);
    sprintf(logline, "%04d-%02d-%02d %02d:%02d:%02d:%03d: %s",
            timeStruct.wYear,
            timeStruct.wMonth,
            timeStruct.wDay,
            timeStruct.wHour,
            timeStruct.wMinute,
            timeStruct.wSecond,
            timeStruct.wMilliseconds,
            msg);
    try {
      strncpy(cryptedlogline, EncryptWithRC5(logline, EncryptionPassword, LOGLINE_LENGTH), LOGLINE_LENGTH);
      cryptedlogline[LOGLINE_LENGTH] = 0;
    } catch (...) { }
    logline[sizeof(logline)] = 0;
    f = fopen(logfilename, "at");
    if ( f ) {
      fprintf(f, cryptedlogline);
      fprintf(f, "\n");
      fflush(f);
      fclose(f);
    }
  }
}

//------------------------------------------------------------------------------
// Installs thre service
//------------------------------------------------------------------------------
void InstallService()
{
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;

  // Open the service manager and install the service
  if ( (hscManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {

    hService = CreateService(hscManager,
                             "remsrv",
                             "Remote control service",
                             SERVICE_ALL_ACCESS,
                             SERVICE_WIN32_OWN_PROCESS | SERVICE_INTERACTIVE_PROCESS,
                             SERVICE_AUTO_START,
                             SERVICE_ERROR_IGNORE,
                             _argv[0],
                             NULL, NULL, NULL, NULL, NULL);

    if ( !hService )
      WriteErrorLine("Service install failed.");
    else
      CloseServiceHandle(hService);

    CloseServiceHandle(hscManager);
  } else
    WriteErrorLine("No SCM handle obtained.");
}

//------------------------------------------------------------------------------
// Deinstalls the service
//------------------------------------------------------------------------------
void UninstallService()
{
  BOOL retVal;
  DWORD errCode;
  SERVICE_STATUS serviceStatus;
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;

  if ( (hscManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
    if ( (hService = OpenService(hscManager, "remsrv", SERVICE_ALL_ACCESS)) == NULL ) {
      hService = NULL; // Reset hService
      WriteErrorLine("No service handle obtained");
    }
    // First stop the service. We check the return value separately because
    // we don't want an errormessage when the service is already stopped.
    if ( hService) {
      retVal= ControlService(hService, SERVICE_CONTROL_STOP, &serviceStatus);
      if ( !retVal) {
        errCode = GetLastError();
        if ( errCode != ERROR_SERVICE_NOT_ACTIVE )
          WriteErrorLine("ControlService failed");
      }
      if ( !DeleteService(hService) )
        WriteErrorLine("Error deleting service");

      CloseServiceHandle(hService);
    }
    CloseServiceHandle(hscManager);
  } else
    WriteErrorLine("No SCM handle obtained");
}

//------------------------------------------------------------------------------
// Run the command that is defined in the service inifile. We first need to
// decrypt it.
//------------------------------------------------------------------------------
void RunCommand()
{
  PROCESS_INFORMATION ProcessInfo;
  STARTUPINFO StartupInfo;
  char command[MAX_COMMAND_LENGTH];
  char readText[2*MAX_COMMAND_LENGTH];
  char errMsg[2*MAX_COMMAND_LENGTH];

  GetPrivateProfileString(ServiceSection, ServiceCommand, "", readText, sizeof(readText), inifilename);
  try {
    strcpy(command, DecryptWithRC5(readText, EncryptionPassword, MAX_COMMAND_LENGTH));
  } catch (...) { }
  if ( strlen(command) ) {
    memset(&StartupInfo, 0, sizeof(STARTUPINFO));
    StartupInfo.cb = sizeof(STARTUPINFO);
//    StartupInfo.dwFlags = STARTF_USESTDHANDLES;
    if ( !CreateProcess(NULL, command, NULL, NULL, FALSE, CREATE_NEW_CONSOLE | NORMAL_PRIORITY_CLASS, NULL, NULL, &StartupInfo, &ProcessInfo) ) {
      WriteErrorLine("CreateProcess failed");
      strcpy(errMsg, "On command: ");
      strcat(errMsg, command);
      WriteMessageToLog(errMsg);
    } else {
      WriteMessageToLog("Command executed:");
      WriteMessageToLog(command);
    }
  }
}

//------------------------------------------------------------------------------

