/*
    Large Time Screensaver
    Copyright 2005 - 2007 Martin Storsj�

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

    Martin Storsj�
    martin@martin.st
*/

#ifndef __CHECKMAIL_H
#define __CHECKMAIL_H

#include <e32base.h>
#include <msvapi.h>

class CClientMtmRegistry;

class CCheckMail : public CBase, public MMsvSessionObserver {
public:
	static CCheckMail* NewLC();
	static CCheckMail* NewL();
	CCheckMail();
	~CCheckMail();
	void ConstructL();

	void HandleSessionEvent(TMsvSessionEvent aEvent, TAny* aArg1, TAny* aArg2, TAny* aArg3);
	void HandleSessionEventL(TMsvSessionEvent aEvent, TAny* aArg1, TAny* aArg2, TAny* aArg3);

	void CountMailsInFolderL(CBaseMtm* aMtm, TMsvId aId, TInt& aTotal, TInt& aUnread);
	void CountMailsInMtmL(CBaseMtm* aMtm, TInt& aTotal, TInt &aUnread);
	void CountMailsL(TInt& aTotal, TInt& aUnread);

	static TInt CountUnreadL();
	static TInt CountUnread();

	static TBool GetUnread(TInt& aCount);

private:
	CMsvSession* iSession;
	CClientMtmRegistry* iRegistry;
};

#endif
