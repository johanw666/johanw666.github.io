/*
    Large Time Screensaver
    Copyright 2005 - 2007 Martin Storsj�

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

    Martin Storsj�
    martin@martin.st
*/

#ifndef __LARGETIME_H
#define __LARGETIME_H

#include <coecntrl.h>
#include <screensaverplugin.h>
#include <eikenv.h>

#ifdef EKA2
#include <screensaverpluginintdef.h>

class CLargeTime : public CScreensaverPluginInterfaceDefinition {
#else
class CLargeTime : public CBase, public MScreensaverPlugin {
#endif
public:
	static CLargeTime* NewL();

	CLargeTime();
	~CLargeTime();

	// MScreensaverPlugin
	TInt InitializeL(MScreensaverPluginHost* aHost);
	TInt Draw(CWindowGc& aGc);
	const TDesC16& Name() const;
	TInt HandleScreensaverEventL(TScreensaverEvent aEvent, TAny* aData);
	TInt Capabilities();
	TInt PluginFunction(TScPluginCaps aFunction, TAny* aParam);

private:
	enum TNumberParts {
		EPartTop = 1, EPartBottom = 2, EPartCenter = 4, EPartTopLeft = 8, EPartTopRight = 16, EPartBottomLeft = 32, EPartBottomRight = 64
	};

	void GetState();
	void CalcSizes(TSize aSize);
	static TInt DecodeNumber(TInt aNumber);
	void DrawNumber(CWindowGc& aGc, TRect aRect, TInt aNumber);
	void DrawNumber2(CWindowGc& aGc, TRect aRect, TInt aNumber);
	void DrawColon(CWindowGc& aGc, TRect aRect);
	void DrawKey(CWindowGc& aGc, TPoint& aPoint, TInt aHeight);
	void DrawEnvelope(CWindowGc& aGc, TRect aRect, TInt aSize);
	void DrawCalls(CWindowGc& aGc, TRect aRect);
	void DrawMiniCalls(CWindowGc& aGc, TInt aHeight, TPoint& aPoint);
	void DrawEmails(CWindowGc& aGc, TInt aHeight, TPoint& aPoint);
	void DrawBanner(CWindowGc& aGc, TPoint& aPoint, TInt aHeight, const CFont* aFont);
	void DrawBanner2(CWindowGc& aGc, TPoint& aPoint, TInt aHeight, const CFont* aFont);
	void DrawClock(CWindowGc& aGc, TPoint& aPoint);
	void DrawMsgsCalls(CWindowGc& aGc, TPoint& aPoint);

	void ConfigureL();
	void StoreL() const;
	void RestoreL();
	void RestoreFileL(RFs& aFs, const TDesC& aFileName);
	TStreamId StoreL(CStreamStore& aStore) const;
	void RestoreL(const CStreamStore& aStore, TStreamId aStreamId);
	void ExternalizeL(RWriteStream& aStream) const;
	void InternalizeL(RReadStream& aStream);

private:
	MScreensaverPluginHost* iHost;
	CEikonEnv* iEikEnv;
	TInt iMsgs;
	TInt iEmailCount;
	TInt iCalls;
	TBool iHasEmails;
	TBool iDrawEnvelope;
	TBool iDrawCalls;
#ifdef EKA2
	TBuf16<KMaxPayloadTextLength> iProfile;
#else
	TBuf16<KMaxPayloadTextLenght> iProfile;
#endif
	TBool iLocked;
	TBool iSilent;
	TTime iTime;
	TDateTime iDateTime;
	TInt64 iSeed;
	TInt iOffsetY;
	TInt iLastTotHeight;
	TInt iLastRandomize;
	TInt iPeriod;
	TInt iLastDraw;

	TInt iScreenWidth, iScreenHeight;
	TInt iRatio, iBannerRatio;
	TInt iSegmentThickness;
	TInt iSegmentMargin;
	TInt iNumberMargin;
	TInt iNumbersWidth, iNumbersHeight;
	TInt iEnvelopeWidth;
	TInt iCallsWidth;
	TInt iEnvelopeCallsHeight;
	TInt iIdentifierMarginX;
	TInt iMarginY;
	TInt iScreenMarginY;

	TBool iWhite;
	TBool iWholeBackground;
	TRgb iForeground, iBanner, iBackground;
};

#endif
