/*
    Large Time Screensaver
    Copyright 2005 - 2007 Martin Storsj�

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

    Martin Storsj�
    martin@martin.st
*/

#include "LargeTime.h"
#include "LargeTime.hrh"
#include <e32base.h>
#include <aknkeylock.h>
#ifndef EKA2
#include <settinginfo.h>
#else
#include <implementationproxy.h>
#endif
#include <flogger.h>
#include <hal.h>
#include <e32math.h>
#include <aknnotewrappers.h>
#include <LargeTimeUI.rsg>
#include <s32file.h>
#include <bautils.h>
#include "CheckMail.h"

_LIT(KScreensaverName, "Large Time");

//#define LOG(x) RFileLogger::WriteFormat(_L("debug"), _L("largetime.txt"), EFileLoggingModeAppend, x)
#define LOG(x)

#define RESCALE(x) (((x)*iRatio) >> 8)
#define RESCALEBANNER(x) (((x)*iBannerRatio) >> 8)




#ifdef EKA2

const TImplementationProxy ImplementationTable[] = {
	{ { 0x10273927 }, (TAny*(*)()) CLargeTime::NewL }
};

EXPORT_C const TImplementationProxy* ImplementationGroupProxy(TInt& aTableCount) {
	aTableCount = sizeof(ImplementationTable) / sizeof(TImplementationProxy);
	return ImplementationTable;
}

#else

GLDEF_C TInt E32Dll(TDllReason aReason) {
	return KErrNone;
}

EXPORT_C MScreensaverPlugin* CreatePluginModule() {
	return new CLargeTime();
}

#endif




CLargeTime* CLargeTime::NewL() {
	return new(ELeave) CLargeTime();
}

CLargeTime::CLargeTime() {
	iWhite = ETrue;
	iWholeBackground = EFalse;
}

CLargeTime::~CLargeTime() {
}

TInt CLargeTime::InitializeL(MScreensaverPluginHost* aHost) {
	LOG(_L("InitializeL\n"));
	iHost = aHost;

	TRAPD(err, RestoreL());

	iHost->OverrideStandardIndicators();
	iHost->SetRefreshTimerValue(20*1000000);

	iEikEnv = CEikonEnv::Static();

	iSeed = User::TickCount();

	iLastTotHeight = 0;

	iPeriod = 1000/64;
	TInt period;
	if (HAL::Get(HALData::ESystemTickPeriod, period) == KErrNone)
		iPeriod = period / 1000;
	iLastRandomize = User::TickCount() - 60*1000/iPeriod;
	iLastDraw = User::TickCount();


	LOG(_L("InitializeL done\n"));
	return KErrNone;
}

void CLargeTime::GetState() {
	iMsgs = 0;
	iEmailCount = 0;
	iHasEmails = EFalse;
	iCalls = 0;
	TIndicatorPayload result;
	TInt status = iHost->GetIndicatorPayload(EScreensaverIndicatorIndexNewMessages, result);
	if (status == KErrNone)
		iMsgs = result.iInteger;
/*
	status = iHost->GetIndicatorPayload(EScreensaverIndicatorIndexEmail, result);
	if (status == KErrNone && result.iType == EPayloadTypeInteger)
		iEmailCount = result.iInteger;
*/
	iHasEmails = CCheckMail::GetUnread(iEmailCount);

	status = iHost->GetIndicatorPayload(EScreensaverIndicatorIndexNewMissedCalls, result);
	if (status == KErrNone)
		iCalls = result.iInteger;

	iDrawEnvelope = (iMsgs > 0) || iHasEmails;
	iDrawCalls = iCalls > 0;

#ifndef EKA2
	TInt profile, ringing;
	TRAPD(err,
		CSettingInfo* info = CSettingInfo::NewL(NULL);
		CleanupStack::PushL(info);
		User::LeaveIfError(info->Get(SettingInfo::EActiveProfile, profile));
		User::LeaveIfError(info->Get(SettingInfo::ERingingType, ringing));
		CleanupStack::PopAndDestroy();
		);

	iSilent = EFalse;
	if (err == KErrNone)
		iSilent = ringing == 4;

	iProfile.SetLength(0);
	if (profile != 0 && err == KErrNone) {
		status = iHost->GetIndicatorPayload(EScreensaverIndicatorIndexProfileName, result);
		if (status == KErrNone)
			iProfile = result.iText;
	}
#else
	status = iHost->GetIndicatorPayload(EScreensaverIndicatorIndexProfileName, result);
	if (status == KErrNone)
		iProfile = result.iText;
#endif

	iLocked = EFalse;
//	status = iHost->GetIndicatorPayload(EScreensaverIndicatorIndexKeyGuardState, result);
//	if (status == KErrNone && result.iInteger != 0)
//		iLocked = ETrue;

	RAknKeyLock keyLock;
	if (keyLock.Connect() == KErrNone) {
		iLocked = keyLock.IsKeyLockEnabled();
		keyLock.Close();
	}

	iTime.HomeTime();
	iDateTime = iTime.DateTime();
}

TInt CLargeTime::Draw(CWindowGc& aGc) {
	LOG(_L("Draw\n"));

	TInt now = User::TickCount();
	if ((now - iLastDraw)*iPeriod >= 2*iHost->RefreshTimerValue()/1000) {
		TRAPD(err, RestoreL());
	}
	iLastDraw = now;

	if (iWhite) {
		iForeground = KRgbBlack;
//		iBanner = TRgb(0xcccccc);
		iBanner = KRgbWhite;
		iBackground = KRgbWhite;
	} else {
		iForeground = KRgbWhite;
		iBanner = KRgbDarkGray;
		iBackground = KRgbBlack;
	}

	GetState();

	CalcSizes(aGc.Device()->SizeInPixels());

	TInt totHeight = iNumbersHeight;

	const CFont* font = iEikEnv->AnnotationFont();
	TInt bannerHeight = 0;
	bannerHeight = font->HeightInPixels() + RESCALE(4);
	totHeight += iMarginY + bannerHeight;

	if (iMsgs || iHasEmails || iCalls)
		totHeight += iMarginY + iEnvelopeCallsHeight + iMarginY + bannerHeight;




	if (iLastTotHeight != totHeight || (User::TickCount() - iLastRandomize) >= 60*1000/iPeriod) {
		iOffsetY = iScreenMarginY + Math::Rand(iSeed) % (iScreenHeight - totHeight - 2*iScreenMarginY);
		iLastTotHeight = totHeight;
		iLastRandomize = User::TickCount();
	}



	aGc.SetBrushColor(iBackground);
	aGc.Clear(TRect(0, 0, iScreenWidth, iScreenHeight));

	TScreensaverPartialMode partialMode;
//	partialMode.iBpp = 0;
//	partialMode.iType = EPartialModeTypeMostPowerSaving;
	TScreensaverColorModel model = iHost->GetColorModel();
	partialMode = model.iSystemPartialMode;
	// padding due to pen size > 1

	TRect activeRect(TPoint(0, 0), TSize(iScreenWidth, iScreenHeight));
	if (!iWholeBackground) {
		activeRect.iTl.iY = iOffsetY - RESCALE(3);
		activeRect.iBr.iY = iOffsetY + totHeight + RESCALE(3);
	}
#ifdef EKA2
	iHost->SetActiveDisplayArea(activeRect, partialMode);
#else
	iHost->SetActiveDisplayArea(activeRect.iTl.iY, activeRect.iBr.iY - 1, partialMode);
#endif


	TPoint tl = TPoint(0, iOffsetY);
	if (iMsgs || iHasEmails || iCalls) {
		DrawBanner2(aGc, tl, bannerHeight, font);
		tl += TPoint(0, iMarginY);

		DrawMsgsCalls(aGc, tl);
		tl += TPoint(0, iMarginY);
	}

	DrawClock(aGc, tl);
	tl += TPoint(0, iMarginY);

	DrawBanner(aGc, tl, bannerHeight, font);
	tl += TPoint(0, iMarginY);

	LOG(_L("Draw done\n"));
	return KErrNone;
}

void CLargeTime::DrawClock(CWindowGc& aGc, TPoint& aPoint) {
	TInt hours = iDateTime.Hour();
	TInt minutes = iDateTime.Minute();

	TLocale locale;
	if (locale.TimeFormat() == ETime12)
		hours = 1 + (hours + 11) % 12;

	TInt colonWidth = 2*iSegmentThickness;
	TInt firstNumberWidth = 0;
	TSize numberSize = TSize((iNumbersWidth - 4*iNumberMargin - colonWidth)/4, iNumbersHeight);
	TInt realWidth = iNumbersWidth;
	TInt firstOffset = 0;

/*	if (hours < 10) {
		realWidth = numberSize.iWidth*3 + colonWidth + iNumberMargin*3;
	} else if (hours < 20) {
		TInt firstNumberWidth = 2*iSegmentThickness;
		realWidth = numberSize.iWidth*3 + colonWidth + firstNumberWidth + iNumberMargin*4;
		firstOffset = numberSize.iWidth - firstNumberWidth;
	} else {
		realWidth = numberSize.iWidth*4 + colonWidth + iNumberMargin*4;
//		realWidth = iNumbersWidth;
	}
*/
	TPoint tl = TPoint((iScreenWidth - realWidth)/2, aPoint.iY);

//	if (hours >= 10) {
		tl.iX -= firstOffset;
		DrawNumber2(aGc, TRect(tl, numberSize), hours/10);
		tl += TPoint(numberSize.iWidth + iNumberMargin, 0);
//	}
	DrawNumber2(aGc, TRect(tl, numberSize), hours%10);
	tl += TPoint(numberSize.iWidth + iNumberMargin, 0);
	DrawColon(aGc, TRect(tl, TSize(colonWidth, iNumbersHeight)));
	tl += TPoint(colonWidth + iNumberMargin, 0);
	DrawNumber2(aGc, TRect(tl, numberSize), minutes/10);
	tl += TPoint(numberSize.iWidth + iNumberMargin, 0);
	DrawNumber2(aGc, TRect(tl, numberSize), minutes%10);

	aPoint += TPoint(0, iNumbersHeight);
}

void CLargeTime::DrawMsgsCalls(CWindowGc& aGc, TPoint& aPoint) {
	if (iDrawCalls && iDrawEnvelope)
		aPoint.iX = (iScreenWidth - iIdentifierMarginX - iEnvelopeWidth - iCallsWidth)/2;
	else if (iDrawCalls)
		aPoint.iX = (iScreenWidth - iCallsWidth)/2;
	else if (iDrawEnvelope)
		aPoint.iX = (iScreenWidth - iEnvelopeWidth)/2;

	if (iDrawEnvelope) {
		DrawEnvelope(aGc, TRect(aPoint, TSize(iEnvelopeWidth, iEnvelopeCallsHeight)), RESCALE(5));
		aPoint += TPoint(iEnvelopeWidth + iIdentifierMarginX, 0);
	}
	if (iDrawCalls) {
		DrawCalls(aGc, TRect(aPoint, TSize(iCallsWidth, iEnvelopeCallsHeight)));
		aPoint += TPoint(iCallsWidth + iIdentifierMarginX, 0);
	}

	aPoint += TPoint(0, iEnvelopeCallsHeight);

}

void CLargeTime::DrawBanner(CWindowGc& aGc, TPoint& aPoint, TInt aHeight, const CFont* aFont) {
	iBannerRatio = (1<<8)*aFont->HeightInPixels()/12;
	TInt contentHeight = aHeight;
	TInt textRealHeight = aFont->HeightInPixels() - aFont->DescentInPixels();
	TInt textOffsetY = (contentHeight - textRealHeight)/2 + textRealHeight;

	TPoint origPoint = aPoint;
	aPoint.iX = 0;

	aGc.SetBrushColor(iBanner);
	aGc.Clear(TRect(aPoint, TSize(iScreenWidth, aHeight)));

	TPoint indent(RESCALE(3), RESCALE(0));
	aPoint += indent;
	if (iLocked) {
		TInt height = RESCALEBANNER(8);
		aPoint.iY += (contentHeight - height)/2;
		DrawKey(aGc, aPoint, height);
		aPoint.iY = origPoint.iY;
		aPoint.iX += RESCALEBANNER(4);
	}
	aGc.SetPenColor(iForeground);
	aGc.UseFont(aFont);
	if (iProfile.Length() > 0) {
		aGc.DrawText(iProfile, TPoint(aPoint.iX, aPoint.iY + textOffsetY));
	}

	aGc.UseFont(aFont);
	TBuf<100> buf;
	_LIT(KDateFormat, "%/0%1%/1%2%/2%3%/3");
	iTime.FormatL(buf, KDateFormat);
	aPoint.iX = iScreenWidth - 1 - RESCALEBANNER(3) - aFont->TextWidthInPixels(buf);
	aGc.DrawText(buf, TPoint(aPoint.iX, aPoint.iY + textOffsetY));

	TLocale locale;
	if (locale.TimeFormat() == ETime12) {
		iTime.FormatL(buf, _L("%*A"));
		aGc.DrawText(buf, TPoint((iScreenWidth - aFont->TextWidthInPixels(buf))/2, aPoint.iY + textOffsetY));
	}

	aPoint = origPoint + TPoint(0, aHeight);
}


void CLargeTime::DrawBanner2(CWindowGc& aGc, TPoint& aPoint, TInt aHeight, const CFont* aFont) {
	iBannerRatio = (1<<8)*aFont->HeightInPixels()/12;
	TInt contentHeight = aHeight;
	TInt textRealHeight = aFont->HeightInPixels() - aFont->DescentInPixels();
	TInt textOffsetY = (contentHeight - textRealHeight)/2 + textRealHeight;


	TPoint origPoint = aPoint;

	aGc.SetBrushColor(iBanner);
	aGc.Clear(TRect(aPoint, TSize(iScreenWidth, aHeight)));

	aGc.SetPenColor(iForeground);
	aGc.UseFont(aFont);

	aPoint.iX = iScreenWidth - RESCALEBANNER(5);

	TBuf<100> buf;
	if (iCalls > 0) {
		TInt height = 9;
		height = RESCALEBANNER(height);
		aPoint.iY += (contentHeight - height)/2;
		DrawMiniCalls(aGc, height, aPoint);
		aPoint.iY = origPoint.iY;

		buf.Format(_L("%d"), iCalls);
		aPoint.iX -= aFont->TextWidthInPixels(buf) + RESCALEBANNER(3);
		aGc.DrawText(buf, TPoint(aPoint.iX, aPoint.iY + textOffsetY));
		aPoint.iX -= RESCALEBANNER(10);
	}

	if (iMsgs > 0) {
		TSize iconSize(13, 8);
		TInt envSize = 1;
		if (aFont->HeightInPixels() >= 13) {
			iconSize.iHeight = 8;
			envSize = 2;
		}
		iconSize.iWidth = RESCALEBANNER(iconSize.iWidth);
		iconSize.iHeight = RESCALEBANNER(iconSize.iHeight);
		aPoint.iX -= iconSize.iWidth;
		DrawEnvelope(aGc, TRect(aPoint + TPoint(0, (contentHeight - iconSize.iHeight)/2), iconSize), envSize);
		buf.Format(_L("%d"), iMsgs);
		aPoint.iX -= aFont->TextWidthInPixels(buf) + RESCALEBANNER(4);
		aGc.DrawText(buf, TPoint(aPoint.iX, aPoint.iY + textOffsetY));
		aPoint.iX -= RESCALEBANNER(10);
	}

	if (iHasEmails) {
		aPoint.iX -= RESCALEBANNER(1);
		TInt height = aFont->HeightInPixels();
		aPoint.iY += (contentHeight - height)/2;
		DrawEmails(aGc, height, aPoint);
		aPoint.iY = origPoint.iY;
		if (iEmailCount > 0) {
			buf.Format(_L("%d"), iEmailCount);
			aPoint.iX -= aFont->TextWidthInPixels(buf) + RESCALEBANNER(2);
			aGc.DrawText(buf, TPoint(aPoint.iX, aPoint.iY + textOffsetY));
		}
		aPoint.iX -= RESCALEBANNER(10);
	}

	aPoint = origPoint + TPoint(0, aHeight);
}

const TDesC16& CLargeTime::Name() const {
	LOG(_L("Name\n"));
	return KScreensaverName;
}

TInt CLargeTime::HandleScreensaverEventL(TScreensaverEvent aEvent, TAny* aData) {
	LOG(_L("HandleScreensaverEventL\n"));
	return KErrNone;
}

TInt CLargeTime::Capabilities() {
	LOG(_L("Capabilities\n"));
	return EScpCapsConfigure;
//	return EScpCapsNone;
}

TInt CLargeTime::PluginFunction(TScPluginCaps aFunction, TAny* aParam) {
	TBuf<100> buf;
	buf.Format(_L("PluginFunction %d"), aFunction);
	LOG(buf);
	if (aFunction == EScpCapsConfigure) {
		TRAPD(err, ConfigureL());
		return err;
	}
	return KErrNone;
}


TInt CLargeTime::DecodeNumber(TInt aNumber) {
	switch (aNumber) {
	case 0:
		return EPartTop | EPartTopLeft | EPartTopRight | EPartBottomLeft | EPartBottomRight | EPartBottom;
	case 1:
		return EPartTopRight | EPartBottomRight;
	case 2:
		return EPartTop | EPartTopRight | EPartCenter | EPartBottomLeft | EPartBottom;
	case 3:
		return EPartTop | EPartCenter | EPartBottom | EPartTopRight | EPartBottomRight;
	case 4:
		return EPartTopLeft | EPartCenter | EPartTopRight | EPartBottomRight;
	case 5:
		return EPartTop | EPartTopLeft | EPartCenter | EPartBottomRight | EPartBottom;
	case 6:
		return EPartTop | EPartTopLeft | EPartBottomLeft | EPartBottom | EPartBottomRight | EPartCenter;
	case 7:
		return EPartTop | EPartTopRight | EPartBottomRight;
	case 8:
		return EPartTop | EPartTopLeft | EPartTopRight | EPartCenter | EPartBottomLeft | EPartBottomRight | EPartBottom;
	case 9:
		return EPartCenter | EPartTopLeft | EPartTop | EPartTopRight | EPartBottomRight | EPartBottom;
	default:
		break;
	}
	return 0;
}

void CLargeTime::DrawNumber(CWindowGc& aGc, TRect aRect, TInt aNumber) {
	TInt parts = DecodeNumber(aNumber);

	TPoint tl = aRect.iTl;
	TPoint br = aRect.iBr - TPoint(1,1);
	TPoint bl = TPoint(tl.iX, br.iY);
	TPoint tr = TPoint(br.iX, tl.iY);
	TPoint cl = TPoint(tl.iX, (tl.iY+br.iY)/2);
	TPoint cr = TPoint(br.iX, (tl.iY+br.iY)/2);

	aGc.SetPenColor(iForeground);
	aGc.SetBrushColor(iForeground);
	aGc.SetBrushStyle(CGraphicsContext::ESolidBrush);

	if (parts & EPartTop) {
		TPoint points[4];
		points[0] = tl + TPoint(iSegmentMargin, 0);
		points[1] = tr + TPoint(-iSegmentMargin, 0);
		points[2] = tr + TPoint(-iSegmentMargin - iSegmentThickness, iSegmentThickness);
		points[3] = tl + TPoint(iSegmentMargin + iSegmentThickness, iSegmentThickness);
		aGc.DrawPolygon(points, 4);
	}
	if (parts & EPartBottom) {
		TPoint points[4];
		points[0] = bl + TPoint(iSegmentMargin, 0);
		points[1] = bl + TPoint(iSegmentMargin + iSegmentThickness, -iSegmentThickness);
		points[2] = br + TPoint(-iSegmentMargin - iSegmentThickness, -iSegmentThickness);
		points[3] = br + TPoint(-iSegmentMargin, 0);
		aGc.DrawPolygon(points, 4);
	}
	if (parts & EPartTopLeft) {
		TPoint points[4];
		points[0] = tl + TPoint(0, iSegmentMargin);
		points[1] = tl + TPoint(iSegmentThickness, iSegmentMargin + iSegmentThickness);
		points[2] = cl + TPoint(iSegmentThickness, -iSegmentMargin - iSegmentThickness);
		points[3] = cl + TPoint(0, -iSegmentMargin);
		aGc.DrawPolygon(points, 4);
	}
	if (parts & EPartTopRight) {
		TPoint points[4];
		points[0] = tr + TPoint(0, iSegmentMargin);
		points[1] = cr + TPoint(0, -iSegmentMargin);
		points[2] = cr + TPoint(-iSegmentThickness, -iSegmentMargin - iSegmentThickness);
		points[3] = tr + TPoint(-iSegmentThickness, iSegmentMargin + iSegmentThickness);
		aGc.DrawPolygon(points, 4);
	}
	if (parts & EPartBottomLeft) {
		TPoint points[4];
		points[0] = cl + TPoint(0, iSegmentMargin);
		points[1] = cl + TPoint(iSegmentThickness, iSegmentMargin + iSegmentThickness);
		points[2] = bl + TPoint(iSegmentThickness, -iSegmentMargin - iSegmentThickness);
		points[3] = bl + TPoint(0, -iSegmentMargin);
		aGc.DrawPolygon(points, 4);
	}
	if (parts & EPartBottomRight) {
		TPoint points[4];
		points[0] = cr + TPoint(0, iSegmentMargin);
		points[1] = br + TPoint(0, -iSegmentMargin);
		points[2] = br + TPoint(-iSegmentThickness, -iSegmentMargin - iSegmentThickness);
		points[3] = cr + TPoint(-iSegmentThickness, iSegmentMargin + iSegmentThickness);
		aGc.DrawPolygon(points, 4);
	}
	if (parts & EPartCenter) {
		TPoint points[6];
		points[0] = cl + TPoint(iSegmentMargin, 0);
		points[1] = cl + TPoint(iSegmentMargin + iSegmentThickness/2, -iSegmentThickness/2);
		points[2] = cr + TPoint(-iSegmentMargin - iSegmentThickness/2, -iSegmentThickness/2);
		points[3] = cr + TPoint(-iSegmentMargin, 0);
		points[4] = cr + TPoint(-iSegmentMargin - iSegmentThickness/2, iSegmentThickness/2);
		points[5] = cl + TPoint(iSegmentMargin + iSegmentThickness/2, iSegmentThickness/2);
		aGc.DrawPolygon(points, 6);
	}

}

void CLargeTime::DrawNumber2(CWindowGc& aGc, TRect aRect, TInt aNumber) {
	TInt parts = DecodeNumber(aNumber);

	TPoint tl = aRect.iTl;
	TPoint br = aRect.iBr - TPoint(1,1);
	TPoint bl = TPoint(tl.iX, br.iY);
	TPoint tr = TPoint(br.iX, tl.iY);
	TPoint cl = TPoint(tl.iX, (tl.iY+br.iY)/2);
	TPoint cr = TPoint(br.iX, (tl.iY+br.iY)/2);

	aGc.SetPenColor(iForeground);
	aGc.SetBrushColor(iForeground);
	aGc.SetBrushStyle(CGraphicsContext::ESolidBrush);

	if (parts & EPartTop) {
		TPoint points[6];
		points[0] = tl + TPoint(iSegmentMargin + iSegmentThickness, iSegmentThickness);
		points[1] = tl + TPoint(iSegmentMargin + 2*iSegmentThickness, 0);
		points[2] = tr + TPoint(-iSegmentMargin - 2*iSegmentThickness, 0);
		points[3] = tr + TPoint(-iSegmentMargin - iSegmentThickness, iSegmentThickness);
		points[4] = tr + TPoint(-iSegmentMargin - 2*iSegmentThickness, 2*iSegmentThickness);
		points[5] = tl + TPoint(iSegmentMargin + 2*iSegmentThickness, 2*iSegmentThickness);
		aGc.DrawPolygon(points, 6);
	}
	if (parts & EPartBottom) {
		TPoint points[6];
		points[0] = bl + TPoint(iSegmentMargin + iSegmentThickness, -iSegmentThickness);
		points[1] = bl + TPoint(iSegmentMargin + 2*iSegmentThickness, -2*iSegmentThickness);
		points[2] = br + TPoint(-iSegmentMargin - 2*iSegmentThickness, -2*iSegmentThickness);
		points[3] = br + TPoint(-iSegmentMargin - iSegmentThickness, -iSegmentThickness);
		points[4] = br + TPoint(-iSegmentMargin - 2*iSegmentThickness, 0);
		points[5] = bl + TPoint(iSegmentMargin + 2*iSegmentThickness, 0);
		aGc.DrawPolygon(points, 6);
	}
	if (parts & EPartTopLeft) {
		TPoint points[6];
		points[0] = tl + TPoint(iSegmentThickness, iSegmentMargin + iSegmentThickness);
		points[1] = tl + TPoint(2*iSegmentThickness, iSegmentMargin + 2*iSegmentThickness);
		points[2] = cl + TPoint(2*iSegmentThickness, -iSegmentMargin - iSegmentThickness);
		points[3] = cl + TPoint(iSegmentThickness, -iSegmentMargin);
		points[4] = cl + TPoint(0, -iSegmentMargin - iSegmentThickness);
		points[5] = tl + TPoint(0, iSegmentMargin + 2*iSegmentThickness);
		aGc.DrawPolygon(points, 6);
	}
	if (parts & EPartTopRight) {
		TPoint points[6];
		points[0] = tr + TPoint(-iSegmentThickness, iSegmentMargin + iSegmentThickness);
		points[1] = tr + TPoint(0, iSegmentMargin + 2*iSegmentThickness);
		points[2] = cr + TPoint(0, -iSegmentMargin - iSegmentThickness);
		points[3] = cr + TPoint(-iSegmentThickness, -iSegmentMargin);
		points[4] = cr + TPoint(-2*iSegmentThickness, -iSegmentMargin - iSegmentThickness);
		points[5] = tr + TPoint(-2*iSegmentThickness, iSegmentMargin + 2*iSegmentThickness);
		aGc.DrawPolygon(points, 6);
	}
	if (parts & EPartBottomLeft) {
		TPoint points[6];
		points[0] = cl + TPoint(iSegmentThickness, iSegmentMargin);
		points[1] = cl + TPoint(2*iSegmentThickness, iSegmentMargin + iSegmentThickness);
		points[2] = bl + TPoint(2*iSegmentThickness, -iSegmentMargin - 2*iSegmentThickness);
		points[3] = bl + TPoint(iSegmentThickness, -iSegmentMargin - iSegmentThickness);
		points[4] = bl + TPoint(0, -iSegmentMargin - 2*iSegmentThickness);
		points[5] = cl + TPoint(0, iSegmentMargin + iSegmentThickness);
		aGc.DrawPolygon(points, 6);
	}
	if (parts & EPartBottomRight) {
		TPoint points[6];
		points[0] = cr + TPoint(-iSegmentThickness, iSegmentMargin);
		points[1] = cr + TPoint(0, iSegmentMargin + iSegmentThickness);
		points[2] = br + TPoint(0, -iSegmentMargin - 2*iSegmentThickness);
		points[3] = br + TPoint(-iSegmentThickness, -iSegmentMargin - iSegmentThickness);
		points[4] = br + TPoint(-2*iSegmentThickness, -iSegmentMargin - 2*iSegmentThickness);
		points[5] = cr + TPoint(-2*iSegmentThickness, iSegmentMargin + iSegmentThickness);
		aGc.DrawPolygon(points, 6);
	}
	if (parts & EPartCenter) {
		TPoint points[6];
		points[0] = cl + TPoint(iSegmentMargin + iSegmentThickness, 0);
		points[1] = cl + TPoint(iSegmentMargin + 2*iSegmentThickness, -iSegmentThickness);
		points[2] = cr + TPoint(-iSegmentMargin - 2*iSegmentThickness, -iSegmentThickness);
		points[3] = cr + TPoint(-iSegmentMargin - iSegmentThickness, 0);
		points[4] = cr + TPoint(-iSegmentMargin - 2*iSegmentThickness, iSegmentThickness);
		points[5] = cl + TPoint(iSegmentMargin + 2*iSegmentThickness, iSegmentThickness);
		aGc.DrawPolygon(points, 6);
	}

}


void CLargeTime::DrawColon(CWindowGc& aGc, TRect aRect) {
	TPoint top = TPoint((aRect.iTl.iX+aRect.iBr.iX)/2, aRect.iTl.iY + aRect.Size().iHeight/4);
	TPoint bottom = TPoint((aRect.iTl.iX+aRect.iBr.iX)/2, aRect.iTl.iY + aRect.Size().iHeight*3/4);
	aGc.SetPenColor(iForeground);
	aGc.SetBrushColor(iForeground);
	aGc.SetBrushStyle(CGraphicsContext::ESolidBrush);

	aGc.DrawRect(TRect(top - TPoint(iSegmentThickness, iSegmentThickness), TSize(iSegmentThickness*2, iSegmentThickness*2)));
	aGc.DrawRect(TRect(bottom - TPoint(iSegmentThickness, iSegmentThickness), TSize(iSegmentThickness*2, iSegmentThickness*2)));
}

void CLargeTime::DrawKey(CWindowGc& aGc, TPoint& aPoint, TInt aHeight) {
	TInt ringWidth = 6*aHeight/8;
	TInt width = 17*aHeight/8;
	TInt linePos = 2*aHeight/8;
	TInt lineEnd = 7*aHeight/8;

	aGc.SetPenColor(iForeground);
	aGc.SetBrushStyle(CGraphicsContext::ENullBrush);
	aGc.SetPenSize(TSize(RESCALEBANNER(2), RESCALEBANNER(2)));
	aGc.DrawEllipse(TRect(TPoint(aPoint.iX + width - ringWidth, aPoint.iY), TSize(ringWidth, aHeight)));
	aGc.DrawLine(TPoint(aPoint.iX + width - ringWidth, aPoint.iY + aHeight/2), TPoint(aPoint.iX, aPoint.iY + aHeight/2));
	aGc.DrawLine(TPoint(aPoint.iX + linePos, aPoint.iY + aHeight/2), TPoint(aPoint.iX + linePos, aPoint.iY + lineEnd));
	aGc.SetPenSize(TSize(1,1));
	aPoint.iX += width;
}

void CLargeTime::DrawEnvelope(CWindowGc& aGc, TRect aRect, TInt aSize) {
	aGc.SetPenColor(iForeground);
	aGc.SetBrushStyle(CGraphicsContext::ENullBrush);
	aGc.SetPenSize(TSize(aSize, aSize));
	aGc.DrawRect(aRect);
	TPoint points[3];
	points[0] = aRect.iTl;
	points[1] = TPoint((aRect.iTl.iX + aRect.iBr.iX)/2, (aRect.iTl.iY + aRect.iBr.iY)/2);
	points[2] = TPoint(aRect.iBr.iX-1, aRect.iTl.iY);
	aGc.DrawPolyLine(points, 3);
	aGc.SetPenSize(TSize(1,1));
}

void CLargeTime::DrawCalls(CWindowGc& aGc, TRect aRect) {
//	aGc.SetBrushColor(KRgbGreen);
//	aGc.Clear(aRect);
	aGc.SetPenColor(iForeground);
	aGc.SetBrushStyle(CGraphicsContext::ESolidBrush);

	TPoint tl = aRect.iTl;
	TSize size = aRect.Size();
#define POINT(x,y) TPoint(tl.iX+size.iWidth*x/55, tl.iY+size.iHeight*y/55)
#define ADDPOINT() do { points[i++] = POINT(curPos.iX, curPos.iY); } while (0)
#define MOVE(x,y) do { curPos += TPoint(x,y); ADDPOINT(); } while (0)
	TInt i, x, y;
	TPoint points[15], curPos;

	i = 0;
	curPos = TPoint(31, 0);
	ADDPOINT();
	MOVE(10, 0);
	MOVE(0, 25);
	MOVE(-7, 7);
	MOVE(-21, 0);
	MOVE(-7, -7);
	MOVE(0, -14);
	MOVE(-7, 0);
	MOVE(12, -12);
	MOVE(1, 0);
	MOVE(12, 12);
	MOVE(-7, 0);
	MOVE(0, 10);
	MOVE(14, 0);
	aGc.SetPenSize(TSize(1,1));
	aGc.SetBrushColor(iForeground);
	aGc.DrawPolygon(points, i);

	i = 0;
	curPos = TPoint(21, 34);
	ADDPOINT();
	MOVE(17, -17);
	MOVE(14, 0);
	MOVE(3, 3);
	MOVE(0, 7);
	MOVE(-7, 7);
	MOVE(-7, 0);
	MOVE(0, -7);
	MOVE(-14, 14);
	MOVE(7, 0);
	MOVE(0, 7);
	MOVE(-7, 7);
	MOVE(-7, 0);
	MOVE(-3, -3);
	MOVE(0, -14);
	aGc.SetPenSize(TSize(RESCALE(5), RESCALE(5)));
	aGc.SetBrushColor(iBackground);
	aGc.DrawPolygon(points, i);

	aGc.SetPenSize(TSize(1,1));
#undef POINT
#undef ADDPOINT
#undef MOVE
}

void CLargeTime::DrawMiniCalls(CWindowGc& aGc, TInt aHeight, TPoint& aPoint) {
	aGc.SetPenColor(iForeground);
	aGc.SetBrushStyle(CGraphicsContext::ESolidBrush);

	TInt thickness = (3*aHeight + 5)/9;
	TInt arrowSize = (4*aHeight + 5)/9;
	TInt cornerSize = (2*aHeight + 5)/9;
	TInt spaceWidth = (5*aHeight + 5)/9;
	if ((thickness % 2) == 0) thickness++;

	TPoint points[] = {
		TPoint(0, 0),
		TPoint(0, aHeight - 1 - cornerSize),
		TPoint(-cornerSize, aHeight - 1),
		TPoint(-(thickness-1) - spaceWidth - 1 - (thickness-1) + cornerSize, aHeight - 1),
		TPoint(-(thickness-1) - spaceWidth - 1 - (thickness-1), aHeight - 1 - cornerSize),
		TPoint(-(thickness-1) - spaceWidth - 1 - (thickness-1), arrowSize - 1),
		TPoint(-(thickness-1) - spaceWidth - 1 - thickness/2 - (arrowSize-1), arrowSize - 1),
		TPoint(-(thickness-1) - spaceWidth - 1 - thickness/2, 0),
		TPoint(-(thickness-1) - spaceWidth - 1 - thickness/2 + (arrowSize-1), arrowSize - 1),
		TPoint(-(thickness-1) - spaceWidth - 1, arrowSize - 1),
		TPoint(-(thickness-1) - spaceWidth - 1, aHeight - thickness),
		TPoint(-(thickness-1), aHeight - thickness),
		TPoint(-(thickness-1), 0)
	};
	int n = sizeof(points)/sizeof(points[0]);
	for (int i = 0; i < n; i++)
		points[i] += aPoint;

	aGc.SetPenSize(TSize(1,1));
	aGc.SetBrushColor(iForeground);
	aGc.DrawPolygon(points, n);

	aGc.SetPenSize(TSize(1,1));

	aPoint.iX = points[6].iX;
}

void CLargeTime::DrawEmails(CWindowGc& aGc, TInt aHeight, TPoint& aPoint) {
	aGc.SetPenColor(iForeground);
	int n = 0;
	TPoint* ptr = NULL;
	int height = 0;
	int width = 0;
	TPoint points1[] = {
		TPoint(-2, 4),
		TPoint(-2, 2),
		TPoint(-4, 2),
		TPoint(-5, 3),
		TPoint(-4, 4),
		TPoint(-0, 4),
		TPoint(-0, 1),
		TPoint(-1, 0),
		TPoint(-6, 0),
		TPoint(-7, 3),
		TPoint(-6, 6),
		TPoint(-0, 6)
	};
	TPoint points2[] = {
		TPoint(-3, 6),
		TPoint(-3, 3),
		TPoint(-6, 3),
		TPoint(-7, 5),
		TPoint(-6, 6),
		TPoint(-0, 6),
		TPoint(-0, 2),
		TPoint(-1, 0),
		TPoint(-9, 0),
		TPoint(-10, 4),
		TPoint(-9, 9),
		TPoint(-0, 9)
	};
	TPoint points3[] = {
		TPoint(-4, 8),
		TPoint(-4, 4),
		TPoint(-8, 4),
		TPoint(-9, 6),
		TPoint(-8, 8),
		TPoint(-0, 8),
		TPoint(-0, 2),
		TPoint(-2, 0),
		TPoint(-11, 0),
		TPoint(-13, 6),
		TPoint(-11, 12),
		TPoint(-0, 12)
	};
	if (aHeight <= 12) {
		aGc.SetPenSize(TSize(1, 1));
		height = 6;
		width = 7;
		n = sizeof(points1)/sizeof(points1[0]);
		ptr = points1;
	} else if (aHeight < 19) {
		aGc.SetPenSize(TSize(2, 2));
		height = 10;
		width = 10;
		n = sizeof(points2)/sizeof(points2[0]);
		ptr = points2;
	} else {
		aGc.SetPenSize(TSize(2, 2));
		height = 13;
		width = 13;
		n = sizeof(points3)/sizeof(points3[0]);
		ptr = points3;
	}
	for (int i = 0; i < n; i++)
		ptr[i] += aPoint + TPoint(0, (aHeight - height)/2);
	aGc.DrawPolyLine(ptr, n);
	aGc.SetPenSize(TSize(1,1));
	aPoint.iX -= width;
}

void CLargeTime::CalcSizes(TSize aSize) {
	iScreenWidth = aSize.iWidth;
	iScreenHeight = aSize.iHeight;

	TInt xRatio = (1<<8)*iScreenWidth/176;
	TInt yRatio = (1<<8)*iScreenHeight/208;
	iRatio = xRatio;
	if (yRatio < iRatio)
		iRatio = yRatio;

	iSegmentThickness = RESCALE(3);
	iSegmentMargin = RESCALE(1);
	iNumberMargin = RESCALE(5);
	iNumbersWidth = RESCALE(150);
	iNumbersHeight = RESCALE(60);
	iEnvelopeWidth = RESCALE(75);
	iCallsWidth = RESCALE(55);
	iEnvelopeCallsHeight = RESCALE(55);
	iIdentifierMarginX = RESCALE(20);
	iMarginY = RESCALE(15);
	iScreenMarginY = RESCALE(5);
}

void CLargeTime::ConfigureL() {
	CCoeEnv* coeEnv = CCoeEnv::Static();
#ifdef EKA2
	_LIT(KResFile, "\\resource\\apps\\LargeTimeUI.r01");
#else
	_LIT(KResFile, "\\system\\data\\LargeTimeUI.r01");
#endif
	TPtrC drives[] = { _L("c:"), _L("e:"), _L("z:") };

	RFs fs;
	User::LeaveIfError(fs.Connect());
	TFileName filename;
	TInt drive;
	for (drive = 0; drive < 3; drive++) {
		filename.Format(_L("%S%S"), &drives[drive], &KResFile);
		BaflUtils::NearestLanguageFile(fs, filename);
//		TEntry entry;
//		TInt err = fs.Entry(filename, entry);
//		if (err == KErrNone)
//			break;
		if (BaflUtils::FileExists(fs, filename))
			break;
	}
	fs.Close();
	if (drive == 3)
		User::Leave(KErrNotFound);

	TInt offset = coeEnv->AddResourceFileL(filename);
	CAknQueryDialog* dialog;
	dialog = CAknQueryDialog::NewL();
	TInt ans1 = dialog->ExecuteLD(R_LARGETIME_WHITE);
	dialog = CAknQueryDialog::NewL();
	TInt ans2 = dialog->ExecuteLD(R_LARGETIME_WHOLE);
	coeEnv->DeleteResourceFile(offset);

	iWhite = ans1 == ELargeTimeWhite;
	iWholeBackground = ans2 == ELargeTimeNo;

	StoreL();
}

#ifdef EKA2
_LIT(KStoreFileName, "c:\\Settings\\LargeTimeSettings.dat");
_LIT(KSettingsDir, "c:\\Settings");
_LIT(KStoreOldFileName, "c:\\system\\data\\LargeTimeSettings.dat");
#else
_LIT(KStoreFileName, "c:\\system\\data\\LargeTimeSettings.dat");
#endif
static const TUid KUidLargeTimeSettings = { 0x00000001 };

void CLargeTime::StoreL() const {
	RFs fs;
	User::LeaveIfError(fs.Connect());
	CleanupClosePushL(fs);

	fs.MkDirAll(KStoreFileName);
#ifdef EKA2
	fs.SetAtt(KSettingsDir, KEntryAttHidden, 0);
#endif

	CFileStore* store = CDirectFileStore::ReplaceLC(fs, KStoreFileName, EFileWrite);
	store->SetTypeL(KDirectFileStoreLayoutUid);

	TStreamId id = StoreL(*store);

	CStreamDictionary* dictionary = CStreamDictionary::NewLC();
	dictionary->AssignL(KUidLargeTimeSettings, id);

	RStoreWriteStream dictStream;
	TStreamId dictId = dictStream.CreateLC(*store);
	dictionary->ExternalizeL(dictStream);
	dictStream.CommitL();

	CleanupStack::PopAndDestroy();
	CleanupStack::PopAndDestroy(dictionary);

	store->SetRootL(dictId);
	store->CommitL();

	CleanupStack::PopAndDestroy(store);

	CleanupStack::PopAndDestroy();
}

void CLargeTime::RestoreL() {
	RFs fs;
	User::LeaveIfError(fs.Connect());
	CleanupClosePushL(fs);

	TInt err;
	TRAP(err, RestoreFileL(fs, KStoreFileName));
#ifdef EKA2
	if (err != KErrNone) {
		TRAP(err, RestoreFileL(fs, KStoreOldFileName));
		if (err == KErrNone) {
			StoreL();
			fs.Delete(KStoreOldFileName);
		}
	}
#endif
	CleanupStack::PopAndDestroy(&fs);
}

void CLargeTime::RestoreFileL(RFs& aFs, const TDesC& aFileName) {
	CFileStore* store = CDirectFileStore::OpenLC(aFs, aFileName, EFileRead);

	RStoreReadStream dictStream;
	dictStream.OpenLC(*store, store->Root());

	CStreamDictionary* dictionary = CStreamDictionary::NewLC();
	dictionary->InternalizeL(dictStream);
	
	TStreamId id = dictionary->At(KUidLargeTimeSettings);

	CleanupStack::PopAndDestroy(dictionary);
	CleanupStack::PopAndDestroy();

	RestoreL(*store, id);

	CleanupStack::PopAndDestroy(store);
}

TStreamId CLargeTime::StoreL(CStreamStore& aStore) const {
	RStoreWriteStream stream;
	TStreamId id = stream.CreateLC(aStore);
	ExternalizeL(stream);
	stream.CommitL();
	CleanupStack::PopAndDestroy();
	return id;
}

void CLargeTime::RestoreL(const CStreamStore& aStore, TStreamId aStreamId) {
	RStoreReadStream stream;
	stream.OpenLC(aStore, aStreamId);
	InternalizeL(stream);
	CleanupStack::PopAndDestroy();
}

void CLargeTime::ExternalizeL(RWriteStream& aStream) const {
	aStream.WriteInt32L(1);
	aStream.WriteInt32L(iWhite);
	aStream.WriteInt32L(iWholeBackground);
}

void CLargeTime::InternalizeL(RReadStream& aStream) {
	TInt version = aStream.ReadInt32L();
	if (version != 1) User::Leave(KErrNotSupported);
	iWhite = aStream.ReadInt32L();
	iWholeBackground = aStream.ReadInt32L();
}

