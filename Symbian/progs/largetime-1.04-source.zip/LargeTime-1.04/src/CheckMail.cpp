/*
    Large Time Screensaver
    Copyright 2005 - 2007 Martin Storsj�

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version. 

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

    Martin Storsj�
    martin@martin.st
*/

#include "CheckMail.h"
#include <msvapi.h>
#include <msvstd.h>
#include <msvids.h>
#include <smut.h>
#include <btmsgtypeuid.h>
#include <miutset.h>
#include <mtclreg.h>
#include <mtclbase.h>

#include <flogger.h>

const TUid KUidMsvTechnologyGroupEmail = {0x10001671}; 


#ifdef EKA2
#include <e32property.h>

// From Forum Nokia Wiki, KCoreAppUIsNewEmailStatus API
const TUid KPSUidCoreApplicationUIs = { 0x101F8767 };
const TUint32 KCoreAppUIsNewEmailStatus = { 0x00000112 };

enum TCoreAppUIsNewEmailStatus { 
	ECoreAppUIsNewEmailStatusUninitialized = 0,
	ECoreAppUIsNoNewEmail,
	ECoreAppUIsNewEmail 
};
#endif


CCheckMail* CCheckMail::NewLC() {
	CCheckMail* self = new(ELeave) CCheckMail();
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
}

CCheckMail* CCheckMail::NewL() {
	CCheckMail* self = NewLC();
	CleanupStack::Pop(self);
	return self;
}

CCheckMail::CCheckMail() {
}

CCheckMail::~CCheckMail() {
	delete iRegistry;
	delete iSession;
}

void CCheckMail::ConstructL() {
	iSession = CMsvSession::OpenSyncL(*this);
	iRegistry = CClientMtmRegistry::NewL(*iSession);
}

void CCheckMail::HandleSessionEvent(TMsvSessionEvent aEvent, TAny* aArg1, TAny* aArg2, TAny* aArg3) {
}

void CCheckMail::HandleSessionEventL(TMsvSessionEvent aEvent, TAny* aArg1, TAny* aArg2, TAny* aArg3) {
}



void CCheckMail::CountMailsInFolderL(CBaseMtm* aMtm, TMsvId aId, TInt& aTotal, TInt& aUnread) {
	aMtm->SwitchCurrentEntryL(aId);
	CMsvEntry &entry = aMtm->Entry();
	CMsvEntrySelection* selection = entry.ChildrenWithMtmL(aMtm->Type());
	CleanupStack::PushL(selection);
	aTotal += selection->Count();
	for (TInt i = 0; i < selection->Count(); i++) {
		TMsvId id = selection->At(i);
		aMtm->SwitchCurrentEntryL(id);
		if (aMtm->Entry().Entry().Unread())
			aUnread++;
	}
	CleanupStack::PopAndDestroy(selection);
}

void CCheckMail::CountMailsInMtmL(CBaseMtm* aMtm, TInt& aTotal, TInt &aUnread) {
	CMsvEntry* entry = CMsvEntry::NewL(*iSession, KMsvRootIndexEntryId, TMsvSelectionOrdering());
	CleanupStack::PushL(entry);
	CMsvEntrySelection* selection = entry->ChildrenWithMtmL(aMtm->Type());
	CleanupStack::PushL(selection);
	for (TInt i = 0; i < selection->Count(); i++) {
		aMtm->SwitchCurrentEntryL(selection->At(i));

		CMsvEntrySelection* folders = aMtm->Entry().ChildrenWithMtmL(aMtm->Type());
		CleanupStack::PushL(folders);
		for (TInt j = 0; j < folders->Count(); j++) {
			CountMailsInFolderL(aMtm, folders->At(j), aTotal, aUnread);
		}
		CleanupStack::PopAndDestroy(folders);
	}
	CleanupStack::PopAndDestroy(selection);
	CleanupStack::PopAndDestroy(entry);
}

void CCheckMail::CountMailsL(TInt& aTotal, TInt& aUnread) {
	for (TInt i = 0; i < iRegistry->NumRegisteredMtmDlls(); i++) {
		TUid uid = iRegistry->MtmTypeUid(i);
		if (iRegistry->TechnologyTypeUid(uid) == KUidMsvTechnologyGroupEmail) {
			CBaseMtm* mtm = iRegistry->NewMtmL(uid);
			CleanupStack::PushL(mtm);
			CountMailsInMtmL(mtm, aTotal, aUnread);
			CleanupStack::PopAndDestroy(mtm);
		}
	}
}

TInt CCheckMail::CountUnreadL() {
	CCheckMail* check = CCheckMail::NewLC();

	TInt emails = 0;
	TInt unread = 0;
	check->CountMailsL(emails, unread);

	CleanupStack::PopAndDestroy(check);
	return unread;
}

TInt CCheckMail::CountUnread() {
	TInt num = 0;
	TRAPD(err, num = CountUnreadL());
	if (err != KErrNone) {
		RFileLogger::WriteFormat(_L("debug"), _L("mail.txt"), EFileLoggingModeAppend, _L("CCheckMail::CountUnreadL: %d"), err);
		return 0;
	} else {
		return num;
	}
}

TBool CCheckMail::GetUnread(TInt& aCount) {
#ifdef EKA2
	aCount = -1;
	TInt status;
	RProperty::Get(KPSUidCoreApplicationUIs, KCoreAppUIsNewEmailStatus, status);
	return status == ECoreAppUIsNewEmail;
#else
	aCount = CountUnread();
	return aCount > 0;
#endif
}


