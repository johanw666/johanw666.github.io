call makesis Symella_S60-3rd.pkg
call signsis -s Symella_S60-3rd.SIS Symella_S60-3rd.SISX SymTorrent2008-10-11.cer SymTorrent2008-10-11.key amorg

