makesis Symella_S60-3rd.pkg
signsis Symella_S60-3rd.sis Symella_S60-3rd.sisx Symella.cer Symella.key