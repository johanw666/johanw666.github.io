/*****************************************************************************
 * Copyright (C) 2005, 2006 Imre Kel�nyi, Bertalan Forstner
 *-------------------------------------------------------------------
 * This file is part of Symella
 *
 * Symella is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Symella is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Symella; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *****************************************************************************/

#include "FileSelectionSettingItem.h"
#include <aknlists.h> 
#include <avkon.hrh>
#include <aknPopup.h>
#include <caknfileselectiondialog.h>
#include <caknmemoryselectiondialog.h> 


CFileSelectionSettingItem::CFileSelectionSettingItem(TInt aIdentifier, TFileName& aFileName, TCommonDialogType aDialogType) :
	CAknTextSettingItem(aIdentifier, aFileName),
	iFileName(aFileName),
	iDialogType(aDialogType),
	iOwnedFileName(aFileName)
{		
}

void CFileSelectionSettingItem::LoadL() 
{ 
	CAknTextSettingItem::LoadL();
}

const TDesC& CFileSelectionSettingItem::SettingTextL( ) 
{
	return iOwnedFileName;
}

void CFileSelectionSettingItem::EditItemL(TBool /*aCalledFromMenu*/)
{
	// Select memory
	CAknMemorySelectionDialog* memSelectionDialog = CAknMemorySelectionDialog::NewL
		(ECFDDialogTypeNormal, /*aShowUnavailableDrives*/EFalse);
	CleanupStack::PushL(memSelectionDialog);

	CAknMemorySelectionDialog::TMemory mem(CAknMemorySelectionDialog::EPhoneMemory);

	TInt ret = memSelectionDialog->ExecuteL(mem);
	CleanupStack::PopAndDestroy(memSelectionDialog);
	if (!ret) return;

	CAknFileSelectionDialog* fileSelectionDialog = 
		CAknFileSelectionDialog::NewL(iDialogType);	
	CleanupStack::PushL(fileSelectionDialog);
	
	fileSelectionDialog->SetTitleL(_L("Download files to"));
	fileSelectionDialog->SetLeftSoftkeyFileL(_L("Select"));	
	
	if (mem == CAknMemorySelectionDialog::EMemoryCard)	
		iOwnedFileName = _L("E:\\");
	else
#ifdef EKA2
		iOwnedFileName = _L("C:\\Data"); 
#else
		iOwnedFileName = _L("C:\\Nokia"); 
#endif

	// launch file select dialog
	TBool result = fileSelectionDialog->ExecuteL(iOwnedFileName);
	CleanupStack::PopAndDestroy(); // fileSelectionDialog
	
	if (result)
		iFileName = iOwnedFileName;
	else
		iOwnedFileName = iFileName;
}

