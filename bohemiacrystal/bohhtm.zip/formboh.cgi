#!/usr/bin/perl

# ------------------------------------------------------------
# Form-mail.pl, by Reuven M. Lerner (reuven@the-tech.mit.edu).
#
# Last updated: March 14, 1994
#
# Form-mail provides a mechanism by which users of a World-
# Wide Web browser may submit comments to the webmasters
# (or anyone else) at a site.  It should be compatible with
# any CGI-compatible HTTP server.
# 
# Please read the README file that came with this distribution
# for further details.
# ------------------------------------------------------------

# ------------------------------------------------------------
# This package is Copyright 1994 by The Tech. 

# Form-mail is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 2, or (at your option) any
# later version.

# Form-mail is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Form-mail; see the file COPYING.  If not, write to the Free
# Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# ------------------------------------------------------------

# Define fairly-constants

# This should match the mail program on your system.
$mailprog = '/usr/lib/sendmail';

# This should be set to the username or alias that runs your
# WWW server.
$recipient = 'bohemian@vulcan.xs4all.nl';
#$recipient = 'johanw@iae.nl';

# Print out a content-type for HTTP/1.0 compatibility
print "Content-type: text/html\n\n";

# Print a title and initial heading
print "<Head><Title>Bedankt voor uw reactie</Title></Head>";
#print "<Body BGCOLOR=#022C76>";

print "<body bgcolor=#FFFFFF background=blank text=#FFFFFF link=#FFFFFF vlink=#FFFFFF alink=#FFFFFF>";
print "<table width=100\% border=0 cellspacing=4 cellpadding=4>";
print "<tr><td valign=top colspan=2><p>";
print "<font face=\"Arial, Helvetica, sans-serif\" size=\"1\" color=\"#FF0000\"><b><font size=\"2\"><font color=\"#000000\" size=\"2\">";
print "<font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#000000\"><b></b></font><p>\&nbsp\;</p>";
print "<p><font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#FFFFFF\">Uw bericht is verstuurd.</font></p>";
print "<p><font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#000000\">";
print "<a href=\"http://www.electex.nl/Registration_NL.htm\">Klik hier om terug naar de hoofdpagina te gaan.</a>";
print "</font></p><p>\&nbsp\;</p><p><font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#000000\"><b><br>";
print "</b></font> </p></td> <td valign=\"top\" width=\"50\">\&nbsp\;\&nbsp\;\&nbsp\;</td> </tr></table>";


# Get the input
read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});

# Split the name-value pairs
@pairs = split(/&/, $buffer);

foreach $pair (@pairs)
{
    ($name, $value) = split(/=/, $pair);

    # Un-Webify plus signs and %-encoding
    $value =~ tr/+/ /;
    $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

    # Stop people from using subshells to execute commands
    # Not a big deal when using sendmail, but very important
    # when using UCB mail (aka mailx).
    # $value =~ s/~!/ ~!/g; 

    # Uncomment for debugging purposes
    # print "Setting $name to $value<P>";

    $FORM{$name} = $value;
}

# If the comments are blank, then give a "blank form" response
#&blank_response unless $FORM{'naam'};

# Now send mail to $recipient

open  (MAIL, "|$mailprog $recipient") || die "Can't open $mailprog!\n";
print MAIL "Reply-to: $FORM{'email'} ($FORM{'naam'})\n";
print MAIL "Subject: Bestelling via de website\n\n";
print MAIL "$FORM{'naam'} bestelde het volgende\n";
print MAIL "NAW gegevens:\n";
print MAIL  "------------------------------------------------------------\n";
print MAIL "Naam: $FORM{'naam'}\n";
print MAIL "Adres: $FORM{'adres'}\n";
print MAIL "Postcode: $FORM{'postcode'}\n";
print MAIL "Plaats: $FORM{'plaats'}\n";
print MAIL "Land: $FORM{'land'}\n";
print MAIL "Telefoon: $FORM{'telefoon'}\n";
print MAIL "Email: $FORM{'email'}\n";
print MAIL "\n";
print MAIL "Aantal 12170/160: $FORM{'12170160'}";
print MAIL " Subtotaal: $FORM{'12170160_totaal'}\n";
print MAIL "Aantal 12170/210: $FORM{'12170210'}";
print MAIL " Subtotaal: $FORM{'12170210_totaal'}\n";
print MAIL "Aantal 12116/170: $FORM{'12116170'}";
print MAIL " Subtotaal: $FORM{'12116170_totaal'}\n";
print MAIL "Aantal 12703/090: $FORM{'12703090'}";
print MAIL " Subtotaal: $FORM{'12703090_totaal'}\n";
print MAIL "Aantal 22093/230: $FORM{'22093230'}";
print MAIL " Subtotaal: $FORM{'22093230_totaal'}\n";
print MAIL "Aantal 20001/350: $FORM{'20001350'}";
print MAIL " Subtotaal: $FORM{'20001350_totaal'}\n";
print MAIL "Aantal 80080/205: $FORM{'80080205'}";
print MAIL " Subtotaal: $FORM{'80080205_totaal'\n";
print MAIL "Aantal 61147/300: $FORM{'61147300'}";
print MAIL " Subtotaal: $FORM{'61147300_totaal'}\n";
print MAIL "Aantal 69019/200: $FORM{'69019200'}";
print MAIL " Subtotaal: $FORM{'69019200_totaal'}\n";
print MAIL "Aantal 60386/230: $FORM{'60386230'}";
print MAIL " Subtotaal: $FORM{'60386230_totaal'}\n";
print MAIL "Aantal 66025/280: $FORM{'66025280'}";
print MAIL " Subtotaal: $FORM{'66025280_totaal'}\n";
print MAIL "Aantal 60665/254: $FORM{'60665254'}";
print MAIL " Subtotaal: $FORM{'60665254_totaal'}\n";
print MAIL "Aantal 70125/155: $FORM{'70125155'}";
print MAIL " Subtotaal: $FORM{'70125155_totaal'}\n";
print MAIL "Aantal 80469/150: $FORM{'80469150'}";
print MAIL " Subtotaal: $FORM{'80469150_totaal'}\n";
print MAIL "Aantal 23057/500: $FORM{'23057500'}";
print MAIL " Subtotaal: $FORM{'23057500_totaal'}\n";
print MAIL "Totaal: Eur $FORM{'totaal'}\n";

close (MAIL);

# Make the person feel good for writing to us

#print "Bedankt voor uw reactie<P>";
#print "Klik hier om terug te gaan:
#HREF=\"http://www.xs4all.nl/~johanw/prijzen.htm\">Bohemia Crystal</A>";

# ------------------------------------------------------------
# subroutine blank_response
sub blank_response
{
    print "U bent een aantal velden vergeten in te vullen, er is dus ook geen mailtje verzonden<BR>";
    print "Klik op BACK om terug naar het mail-form te gaan<BR>";
    print "of ga terug naar de hoofdpagina <A HREF=\"http://www.xs4all.nl/bohemiacrystal/index.htm\">www.elextec.nl</A><P>";
    exit;
}

