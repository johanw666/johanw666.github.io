#!/usr/bin/perl

# ------------------------------------------------------------
# Form-mail.pl, by Reuven M. Lerner (reuven@the-tech.mit.edu).
#
# Last updated: March 14, 1994
#
# Form-mail provides a mechanism by which users of a World-
# Wide Web browser may submit comments to the webmasters
# (or anyone else) at a site.  It should be compatible with
# any CGI-compatible HTTP server.
# 
# Please read the README file that came with this distribution
# for further details.
# ------------------------------------------------------------

# ------------------------------------------------------------
# This package is Copyright 1994 by The Tech. 

# Form-mail is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 2, or (at your option) any
# later version.

# Form-mail is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Form-mail; see the file COPYING.  If not, write to the Free
# Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# ------------------------------------------------------------

# Define fairly-constants

# This should match the mail program on your system.
$mailprog = '/usr/lib/sendmail';

# This should be set to the username or alias that runs your
# WWW server.
$recipient = 'bohemian@vulcan.xs4all.nl';
#$recipient = 'johanw@iae.nl';

# Print out a content-type for HTTP/1.0 compatibility
print "Content-type: text/html\n\n";

# Print a title and initial heading
print "<Head><Title>Bedankt voor uw reactie</Title></Head>";
#print "<Body BGCOLOR=#022C76>";

print "<body bgcolor=#FFFFFF background=blank text=#FFFFFF link=#FFFFFF vlink=#FFFFFF alink=#FFFFFF>";
print "<table width=100\% border=0 cellspacing=4 cellpadding=4>";
print "<tr><td valign=top colspan=2><p>";
print "<font face=\"Arial, Helvetica, sans-serif\" size=\"1\" color=\"#FF0000\"><b><font size=\"2\"><font color=\"#000000\" size=\"2\">";
print "<font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#000000\"><b></b></font><p>\&nbsp\;</p>";
print "<p><font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#FFFFFF\">Uw bericht is verstuurd.</font></p>";
print "<p><font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#000000\">";
print "<a href=\"http://www.electex.nl/Registration_NL.htm\">Klik hier om terug naar de hoofdpagina te gaan.</a>";
print "</font></p><p>\&nbsp\;</p><p><font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#000000\"><b><br>";
print "</b></font> </p></td> <td valign=\"top\" width=\"50\">\&nbsp\;\&nbsp\;\&nbsp\;</td> </tr></table>";


# Get the input
read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});

# Split the name-value pairs
@pairs = split(/&/, $buffer);

foreach $pair (@pairs)
{
    ($name, $value) = split(/=/, $pair);

    # Un-Webify plus signs and %-encoding
    $value =~ tr/+/ /;
    $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

    # Stop people from using subshells to execute commands
    # Not a big deal when using sendmail, but very important
    # when using UCB mail (aka mailx).
    # $value =~ s/~!/ ~!/g; 

    # Uncomment for debugging purposes
    # print "Setting $name to $value<P>";

    $FORM{$name} = $value;
}

# If the comments are blank, then give a "blank form" response
#&blank_response unless $FORM{'naam'};

# Now send mail to $recipient

open  (MAIL, "|$mailprog $recipient") || die "Can't open $mailprog!\n";
print MAIL "Reply-to: $FORM{'email'} ($FORM{'naam'})\n";
print MAIL "Subject: Bestelling via de website\n\n";
print MAIL "$FORM{'naam'} bestelde de volgende kerstversieringen:\n";
print MAIL "NAW gegevens:\n";
print MAIL  "------------------------------------------------------------\n";
print MAIL "Naam: $FORM{'naam'}\n";
print MAIL "Adres: $FORM{'adres'}\n";
print MAIL "Postcode: $FORM{'postcode'}\n";
print MAIL "Plaats: $FORM{'plaats'}\n";
print MAIL "Telefoon: $FORM{'telefoon'}\n";
print MAIL "Email: $FORM{'email'}\n";
print MAIL "\n";
print MAIL "Aantal 183 42: $FORM{'18342'}\n";
print MAIL "Aantal 071 00: $FORM{'07100'}\n";
print MAIL "Aantal 189 00: $FORM{'18900'}\n";
print MAIL "Aantal 183 77: $FORM{'18377'}\n";
print MAIL "Aantal 184 42: $FORM{'18442'}\n";
print MAIL "Aantal 072 00: $FORM{'07200'}\n";
print MAIL "Aantal 189 02: $FORM{'18902'}\n";
print MAIL "Aantal 184 77: $FORM{'18477'}\n";
print MAIL "Aantal 185 42: $FORM{'18542'}\n";
print MAIL "Aantal 107 00: $FORM{'10700'}\n";
print MAIL "Aantal 216 10: $FORM{'21610'}\n";
print MAIL "Aantal 185 77: $FORM{'18577'}\n";
print MAIL "Aantal 186 42: $FORM{'18642'}\n";
print MAIL "Aantal 108 00: $FORM{'10800'}\n";
print MAIL "Aantal 215 70: $FORM{'21570'}\n";
print MAIL "Aantal 186 77: $FORM{'18677'}\n";
print MAIL "Aantal 187 42: $FORM{'18742'}\n";
print MAIL "Aantal 110 10: $FORM{'11010'}\n";
print MAIL "Aantal 190 63: $FORM{'19063'}\n";
print MAIL "Aantal 187 77: $FORM{'18777'}\n";
close (MAIL);

# Make the person feel good for writing to us

#print "Bedankt voor uw reactie<P>";
#print "Klik hier om terug: 
#HREF=\"http://www.xs4all.nl/~johanw/prijzen.htm\">Bohemia Crystal</A>";

# ------------------------------------------------------------
# subroutine blank_response
sub blank_response
{
    print "U bent een aantal velden vergeten in te vullen, er is dus ook geen mailtje verzonden<BR>";
    print "Klik op BACK om terug naar het mail-form te gaan<BR>";
    print "of ga terug naar de hoofdpagina <A HREF=\"http://www.xs4all.nl/bohemiacrystal/index.htm\">www.elextec.nl</A><P>";
    exit;
}

