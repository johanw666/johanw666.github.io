//------------------------------------------------------------------------------
// This file is part of Remote Service Control Center by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: dirsel.h
//------------------------------------------------------------------------------
#ifndef dirselH
#define dirselH
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <FileCtrl.hpp>
//------------------------------------------------------------------------------
class TDirSelForm: public TForm
{
__published:
  TPanel* Panel1;
  TPanel* Panel2;
  TPanel* Panel3;
  TPanel* Panel4;
  TDriveComboBox* DriveComboBox1;
  TDirectoryListBox* DirectoryListBox1;
  TButton* CancelButton;
  TButton* OKButton;
  void __fastcall FormResize(TObject* Sender);
private:
  __fastcall TDirSelForm(TComponent* Owner);
public:
  __fastcall TDirSelForm(TComponent* Owner, AnsiString startDir);
};
//------------------------------------------------------------------------------
#endif
