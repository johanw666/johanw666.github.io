//------------------------------------------------------------------------------
// This file is part of Remote Service Control Center by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: logfile.cpp
//
// Contains the form to show a logfile.
//------------------------------------------------------------------------------
#include <vcl.h>
#include <stdlib.h>
#pragma hdrstop

#include "logfile.h"
//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

//------------------------------------------------------------------------------
// Standard constructor. Private, not to be used.
//------------------------------------------------------------------------------
__fastcall TViewLogFileForm::TViewLogFileForm(TComponent* Owner): TForm(Owner)
{
}

//------------------------------------------------------------------------------
// Constructor. Reads data from the specified logfile.
//------------------------------------------------------------------------------
__fastcall TViewLogFileForm::TViewLogFileForm(TComponent* Owner,
                                              AnsiString aLogFileName,
                                              int  aLogRefreshTime,
                                              bool autoRefresh, // Refresh time in ms
                                              bool aProxyConlogFile,
                                              AnsiString aRC5Challenge): TForm(Owner)
{
  LogFileName = aLogFileName;
  fProxyConlogFile = aProxyConlogFile;
  RC5Challenge = aRC5Challenge;
  if ( !fProxyConlogFile ) {
    // Make proxy controls invisible
    FilterRC5CheckBox->Enabled = false;
    FilterRC5CheckBox->Visible = false;
    FilterOGRCheckBox->Enabled = false;
    FilterOGRCheckBox->Visible = false;
    FilterOGRP2CheckBox->Enabled = false;
    FilterOGRP2CheckBox->Visible = false;
    FilterOGRNGCheckBox->Enabled = false;
    FilterOGRNGCheckBox->Visible = false;
    RC5SentLabel->Visible = false;
    OGRSentLabel->Visible = false;
    OGRP2SentLabel->Visible = false;
    OGRNGSentLabel->Visible = false;
    // Panel can be smaller when checkboxes are not there
    Panel1->Height = 33;
    RefreshButton->Top = 4;
    CloseButton->Top = 4;
  }
  RefreshTimer->Interval = aLogRefreshTime;
  // See if the timer should be enabled
  if ( autoRefresh ) RefreshTimer->Enabled = true;
  if ( FileExists(aLogFileName) )
    RefreshText(NULL);
  else {
    AnsiString errorMsg = "Could not find logfile " + aLogFileName;
    Application->MessageBox(errorMsg.c_str(), Application->Title.c_str(), MB_OK);
  }
  Caption = aLogFileName;
  if ( Owner ) {
    Top = ((TForm*)Owner)->Top + (((TForm*)Owner)->Height - Height);
    if ( Top < 0 ) Top = 0;
    Left = ((TForm*)Owner)->Left;
  } else
    Position = poScreenCenter;
  // Safe defaults
  mainForm = NULL;
  windowMenuItem = NULL;
}

//------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------
void __fastcall TViewLogFileForm::CloseButtonClick(TObject* Sender)
{
  Close();
}

//------------------------------------------------------------------------------
// Refresh the logfile contents.
//------------------------------------------------------------------------------
void __fastcall TViewLogFileForm::RefreshText(TObject* Sender)
{
  bool b1, b2;
  char rc5Identifier0[32];
  memset(rc5Identifier0, 0, sizeof(rc5Identifier0));
  strcpy(rc5Identifier0, ",rc5");
  // For RC5-64 no "-" was written in the logfile
  if ( !((RC5Challenge.c_str()[0] == '6') && (RC5Challenge.c_str()[1] == '4')))
    strcat(rc5Identifier0, "-");
  strcat(rc5Identifier0, RC5Challenge.c_str());
  strcat(rc5Identifier0, " r=");
  char rc5Identifier1[64];
  memset(rc5Identifier1, 0, sizeof(rc5Identifier1));
  strcpy(rc5Identifier1, "Status: rc5");
  // For RC5-64 no "-" was written in the logfile
  if ( !((RC5Challenge.c_str()[0] == '6') && (RC5Challenge.c_str()[1] == '4')))
    strcat(rc5Identifier1, "-");
  strcat(rc5Identifier1, RC5Challenge.c_str());
  strcat(rc5Identifier1, ": Last uplink sent ");
  // OGR
  const char ogrIdentifier0[] = ",ogr r=";
  const char ogrIdentifier1[] = "Status: ogr: Last uplink sent ";
  // OGR P2
  const char ogrp2Identifier0[] = ",ogrp2 r=";
  const char ogrp2Identifier1[] = "Status: ogrp2: Last uplink sent ";
  // OGR NG
  const char ogrngIdentifier0[] = ",ogrng r=";
  const char ogrngIdentifier1[] = "Status: ogrng: Last uplink sent ";
  bool showLine; // Set to true if a line matches with a filter
  int i, totalBlocksSent, totalStubsOGRSent, totalStubsOGRP2Sent, totalStubsOGRNGSent;

  LogFileMemo->Lines->Clear();

  if ( !FilterRC5CheckBox->Checked && !FilterOGRCheckBox->Checked && !FilterOGRP2CheckBox->Checked && !FilterOGRNGCheckBox->Checked) {
    // Show all loglines
    LogFileMemo->Lines->LoadFromFile(LogFileName);
    SetCursorPos();
  } else {
    // Filter the loglines
    TStringList* sl = new TStringList;
    if ( sl ) {
      sl->LoadFromFile(LogFileName);
      totalBlocksSent = 0;
      totalStubsOGRSent = 0;
      totalStubsOGRP2Sent = 0;
      totalStubsOGRNGSent = 0;
      for (i = 0; i < sl->Count; i++) {
        showLine = false;

        if ( FilterRC5CheckBox->Checked ) {
          b1 = strstr(sl->Strings[i].c_str(), rc5Identifier0);
          b2 = strstr(sl->Strings[i].c_str(), rc5Identifier1);
          if ( b1 || b2 ) showLine = true;
          if (b2) totalBlocksSent += GetNrOfBlocksInLine(sl->Strings[i], rc5Identifier1);
        }
        if ( FilterOGRCheckBox->Checked && !showLine ) { // Extra test for showLine to prevent checking RC5 lines for OGR stubs, saves time
          b1 = strstr(sl->Strings[i].c_str(), ogrIdentifier0);
          b2 = strstr(sl->Strings[i].c_str(), ogrIdentifier1);
          if ( b1 || b2 ) showLine = true;
          if (b2) totalStubsOGRSent += GetNrOfBlocksInLine(sl->Strings[i], ogrIdentifier1);
        }
        if ( FilterOGRP2CheckBox->Checked && !showLine ) {
          b1 = strstr(sl->Strings[i].c_str(), ogrp2Identifier0);
          b2 = strstr(sl->Strings[i].c_str(), ogrp2Identifier1);
          if ( b1 || b2 ) showLine = true;
          if (b2) totalStubsOGRP2Sent += GetNrOfBlocksInLine(sl->Strings[i], ogrp2Identifier1);
        }
        if ( FilterOGRNGCheckBox->Checked && !showLine ) {
          b1 = strstr(sl->Strings[i].c_str(), ogrngIdentifier0);
          b2 = strstr(sl->Strings[i].c_str(), ogrngIdentifier1);
          if ( b1 || b2 ) showLine = true;
          if (b2) totalStubsOGRNGSent += GetNrOfBlocksInLine(sl->Strings[i], ogrngIdentifier1);
        }
        if ( !showLine ) {
          sl->Delete(i); // Delete the line
          i--;           // String numbers are reset, go back one line number
        }
      } // for nroflines
      RC5SentLabel->Caption = "Sent " + IntToStr(totalBlocksSent) + " blocks";
      OGRSentLabel->Caption = "Sent " + IntToStr(totalStubsOGRSent) + " stubs";
      OGRP2SentLabel->Caption = "Sent " + IntToStr(totalStubsOGRP2Sent) + " stubs";
      OGRNGSentLabel->Caption = "Sent " + IntToStr(totalStubsOGRNGSent) + " stubs";
      LogFileMemo->Lines = sl;
      delete sl;
      SetCursorPos();
    }
  }
}

//------------------------------------------------------------------------------
// Calculate the number of blocks/stubs mentioned in a logfile line
//------------------------------------------------------------------------------
int __fastcall TViewLogFileForm::GetNrOfBlocksInLine(AnsiString line, const char* identifier)
{
  int i, Result = 0;
  char nr[16];
  char* c = strstr(line.c_str(), identifier);
  if ( c ) {
    // Get the chars after identifier, which is the number, up to the first space
    for (i = 0; !isspace(*(c + i + strlen(identifier))); i++);
    strncpy(nr, c + strlen(identifier), i);
    *(nr + i) = 0; // Cut it off (if previous nr was longer than this one)
    try {
      Result = atoi(nr);
    } catch (...) { // atoi error
    }
  }
  return Result;
}

//------------------------------------------------------------------------------
// Set the cursor to the end of the loaded text.
//------------------------------------------------------------------------------
void __fastcall TViewLogFileForm::SetCursorPos()
{
  int i, j;

  for (j = 0, i = 0; i < LogFileMemo->Lines->Count; i++)
    j += LogFileMemo->Lines->Strings[i].Length() + 2; // 2 for \r\n

  LogFileMemo->SelStart = j;
  LogFileMemo->SelLength = 1;
}

//------------------------------------------------------------------------------
// Filter the lines from the personal proxy console logfile. We only want to see
// lines with number of blocks in the buffer and lines with number of blocks
// sent to the uplink.
//------------------------------------------------------------------------------
void __fastcall TViewLogFileForm::FilterCheckBoxClick(TObject* Sender)
{
  RefreshText(Sender);
  RC5SentLabel->Visible = FilterRC5CheckBox->Checked;
  OGRSentLabel->Visible = FilterOGRCheckBox->Checked;
  OGRP2SentLabel->Visible = FilterOGRP2CheckBox->Checked;
  OGRNGSentLabel->Visible = FilterOGRNGCheckBox->Checked;
}

//------------------------------------------------------------------------------
// Close the form when escape or enter is pressed.
//------------------------------------------------------------------------------
void __fastcall TViewLogFileForm::CloseButtonKeyDown(TObject* Sender, WORD& Key, TShiftState Shift)
{
  if ( (Key == VK_ESCAPE) || (Key == VK_RETURN) ) Close();
}

//------------------------------------------------------------------------------
// Set the cursor to the bottom of the text the first time the form is shown.
// Disable the timer afterwards.
//------------------------------------------------------------------------------
void __fastcall TViewLogFileForm::SetCursorTimerTimer(TObject* Sender)
{
  SetCursorTimer->Enabled = false;
  SetCursorPos();
}

//------------------------------------------------------------------------------
// Notify parent form (TMainForm) that the window is closed,
// to remove the pointer from the childlist and delete allocated memory.
//------------------------------------------------------------------------------
void __fastcall TViewLogFileForm::FormClose(TObject* Sender, TCloseAction& Action)
{
  if ( mainForm ) {
    // PostMessage!!! since we cannot let the receive method execute its code here
    // (which is deleting the object we're just running in :)
    PostMessage(mainForm->Handle, WM_CLOSE_VIEW_LOGFILE, (WPARAM)this, (LPARAM)windowMenuItem);
  }
}

//------------------------------------------------------------------------------


