//------------------------------------------------------------------------------
// This file is part of Remote Service Control Center by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: defsetup.h
//------------------------------------------------------------------------------
#ifndef defsetupH
#define defsetupH
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>

#include "scc.h"
#include <Mask.hpp>
//------------------------------------------------------------------------------
class TDefaultsForm: public TForm
{
__published:
  TPanel* Panel1;
  TPanel* Panel2;
  TPanel* Panel3;
  TButton* OKButton;
  TButton* CancelButton;
  TEdit* ExeNameEdit;
  TEdit* IniNameEdit;
  TEdit* RemotePathEdit;
  TLabel* ExeLabel;
  TLabel* IniLabel;
  TLabel* DestPathLabel;
  TLabel* RemotenameLabel;
  TEdit* RemoteNameEdit;
  TButton* BrowseExeButton;
  TButton* BrowseIniButton;
  TOpenDialog* FileOpenDialog;
  TLabel* DisplayLabel;
  TEdit* DisplayNameEdit;
  TButton* BrowsePathButton;
  TLabel* ServiceNameLabel;
  TEdit* ServiceNameEdit;
  TLabel* ArgumentsLabel;
  TEdit* ArgumentsEdit;
  TCheckBox* EditNameCheckBox;
  TCheckBox* EditParamsCheckBox;
  TRadioGroup* StartupRadioGroup;
  TRadioButton* AutoRadioButton;
  TRadioButton* ManualRadioButton;
  TCheckBox* StartAfterInstallCheckBox;
  TGroupBox* IniFileGroupBox;
  TEdit* IniFileSectionEdit;
  TLabel* IniSectionLabel;
  TLabel* IniKeyLabel;
  TEdit* IniFileKeyEdit;
  TButton* EditIniButton;
  void __fastcall OKButtonClick(TObject* Sender);
  void __fastcall CancelButtonClick(TObject* Sender);
  void __fastcall BrowseExeButtonClick(TObject* Sender);
  void __fastcall BrowseIniButtonClick(TObject* Sender);
  void __fastcall BrowsePathButtonClick(TObject* Sender);
  void __fastcall RemotePathEditExit(TObject* Sender);
  void __fastcall EditNameCheckBoxClick(TObject* Sender);
  void __fastcall EditParamsCheckBoxClick(TObject* Sender);
  void __fastcall FormResize(TObject* Sender);
  void __fastcall EditIniButtonClick(TObject* Sender);
private:
  ServiceParams* CfgData;
  __fastcall TDefaultsForm(TComponent* Owner); // Hide default constructor
  void __fastcall CopySettings(void);
public:
  __fastcall TDefaultsForm(TComponent* Owner, ServiceParams* aCfg);
  void __fastcall SetTitle(AnsiString aTitle);
};
//------------------------------------------------------------------------------
#endif

