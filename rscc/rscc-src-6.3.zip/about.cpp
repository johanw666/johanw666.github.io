//------------------------------------------------------------------------------
// This file is part of Remote Service Control Center by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: about.cpp
//
// Contains the about form.
//------------------------------------------------------------------------------
#include <vcl.h>
#include <shellapi.h>
#pragma hdrstop

#include "about.h"
#include "scc.h"
//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAboutForm* AboutForm;
//------------------------------------------------------------------------------
__fastcall TAboutForm::TAboutForm(TComponent* Owner): TForm(Owner)
{
  Caption = "About " + Application->Title;
  Panel3->Color = (TColor)0x00E1FFFF;
}

//------------------------------------------------------------------------------
void __fastcall TAboutForm::OKButtonClick(TObject* Sender)
{
  Close();
}

//------------------------------------------------------------------------------
// Close form on escape and return
//------------------------------------------------------------------------------
void __fastcall TAboutForm::FormKeyDown(TObject* Sender, WORD& Key, TShiftState Shift)
{
  if ( (Key == VK_ESCAPE) || (Key == VK_RETURN) ) Close();
}

//------------------------------------------------------------------------------
// Reposition the form. If it is put below the bottom of the screen this is
// corrected but the taskbar is not taken into account for this.
//------------------------------------------------------------------------------
void __fastcall TAboutForm::FormShow(TObject* Sender)
{
  // Position the form
  Top = MainForm->Top + MainForm->Height - Height;
  if ( Top < 0 ) Top = 0;
  Left = MainForm->Left + 0.5 * (MainForm->Width - Width);
}

//------------------------------------------------------------------------------
// Mail me
//------------------------------------------------------------------------------
void __fastcall TAboutForm::MailLabelClick(TObject* Sender)
{
  ShellExecute(NULL, "open", "mailto:johanw@vulcan.xs4all.nl", NULL, NULL, SW_SHOWNORMAL);
}

//------------------------------------------------------------------------------
// Go to my homepage
//------------------------------------------------------------------------------
void __fastcall TAboutForm::WebsiteLabelClick(TObject* Sender)
{
  ShellExecute(NULL, "open", WebsiteLabel->Caption.c_str(), NULL, NULL, SW_SHOWNORMAL);
}

//------------------------------------------------------------------------------
// Go to the rscc page
//------------------------------------------------------------------------------
void __fastcall TAboutForm::UpdateLabelClick(TObject* Sender)
{
  ShellExecute(NULL, "open", UpdateLabel->Caption.c_str(), NULL, NULL, SW_SHOWNORMAL);
}

//------------------------------------------------------------------------------
// Go to the distributed.net site
//------------------------------------------------------------------------------
void __fastcall TAboutForm::DistNetLinkLabelClick(TObject* Sender)
{
  ShellExecute(NULL, "open", DistNetLinkLabel->Caption.c_str(), NULL, NULL, SW_SHOWNORMAL);
}

//------------------------------------------------------------------------------
// Go to the Delphi Cryptography Page
//------------------------------------------------------------------------------
void __fastcall TAboutForm::Label7Click(TObject* Sender)
{
  ShellExecute(NULL, "open", "http://www.scramdisk.clara.net/", NULL, NULL, SW_SHOWNORMAL);
}

//------------------------------------------------------------------------------

