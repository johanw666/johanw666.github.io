//------------------------------------------------------------------------------
// This file is part of Remote Service Control Center by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: dirsel.cpp
//
// Contains the code for the directory selector.
//------------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "dirsel.h"
//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
//------------------------------------------------------------------------------
__fastcall TDirSelForm::TDirSelForm(TComponent* Owner): TForm(Owner)
{
}

//------------------------------------------------------------------------------
__fastcall TDirSelForm::TDirSelForm(TComponent* Owner, AnsiString startDir): TForm(Owner)
{
  if ( DirectoryExists(startDir) ) DirectoryListBox1->Directory = startDir;
}

//------------------------------------------------------------------------------
void __fastcall TDirSelForm::FormResize(TObject* Sender)
{
  DriveComboBox1->Width = ClientWidth;
}

//------------------------------------------------------------------------------

