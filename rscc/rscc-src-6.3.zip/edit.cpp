//------------------------------------------------------------------------------
// This file is part of Remote Service Control Center by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: edit.cpp
//
// Contains the code for the form to edit the client/proxy's inifile.
//------------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "edit.h"
//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
//------------------------------------------------------------------------------
// Default constructor, not to be used.
//------------------------------------------------------------------------------
__fastcall TEditForm::TEditForm(TComponent* Owner): TForm(Owner)
{
}

//------------------------------------------------------------------------------
// Constructor, gets passed a filename.
//------------------------------------------------------------------------------
__fastcall TEditForm::TEditForm(TComponent* Owner, AnsiString aFileName): TForm(Owner)
{
  // Position the form
  if ( Owner ) {
    Top = ((TForm*)Owner)->Top + (((TForm*)Owner)->Height - Height);
    if ( Top < 0 ) Top = 0;
    Left = ((TForm*)Owner)->Left + 0.5 * (((TForm*)Owner)->Width - Width);
  } else Position = poScreenCenter;
  fFileName = aFileName;
  // Read the inifile
  if ( FileExists(fFileName) ) IniFileMemo->Lines->LoadFromFile(fFileName);
  Caption = "File: " + fFileName;
}

//------------------------------------------------------------------------------
void __fastcall TEditForm::CancelButtonClick(TObject* Sender)
{
  Close();
}

//------------------------------------------------------------------------------
// Save changes
//------------------------------------------------------------------------------
void __fastcall TEditForm::SaveButtonClick(TObject* Sender)
{
  IniFileMemo->Lines->SaveToFile(fFileName);
  Close();
}
//------------------------------------------------------------------------------

