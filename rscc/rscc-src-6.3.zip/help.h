//------------------------------------------------------------------------------
// This file is part of Remote Service Control Center by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: help.h
//------------------------------------------------------------------------------
#ifndef helpH
#define helpH
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//------------------------------------------------------------------------------
class THelpForm: public TForm
{
__published:
  TPanel* Panel1;
  TPanel* Panel2;
  TButton* CloseButton;
  TMemo* HelpMemo;
  void __fastcall CloseButtonKeyDown(TObject* Sender, WORD& Key, TShiftState Shift);
  void __fastcall CloseButtonClick(TObject* Sender);
private:
public:
  __fastcall THelpForm(TComponent* Owner);
};
//------------------------------------------------------------------------------

#endif

