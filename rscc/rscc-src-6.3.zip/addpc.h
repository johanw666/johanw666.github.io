//------------------------------------------------------------------------------
// This file is part of Remote Service Control Center by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: addpc.h
//------------------------------------------------------------------------------
#ifndef addpcH
#define addpcH
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <CheckLst.hpp>
#include <comctrls.hpp>
//------------------------------------------------------------------------------
class TAddComputerForm: public TForm
{
__published:
  TPanel* Panel1;
  TButton* OKButton;
  TButton* CancelButton;
  TPanel* Panel2;
  TLabel* ComputerNameLabel;
  TEdit* ComputerNameEdit;
  TCheckBox* AddToClientsCheckBox;
  TCheckBox* AddToProxiesCheckBox;
  void __fastcall OKButtonClick(TObject* Sender);
  void __fastcall FormShow(TObject* Sender);
  void __fastcall ComputerNameEditKeyPress(TObject* Sender, char& Key);
private:
  bool* fAddToClients;
  bool* fAddToProxies;
  char* fComputerName;
  size_t fBuffLength;
  __fastcall TAddComputerForm(TComponent* Owner);
public:
  __fastcall TAddComputerForm(TComponent* Owner, char* computerName, size_t buffLength, bool* addToClients, bool* addToProxies);
};

//------------------------------------------------------------------------------
#endif

