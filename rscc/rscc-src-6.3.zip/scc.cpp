//------------------------------------------------------------------------------
// This file is part of Remote Service Control Center by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: scc.cpp
//
// Contains the code for the main form and the network scan thread. It also
// contains all service manager code.
//------------------------------------------------------------------------------
#include <vcl.h>
#include <FileCtrl.hpp>
#include <shellapi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sysdefs.h>
#include <lm.h>  // LAN manager API for NetServerGetInfo.
#pragma hdrstop

#include "scc.h"
#include "defsetup.h"
#include "addpc.h"
#include "config.h"
#include "about.h"
#include "help.h"
#include "edit.h"
#include "account.h"
#include "logfile.h"
#include "password.h"
#include "settings.h"
//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMainForm* MainForm;

//------------------------------------------------------------------------------
// Program constants
//------------------------------------------------------------------------------
// Listview indices
const int lStatusIndex  = 0; // Service status
const int lPathIndex    = 1; // Service path
const int lVersionIndex = 2; // program version
const int lEmailIndex   = 3; // Client email (for proxies default ipadress field)
// Error constant
const int NO_SERVICEMANAGER_FOUND = 0x21;
const int COMPUTERNAME_NOT_FOUND  = 0x22;
//------------------------------------------------------------------------------
// Signals that can be sent to remote clients via ControlService
const DWORD CLIENT_SERVICE_CONTROL_RESTART  = 0x80;
const DWORD CLIENT_SERVICE_CONTROL_FETCH    = 0x81;
const DWORD CLIENT_SERVICE_CONTROL_FLUSH    = 0x82;
const DWORD CLIENT_SERVICE_CONTROL_UPDATE   = 0x83;
const DWORD CLIENT_SERVICE_CONTROL_CAPSSTAT = 0x84;
const DWORD PROXY_SERVICE_CONTROL_CONNECT   = 0x83;
// The following is standard in Win2000 but does not work in NT4
#ifndef SERVICE_CONTROL_PARAMCHANGE
const DWORD SERVICE_CONTROL_PARAMCHANGE = 0x06;
#endif
//------------------------------------------------------------------------------
// Default column sizes
const int defaultNameColumnWidth    = 120;
const int defaultStatusColumnWidth  = 150;
const int defaultPathColumnWidth    = 240;
const int defaultVersionColumnWidth = 100;
const int defaultEmailColumnWidth   = 125;
// Default form sizes
const int defaultTopPos     = 0;
const int defaultLeftPos    = 0;
const int defaultFormHeight = 470;
const int defaultFormWidth  = 765;
// Name of the logfile, if used
AnsiString tracefile;

//------------------------------------------------------------------------------
// Show error string. This method is either passed the address of an error code
// or, when NULL is passed, will call GetLastError().
//------------------------------------------------------------------------------
void __fastcall ShowErrorMessage(char aHeaderText[], DWORD* errCode)
{
  LPVOID lpMsgBuf; // For error info text
  DWORD errorCode; // For error code if required.
  // If pointer is NULL, get errorcode from windows
  if ( !errCode ) errorCode = GetLastError();
  else errorCode = *errCode;

  FormatMessage(
    FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
    NULL,
    errorCode,
    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
    (LPTSTR)&lpMsgBuf, 0, NULL);
  // Display the message.
  Application->MessageBox((char*)lpMsgBuf, aHeaderText, MB_OK|MB_ICONWARNING);
  // Free the buffer.
  LocalFree(lpMsgBuf);
}

//------------------------------------------------------------------------------
// Get the errormessage and return it in buffer.
//------------------------------------------------------------------------------
void __fastcall GetErrormessage(DWORD* errCode, char* buffer, size_t buffSize)
{
  LPVOID lpMsgBuf; // For error info text
  DWORD errorCode; // For error code if required.
  // If pointer is NULL, get errorcode from windows
  if ( !errCode ) errorCode = GetLastError();
  else errorCode = *errCode;

  FormatMessage(
    FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
    NULL,
    errorCode,
    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
    (LPTSTR)&lpMsgBuf, 0, NULL);

  strncpy(buffer, (char*)lpMsgBuf, buffSize);
  strcat(buffer, "\n");
  // Free the buffer.
  LocalFree(lpMsgBuf);
}

//------------------------------------------------------------------------------
// Returns the type of a remote machine. NetServerGetInfo called on level 101
// rewuires no special privileges.
// returns 400 for win95, 410 for win98, 490 for WinME,
// 2000+350 for NT3.5, 2000+400 for NT4, 2000+500 for NT 5 etc.
// Returns 0 if machine is neither WinNT or Win9x.
//------------------------------------------------------------------------------
long __fastcall GetRemotePlatformType(const char* servername)
{
  long ver = 0;
  LPSERVER_INFO_101 si = NULL;
  // Function NetServerGetInfo() requires unicode input.
  wchar_t uServerName[(2*MAX_COMPUTERNAME_LENGTH) + 2];
  AnsiToUnicode(servername, uServerName, sizeof(uServerName));
  // CBuilder 3 and 5 require different code here.
#if defined(__BORLANDC__) && (__BORLANDC__ <= 0x530) // CBuilder 3
  if ( NetServerGetInfo((LPTSTR)uServerName, 101, (LPBYTE*)&si) == 0 ) {
#else
  if ( NetServerGetInfo((wchar_t*)uServerName, 101, (LPBYTE*)&si) == 0 ) {
#endif
    if ((si->sv101_type & (SV_TYPE_NT | SV_TYPE_WINDOWS)) != 0 ) {
      ver = (si->sv101_version_major * 100) + (si->sv101_version_minor);
      if ( (si->sv101_type & SV_TYPE_NT) != 0 ) ver += 2000;
    }
  }
  if (si) NetApiBufferFree(si);
  return ver;
}

//------------------------------------------------------------------------------
// Converts the unicode string ustr to ANSI. The string may not contain more
// than 511 unicode characters.
//------------------------------------------------------------------------------
const char* UnicodeToAnsi(const void* ustr, char* outbuf, size_t bufflen)
{
  if (ustr) {
    if (WideCharToMultiByte(CP_ACP, 0, (LPCWSTR)ustr, -1, outbuf, bufflen, NULL, NULL) > 0) {
      outbuf[bufflen-1] = 0;
      return outbuf;
    }
  }
  return "";
}

//------------------------------------------------------------------------------
// Converts the ANSI string astr to unicode. The string may not contain more
// than 511 ANSI characters.
//------------------------------------------------------------------------------
LPCWSTR AnsiToUnicode(const char* astr, wchar_t* outbuf, size_t bufflen)
{
  if (astr) {
    if (MultiByteToWideChar(CP_ACP, 0, (LPCSTR)astr, -1, (LPWSTR)&outbuf[0], bufflen) > 0) {
      outbuf[bufflen-2] = 0;
      outbuf[bufflen-1] = 0;
      return (LPCWSTR)&outbuf[0];
    }
  }
  return L"";
}

//------------------------------------------------------------------------------
// Debug functions. if writedebuginfo == true they write debug info to the logfile.
//------------------------------------------------------------------------------
// Debug version of ControlService()
//------------------------------------------------------------------------------
BOOL TMainForm::RSCC_ControlService(SC_HANDLE hService, DWORD dwControl, LPSERVICE_STATUS lpServiceStatus, bool writedebuginfo, char* computername)
{
  BOOL retVal = ControlService(hService, dwControl, lpServiceStatus);
  // Store old errorcode in case something gets wrong here
  DWORD errCode = GetLastError();

  if ( writedebuginfo ) {
    char msgStr[2048];
    sprintf(msgStr, "Controlservice() call to %s.\nSent code %s (0x%x).\nSERVICE_STATUS after call:\ndwServiceType:\t\t%d\ndwCurrentState:\t\t%d\ndwControlsAccepted:\t%d\ndwWin32ExitCode:\t\t%d\ndwServiceSpecificExitCode:\t%d\ndwCheckPoint:\t\t%d\ndwWaitHint:\t\t%d\nReturn code: %s",
            computername,
            ControlcodeDescription(dwControl).c_str(),
            dwControl,
            lpServiceStatus->dwServiceType,
            lpServiceStatus->dwCurrentState,
            lpServiceStatus->dwControlsAccepted,
            lpServiceStatus->dwWin32ExitCode,
            lpServiceStatus->dwServiceSpecificExitCode,
            lpServiceStatus->dwCheckPoint,
            lpServiceStatus->dwWaitHint,
            retVal == TRUE? "TRUE" : "FALSE");
    if ( !retVal ) {
      char errStr[512];
      GetErrormessage(NULL, errStr, sizeof(errStr));
      strcat(msgStr, "; Error message: ");
      strncat(msgStr, errStr, sizeof(msgStr) - strlen(msgStr) - 2);
      strcat(msgStr, "\n");
    } else
      strcat(msgStr, "\n");

    WriteDebugString(tracefile.c_str(), msgStr);
  }
  // Set the last errorcode back
  SetLastError(errCode);
  return retVal;
}

//------------------------------------------------------------------------------
// Debug version of StartService()
//------------------------------------------------------------------------------
BOOL TMainForm::RSCC_StartService(SC_HANDLE hService, DWORD dwNumServiceArgs, LPCTSTR* lpServiceArgVectors, bool writedebuginfo, char* computername)
{
  BOOL retVal = StartService(hService, dwNumServiceArgs, lpServiceArgVectors);
  // Store old errorcode in case something gets wrong here
  DWORD errCode = GetLastError();

  if ( writedebuginfo ) {
    char msgStr[128];
    sprintf(msgStr, "StartService call to %s\nReturn code: %s", computername, retVal == TRUE? "TRUE" : "FALSE");
    if ( !retVal ) {
      char errStr[512];
      GetErrormessage(NULL, errStr, sizeof(errStr));
      strcat(msgStr, "; Error message: ");
      strncat(msgStr, errStr, sizeof(msgStr) - strlen(msgStr) - 2);
      strcat(msgStr, "\n");
    } else
      strcat(msgStr, "\n");

    WriteDebugString(tracefile.c_str(), msgStr);
  }
  // Set the last errorcode back
  SetLastError(errCode);
  return retVal;
}

//------------------------------------------------------------------------------
// Debug version of CopyFile()
//------------------------------------------------------------------------------
BOOL TMainForm::RSCC_CopyFile(LPCTSTR lpExistingFileName, LPCTSTR lpNewFileName, BOOL bFailIfExists, bool writedebuginfo)
{
  BOOL retVal = CopyFile(lpExistingFileName, lpNewFileName, bFailIfExists);
  // Store old errorcode in case something gets wrong here
  DWORD errCode = GetLastError();

  if ( writedebuginfo ) {
    char msgStr[128];
    sprintf(msgStr, "CopyFile(%s, %s, %s)\nReturn code: %s",
            lpExistingFileName, lpNewFileName,
            bFailIfExists == TRUE? "TRUE" : "FALSE",
            retVal == TRUE? "TRUE" : "FALSE");
    if ( !retVal ) {
      char errStr[512];
      GetErrormessage(NULL, errStr, sizeof(errStr));
      strcat(msgStr, "; Error message: ");
      strncat(msgStr, errStr, sizeof(msgStr) - strlen(msgStr) - 2);
      strcat(msgStr, "\n");
    } else
      strcat(msgStr, "\n");

    WriteDebugString(tracefile.c_str(), msgStr);
  }
  // Set the last errorcode back
  SetLastError(errCode);
  return retVal;
}

//------------------------------------------------------------------------------
// Debug version of DeleteFile()
//------------------------------------------------------------------------------
BOOL TMainForm::RSCC_DeleteFile(LPCTSTR lpFileName, bool writedebuginfo)
{
  BOOL retVal = DeleteFile(lpFileName);
  // Store old errorcode in case something gets wrong here
  DWORD errCode = GetLastError();

  if ( writedebuginfo ) {
    char msgStr[128];
    sprintf(msgStr, "DeleteFile(%s)\nReturn code: %s", lpFileName, retVal == TRUE? "TRUE" : "FALSE");
    if ( !retVal ) {
      char errStr[512];
      GetErrormessage(NULL, errStr, sizeof(errStr));
      strcat(msgStr, "; Error message: ");
      strncat(msgStr, errStr, sizeof(msgStr) - strlen(msgStr) - 2);
      strcat(msgStr, "\n");
    } else
      strcat(msgStr, "\n");

    WriteDebugString(tracefile.c_str(), msgStr);
  }
  // Set the last errorcode back
  SetLastError(errCode);
  return retVal;
}

//------------------------------------------------------------------------------
// Debug version of MoveFileEx()
//------------------------------------------------------------------------------
BOOL TMainForm::RSCC_MoveFileEx(LPCTSTR lpExistingFileName, LPCTSTR lpNewFileName, DWORD dwFlags, bool writedebuginfo)
{
  BOOL retVal = MoveFileEx(lpExistingFileName, lpNewFileName, dwFlags);
  // Store old errorcode in case something gets wrong here
  DWORD errCode = GetLastError();

  if ( writedebuginfo ) {
    char msgStr[128];
    sprintf(msgStr, "MoveFileEx(%s, %s, 0x%x)\nReturn code: %s",
            lpExistingFileName, lpNewFileName, dwFlags,
            retVal == TRUE? "TRUE" : "FALSE");
    if ( !retVal ) {
      char errStr[512];
      GetErrormessage(NULL, errStr, sizeof(errStr));
      strcat(msgStr, "; Error message: ");
      strncat(msgStr, errStr, sizeof(msgStr) - strlen(msgStr) - 2);
      strcat(msgStr, "\n");
    } else
      strcat(msgStr, "\n");

    WriteDebugString(tracefile.c_str(), msgStr);
  }
  // Set the last errorcode back
  SetLastError(errCode);
  return retVal;
}

//------------------------------------------------------------------------------
// Write the message in the logfile.
//------------------------------------------------------------------------------
void __fastcall WriteDebugString(char* fileName, char* msg)
{
  FILE* file = fopen(fileName, "at");
  if ( file ) {
    DWORD ms = GetTickCount();
    SYSTEMTIME timeStruct;
    GetSystemTime(&timeStruct); // Get time in UTC
    fprintf(file, "%04d-%02d-%02d %02d:%02d:%02d:%03d (%05d.%03d): %s\n",
                  timeStruct.wYear,
                  timeStruct.wMonth,
                  timeStruct.wDay,
                  timeStruct.wHour,
                  timeStruct.wMinute,
                  timeStruct.wSecond,
                  timeStruct.wMilliseconds,
                  (int)ms/1000, (int)(ms%1000), msg);
    fflush(file);
    fclose(file);
  }
}

//------------------------------------------------------------------------------
// Check if a given computername still exists on the network and if it can run a
// SCM (NT/2000/XP)
//------------------------------------------------------------------------------
bool __fastcall TMainForm::IsComputerOnlineAndNT(const char* lpMachineName)
{
  LPSERVER_INFO_101 si = NULL;
  LPSERVER_INFO_101 tmpsi;
  DWORD level = 101;
  DWORD entriesRead = 0;
  DWORD totalEntries = 0;
  DWORD resumeHandle = 0;
  NET_API_STATUS testVal;
  unsigned i;
  char ComputerName[MAX_COMPUTERNAME_LENGTH + 1];
  long ver = 0;
  bool retVal = false;

  testVal = NetServerEnum(NULL,
                          level,
                          (LPBYTE*)(&si),
                          MAX_PREFERRED_LENGTH,
                          &entriesRead,
                          &totalEntries,
                          SV_TYPE_WORKSTATION,
                          NULL,
                          &resumeHandle);

  if ((testVal == NERR_Success) || (testVal == ERROR_MORE_DATA)) {
    if ((tmpsi = si) != NULL) {
      // Now add all servers c.q. all NT machines to the listviews.
      for (i = 0; i < entriesRead; i++) {
        if (!tmpsi) {
          ShowErrorMessage("NetServerEnum", NULL);
          break;
        }
        UnicodeToAnsi(tmpsi->sv101_name, ComputerName, sizeof(ComputerName));
        if ((tmpsi->sv101_type & (SV_TYPE_NT | SV_TYPE_WINDOWS)) != 0 ) {
          ver = (tmpsi->sv101_version_major * 100) + (tmpsi->sv101_version_minor);
          if ( (tmpsi->sv101_type & SV_TYPE_NT) != 0 ) ver += 2000;
        }
        if (ver >= 2000) {
          // NetServerEnum() returns names in uppercase so case conversion is required
          if (LowerCase(ComputerName) == LowerCase(lpMachineName)) {
            // Computer name found in list
            retVal = true;
            break;
          }
        }
        tmpsi++;
      }
    }
    if (testVal == ERROR_MORE_DATA) ShowErrorMessage("NetServerEnum", NULL);
  }
  else
    ShowErrorMessage("NetServerEnum", NULL);

  if (si) NetApiBufferFree(si);
  return retVal;
}

//------------------------------------------------------------------------------
// Version of OpenSCManager that first checks if the computername extsts in the
// network and if it is of type NT. This is implemented to prevent long delays,
// for example when a machine is switched off. Just calling OpenSCManager()
// would hang the program for 30 seconds.
//------------------------------------------------------------------------------
SC_HANDLE TMainForm::RSCC_OpenSCManager(LPCTSTR lpMachineName,
                                        LPCTSTR lpDatabaseName,
                                        DWORD dwDesiredAccess)
{
  SC_HANDLE retVal = 0;
  // if true, do the real OpenSCManager() call
  if (pcfg.allowNonDomain || pcfg.scanOutsideDomain || IsComputerOnlineAndNT(lpMachineName))
    retVal = OpenSCManager(lpMachineName, lpDatabaseName, dwDesiredAccess);

  return retVal;
}

//------------------------------------------------------------------------------
//  Constructor.
//------------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner): TForm(Owner)
{
  char* p;

  // System tray icon
  TrayIcon = new Graphics::TIcon;
  TrayIcon->Handle = LoadImage(HInstance, "MAINICON", IMAGE_ICON, 0, 0, 0);
  // Set the event handlers for minimizing/restoring from the system tray
  Application->OnMinimize = AppOnMinimize;
  Application->OnRestore  = AppOnRestore;
  // Find inifilename
  iniFileName = ParamStr(0);
  p = strrchr(iniFileName.c_str(), '.');
  if ( p ) *p = 0;
  strcat(iniFileName.c_str(), ".ini");
  // Create inifile for settings
  ProgramSettingsFile = new TIniFile(iniFileName);
  // Find logfilename
  tracefile = ParamStr(0);
  p = strrchr(tracefile.c_str(), '.');
  if ( p ) *p = 0;
  strcat(tracefile.c_str(), ".log");
  viewLogFilesChildren = new TList();
}

//------------------------------------------------------------------------------
//  Set program defaults.
//------------------------------------------------------------------------------
void __fastcall TMainForm::FormShow(TObject* Sender)
{
  char* domainName;
  AnsiString versionString;
  char versionNr[256];
  DWORD errCode;
  char errMsg[512], msg[1024];

  // Default reason why FormClose is called
  prgCloseReason = PRG_CLOSE_OTHER;
  // Get the windows type. The program only runs on winNT/2000/XP.
  if ( GetWin32Platform(versionNr, sizeof(versionNr) ) != VER_PLATFORM_WIN32_NT ) {
    versionString = "Windows " + AnsiString(versionNr) + " detected.\nThis program requires Windows NT, 2000 or XP.";
    Application->MessageBox(versionString.c_str(), "Incorrect windows version", MB_OK|MB_ICONSTOP);
    Application->Terminate();
  }
  AboutForm->WindowsVersionLabel->Caption = "Running on Windows " + AnsiString(versionNr);
  // Read inifile settings
  ReadIniSettings();
  // Login as specified user and get its priviliges
  if ( pcfg.SwitchUserID && strlen(pcfg.Username) ) {
    // Domain name need not be specified
    if ( pcfg.Domain && strlen(pcfg.Domain) ) domainName = pcfg.Domain;
    else domainName = NULL;

    if ( !LogonUser(pcfg.Username, domainName, pcfg.Password,
                    LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, &hToken) ) {
      errCode = GetLastError();
      GetErrormessage(&errCode, errMsg, sizeof(errMsg));
      strcpy(msg, "RSCC wanted to login as another user but failed. The error was:\n");
      strcat(msg, errMsg);
      strcat(msg, "\nDo you want to edit the login data now?");
      if ( MessageBox(NULL, msg, Application->Title.c_str(), MB_YESNO) == IDYES ) {
        SwitchAccountButtonClick(Sender);
        // Don't try to login now, probably the required privilege was not found
        // so a logoff/logon is necessary anyway.
      }
    }
    if ( hToken ) {
      if ( !ImpersonateLoggedOnUser(hToken) )
        ShowErrorMessage("ImpersonateLoggedOnUser", NULL);
    }
  }
  // No thread is currently running
  NetworkScanThreadIsRunning = false;
  // Read the computer names stored in the inifile and scan the network if
  // this is configured:
  clientComputersListView->Items->Clear();
  proxyComputersListView->Items->Clear();
  ReadComputerNames();
  // Store the computer names so we can see if the configuration has changed
  // when we close.
  StoreComputerNames();
  // Select the first computer in the lists:
  if ( clientComputersListView->Items->Count > 0 )
    clientComputersListView->Items->Item[0]->Selected = true;
  if ( proxyComputersListView->Items->Count > 0 )
    proxyComputersListView->Items->Item[0]->Selected = true;
}

//------------------------------------------------------------------------------
// Destructor.
//------------------------------------------------------------------------------
__fastcall TMainForm::~TMainForm()
{
  // Remove the system tray icon
  RemoveIcon();
  delete TrayIcon;
  // Delete settingsfile
  delete ProgramSettingsFile;
  // Delete list of logfiles.
  delete viewLogFilesChildren;
}

//------------------------------------------------------------------------------
// Saves the settings and deletes the inifile. Doing this in the destructor
// gives access violations so we do it in the OnClose event.
//------------------------------------------------------------------------------
void __fastcall TMainForm::FormClose(TObject* Sender, TCloseAction& Action)
{
  int i;
  bool saveSettings = false;

  // Make sure the computernames in pcfg and the GUI match.
  StoreComputerNames();
  // Save settings if necessary.
  switch ( prgCloseReason ) {
    case PRG_CLOSE_CANCEL:
         saveSettings = false;
         break;
    case PRG_CLOSE_EXIT:
         saveSettings = true;
         break;
    default:
      if ((orgpcfg != pcfg) || (orgClientData != clientData) || (orgProxyData != proxyData)) {
        switch ( Application->MessageBox("Settings have changed, save changes?", Application->Title.c_str(), MB_YESNOCANCEL) ) {
          case IDYES: // Save
               saveSettings = true;
               break;
          case IDCANCEL: // Don't close the form
               Action = caNone;
               prgCloseReason = PRG_CLOSE_OTHER; // Reset reason
               saveSettings = false;
               break;
          default: break; // Don't save
        }
      }
  }
  if ( Action != caNone ) {
    // Drop priviliges. This is done here to prevent access right errors writing
    // the config files. It is assumed that the calling user has the right to
    // write to the program's ini file.
    if (hToken && !CloseHandle(hToken) ) ShowErrorMessage("CloseHandle", NULL);
    if ( pcfg.SwitchUserID && !RevertToSelf() ) ShowErrorMessage("RevertToSelf", NULL);
    // run through the list of open logfile viewer child windows,
    // Close all and free memory.
    // The childlist itself is deleted in the destructor.
    for (i = 0; i < viewLogFilesChildren->Count; i++) {
      TViewLogFileForm* f = (TViewLogFileForm*)viewLogFilesChildren->Items[i];
      // prevent the child form to send its WM_CLOSE_VIEW_LOGFILE notification,
      // since we are already closing and freeing it and dont need it here
      f->mainForm = NULL;
      // Delete the menuitem
      delete f->windowMenuItem;
      f->Close();
      delete f;
    }
  }
  if ( saveSettings ) SaveIniSettings();
}

//------------------------------------------------------------------------------
// this method is called on WM_CLOSE_VIEW_LOGFILE sent by the
// TViewLogFileForm when closing.
//------------------------------------------------------------------------------
void __fastcall TMainForm::WMCloseViewLog(TMessage& Message)
{
  // find the window in the child list by pointer
  int i = viewLogFilesChildren->IndexOf((TObject*)Message.WParam);

  if (i >= 0) {
    TViewLogFileForm* f = (TViewLogFileForm*)viewLogFilesChildren->Items[i];
    viewLogFilesChildren->Delete(i);
    // Delete corresponding menuitem
    delete (TMenuItem*)Message.LParam;
    // Delete the logfile form
    delete f;
  }
}

//------------------------------------------------------------------------------
// Save settings and close the form
//------------------------------------------------------------------------------
void __fastcall TMainForm::ExitButtonClick(TObject* Sender)
{
  prgCloseReason = PRG_CLOSE_EXIT;
  Close();
}

//------------------------------------------------------------------------------
// Close without saving.
//------------------------------------------------------------------------------
void __fastcall TMainForm::CancelButtonClick(TObject* Sender)
{
  prgCloseReason = PRG_CLOSE_CANCEL;
  Close();
}

//------------------------------------------------------------------------------
// Check all computers in the active list
//------------------------------------------------------------------------------
void __fastcall TMainForm::CheckAll1Click(TObject* Sender)
{
  for (int i = 0; i < activeListView->Items->Count; i++)
    activeListView->Items->Item[i]->Checked = true;
}

//------------------------------------------------------------------------------
// Uncheck all computers in the active list
//------------------------------------------------------------------------------
void __fastcall TMainForm::UncheckAll1Click(TObject* Sender)
{
  for (int i = 0; i < activeListView->Items->Count; i++)
    activeListView->Items->Item[i]->Checked = false;
}

//------------------------------------------------------------------------------
// Save the program settings to the inifile.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Savesettings1Click(TObject* Sender)
{
  SaveIniSettings();
}

//------------------------------------------------------------------------------
// Store the computer names so we can see if the configuration has changed
//------------------------------------------------------------------------------
void __fastcall TMainForm::StoreComputerNames()
{
  int i;
  pcfg.clientComputerNameList->Clear();
  for (i = 0; i < clientComputersListView->Items->Count; i++) {
    pcfg.clientComputerNameList->Add(clientComputersListView->Items->Item[i]->Caption);
    pcfg.clientComputerNameList->Objects[i] = (TObject*)clientComputersListView->Items->Item[i]->Checked;
  }
  pcfg.proxyComputerNameList->Clear();
  for (i = 0; i < proxyComputersListView->Items->Count; i++) {
    pcfg.proxyComputerNameList->Add(proxyComputersListView->Items->Item[i]->Caption);
    pcfg.proxyComputerNameList->Objects[i] = (TObject*)proxyComputersListView->Items->Item[i]->Checked;
  }
}

//------------------------------------------------------------------------------
// Read the settings from the inifile.
//------------------------------------------------------------------------------
void __fastcall TMainForm::ReadIniSettings()
{
  // Required data, not to be changed by the user interface
  strcpy(clientData.IniSection, "Client");
  strcpy(proxyData.IniSection, "Proxy");
  // Read program settings
  pcfg.ReadSettings(ProgramSettingsFile);
  // If any periodic start/stop operation is to be performed, enable the timer
  if (pcfg.startOnWeekdays || pcfg.stopOnWeekdays || pcfg.startOnWeekends || pcfg.stopOnWeekends)
    PeriodicStartStopTimer->Enabled = true;
  else
    PeriodicStartStopTimer->Enabled = false;
  // Store old settings so we can later check if they have changed.
  orgpcfg = pcfg;
  // Read the defaults for client and proxy. If the inifile does not exist it will return defaults.
  clientData.ReadSettings(ProgramSettingsFile);
  proxyData.ReadSettings(ProgramSettingsFile);
  // Store old settings so we can later check if they have changed.
  orgClientData = clientData;
  orgProxyData = proxyData;
  // See if we want to see the buttons and settings panel
  ShowButtons1->Checked = pcfg.showButtons;
  ButtonPanel->Visible = pcfg.showButtons;
  ShowSettings1->Checked = pcfg.showSettings;
  SettingsPanel->Visible = pcfg.showSettings;
  clientComputersListView->RowSelect = pcfg.selectWholeLine;
  proxyComputersListView->RowSelect = pcfg.selectWholeLine;
  // Check which proxy logfile we want to see
  if ( pcfg.whichProxyLogFile == conLogFile )      ViewConlog1->Checked = true;
  else if ( pcfg.whichProxyLogFile == rc5LogFile ) ViewRC5log1->Checked = true;
  else if ( pcfg.whichProxyLogFile == ogrLogFile ) ViewOGRlog1->Checked = true;
  else if ( pcfg.whichProxyLogFile == ogrp2LogFile ) ViewOGRP2log1->Checked = true;
  else if ( pcfg.whichProxyLogFile == ogrngLogFile ) ViewOGRNGlog1->Checked = true;
  // De-assign the OnClick event handlers, we don't want to call them here.
  ClientRadioButton->OnClick = NULL;
  PerProxyRadioButton->OnClick = NULL;
  // Read which service we want to start with
  if ( pcfg.ServiceToShow == serviceProxy ) {
    cfg = &proxyData;
    activeListView = proxyComputersListView;
    clientComputersListView->Visible = false;
    proxyComputersListView->Visible = true;
    PerProxyRadioButton->Checked = true;
    EnableClientOrProxySpecificOptions(false, true);
  } else {
    cfg = &clientData;
    activeListView = clientComputersListView;
    proxyComputersListView->Visible = false;
    clientComputersListView->Visible = true;
    ClientRadioButton->Checked = true;
    EnableClientOrProxySpecificOptions(true, false);
  }
  // Assign the event handlers AFTER one radio button's state has set to checked.
  // Otherwise the method gets called resulting in an AV.
  ClientRadioButton->OnClick   = RadioButtonClick;
  PerProxyRadioButton->OnClick = RadioButtonClick;
  // Set defaults client and proxy data if not filled.
  // Client data
  SetClientDefaults();
  // Proxy data
  SetProxyDefaults();
  // RC5 challenge (default to 72, this will change if RC5-72 is completed
  if ( !strlen(pcfg.activeRC5Challenge.c_str()) )
    pcfg.activeRC5Challenge = "72";
  // Name the last client listview column
  if ( strcmp(clientData.DestinationKey, "id") )
    clientComputersListView->Columns->Items[lEmailIndex + 1]->Caption = clientData.DestinationKey;
  else // We call the field "id" Email for clarity
    clientComputersListView->Columns->Items[lEmailIndex + 1]->Caption = "Email";
  // Caption of the last proxy listview column
  proxyComputersListView->Columns->Items[lEmailIndex + 1]->Caption = proxyData.DestinationKey;
  // Read the form position and sizes
  Top  = ProgramSettingsFile->ReadInteger(ProgramIniSection, TopPos, defaultTopPos);
  Left = ProgramSettingsFile->ReadInteger(ProgramIniSection, LeftPos, defaultLeftPos);
  Height = ProgramSettingsFile->ReadInteger(ProgramIniSection, FormHeight, defaultFormHeight);
  Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, FormWidth, defaultFormWidth);
  clientComputersListView->Columns->Items[0]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, NameColumnWidth, defaultNameColumnWidth);
  clientComputersListView->Columns->Items[1]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, StatusColumnWidth, defaultStatusColumnWidth);
  clientComputersListView->Columns->Items[2]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, PathColumnWidth, defaultPathColumnWidth);
  clientComputersListView->Columns->Items[3]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, VersionColumnWidth, defaultVersionColumnWidth);
  clientComputersListView->Columns->Items[4]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, EmailColumnWidth, defaultEmailColumnWidth);
  proxyComputersListView->Columns->Items[0]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, pNameColumnWidth, defaultNameColumnWidth);
  proxyComputersListView->Columns->Items[1]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, pStatusColumnWidth, defaultStatusColumnWidth);
  proxyComputersListView->Columns->Items[2]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, pPathColumnWidth, defaultPathColumnWidth);
  proxyComputersListView->Columns->Items[3]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, pVersionColumnWidth, defaultVersionColumnWidth);
  proxyComputersListView->Columns->Items[4]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, pEmailColumnWidth, defaultEmailColumnWidth);
  // See if we want to switch to another accocunt. Default is we don't.
  hToken = NULL;
  // See how we want to encrypt the login data
  DefaultPassword1->Checked = !pcfg.useSecureCipher;
  Password1->Enabled = pcfg.useSecureCipher;
}

//------------------------------------------------------------------------------
// Default client info when starting up rscc. We first try to read it from the
// inifile, if there is no configuration information found we check if the
// client is installed on the local system and copy the information from the
// SCM database. If the client is not installed on the local system we use
// hard-coded default values.
//------------------------------------------------------------------------------
void __fastcall TMainForm::SetClientDefaults()
{
  // First set the service name. If this one is not read from the inifile
  // we need a hard-coded value to connect with the local machine.
  if ( !strlen(clientData.ServiceName) )
    strcpy(clientData.ServiceName, "dnetc");
  // These are not stored in the SCM database
  if ( !strlen(clientData.DestinationKey) )
    strcpy(clientData.DestinationKey, "id");
  if ( !strlen(clientData.DestinationSection) )
    strcpy(clientData.DestinationSection, "parameters");
  // If the other info is not known, obtain them rom the SCM database:
  if ( !strlen(clientData.ExeFrom) || !strlen(clientData.IniFrom) || !strlen(clientData.DirectoryTo) )
    if ( SetServiceDefaults(&clientData) )
      Application->MessageBox("Copied default client configuration data from the locally installed client", Application->Title.c_str(), MB_OK | MB_ICONINFORMATION);
  // Set these values if they are not yet set.
  if ( !strlen(clientData.DisplayName) )
    strcpy(clientData.DisplayName, "distributed.net client");
  if ( !strlen(clientData.BootParams) )
    strcpy(clientData.BootParams, "-svcstart");
  if ( !strlen(clientData.RemoteName) )
    strcpy(clientData.RemoteName, "dnetc");
  if ( !strlen(clientData.DirectoryTo) )
    strcpy(clientData.DirectoryTo, "C:\\WINNT\\");
  // Check if directories last char is "\\", add it if not so:
  if ( clientData.DirectoryTo[strlen(clientData.DirectoryTo) - 1] != '\\' )
    strcat(clientData.DirectoryTo, "\\");
}

//------------------------------------------------------------------------------
// Default proxy info when starting up rscc.
//------------------------------------------------------------------------------
void __fastcall TMainForm::SetProxyDefaults()
{
  if ( !strlen(proxyData.ServiceName) )
    strcpy(proxyData.ServiceName, "dnetd");
  if ( !strlen(proxyData.DestinationKey) )
    strcpy(proxyData.DestinationKey, "ipaddress");
  if ( !strlen(proxyData.DestinationSection) )
    strcpy(proxyData.DestinationSection, "KeyServer");
  // If the other info is not known, obtain them rom the SCM database:
  if ( !strlen(proxyData.ExeFrom) || !strlen(proxyData.IniFrom) || !strlen(proxyData.DirectoryTo) )
    if ( SetServiceDefaults(&proxyData) )
      Application->MessageBox("Copied default personal proxy configuration data from the locally installed perproxy", Application->Title.c_str(), MB_OK | MB_ICONINFORMATION);
  // Set these values if they are not yet set.
  if ( !strlen(proxyData.DisplayName) )
    strcpy(proxyData.DisplayName, "distributed.net personal proxy");
  if ( !strlen(proxyData.BootParams) )
    strcpy(proxyData.BootParams, "-svcrun");
  if ( !strlen(proxyData.RemoteName) )
    strcpy(proxyData.RemoteName, "proxyper");
  if ( !strlen(proxyData.DirectoryTo) )
    strcpy(proxyData.DirectoryTo, "C:\\WINNT\\");
  // Check if directories last char is "\\", add it if not so:
  if ( proxyData.DirectoryTo[strlen(proxyData.DirectoryTo) - 1] != '\\' )
    strcat(proxyData.DirectoryTo, "\\");
}

//------------------------------------------------------------------------------
// Get default service settings from the local SCM database, if present.
//------------------------------------------------------------------------------
bool __fastcall TMainForm::SetServiceDefaults(ServiceParams* spars)
{
  char buffer[2048];
  unsigned int i, n;
  char* c;
  char remoteMachineName[MAX_COMPUTERNAME_LENGTH + 1];
  char tempFileName[MAX_PATH];
  DWORD remoteMachineNameSize = sizeof(remoteMachineName);
  // Config params
  DWORD dwStartType;
  DWORD bytesNeeded;
  char lpBinaryPathName[MAX_PATH];
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  bool retVal = false;

  if ( GetComputerName(remoteMachineName, &remoteMachineNameSize) ) {
    if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_CONNECT)) == 0 )
      hscManager = NULL;

    if ( hscManager ) {
      if ( (hService = OpenService(hscManager, spars->ServiceName, SERVICE_QUERY_CONFIG)) == NULL )
        hService = NULL;

      if ( hService ) {
        if ( QueryServiceConfig(hService, (QUERY_SERVICE_CONFIG*)buffer, sizeof(buffer), &bytesNeeded) )
          retVal = true; // We got information
        // Save the data
        dwStartType = ((QUERY_SERVICE_CONFIG*)buffer)->dwStartType;
        if ( dwStartType == SERVICE_AUTO_START )
          spars->StartOnBoot = true;
        else
          spars->StartOnBoot = false;

        strcpy(lpBinaryPathName, ((QUERY_SERVICE_CONFIG*)buffer)->lpBinaryPathName);
        // Remove possible quotes from the name (could happen on existing installs)
        for (n = 0, i = 0; i < strlen(lpBinaryPathName); i++) {
          if ( lpBinaryPathName[i] != '\"' ) {
            tempFileName[n] = lpBinaryPathName[i];
            n++;
          }
        }
        tempFileName[n] = 0;
        // The directory the service files should be copied to
        strncpy(spars->DirectoryTo, ExtractFilePath(tempFileName).c_str(), sizeof(spars->DirectoryTo) - 1);
        // The boot parameters. We assume they can be found after the last space.
        c = strrchr(tempFileName, ' ');
        if ( c ) strcpy(spars->BootParams, c + 1);
        // Get the exefile name
        if ( c ) *c = 0;
        strcpy(spars->ExeFrom, tempFileName);
        c = strrchr(tempFileName, '.');
        if ( c ) *c = 0;
        strcpy(spars->RemoteName, ExtractFileName(tempFileName).c_str());
        strcat(tempFileName, ".ini");
        strcpy(spars->IniFrom, tempFileName);
        // Display name
        strcpy(spars->DisplayName, ((QUERY_SERVICE_CONFIG*)buffer)->lpDisplayName);
        if ( !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
      }
      if ( !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
    }
  }
  return retVal;
}

//------------------------------------------------------------------------------
// Save the program settings to the inifile.
//------------------------------------------------------------------------------
void __fastcall TMainForm::SaveIniSettings()
{
  clientData.SaveSettings(ProgramSettingsFile);
  proxyData.SaveSettings(ProgramSettingsFile);
  // Write program settings. Store current computernames first.
  StoreComputerNames();
  pcfg.SaveSettings(ProgramSettingsFile);
  // Save the form position
  ProgramSettingsFile->WriteInteger(ProgramIniSection, TopPos, Top);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, LeftPos, Left);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, FormHeight, Height);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, MaxWaitTime, pcfg.MaxWaitTime);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, LogRefreshTime, pcfg.LogRefreshTime);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, FormWidth, Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, NameColumnWidth, clientComputersListView->Columns->Items[0]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, StatusColumnWidth, clientComputersListView->Columns->Items[1]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, PathColumnWidth, clientComputersListView->Columns->Items[2]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, VersionColumnWidth, clientComputersListView->Columns->Items[3]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, EmailColumnWidth, clientComputersListView->Columns->Items[4]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, pNameColumnWidth, proxyComputersListView->Columns->Items[0]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, pStatusColumnWidth, proxyComputersListView->Columns->Items[1]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, pPathColumnWidth, proxyComputersListView->Columns->Items[2]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, pVersionColumnWidth, proxyComputersListView->Columns->Items[3]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, pEmailColumnWidth, proxyComputersListView->Columns->Items[4]->Width);
  // Set the stored settings to the saved ones
  orgpcfg = pcfg;
  orgClientData = clientData;
  orgProxyData = proxyData;
}

//------------------------------------------------------------------------------
// Enables or disables client and proxy specific menuitems.
//------------------------------------------------------------------------------
void __fastcall TMainForm::EnableClientOrProxySpecificOptions(bool enableClientOptions, bool enableProxyOptions)
{
  Client1->Enabled = enableClientOptions;
  Client2->Enabled = enableClientOptions;
  Proxy1->Enabled = enableProxyOptions;
  Proxy2->Enabled = enableProxyOptions;
  // Proxy service cannot be paused/continued.
  Pauseservice1->Enabled = enableClientOptions;
  Continueservice1->Enabled = enableClientOptions;
  // Reload cfg via a SCM message is not yet supported by the proxy
  ReloadServiceConfiguration1->Enabled = enableClientOptions;
}

//------------------------------------------------------------------------------
// Restore on double click on the tray icon.
//------------------------------------------------------------------------------
void __fastcall TMainForm::WMTrayNotify(TMessage& Msg)
{
  POINT p;
  // The LPARAM of the message identifies the type of mouse message.
  if ( Msg.LParam == WM_LBUTTONDBLCLK ) Application->Restore();
  // Right button pressed: show popup menu
  else if ( Msg.LParam == WM_RBUTTONDOWN ) {
    SetForegroundWindow(Handle);
    GetCursorPos(&p);
    TrayPopupMenu->Popup(p.x, p.y);
    PostMessage(Handle, WM_NULL, 0, 0); // Done to bypass a bug in windows
  }
}

//------------------------------------------------------------------------------
// Use the Shell_NotifyIcon API function to add the icon to the system tray.
//------------------------------------------------------------------------------
void __fastcall TMainForm::AddIcon()
{
  NOTIFYICONDATA IconData;
  IconData.cbSize = sizeof(NOTIFYICONDATA);
  IconData.uID    = IDC_TRAY1;
  IconData.hWnd   = Handle;
  IconData.uFlags = NIF_MESSAGE|NIF_ICON|NIF_TIP;
  IconData.uCallbackMessage = WM_TRAYNOTIFY;
  lstrcpy(IconData.szTip, "Remote service control center");
  IconData.hIcon  = TrayIcon->Handle;
  Shell_NotifyIcon(NIM_ADD, &IconData);
}

//------------------------------------------------------------------------------
// Remove the icon from the system tray
//------------------------------------------------------------------------------
void __fastcall TMainForm::RemoveIcon()
{
  NOTIFYICONDATA IconData;
  IconData.cbSize = sizeof(NOTIFYICONDATA);
  IconData.uID    = IDC_TRAY1;
  IconData.hWnd   = Handle;
  IconData.hIcon  = TrayIcon->Handle;
  Shell_NotifyIcon(NIM_DELETE, &IconData);
}

//------------------------------------------------------------------------------
// Minimize to the system tray if required
//------------------------------------------------------------------------------
void __fastcall TMainForm::AppOnMinimize(TObject* Sender)
{
  if ( pcfg.minimizeToSystray ) {
    AddIcon();
    ShowWindow(Application->Handle, SW_HIDE);
  }
}

//------------------------------------------------------------------------------
// Restore from the system tray if required
//------------------------------------------------------------------------------
void __fastcall TMainForm::AppOnRestore(TObject* Sender)
{
  if ( pcfg.minimizeToSystray ) {
    RemoveIcon();
    ShowWindow(Application->Handle, SW_SHOW);
    SetForegroundWindow(Application->Handle);
  }
}

//------------------------------------------------------------------------------
// Restore from the system tray if the restore popup menu item clicked.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Restore3Click(TObject* Sender)
{
  Application->Restore();
}

//------------------------------------------------------------------------------
// The delete button also deletes computers from the list
//------------------------------------------------------------------------------
void __fastcall TMainForm::ComputersListViewKeyDown(TObject* Sender, WORD& Key, TShiftState Shift)
{
  if ( Key == VK_DELETE ) RemPCButtonClick(Sender);
  CurrActiveItem = NULL;
}

//------------------------------------------------------------------------------
//  Switch between client and proxy. Update the status of all checked computers.
//------------------------------------------------------------------------------
void __fastcall TMainForm::RadioButtonClick(TObject* Sender)
{
  if ( ClientRadioButton->Checked ) {
    cfg = &clientData;
    pcfg.ServiceToShow = serviceClient;
    activeListView = clientComputersListView;
    proxyComputersListView->Visible = false;
    clientComputersListView->Visible = true;
    EnableClientOrProxySpecificOptions(true, false);
  }
  else {
    cfg = &proxyData;
    pcfg.ServiceToShow = serviceProxy;
    activeListView = proxyComputersListView;
    clientComputersListView->Visible = false;
    proxyComputersListView->Visible = true;
    EnableClientOrProxySpecificOptions(false, true);
  }
  // Update status info for all checked lines
  UpdateStatus(0, true, true, activeListView);
}

//------------------------------------------------------------------------------
// See if we want to hide the buttons
//------------------------------------------------------------------------------
void __fastcall TMainForm::ShowButtons1Click(TObject* Sender)
{
  ShowButtons1->Checked = !ShowButtons1->Checked;
  pcfg.showButtons = ShowButtons1->Checked;
  ButtonPanel->Visible = pcfg.showButtons;
}

//------------------------------------------------------------------------------
// See if we want to hide the settings panel
//------------------------------------------------------------------------------
void __fastcall TMainForm::ShowSettings1Click(TObject* Sender)
{
  ShowSettings1->Checked = !ShowSettings1->Checked;
  pcfg.showSettings = ShowSettings1->Checked;
  SettingsPanel->Visible = pcfg.showSettings;
}

//------------------------------------------------------------------------------
// Select which logfile we see when we view the proxy logfile.
//------------------------------------------------------------------------------
void __fastcall TMainForm::ViewConLog1Click(TObject* Sender)
{
  ViewConlog1->Checked = true;
  pcfg.whichProxyLogFile = conLogFile;
}

void __fastcall TMainForm::ViewRC5Log1Click(TObject* Sender)
{
  ViewRC5log1->Checked = true;
  pcfg.whichProxyLogFile = rc5LogFile;
}

void __fastcall TMainForm::ViewOGRLog1Click(TObject* Sender)
{
  ViewOGRlog1->Checked = true;
  pcfg.whichProxyLogFile = ogrLogFile;
}

void __fastcall TMainForm::ViewOGRP2log1Click(TObject* Sender)
{
  ViewOGRP2log1->Checked = true;
  pcfg.whichProxyLogFile = ogrp2LogFile;
}

void __fastcall TMainForm::ViewOGRNGlog1Click(TObject* Sender)
{
  ViewOGRNGlog1->Checked = true;
  pcfg.whichProxyLogFile = ogrngLogFile;
}

//------------------------------------------------------------------------------
// If checked, use a default password for the RC5 encryption for login data.
// Else use a user-supplied password.
//------------------------------------------------------------------------------
void __fastcall TMainForm::DefaultPassword1Click(TObject* Sender)
{
  DefaultPassword1->Checked = !DefaultPassword1->Checked;
  pcfg.useSecureCipher = !DefaultPassword1->Checked;
  Password1->Enabled = !DefaultPassword1->Checked;
  // Set default password if not secure
  if ( !pcfg.useSecureCipher ) {
    strcpy(pcfg.ProgramPassword, DefaultPassword);
    // Ask to change settings
    if ( Application->MessageBox("Password has changed, save settings?", Application->Title.c_str(), MB_YESNO) == ID_YES)
      SaveIniSettings();
  }
  // Ask for password if none set or password == defaultpassword
  else if ( pcfg.useSecureCipher && (!strlen(pcfg.ProgramPassword) || !strcmp(pcfg.ProgramPassword, DefaultPassword)) )
    Password1Click(Sender);
}

//------------------------------------------------------------------------------
// Set the program password used to encrypt the login information with RC5.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Password1Click(TObject* Sender)
{
  TModalResult mrRes;
  char OldProgramPassword[128];

  strcpy(OldProgramPassword, pcfg.ProgramPassword);
  TPasswordForm* PwdForm = new TPasswordForm(this, pcfg.ProgramPassword, sizeof(pcfg.ProgramPassword) - 1, true, "Please enter program password to access logon data");
  if ( PwdForm ) {
    // We ask to save the settings if the password is changed AND used.
    mrRes = PwdForm->ShowModal();
    if (!strlen(pcfg.ProgramPassword) || (mrRes != mrOk)) { // Empty password means use insecure cipher
      pcfg.useSecureCipher = false;
      DefaultPassword1->Checked = true;
      Password1->Enabled = false;
      strcpy(pcfg.ProgramPassword, DefaultPassword); // Set default password
    } else if (mrRes == mrOk) {
      pcfg.useSecureCipher = true;
      DefaultPassword1->Checked = false;
      Password1->Enabled = true;
    }
    if ( (mrRes == mrOk) && strcmp(OldProgramPassword, pcfg.ProgramPassword) ) {
      if ( Application->MessageBox("Password has changed, save settings?", Application->Title.c_str(), MB_YESNO) == ID_YES)
        SaveIniSettings();
    }
    delete PwdForm;
    // Remove password from memory
    memset(OldProgramPassword, 0, sizeof(OldProgramPassword));
  }
}

//------------------------------------------------------------------------------
// Shows the settings form.
//------------------------------------------------------------------------------
void __fastcall TMainForm::settings1Click(TObject* Sender)
{
  AnsiString previousSelectedService = pcfg.ServiceToShow;
  bool lineSelect = clientComputersListView->RowSelect; // Both listviews behave the same

  TSettingsForm* SettingsForm = new TSettingsForm(this, &pcfg);
  if ( SettingsForm ) {
    SettingsForm->ShowModal();
    delete SettingsForm;
  }
  // if the service to show has changed then process this change
  if ( pcfg.ServiceToShow != previousSelectedService ) {
    // Reassign the event handlers AFTER one radio button's state has set to checked.
    // This prevents them from being called too often which reduces performance.
    ClientRadioButton->OnClick   = NULL;
    PerProxyRadioButton->OnClick = NULL;
    // Some changes in the settings program affect the UI of the main form
    if ( pcfg.ServiceToShow == serviceClient ) {
      PerProxyRadioButton->Checked = false;
      ClientRadioButton->Checked = true;
      if ( SettingsPanel->Visible )
        ClientRadioButton->SetFocus(); // Necessary or it will not work.
    } else if ( pcfg.ServiceToShow == serviceProxy ) {
      ClientRadioButton->Checked = false;
      PerProxyRadioButton->Checked = true;
      if ( SettingsPanel->Visible )
        PerProxyRadioButton->SetFocus(); // Necessary or it will not work.
    }
    RadioButtonClick(Sender);
    ClientRadioButton->OnClick   = RadioButtonClick;
    PerProxyRadioButton->OnClick = RadioButtonClick;
  }
  // Secure cipher options:
  DefaultPassword1->Checked = !pcfg.useSecureCipher;
  Password1->Enabled = pcfg.useSecureCipher;
  // Set default password if not secure
  if ( !pcfg.useSecureCipher ) strcpy(pcfg.ProgramPassword, DefaultPassword);
  // Ask for password if none set or password == defaultpassword
  if ( pcfg.useSecureCipher && (!strlen(pcfg.ProgramPassword) || !strcmp(pcfg.ProgramPassword, DefaultPassword)) )
    Password1Click(Sender);
  // GUI
  if ( pcfg.selectWholeLine != lineSelect ) {
    clientComputersListView->RowSelect = pcfg.selectWholeLine;
    proxyComputersListView->RowSelect = pcfg.selectWholeLine;
  }
  // Check which proxy logfile we want to see
  if ( pcfg.whichProxyLogFile == conLogFile )      ViewConlog1->Checked = true;
  else if ( pcfg.whichProxyLogFile == rc5LogFile ) ViewRC5log1->Checked = true;
  else if ( pcfg.whichProxyLogFile == ogrLogFile ) ViewOGRlog1->Checked = true;
  else if ( pcfg.whichProxyLogFile == ogrp2LogFile ) ViewOGRP2log1->Checked = true;
  else if ( pcfg.whichProxyLogFile == ogrngLogFile ) ViewOGRNGlog1->Checked = true;
  // If any periodic start/stop operation is to be performed, enable the timer
  if (pcfg.startOnWeekdays || pcfg.stopOnWeekdays || pcfg.startOnWeekends || pcfg.stopOnWeekends)
    PeriodicStartStopTimer->Enabled = true;
  else
    PeriodicStartStopTimer->Enabled = false;
}

//------------------------------------------------------------------------------
// Shows the stored computernames in the listviews.
//------------------------------------------------------------------------------
void __fastcall TMainForm::ReadComputerNames()
{
  int i;
  TListItem* L;

  // Add the listitems and see which ones need to be checked.
  // 1. Clients
  for (i = 0; i < pcfg.clientComputerNameList->Count; i++) {
    L = clientComputersListView->Items->Add();
    L->Caption = pcfg.clientComputerNameList->Strings[i];
    if ( (int)pcfg.clientComputerNameList->Objects[i] == 1 ) {
      L->Checked = true;
    }
    // Add item for status info
    L->SubItems->Add("");
    // Add item for service path
    L->SubItems->Add("");
    // Add subitem for client version
    L->SubItems->Add("");
    // Add subitem for email address
    L->SubItems->Add("");
  }
  // 2. Proxies
  for (i = 0; i < pcfg.proxyComputerNameList->Count; i++) {
    L = proxyComputersListView->Items->Add();
    L->Caption = pcfg.proxyComputerNameList->Strings[i];
    if ( (int)pcfg.proxyComputerNameList->Objects[i] == 1 ) {
      L->Checked = true;
    }
    // Add item for status info
    L->SubItems->Add("");
    // Add item for service path
    L->SubItems->Add("");
    // Add subitem for proxy version
    L->SubItems->Add("");
    // Add subitem for ipaddress
    L->SubItems->Add("");
  }
  // Add all other computers from Network Neighborhood to the list and
  // update the status.
  if ( pcfg.readNetworkNamesAfterStart )
    GetNetworkComputerNames(false, pcfg.readNetworkNamesAfterStart);

  if ( pcfg.updateStatusAfterStart ) {
    UpdateStatus(0, true, true, activeListView);
  }
}

//------------------------------------------------------------------------------
// Create the thread to find the network computer names. If aRunUpdateAfterwards
// is true, the status information will be updated afterwards.
//------------------------------------------------------------------------------
void __fastcall TMainForm::GetNetworkComputerNames(bool waitForResult, bool aRunUpdateAfterwards)
{
  TNetworkScanThread* NetworkScanThread;

  // This prevents errors with indices
  clientComputersListView->SortType = stNone;
  proxyComputersListView->SortType = stNone;
  // We don't start the thread twice. We also don't start the update status
  // thread when scanning the network.
  if ( !NetworkScanThreadIsRunning ) {
    NetworkScanThreadIsRunning = true;
    try {
      // Show a form to indicate we're doing something. This form will be deleted
      // by the readthread
      // Create the readthread. This thread will delete itself when ready and
      // notice when the wait info panel can be hided.
      NetworkScanThread = new TNetworkScanThread(true, aRunUpdateAfterwards, pcfg.scanOutsideDomain, this);
      ShowThreadWaitInfo();
      if ( NetworkScanThread ) {
        NetworkScanThread->Resume();
        if ( waitForResult ) NetworkScanThread->WaitFor();
      } else {
        ShowErrorMessage("Error creating network scan thread", NULL);
        HideThreadWaitInfo();
        NetworkScanThreadIsRunning = false;
      }
    }
    catch (...) {
      HideThreadWaitInfo();
      NetworkScanThreadIsRunning = false;
    }
  }
}

//------------------------------------------------------------------------------
// Shows the wait info panel for the network scan thread.
//------------------------------------------------------------------------------
void __fastcall TMainForm::ShowThreadWaitInfo()
{
  WaitThreadPanel->Width = 300;
  WaitThreadPanel->Height = 110;
  WaitThreadPanel->Color = (TColor)0x00E1C00A;
  WaitThreadPanel->Left = (activeListView->Width - WaitThreadPanel->Width) / 2;
  WaitThreadPanel->Top = (activeListView->Height - WaitThreadPanel->Height) / 2;
  InfoThreadLabel->Caption = "";
  WaitThreadLabel->Caption = "";
  WaitThreadPanel->Visible = true;
}

//------------------------------------------------------------------------------
// Shows the wait info panel for the status update .
//------------------------------------------------------------------------------
void __fastcall TMainForm::ShowUpdateWaitInfo()
{
  WaitUpdatePanel->Width = 300;
  WaitUpdatePanel->Height = 110;
//  WaitUpdatePanel->Color = (TColor)0x00E1C00A;
  WaitUpdatePanel->Left = (activeListView->Width - WaitUpdatePanel->Width) / 2;
  WaitUpdatePanel->Top = (activeListView->Height - WaitUpdatePanel->Height) / 2;
  InfoUpdateLabel->Caption = "";
  WaitUpdateLabel->Caption = "";
  WaitUpdatePanel->Visible = true;
}

//------------------------------------------------------------------------------
// Hides the wait info panel for the network scan thread.
//------------------------------------------------------------------------------
void __fastcall TMainForm::HideThreadWaitInfo()
{
  InfoThreadLabel->Caption = "";
  WaitThreadLabel->Caption = "";
  WaitThreadPanel->Visible = false;
}

//------------------------------------------------------------------------------
// Hides the wait info panel for the status update .
//------------------------------------------------------------------------------
void __fastcall TMainForm::HideUpdateWaitInfo()
{
  InfoUpdateLabel->Caption = "";
  WaitUpdateLabel->Caption = "";
  WaitUpdatePanel->Visible = false;
}

//------------------------------------------------------------------------------
// Sets the label captions in the network scan thread wait info panel.
//------------------------------------------------------------------------------
void __fastcall TMainForm::SetThreadWaitText(AnsiString label, AnsiString info)
{
  WaitThreadLabel->Caption = label;
  InfoThreadLabel->Caption = info;
}

//------------------------------------------------------------------------------
// Sets the label captions in the status update wait info panel.
//------------------------------------------------------------------------------
void __fastcall TMainForm::SetUpdateWaitText(AnsiString label, AnsiString info)
{
  WaitUpdateLabel->Caption = label;
  InfoUpdateLabel->Caption = info;
}

//------------------------------------------------------------------------------
// Updates the status information for the selected computer and the executable
// path info. We can't do this in a separate thread: since we need access to
// network resources we would have to call the method synchronized (the TThread
// class does not pass security descriptors in its CreateThread call). This
// however can cause a deadlock when we waitfor the result. If we don't wait
// for the the thread to finish we can as well do it in the main thread.
// If alwaysUpdateVersionAndIni is true the version and email info will always
// be updated, otherwise it will only be updated if one of those fields is empty.
//------------------------------------------------------------------------------
void __fastcall TMainForm::UpdateStatus(int        index,
                                        bool       updateAll,
                                        bool       alwaysUpdateVersionAndIni,
                                        TListView* viewToUpdate)
{
  unsigned int k;
  int i, n, beginindex, endindex;
  char servicePath[MAX_PATH], serviceExe[MAX_PATH];
  // Client inifile variables
  char serviceIni[MAX_PATH], tempFileName[MAX_PATH], systemShare[MAX_PATH];
  char* shareBoundary;
  TIniFile* clientIniFile;
  char* p;
  AnsiString clientEmail;
  // Version API stuff
  char* versionBlock;
  DWORD versionLength, versionNullHandle;
  unsigned int versionInfoLength;
  void* FileVersionInfoPtr;
  AnsiString formCaption = Caption;

  Screen->Cursor = crHourGlass;
  // Show the wait info panel
  ShowUpdateWaitInfo();
  SetUpdateWaitText("Updating status information...", "");
  // See which info we need to update
  if ( updateAll ) {
    beginindex = 0;
    endindex = viewToUpdate->Items->Count - 1;
  } else {
    beginindex = index;
    endindex = index;
  }
  // Clear the fields
  for (i = beginindex; i <= endindex; i++) {
    viewToUpdate->Items->Item[i]->SubItems->Strings[lStatusIndex] = "";
    viewToUpdate->Items->Item[i]->SubItems->Strings[lPathIndex] = "";
  }
  Application->ProcessMessages(); // Make the changes visible
  // Get the new status info
  for (i = beginindex; i <= endindex; i++) {
    if ( viewToUpdate->Items->Item[i]->Checked ) {
      // Show computername in caption
      SetUpdateWaitText("Updating status information...", viewToUpdate->Items->Item[i]->Caption);
      memset(servicePath, 0, sizeof(servicePath));
      // Get service status and show it
      DWORD returnCode = GetServiceStatus(viewToUpdate->Items->Item[i]->Caption.c_str(), cfg->ServiceName);
      viewToUpdate->Items->Item[i]->SubItems->Strings[lStatusIndex] = ServiceStateDescription(returnCode);
      // Get service path
      if ( (returnCode != ERROR_SERVICE_DOES_NOT_EXIST) && (returnCode != NO_SERVICEMANAGER_FOUND) && (returnCode != COMPUTERNAME_NOT_FOUND)) {
        GetServicePath(viewToUpdate->Items->Item[i]->Caption.c_str(), servicePath, sizeof(servicePath));
        if ( servicePath )
          viewToUpdate->Items->Item[i]->SubItems->Strings[lPathIndex] = AnsiString(servicePath);
      } else
        viewToUpdate->Items->Item[i]->SubItems->Strings[lPathIndex] = "";
      // See if we want to update the version and email info.
      if ( alwaysUpdateVersionAndIni ||
           (!viewToUpdate->Items->Item[i]->SubItems->Strings[lVersionIndex].Length() ||
            !viewToUpdate->Items->Item[i]->SubItems->Strings[lEmailIndex].Length() ) ) {
        viewToUpdate->Items->Item[i]->SubItems->Strings[lVersionIndex] = "";
        viewToUpdate->Items->Item[i]->SubItems->Strings[lEmailIndex] = "";
        // Get client version
        if ( (returnCode != ERROR_SERVICE_DOES_NOT_EXIST) && (returnCode != NO_SERVICEMANAGER_FOUND) && (returnCode != COMPUTERNAME_NOT_FOUND)) {
          // Find network path of the executable
          GetExecutableName(viewToUpdate->Items->Item[i]->Caption.c_str(), servicePath, serviceExe);
          if ( FileExists(serviceExe) ) {
            // Find length of the version resource
            versionLength = GetFileVersionInfoSize(serviceExe, &versionNullHandle);
            // reserve storage for it
            versionBlock = new char[versionLength];
            if ( versionBlock ) {
              versionInfoLength = 0;
              if ( GetFileVersionInfo(serviceExe, NULL, versionLength, versionBlock) ) {
                VerQueryValue(versionBlock, TEXT("\\StringFileInfo\\040904E4\\ProductVersion"), &FileVersionInfoPtr, &versionInfoLength);
                if ( versionInfoLength > 0 ) { // If versioninfo found
                  viewToUpdate->Items->Item[i]->SubItems->Strings[lVersionIndex] = (char*)FileVersionInfoPtr;
                } else { // No version info found
                  viewToUpdate->Items->Item[i]->SubItems->Strings[lVersionIndex] = "Unavailable";
                }
              } else {
                viewToUpdate->Items->Item[i]->SubItems->Strings[lVersionIndex] = "No version info found";
              }
              delete[] versionBlock;
            }
          } else {
            // Can be due to insufficient rights on the network, check this first
            strcpy(systemShare, serviceExe);
            shareBoundary = strchr(systemShare, '$');
            if ( shareBoundary ) *(shareBoundary + 1) = 0;
            if ( !DirectoryExists(systemShare) ) // Insufficient rights to access system share
              viewToUpdate->Items->Item[i]->SubItems->Strings[lVersionIndex] = "Access denied";
            else // File really not found
              viewToUpdate->Items->Item[i]->SubItems->Strings[lVersionIndex] = "File not found";
          }
          // Get email version in client
          // Get inifilename of client
          strcpy(tempFileName, serviceExe);
          p = strrchr(tempFileName, '.');
          if ( p ) *p = 0;
          strcat(tempFileName, ".ini");
          // Remove possible quotes from the name (could happen on existing installs)
          memset(serviceIni, 0, sizeof(serviceIni));
          for (n = 0, k = 0; k < strlen(tempFileName); k++) {
            if ( tempFileName[k] != '\"' ) {
              serviceIni[n] = tempFileName[k];
              n++;
            }
          }
          if ( FileExists(serviceIni) ) {
            clientIniFile = new TIniFile(serviceIni);
            if ( clientIniFile ) {
              clientEmail = clientIniFile->ReadString(cfg->DestinationSection, cfg->DestinationKey, "Key not found");
              viewToUpdate->Items->Item[i]->SubItems->Strings[lEmailIndex] = clientEmail;
              delete clientIniFile;
            }
          }
        }
      }
    }
    Application->ProcessMessages();
  }
  Caption = formCaption;
  Screen->Cursor = crDefault;
  HideUpdateWaitInfo();
}

//------------------------------------------------------------------------------
// Returns the string that belongs to a service state.
//------------------------------------------------------------------------------
AnsiString __fastcall TMainForm::ServiceStateDescription(DWORD serviceState)
{
  AnsiString Result;

  switch ( serviceState ) {
    case SERVICE_STOPPED:
         Result = "Service not running";
         break;
    case SERVICE_START_PENDING:
         Result = "Service starting";
         break;
    case SERVICE_STOP_PENDING:
         Result = "Service stopping";
         break;
    case SERVICE_RUNNING:
         Result = "Service is running";
         break;
    case SERVICE_CONTINUE_PENDING:
         Result = "Continue pending";
         break;
    case SERVICE_PAUSE_PENDING:
         Result = "Pause pending";
         break;
    case SERVICE_PAUSED:
         Result = "Service paused";
         break;
    case ERROR_SERVICE_DOES_NOT_EXIST:
         Result = "Service is not installed";
         break;
    case NO_SERVICEMANAGER_FOUND:
         Result = "No service manager found";
         break;
    case COMPUTERNAME_NOT_FOUND:
         Result = "Computer not found";
         break;
    default:
         Result = "Unknown status";
  }
  return Result;
}

//------------------------------------------------------------------------------
// Gets the service executable name.
// The parameter servicePath contains a buffer to receive the service path. The
// size of this buffer is given by buffSize.
//------------------------------------------------------------------------------
void __fastcall TMainForm::GetServicePath(char computerName[], char* servicePathBuffer, size_t buffSize)
{
  char buffer[2048];
  DWORD bytesNeeded, errCode;
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;

  Screen->Cursor = crHourGlass;

  if ( (hscManager = RSCC_OpenSCManager(computerName, NULL, GENERIC_READ)) != 0 ) {
    // We only need to query the service so we need to open it with only
    // SERVICE_QUERY_CONFIG rights. This does not require admin access to
    // the service.
    if ( (hService = OpenService(hscManager, cfg->ServiceName, SERVICE_QUERY_CONFIG)) == NULL ) {
      errCode = GetLastError();
      if ( errCode == ERROR_ACCESS_DENIED)
        strncpy(servicePathBuffer, "Access denied", buffSize);
      else
        ShowErrorMessage(computerName, &errCode);
    }
    // First stop the service. We check the return value separately because
    // we don't want an errormessage when the service is already stopped.
    if ( hService) {
      // Find out what executable the service uses
      QueryServiceConfig(hService, (QUERY_SERVICE_CONFIG*)buffer, sizeof(buffer), &bytesNeeded);
      strncpy(servicePathBuffer, ((QUERY_SERVICE_CONFIG*)buffer)->lpBinaryPathName, buffSize);
    }
    if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(computerName, NULL);
    if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(computerName, NULL);
  } else {
    errCode = GetLastError();
    if ( errCode == ERROR_ACCESS_DENIED)
      strncpy(servicePathBuffer, "Access denied", buffSize);
    else
      ShowErrorMessage(computerName, &errCode);
  }
  Screen->Cursor = crDefault;
}

//------------------------------------------------------------------------------
// Finds the network name of a executable name from a computername and a
// pathname. The result is stored in networkPath.
//------------------------------------------------------------------------------
void __fastcall TMainForm::GetExecutableName(char aComputerName[], char aPathName[], char networkPath[])
{
  unsigned int i;
  int n;
  char* p;
  char tempFileName[MAX_PATH];

  // Remove the option part from the executable name
  // Make it lowercase
  strcpy(tempFileName, "\\\\");
  // Add computer name
  strcat(tempFileName, aComputerName);
  strcat(tempFileName, "\\");
  strcat(tempFileName, aPathName);
  for (i = 0; i < strlen(tempFileName); i++) tempFileName[i] = (char)tolower(tempFileName[i]);
  p = strrchr(tempFileName, '.');
  if ( p ) *p = 0; // Remove commandline args
  strcat(tempFileName, ".exe");
  // Replace first : by $ to get network name
  for (i = 0; i < strlen(tempFileName); i++) {
    if ( tempFileName[i] == ':' ) {
      tempFileName[i] = '$';
      break;
    }
  }
  // Remove possible quotes from the name (could happen on existing installs)
  for (n = 0, i = 0; i < strlen(tempFileName); i++) {
    if ( tempFileName[i] != '\"' ) {
      networkPath[n] = tempFileName[i];
      n++;
    }
  }
  networkPath[n] = 0;
}

//------------------------------------------------------------------------------
// The read network names thread is ready, close the message window. If the
// message indicates so, update the status.
//------------------------------------------------------------------------------
void __fastcall TMainForm::WMScanThreadReady(TMessage& Message)
{
  HideThreadWaitInfo();
  NetworkScanThreadIsRunning = false;
  if ( Message.WParam == DO_UPDATE_STATUS )
    UpdateStatus(0, true, true, activeListView);
}

//------------------------------------------------------------------------------
// Get the windows version. Returns the windows type it runs on.
//------------------------------------------------------------------------------
DWORD __fastcall TMainForm::GetWin32Platform(char* versionText, size_t buffSize)
{
  OSVERSIONINFO PlatformVersion;

  PlatformVersion.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
  GetVersionEx(&PlatformVersion);
  if ( PlatformVersion.dwPlatformId == VER_PLATFORM_WIN32s ) {
    strcpy(versionText, "Win32s");
  }
  if ( PlatformVersion.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS ) {
    if ( PlatformVersion.dwMajorVersion <= 4 )
      strcpy(versionText, "95 ");
    else if ( PlatformVersion.dwMajorVersion > 4 )
      strcpy(versionText, "98 ");

    strcat(versionText, IntToStr(PlatformVersion.dwMajorVersion).c_str());
    strcat(versionText, ".");
    strcat(versionText, IntToStr(PlatformVersion.dwMinorVersion).c_str());
    strcat(versionText, " build ");
    strcat(versionText, IntToStr(LOWORD(PlatformVersion.dwBuildNumber)).c_str());
    strcat(versionText, " ");
    strcat(versionText, PlatformVersion.szCSDVersion);
  }
  if ( PlatformVersion.dwPlatformId == VER_PLATFORM_WIN32_NT ) {
    // NT4        = 4.0
    // Win2000    = 5.0
    // XP         = 5.1
    // Win2003    = 5.2
    // Win2008    = 6.0
    // Vista      = 6.0
    // Windows 7  = 6.1
    // Win2008 R2 = 6.1
    if ( PlatformVersion.dwMajorVersion <= 4 )
      strcpy(versionText, "NT ");
    else if ((PlatformVersion.dwMajorVersion == 5) && (PlatformVersion.dwMinorVersion == 0))
      strcpy(versionText, "2000 ");
    else if ((PlatformVersion.dwMajorVersion == 5) && (PlatformVersion.dwMinorVersion == 1))
      strcpy(versionText, "XP ");
    else if ((PlatformVersion.dwMajorVersion == 5) && (PlatformVersion.dwMinorVersion > 1))
      strcpy(versionText, "2003 ");
    else if ((PlatformVersion.dwMajorVersion == 6) && (PlatformVersion.dwMinorVersion == 0))
      strcpy(versionText, "Vista or 2008 ");
    else if ((PlatformVersion.dwMajorVersion == 6) && (PlatformVersion.dwMinorVersion > 0))
      strcpy(versionText, "Windows 7 or 2008 R2 ");
    else if (PlatformVersion.dwMajorVersion > 6)
      strcpy(versionText, "Windows (unknown version) ");

    strcat(versionText, IntToStr(PlatformVersion.dwMajorVersion).c_str());
    strcat(versionText, ".");
    strcat(versionText, IntToStr(PlatformVersion.dwMinorVersion).c_str());
    strcat(versionText, " build ");
    strcat(versionText, IntToStr(PlatformVersion.dwBuildNumber).c_str());
    strcat(versionText, " ");
    strcat(versionText, PlatformVersion.szCSDVersion);
  }
  return PlatformVersion.dwPlatformId;
}

//------------------------------------------------------------------------------
// Check if  we are dealing with an NT/2000 or XP/2003 since XP and 2003 have
// different privilige requirements for running processes as another user: the
// SeTcbPrivilege privilege is not required. For now, we assume that successors
// to XP also do not require it, if newer windows versions come out this function
// might need adaption.
//------------------------------------------------------------------------------
bool __fastcall TMainForm::Requires_SeTcbPrivilege()
{
  OSVERSIONINFO PlatformVersion;

  PlatformVersion.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
  GetVersionEx(&PlatformVersion);
  if ( PlatformVersion.dwPlatformId == VER_PLATFORM_WIN32_NT ) {
    // NT4        = 4.0
    // Win2000    = 5.0
    // XP         = 5.1
    // Win2003    = 5.2
    // Win2008    = 6.0
    // Vista      = 6.0
    // Windows 7  = 6.1
    // Win2008 R2 = 6.1
    if ((PlatformVersion.dwMajorVersion == 5) && (PlatformVersion.dwMinorVersion > 0)) // XP/2003
      return false;
    if (PlatformVersion.dwMajorVersion > 5) // 2008 or newer
      return false;
  }
  return true;
}

//------------------------------------------------------------------------------
// Returns true if we only want NT machines in the view, false otherwise
//------------------------------------------------------------------------------
bool __fastcall TMainForm::AddOnlyNTMachinesInView()
{
  return pcfg.addOnlyNTMachines;
}

//------------------------------------------------------------------------------
// Updates the statusinfo if a computer checkbox gets checked
//------------------------------------------------------------------------------
void __fastcall TMainForm::ComputersListViewClick(TObject* Sender)
{
  if ( CurrActiveItem ) {
    if ( CurrActiveItem->Checked )
      UpdateStatus(CurrActiveItem->Index, false, false, activeListView);
    else {
      CurrActiveItem->SubItems->Strings[lStatusIndex] = "";
      CurrActiveItem->SubItems->Strings[lPathIndex] = "";
      CurrActiveItem->SubItems->Strings[lVersionIndex] = "";
      CurrActiveItem->SubItems->Strings[lEmailIndex] = "";
    }
  }
  CurrActiveItem = NULL;
}

//------------------------------------------------------------------------------
// Minimizes the form to the system tray
//------------------------------------------------------------------------------
void __fastcall TMainForm::MinimizeButtonClick(TObject *Sender)
{
  // Set default to minimize to system tray
  pcfg.minimizeToSystray = true;
  Application->Minimize();
}

//------------------------------------------------------------------------------
// Returns the current status of the service. A computername is passed.
//------------------------------------------------------------------------------
DWORD __fastcall TMainForm::GetServiceStatus(char computerName[], char aServiceName[])
{
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  SERVICE_STATUS serviceStatus;
  DWORD result;

  // Now open the service manager and install the service
  if ( (hscManager = RSCC_OpenSCManager(computerName, NULL, SC_MANAGER_CONNECT)) != 0 ) {
    if ( (hService = OpenService(hscManager, aServiceName, SERVICE_QUERY_STATUS)) != NULL ) {
      QueryServiceStatus(hService, &serviceStatus);
      result = serviceStatus.dwCurrentState;
    }
    else
      result = ERROR_SERVICE_DOES_NOT_EXIST;

    if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(computerName, NULL);
  } else { // Probably a win95/98/ME PC
    if (IsComputerOnlineAndNT(computerName)) result = NO_SERVICEMANAGER_FOUND;
    else result = COMPUTERNAME_NOT_FOUND;
  }
  if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(computerName, NULL);
  return result;
}

//------------------------------------------------------------------------------
// Returns true if the service exists, false if not or the status could
// not be obtained
//------------------------------------------------------------------------------
bool __fastcall TMainForm::IsServiceInstalled(char aComputername[])
{
  if ( GetServiceStatus(aComputername, cfg->ServiceName) != ERROR_SERVICE_DOES_NOT_EXIST )
    return true;
  else
    return false;
}

//------------------------------------------------------------------------------
// Checks if the service manager on the remote computer can be contacted. In
// practice this is kind of asking if the remote computer runs NT.
//------------------------------------------------------------------------------
bool __fastcall TMainForm::IsServiceManagerInstalled(char aComputername[])
{
  DWORD status = GetServiceStatus(aComputername, cfg->ServiceName);
  if ((status != NO_SERVICEMANAGER_FOUND) && (status != COMPUTERNAME_NOT_FOUND))
    return true;
  else
    return false;
}

//------------------------------------------------------------------------------
// Returns true if the service is running, false if not or the status could
// not be obtained
//------------------------------------------------------------------------------
bool __fastcall TMainForm::IsServiceRunning(char aComputername[])
{
  if ( GetServiceStatus(aComputername, cfg->ServiceName) == SERVICE_RUNNING )
    return true;
  else
    return false;
}

//------------------------------------------------------------------------------
// Wait for the status to reach the desired status. We assume that the SC manager
// and service handles are valid handles. This method returns true if the service
// reached the desired status, and false if a time-out occurred.
//------------------------------------------------------------------------------
bool __fastcall TMainForm::WaitForServiceToReachStatus(SC_HANDLE aHService, DWORD aServiceStatus, int max_wait_seconds, char aMachineName[])
{
  const int sleepTime = 100; // milliseconds
  int waitTime = 1000 * max_wait_seconds; // Time left to wait
  SERVICE_STATUS serviceStatus;

  QueryServiceStatus(aHService, &serviceStatus);
  while ( (serviceStatus.dwCurrentState != aServiceStatus) && (waitTime >= 0) ) {
    Sleep(sleepTime); // Non-busy sleep
    waitTime -= sleepTime;
    QueryServiceStatus(aHService, &serviceStatus);
  }
  if ( waitTime >= 0 ) return true;
  else {
    Application->MessageBox("Timed out waiting for status to reach state", aMachineName, MB_OK);
    return false;
  }
}

//------------------------------------------------------------------------------
// Installs the service on a remote computer. It only installs if this computer
// is both selected and checked.
//------------------------------------------------------------------------------
void __fastcall TMainForm::InstallButtonClick(TObject* Sender)
{
  int i;
  DWORD startType;
  bool cont; // Set to false if we don't continue after an error
  char errMsg[256];
  char RemoteSystemShare[3];
  char RemoteCommand[MAX_PATH];
  char remoteMachineName[MAX_PATH];
  char remoteMachineDir[MAX_PATH];
  char remoteMachineBasePath[MAX_PATH];
  char remoteExePath[MAX_PATH], remoteIniPath[MAX_PATH];
  char buffer[MAX_PATH];
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  int nrOfComputersSelected = activeListView->SelCount;
  char dependencies[7];

  // Set dependency to TCP/IP service
  memset(dependencies, 0, sizeof(dependencies));
  strcpy(dependencies, "Tcpip");

  if ( !nrOfComputersSelected ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    // We first check if sufficient data is available
    if ( cfg->IsSufficientDataAvailable() ) {
      Screen->Cursor = crHourGlass;
      // We convert the dir to network shares without the machine name:
      // c:\temp becomes c$\temp.
      RemoteSystemShare[0] = cfg->DirectoryTo[0];
      RemoteSystemShare[1] = '$';
      RemoteSystemShare[2] = 0;

      // The command to execute on the remote machine to start the service
      strcpy(RemoteCommand, cfg->DirectoryTo);
      if ( RemoteCommand[strlen(RemoteCommand) - 1] != '\\' ) strcat(RemoteCommand, "\\");
      strcat(RemoteCommand, ExtractFileNameWithoutExt(cfg->RemoteName, buffer, sizeof(buffer)));
      strcat(RemoteCommand, ".exe");
      if ( strlen(cfg->BootParams) ) {
        strcat(RemoteCommand, " ");
        strcat(RemoteCommand, cfg->BootParams);
      }

      for (i = 0; i < activeListView->Items->Count; i++) {
        // We only install if this computer is both selected and checked
        if ( activeListView->Items->Item[i]->Selected && activeListView->Items->Item[i]->Checked ) {
          cont = true;
          // Selected computer name
          strncpy(remoteMachineName, activeListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
          // Full path on remote computer. We can do this because exe and ini file
          // always reside in the same dir
          strcpy(remoteMachineDir, "\\\\");
          strncat(remoteMachineDir, activeListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineDir));
          strcat(remoteMachineDir, "\\");
          strcat(remoteMachineDir, RemoteSystemShare);
          // Check if we can access the system share.
          if ( DirectoryExists(remoteMachineDir) ) {
            strcat(remoteMachineDir, cfg->DirectoryTo + 2); // +2 to skip the drive and ":"
            // Store the path
            strcpy(remoteMachineBasePath, remoteMachineDir);
            // Check if the directory exists, create it if not
            if ( !DirectoryExists(remoteMachineDir) ) {
              ForceDirectories(AnsiString(remoteMachineDir));
              if ( !DirectoryExists(remoteMachineDir) ) {
                strcpy(errMsg, "Computer: ");
                strcat(errMsg, remoteMachineName);
                strcat(errMsg, "\nUnable to create destination directory.\nThe service is not installed.");
                Application->MessageBox(errMsg, Application->Title.c_str(), MB_OK|MB_ICONWARNING);
                cont = false;
              }
              strcat(remoteMachineDir, "\\");
            }
            if ( cont ) {
              // Add the name of the remote executable
              strcat(remoteMachineBasePath, ExtractFileNameWithoutExt(cfg->RemoteName, buffer, sizeof(buffer)));
              // First copy the files to the destination directory. We add the computer
              // names here.
              if ( FileExists(cfg->ExeFrom) ) {
                strcpy(remoteExePath, remoteMachineBasePath);
                strcat(remoteExePath, ".exe");
                RSCC_CopyFile(cfg->ExeFrom, remoteExePath, FALSE, pcfg.writeDebugMessages);
              } else {
                ShowErrorMessage(remoteMachineName, NULL);
              }
              if  ( FileExists(cfg->IniFrom) ) {
                strcpy(remoteIniPath, remoteMachineBasePath);
                strcat(remoteIniPath, ".ini");
                RSCC_CopyFile(cfg->IniFrom, remoteIniPath, FALSE, pcfg.writeDebugMessages);
              } else {
                ShowErrorMessage(remoteMachineName, NULL);
              }
              // Now open the service manager and install the service
              if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
                if ( cfg->StartOnBoot ) startType = SERVICE_AUTO_START;
                else startType = SERVICE_DEMAND_START;

                hService = CreateService(hscManager,
                                         cfg->ServiceName,
                                         cfg->DisplayName,
                                         SERVICE_ALL_ACCESS,
                                         SERVICE_WIN32_OWN_PROCESS,
                                         startType,
                                         SERVICE_ERROR_IGNORE,
                                         RemoteCommand,
                                         NULL, NULL,
                                         (LPCTSTR)dependencies,
                                         NULL, NULL);

                if ( !hService ) ShowErrorMessage(remoteMachineName, NULL);
                else {
                  if ( cfg->StartOnInstall )
                    RSCC_StartService(hService, 0, NULL, pcfg.writeDebugMessages, remoteMachineName);
                  // If only one computer selected, update view immediately
                  if ( nrOfComputersSelected == 1 ) {
                    UpdateStatus(i, false, true, activeListView);
                    if ( cfg->StartOnInstall ) {
                      WaitForServiceToReachStatus(hService, SERVICE_RUNNING, pcfg.MaxWaitTime, remoteMachineName);
                      UpdateStatus(i, false, true, activeListView);
                    }
                  } else {
                    if ( cfg->StartOnInstall )
                      WaitForServiceToReachStatus(hService, SERVICE_RUNNING, pcfg.MaxWaitTime, remoteMachineName);
                  }
                }
                if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
                if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
              } else {
                ShowErrorMessage(remoteMachineName, NULL);
              }
            }
          } else { // Could not access system share
            strcpy(errMsg, "Computer: ");
            strcat(errMsg, remoteMachineName);
            strcat(errMsg, "\nUnable to access system share, you probably have insufficient access rights.\nThe service is not installed.");
            Application->MessageBox(errMsg, Application->Title.c_str(), MB_OK|MB_ICONWARNING);
          }
        }
      }
    }
    // Update view if more computers are selected
    if ( nrOfComputersSelected > 1 ) UpdateStatus(0, true, true, activeListView);
    Screen->Cursor = crDefault;
  }
}

//------------------------------------------------------------------------------
// Skips a possible file extension, including the separating dot.
//------------------------------------------------------------------------------
char* __fastcall TMainForm::ExtractFileNameWithoutExt(const char* aFileName, char* buffer, size_t buffSize)
{
  strncpy(buffer, aFileName, buffSize - 1);
  buffer[buffSize] = 0;
  char* c = strrchr(buffer, '.');
  if ( c ) *c = 0;
  return buffer;
}

//------------------------------------------------------------------------------
// Removes the service from the selected computer. This method only removes
// the service from the selected computer if its chekcbox is also checked.
// The corresponding executable and ini file are also deleted.
//------------------------------------------------------------------------------
void __fastcall TMainForm::RemoveButtonClick(TObject* Sender)
{
  int i, n;
  unsigned int j;
  char* p;
  char tempFileName[MAX_PATH], networkPath[MAX_PATH];
  char remoteMachineName[MAX_PATH], ExePathName[MAX_PATH], IniPathName[MAX_PATH];
  BOOL retVal;
  DWORD errCode;
  char errStr[256];
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  SERVICE_STATUS serviceStatus;
  // Number of selected computers
  int nrOfComputersSelected = activeListView->SelCount;

  if ( !nrOfComputersSelected ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    Screen->Cursor = crHourGlass;
    for (i = 0; i < activeListView->Items->Count; i++) {
      if ( activeListView->Items->Item[i]->Selected && activeListView->Items->Item[i]->Checked ) {
        strncpy(remoteMachineName, activeListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
        if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
          if ( (hService = OpenService(hscManager, cfg->ServiceName, SERVICE_ALL_ACCESS)) == NULL ) {
            hService = NULL; // Reset hService
            ShowErrorMessage(remoteMachineName, NULL);
          }
          // First stop the service. We check the return value separately because
          // we don't want an errormessage when the service is already stopped.
          if ( hService) {
            // Find out what executable the service uses
            // We already have the exe name, now derive the ini filename:
            strcpy(tempFileName, "\\\\");
            // Add computer name
            strcat(tempFileName, activeListView->Items->Item[i]->Caption.c_str());
            strcat(tempFileName, "\\");
            // Add exe and path
            strcat(tempFileName, activeListView->Items->Item[i]->SubItems->Strings[lPathIndex].c_str());
            // Remove possible quotes from the name (could happen on existing installs)
            memset(networkPath, 0, sizeof(networkPath));
            for (n = 0, j = 0; j < strlen(tempFileName); j++) {
              if ( tempFileName[j] != '\"' ) {
                networkPath[n] = tempFileName[j];
                n++;
              }
            }
            networkPath[n] = 0;
            strcpy(tempFileName, networkPath);
            // Replace first : by $ to get network name
            for (j = 0; j < strlen(tempFileName); j++) {
              if ( tempFileName[j] == ':' ) {
                tempFileName[j] = '$';
                break;
              }
            }
            // Replace .exe by .ini. This also removes the bootparams part.
            p = strrchr(tempFileName, '.');
            if ( p ) *p = 0;
            strcpy(ExePathName, tempFileName);
            strcpy(IniPathName, tempFileName);
            strcat(IniPathName, ".ini");
            strcat(ExePathName, ".exe");
            // Now stop the service if it runs.
            retVal= RSCC_ControlService(hService, SERVICE_CONTROL_STOP, &serviceStatus, pcfg.writeDebugMessages, remoteMachineName);
            if ( !retVal) {
              errCode = GetLastError();
              if ( errCode != ERROR_SERVICE_NOT_ACTIVE )
                ShowErrorMessage(remoteMachineName, &errCode);
            }
          }
          // Wait until it has stopped
          WaitForServiceToReachStatus(hService, SERVICE_STOPPED, pcfg.MaxWaitTime, remoteMachineName);
          // Then delete the service entry
          if ( hService && !DeleteService(hService) ) ShowErrorMessage(remoteMachineName, NULL);
          if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
          if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
          // Now remove the executable and ini file
          if ( !RSCC_DeleteFile(ExePathName, pcfg.writeDebugMessages) ) {
            strcpy(errStr, "Error deleting old executable on machine: ");
            strcat(errStr, remoteMachineName);
            ShowErrorMessage(errStr, NULL);
          }
          if ( !RSCC_DeleteFile(IniPathName, pcfg.writeDebugMessages) ) {
            strcpy(errStr, "Error deleting old inifile on machine: ");
            strcat(errStr, remoteMachineName);
            ShowErrorMessage(errStr, NULL);
          }
        } else {
          ShowErrorMessage(remoteMachineName, NULL);
        }
        if ( nrOfComputersSelected == 1 ) UpdateStatus(i, false, true, activeListView);
      }
    }
    if ( nrOfComputersSelected > 1 ) UpdateStatus(0, true, true, activeListView);
    Screen->Cursor = crDefault;
  }
}

//------------------------------------------------------------------------------
// Reinstall the service: we first remove it, then we move the buffer files
// and then we install the service.
//------------------------------------------------------------------------------
void __fastcall TMainForm::ReinstallServiceButtonClick(TObject* Sender)
{
  int i, k, n;
  unsigned int j;
  char* p;
  char tempFileName[MAX_PATH], networkPath[MAX_PATH];
  char remoteMachineName[MAX_PATH], ExePathName[MAX_PATH], IniPathName[MAX_PATH];
  AnsiString DestPath; // Destination path
  BOOL retVal;
  DWORD errCode;
  char errStr[256];
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  SERVICE_STATUS serviceStatus;
  // List of filenames of bufferfiles
  TStringList* oldBufferFileNames = new TStringList;
  TStringList* newBufferFileNames = new TStringList;

  if ( !activeListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    Screen->Cursor = crHourGlass;
    for (i = 0; i < activeListView->Items->Count; i++) {
      if ( activeListView->Items->Item[i]->Selected && activeListView->Items->Item[i]->Checked ) {
        strncpy(remoteMachineName, activeListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
        if ( IsServiceInstalled(remoteMachineName) ) {
          if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
            if ( (hService = OpenService(hscManager, cfg->ServiceName, SERVICE_ALL_ACCESS)) == NULL ) {
              hService = NULL; // Reset hService
              ShowErrorMessage(remoteMachineName, NULL);
            }
            // First stop the service. We check the return value separately because
            // we don't want an errormessage when the service is already stopped.
            if ( hService) {
              // Find out what executable the service uses
              // We already have the exe name, now derive the ini filename:
              strcpy(tempFileName, "\\\\");
              // Add computer name
              strcat(tempFileName, activeListView->Items->Item[i]->Caption.c_str());
              strcat(tempFileName, "\\");
              // Add exe and path
              strcat(tempFileName, activeListView->Items->Item[i]->SubItems->Strings[lPathIndex].c_str());
              // Remove possible quotes from the name (could happen on existing installs)
              memset(networkPath, 0, sizeof(networkPath));
              for (n = 0, j = 0; j < strlen(tempFileName); j++) {
                if ( tempFileName[j] != '\"' ) {
                  networkPath[n] = tempFileName[j];
                  n++;
                }
              }
              networkPath[n] = 0;
              strcpy(tempFileName, networkPath);
              // Replace first : by $ to get network name
              for (j = 0; j < strlen(tempFileName); j++) {
                if ( tempFileName[j] == ':' ) {
                  tempFileName[j] = '$';
                  break;
                }
              }
              // Replace .exe by .ini. This also removes the bootparams part.
              p = strrchr(tempFileName, '.');
              if ( p ) *p = 0;
              strcpy(ExePathName, tempFileName);
              strcpy(IniPathName, tempFileName);
              strcat(IniPathName, ".ini");
              strcat(ExePathName, ".exe");
              // Now stop the service if it runs.
              retVal= RSCC_ControlService(hService, SERVICE_CONTROL_STOP, &serviceStatus, pcfg.writeDebugMessages, remoteMachineName);
              if ( !retVal) {
                errCode = GetLastError();
                if ( errCode != ERROR_SERVICE_NOT_ACTIVE )
                  ShowErrorMessage(remoteMachineName, &errCode);
              }
            }
            // Wait until it has stopped
            WaitForServiceToReachStatus(hService, SERVICE_STOPPED, pcfg.MaxWaitTime, remoteMachineName);
            // Then delete the service entry
            if ( hService && !DeleteService(hService) ) ShowErrorMessage(remoteMachineName, NULL);
            if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
            if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
            // Move the buffer files to their new locations if the new location differs
            // from the old one.  We should do this before deleting the
            // old inifile because the buffer base names could differ.
            FillListOfBufferFiles(IniPathName, remoteMachineName, oldBufferFileNames, newBufferFileNames);
            // Check if the directory exists, create it if not
            DestPath = "\\\\" + AnsiString(remoteMachineName) + "\\" + AnsiString(cfg->DirectoryTo);
            for (int i = 0; i < DestPath.Length(); i++) {
              if ( DestPath.c_str()[i] == ':') {
                DestPath.c_str()[i] = '$'; // Make system share path
                break;
              }
            }
            if ( !DirectoryExists(DestPath) ) {
              ForceDirectories(DestPath);
              if ( !DirectoryExists(DestPath) ) {
                strcpy(errStr, "Computer: ");
                strcat(errStr, remoteMachineName);
                strcat(errStr, "\nUnable to create destination directory.\nThe service is not installed.");
                Application->MessageBox(errStr, Application->Title.c_str(), MB_OK|MB_ICONWARNING);
                break;
              }
            }
            // Now move the buffer files to the new directory c.q. name.
            for (k = 0; k < oldBufferFileNames->Count; k++) {
              // Only move the files if name and path are not identical.
              if ( oldBufferFileNames->Strings[k] != newBufferFileNames->Strings[k] ) {
                if ( !RSCC_MoveFileEx(oldBufferFileNames->Strings[k].c_str(),
                                      newBufferFileNames->Strings[k].c_str(),
                                      MOVEFILE_COPY_ALLOWED|MOVEFILE_WRITE_THROUGH|MOVEFILE_REPLACE_EXISTING,
                                      pcfg.writeDebugMessages) ) {
                  strcpy(errStr, "Unable to move bufferfile on computer ");
                  strcat(errStr, remoteMachineName);
                  ShowErrorMessage(errStr, NULL);
                }
              }
            }
            // Now remove the executable and ini file
            if ( !RSCC_DeleteFile(ExePathName, pcfg.writeDebugMessages) ) {
              strcpy(errStr, "Error deleting old executable on machine: ");
              strcat(errStr, remoteMachineName);
              ShowErrorMessage(errStr, NULL);
            }
            if ( !RSCC_DeleteFile(IniPathName, pcfg.writeDebugMessages) ) {
              strcpy(errStr, "Error deleting old inifile on machine: ");
              strcat(errStr, remoteMachineName);
              ShowErrorMessage(errStr, NULL);
            }
          } else {
            ShowErrorMessage(remoteMachineName, NULL);
          }
        }
      }
    }
    Screen->Cursor = crDefault;
  }
  // Now re-install the service(s)
  InstallButtonClick(Sender);
  delete oldBufferFileNames;
  delete newBufferFileNames;
}

//------------------------------------------------------------------------------
// Fills two stringlists with the full path and names of the buffer files. We
// obtain the buffer basenames from the client inifile (if we are reinstalling
// a proxy the lists will just be empty).
//------------------------------------------------------------------------------
void __fastcall TMainForm::FillListOfBufferFiles(char* remoteIniFileName, char* remoteMachineName, TStringList* oldNames, TStringList* newNames)
{
  // Buffer file base names
  AnsiString oldBuffInBase;
  AnsiString oldBuffOutBase;
  AnsiString oldCkPointName;
  AnsiString newBuffInBase;
  AnsiString newBuffOutBase;
  AnsiString newCkPointName;
  TIniFile* aIniFile;
  // Search record for wildcard search
  TSearchRec searchRecord;
  // We assume the bufferfiles are in the same directory as the inifile:
  AnsiString SrcPath = ExtractFilePath(remoteIniFileName);
  // Destination path
  AnsiString DestPath = "\\\\" + AnsiString(remoteMachineName) + "\\" + AnsiString(cfg->DirectoryTo);
  for (int i = 0; i < DestPath.Length(); i++) {
    if ( DestPath.c_str()[i] == ':') {
      DestPath.c_str()[i] = '$'; // Make system share path
      break;
    }
  }
  // Clear the stringlists first
  oldNames->Clear();
  newNames->Clear();

  // Client buffer files have a base name plus an extension. Base name is
  // default buff-in/out, but can be overriden in the client ini file.
  if ( !strcmp(cfg->IniSection, clientData.IniSection) ) {
    if ( FileExists(remoteIniFileName) && FileExists(cfg->IniFrom) ) {
      aIniFile = new TIniFile(remoteIniFileName); // Old inifile
      if ( aIniFile ) {
        // Get buffer base-filenames for the existing buffers
        oldBuffInBase  = aIniFile->ReadString("buffers", "buffer-file-basename", "buff-in");
        oldBuffOutBase = aIniFile->ReadString("buffers", "output-file-basename", "buff-out");
        oldCkPointName = aIniFile->ReadString("buffers", "checkpoint-filename", "");
        delete aIniFile;
      }
      aIniFile = new TIniFile(cfg->IniFrom); // New inifile
      if ( aIniFile ) {
        // Get buffer base-filenames for the new buffers
        newBuffInBase  = aIniFile->ReadString("buffers", "buffer-file-basename", "buff-in");
        newBuffOutBase = aIniFile->ReadString("buffers", "output-file-basename", "buff-out");
        newCkPointName = aIniFile->ReadString("buffers", "checkpoint-filename", "");
        delete aIniFile;
      }
      // Now find all files with the specified basenames
      // Input buffer
      if ( !FindFirst(SrcPath + oldBuffInBase + "*", faAnyFile, searchRecord) ) {
        oldNames->Add(SrcPath + searchRecord.Name);
        newNames->Add(DestPath + newBuffInBase + ExtractFileExt(searchRecord.Name));
        while ( !FindNext(searchRecord) ) {
          oldNames->Add(SrcPath + searchRecord.Name);
          newNames->Add(DestPath + newBuffInBase + ExtractFileExt(searchRecord.Name));
        }
      }
      FindClose(searchRecord);
      // Output buffer
      if ( !FindFirst(SrcPath + oldBuffOutBase + "*", faAnyFile, searchRecord) ) {
        oldNames->Add(SrcPath + searchRecord.Name);
        newNames->Add(DestPath + newBuffOutBase + ExtractFileExt(searchRecord.Name));
        while ( !FindNext(searchRecord) ) {
          oldNames->Add(SrcPath + searchRecord.Name);
          newNames->Add(DestPath + newBuffOutBase + ExtractFileExt(searchRecord.Name));
        }
      }
      FindClose(searchRecord);
      if ( oldCkPointName.Length() && FileExists(SrcPath + oldCkPointName) ) {
        oldNames->Add(SrcPath + oldCkPointName);
        newNames->Add(DestPath + newCkPointName);
      }
    }
  }
  // Proxy buffer files have fixed names
  if ( !strcmp(cfg->IniSection, proxyData.IniSection) ) {
    // Buffer input files.
    if ( !FindFirst(SrcPath + "pp*in.*", faAnyFile, searchRecord) ) {
      oldNames->Add(SrcPath + searchRecord.Name);
      newNames->Add(DestPath + searchRecord.Name);
      while ( !FindNext(searchRecord) ) {
        oldNames->Add(SrcPath + searchRecord.Name);
        newNames->Add(DestPath + searchRecord.Name);
      }
    }
    FindClose(searchRecord);
    // Buffer output files
    if ( !FindFirst(SrcPath + "pp*out.*", faAnyFile, searchRecord) ) {
      oldNames->Add(SrcPath + searchRecord.Name);
      newNames->Add(DestPath + searchRecord.Name);
      while ( !FindNext(searchRecord) ) {
        oldNames->Add(SrcPath + searchRecord.Name);
        newNames->Add(DestPath + searchRecord.Name);
      }
    }
    FindClose(searchRecord);
  }
}

//------------------------------------------------------------------------------
// Update the service. We stop the service, copy new binaries to the location of
// the old binaries (need not be the installation dir from the default settings)
// and restart the service.
//------------------------------------------------------------------------------
void __fastcall TMainForm::UpdateServiceButtonClick(TObject* Sender)
{
  int i, n;
  unsigned int j;
  char* p;
  char tempFileName[MAX_PATH], networkPath[MAX_PATH];
  char remoteMachineName[MAX_PATH], ExePathName[MAX_PATH], IniPathName[MAX_PATH];
  BOOL retVal;
  DWORD errCode;
  char errStr[256];
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  SERVICE_STATUS serviceStatus;
  // Number of selected computers
  int nrOfComputersSelected = activeListView->SelCount;

  if ( !nrOfComputersSelected ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    Screen->Cursor = crHourGlass;
    for (i = 0; i < activeListView->Items->Count; i++) {
      if ( activeListView->Items->Item[i]->Selected && activeListView->Items->Item[i]->Checked ) {
        strncpy(remoteMachineName, activeListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
        // Reset hService
        hService = NULL;
        if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
          if ( (hService = OpenService(hscManager, cfg->ServiceName, SERVICE_ALL_ACCESS)) == NULL ) {
            ShowErrorMessage(remoteMachineName, NULL);
          }
          // First stop the service. We check the return value separately because
          // we don't want an errormessage when the service is already stopped.
          if ( hService) {
            // Find out what executable the service uses
            // We already have the exe name, now derive the ini filename:
            strcpy(tempFileName, "\\\\");
            // Add computer name
            strcat(tempFileName, activeListView->Items->Item[i]->Caption.c_str());
            strcat(tempFileName, "\\");
            // Add exe and path
            strcat(tempFileName, activeListView->Items->Item[i]->SubItems->Strings[lPathIndex].c_str());
            // Remove possible quotes from the name (could happen on existing installs)
            memset(networkPath, 0, sizeof(networkPath));
            for (n = 0, j = 0; j < strlen(tempFileName); j++) {
              if ( tempFileName[j] != '\"' ) {
                networkPath[n] = tempFileName[j];
                n++;
              }
            }
            networkPath[n] = 0;
            strcpy(tempFileName, networkPath);
            // Replace first : by $ to get network name
            for (j = 0; j < strlen(tempFileName); j++) {
              if ( tempFileName[j] == ':' ) {
                tempFileName[j] = '$';
                break;
              }
            }
            // Replace .exe by .ini. This also removes the bootparams part.
            p = strrchr(tempFileName, '.');
            if ( p ) *p = 0;
            strcpy(ExePathName, tempFileName);
            strcpy(IniPathName, tempFileName);
            strcat(IniPathName, ".ini");
            strcat(ExePathName, ".exe");
            // Now stop the service if it runs.
            retVal= RSCC_ControlService(hService, SERVICE_CONTROL_STOP, &serviceStatus, pcfg.writeDebugMessages, remoteMachineName);
            if ( !retVal) {
              errCode = GetLastError();
              if ( errCode != ERROR_SERVICE_NOT_ACTIVE )
                ShowErrorMessage(remoteMachineName, &errCode);
            }
            // Wait until it has stopped
            WaitForServiceToReachStatus(hService, SERVICE_STOPPED, pcfg.MaxWaitTime, remoteMachineName);
            if ( nrOfComputersSelected == 1 ) UpdateStatus(i, false, true, activeListView);
            // Now remove the executable and ini file
            if ( !RSCC_DeleteFile(ExePathName, pcfg.writeDebugMessages) ) {
              strcpy(errStr, "Error deleting old executable on machine: ");
              strcat(errStr, remoteMachineName);
              ShowErrorMessage(errStr, NULL);
            }
            if ( !RSCC_DeleteFile(IniPathName, pcfg.writeDebugMessages) ) {
              strcpy(errStr, "Error deleting old inifile on machine: ");
              strcat(errStr, remoteMachineName);
              ShowErrorMessage(errStr, NULL);
            }
            // Now copy the new files
            if ( !RSCC_CopyFile(cfg->ExeFrom, ExePathName, FALSE, pcfg.writeDebugMessages) )
              ShowErrorMessage(remoteMachineName, NULL);
            if ( !RSCC_CopyFile(cfg->IniFrom, IniPathName, FALSE, pcfg.writeDebugMessages) )
              ShowErrorMessage(remoteMachineName, NULL);
            // Now restart the service
            if ( cfg->StartOnInstall ) {
              if ( !RSCC_StartService(hService, 0, NULL, pcfg.writeDebugMessages, remoteMachineName) )
                ShowErrorMessage(remoteMachineName, NULL);
            }
          }
        } else {
          ShowErrorMessage(remoteMachineName, NULL);
        }
        // Only update status if we got a valid service handle.
        if ( hService && (nrOfComputersSelected == 1) ) {
          if ( cfg->StartOnInstall )
            WaitForServiceToReachStatus(hService, SERVICE_RUNNING, pcfg.MaxWaitTime, remoteMachineName);
          UpdateStatus(i, false, true, activeListView);
        }
        // Now close the service handle and service manager
        if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
        if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
      }
    }
    if ( nrOfComputersSelected > 1 ) UpdateStatus(0, true, true, activeListView);
    Screen->Cursor = crDefault;
  }
}

//------------------------------------------------------------------------------
// Starts the service on the selected computer. The service is assumed to be
// already installed.
//------------------------------------------------------------------------------
void __fastcall TMainForm::StartButtonClick(TObject* Sender)
{
  int i;
  char remoteMachineName[MAX_PATH];
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  // Number of selected computers
  int nrOfComputersSelected = activeListView->SelCount;

  if ( !nrOfComputersSelected ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    Screen->Cursor = crHourGlass;
    for (i = 0; i < activeListView->Items->Count; i++) {
      if ( activeListView->Items->Item[i]->Selected && activeListView->Items->Item[i]->Checked ) {
        strncpy(remoteMachineName, activeListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
        if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
          if ( (hService = OpenService(hscManager, cfg->ServiceName, SERVICE_ALL_ACCESS)) == NULL ) {
            hService = NULL; // Reset hService
            ShowErrorMessage(remoteMachineName, NULL);
          } else { // Service != NULL
            if ( !RSCC_StartService(hService, 0, NULL, pcfg.writeDebugMessages, remoteMachineName) )
              ShowErrorMessage(remoteMachineName, NULL);
            // Show service status
            if ( nrOfComputersSelected == 1 ) {
              UpdateStatus(i, false, false, activeListView);
              WaitForServiceToReachStatus(hService, SERVICE_RUNNING, pcfg.MaxWaitTime, remoteMachineName);
              UpdateStatus(i, false, false, activeListView);
            } else {
              WaitForServiceToReachStatus(hService, SERVICE_RUNNING, pcfg.MaxWaitTime, remoteMachineName);
            }
          }
          if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
          if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
        } else {
          ShowErrorMessage(remoteMachineName, NULL);
        }
      }
    }
    if ( nrOfComputersSelected > 1 ) UpdateStatus(0, true, false, activeListView);
    Screen->Cursor = crDefault;
  }
}

//------------------------------------------------------------------------------
// Stops the service on the selected computer(s)
//------------------------------------------------------------------------------
void __fastcall TMainForm::StopButtonClick(TObject* Sender)
{
  SendStandardSignalToRemoteService(SERVICE_CONTROL_STOP);
}

//------------------------------------------------------------------------------
// Pauses the service on the selected computer(s)
//------------------------------------------------------------------------------
void __fastcall TMainForm::Pauseservice1Click(TObject* Sender)
{
  SendStandardSignalToRemoteService(SERVICE_CONTROL_PAUSE);
}

//------------------------------------------------------------------------------
// Continues the service on the selected computer(s)
//------------------------------------------------------------------------------
void __fastcall TMainForm::Continueservice1Click(TObject* Sender)
{
  SendStandardSignalToRemoteService(SERVICE_CONTROL_CONTINUE);
}

//------------------------------------------------------------------------------
// Tells the service to reload its configuration.
//------------------------------------------------------------------------------
void __fastcall TMainForm::ReloadServiceConfiguration1Click(TObject* Sender)
{
  SendSignalToRemoteService(CLIENT_SERVICE_CONTROL_RESTART);
}

//------------------------------------------------------------------------------
// Tells the client to fetch its input buffers.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Fetch1Click(TObject* Sender)
{
  SendSignalToRemoteService(CLIENT_SERVICE_CONTROL_FETCH);
}

//------------------------------------------------------------------------------
// Tells the client to flush its output buffers.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Flush1Click(TObject* Sender)
{
  SendSignalToRemoteService(CLIENT_SERVICE_CONTROL_FLUSH);
}

//------------------------------------------------------------------------------
// Tells the client to update its buffers.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Update1Click(TObject* Sender)
{
  SendSignalToRemoteService(CLIENT_SERVICE_CONTROL_UPDATE);
}

//------------------------------------------------------------------------------
// Tells the proxy to connect with the main keyserver.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Connect1Click(TObject* Sender)
{
  SendSignalToRemoteService(PROXY_SERVICE_CONTROL_CONNECT);
}

//------------------------------------------------------------------------------
// Triggers a connect with the keyserver for a Locally running proxy only.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Localproxyconnect1Click(TObject* Sender)
{
  HANDLE hEvent;
  LPCSTR szEventName = "ProxyperConnectEvent";
  hEvent = OpenEvent(EVENT_MODIFY_STATE, FALSE, szEventName);
  if ( !hEvent )
    Application->MessageBox("Unable to open the requested event.\nEnsure proxy is running on the local machine.", Application->Title.c_str(), MB_OK);
  else if ( !SetEvent(hEvent) )
    Application->MessageBox("Unable to signal the requested event.\nEnsure proxy is running on the local machine.", Application->Title.c_str(), MB_OK);
}

//------------------------------------------------------------------------------
// Triggers a shutdown for a Locally running proxy only.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Localproxyshutdown1Click(TObject* Sender)
{
  HANDLE hEvent;
  LPCSTR szEventName = "ProxyperShutdownEvent";
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  int i;
  char remoteMachineName[MAX_COMPUTERNAME_LENGTH + 1];
  DWORD remoteMachineNameSize = sizeof(remoteMachineName);

  hEvent = OpenEvent(EVENT_MODIFY_STATE, FALSE, szEventName);
  if ( !hEvent )
    Application->MessageBox("Unable to open the requested event.\nEnsure proxy is running on the local machine.", Application->Title.c_str(), MB_OK);
  else if ( !SetEvent(hEvent) )
    Application->MessageBox("Unable to signal the requested event.\nEnsure proxy is running  on the local machine.", Application->Title.c_str(), MB_OK);
  else { // Update status for the local machine
    if ( !GetComputerName(remoteMachineName, &remoteMachineNameSize) )
      ShowErrorMessage("GetComputerName", NULL);
    else { // Check if the local machine is in the listview, if so, update its status.
      for (i = 0; i < proxyComputersListView->Items->Count; i++) {
        if ( AnsiString(remoteMachineName).LowerCase() == proxyComputersListView->Items->Item[i]->Caption.c_str() ) {
          // Names match, try to connect. We handle errors silently, since here
          // the proxy might not have been installed as a service.
          hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS);
          if ( hscManager ) {
            hService = OpenService(hscManager, proxyData.ServiceName, SERVICE_ALL_ACCESS);
            if ( hService ) {
              WaitForServiceToReachStatus(hService, SERVICE_STOPPED, pcfg.MaxWaitTime, remoteMachineName);
              UpdateStatus(i, false, false, activeListView);
              if ( !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
            }
            if ( !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
          }
        }
      }
    }
  }
}

//------------------------------------------------------------------------------
// Triggers a reload of the configuration for a Locally running proxy only.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Localproxyreload1Click(TObject* Sender)
{
  HANDLE hEvent;
  LPCSTR szEventName = "ProxyperReloadEvent";
  hEvent = OpenEvent(EVENT_MODIFY_STATE, FALSE, szEventName);
  if ( !hEvent )
    Application->MessageBox("Unable to open the requested event.\nEnsure proxy is running on the local machine.", Application->Title.c_str(), MB_OK);
  else if ( !SetEvent(hEvent) )
    Application->MessageBox("Unable to signal the requested event.\nEnsure proxy is running on the local machine.", Application->Title.c_str(), MB_OK);
}

//------------------------------------------------------------------------------
// Sends a standard control code to a remote service.
//------------------------------------------------------------------------------
void __fastcall TMainForm::SendStandardSignalToRemoteService(DWORD dwControl)
{
  int i;
  char remoteMachineName[MAX_PATH];
  bool retVal;
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  SERVICE_STATUS serviceStatus;
  // Number of selected computers
  int nrOfComputersSelected = activeListView->SelCount;
  DWORD endStatus = GetResultingStatusFromControlCode(dwControl);

  if ( !nrOfComputersSelected ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    Screen->Cursor = crHourGlass;
    for (i = 0; i < activeListView->Items->Count; i++) {
      if ( activeListView->Items->Item[i]->Selected && activeListView->Items->Item[i]->Checked ) {
        strncpy(remoteMachineName, activeListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
        if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
          if ( (hService = OpenService(hscManager, cfg->ServiceName, SERVICE_ALL_ACCESS)) == NULL ) {
            hService = NULL; // Reset hService
            ShowErrorMessage(remoteMachineName, NULL);
          } else { // Service != NULL
            retVal = RSCC_ControlService(hService, dwControl, &serviceStatus, pcfg.writeDebugMessages, remoteMachineName);
            if ( !retVal ) ShowErrorMessage(remoteMachineName, NULL);
            // Show service status. We only do this if endStatus != 0.
            if ( nrOfComputersSelected == 1 && retVal && endStatus ) {
              UpdateStatus(i, false, false, activeListView);
              WaitForServiceToReachStatus(hService, endStatus, pcfg.MaxWaitTime, remoteMachineName);
              UpdateStatus(i, false, false, activeListView);
            } else if (retVal && endStatus) {
              WaitForServiceToReachStatus(hService, endStatus, pcfg.MaxWaitTime, remoteMachineName);
            }
          }
          if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
          if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
        } else {
          ShowErrorMessage(remoteMachineName, NULL);
        }
      }
    }
    if ( (nrOfComputersSelected > 1) && retVal && endStatus ) UpdateStatus(0, true, false, activeListView);
    Screen->Cursor = crDefault;
  }
}

//------------------------------------------------------------------------------
// Sends an arbitrary control code to a remote service. If a non-standard code
// is to be sent then this code should be >= 0x80, others are reserved by NT.
// Win2000 has a control code SERVICE_CONTROL_PARAMCHANGE (0x00000006) but we
// do not use this since NT 4 cannot handle this code.
// We also do not wait for the service to reach a status or update the screen.
//------------------------------------------------------------------------------
void __fastcall TMainForm::SendSignalToRemoteService(DWORD dwControl)
{
  int i;
  char remoteMachineName[MAX_PATH];
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  SERVICE_STATUS serviceStatus;

  if ( !activeListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    Screen->Cursor = crHourGlass;
    for (i = 0; i < activeListView->Items->Count; i++) {
      if ( activeListView->Items->Item[i]->Selected && activeListView->Items->Item[i]->Checked ) {
        strncpy(remoteMachineName, activeListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
        if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
          if ( (hService = OpenService(hscManager, cfg->ServiceName, SERVICE_ALL_ACCESS)) == NULL ) {
            hService = NULL; // Reset hService
            ShowErrorMessage(remoteMachineName, NULL);
          } else { // Service != NULL
            if ( !RSCC_ControlService(hService, dwControl, &serviceStatus, pcfg.writeDebugMessages, remoteMachineName) )
              ShowErrorMessage(remoteMachineName, NULL);
            if ( !RSCC_ControlService(hService, CLIENT_SERVICE_CONTROL_CAPSSTAT, &serviceStatus, pcfg.writeDebugMessages, remoteMachineName) )
              ShowErrorMessage(remoteMachineName, NULL);
            // Check if the service did recognize the control code
            if ((dwControl >= 0x80) &&
                (serviceStatus.dwWin32ExitCode == ERROR_SERVICE_SPECIFIC_ERROR) &&
                !CheckResponseFromClient(dwControl, serviceStatus.dwCheckPoint)) {
              AnsiString serviceState = "The service did not recognize command \"" + ControlcodeDescription(dwControl) + "\"";
              Application->MessageBox(serviceState.c_str(), remoteMachineName, MB_OK);
            }
          }
          if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
          if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
        } else {
          ShowErrorMessage(remoteMachineName, NULL);
        }
      }
    }
    Screen->Cursor = crDefault;
  }
}

//------------------------------------------------------------------------------
// Checks the response from the client when dwControl has been sent to it.
// The responsCode should be
// ((X)<<24)+(('M')<<16)+(('o')<<8)+(('o')<<0) "xMoo" where 'X'
// is a bitfield that you can use to determine which commands are
// currently in progress: 1<<(command_number - 0x80). This value
// would be set whenever serviceStatus.dwCurrentState == SERVICE_RUNNING
//------------------------------------------------------------------------------
bool __fastcall TMainForm::CheckResponseFromClient(DWORD dwControl, DWORD responseCode)
{
  // TEMPORARY CODE UNTIL THIS WORKS IN THE CLIENT
  responseCode = ((dwControl - 0x80)<<24)+(('M')<<16)+(('o')<<8)+(('o')<<0);
  // END TEMPORARY CODE

  DWORD response = (responseCode >> 24) + 0x80; // No mask necessary
  bool Moo1 = (char)((responseCode & 0x00FF0000) >> 16) == 'M';
  bool Moo2 = (char)((responseCode & 0x0000FF00) >> 8) == 'o';
  bool Moo3 = (char)(responseCode & 0x000000FF) == 'o';
  return(Moo1 && Moo2 && Moo3 && (response == dwControl));
}

//------------------------------------------------------------------------------
// Returns the string that belongs to a service action.
//------------------------------------------------------------------------------
AnsiString __fastcall TMainForm::ControlcodeDescription(DWORD dwControl)
{
  AnsiString Result;
  switch ( dwControl ) {
    // Standard control codes
    case SERVICE_CONTROL_STOP:
         Result = "SERVICE_CONTROL_STOP";
         break;
    case SERVICE_CONTROL_PAUSE:
         Result = "SERVICE_CONTROL_PAUSE";
         break;
    case SERVICE_CONTROL_CONTINUE:
         Result = "SERVICE_CONTROL_CONTINUE";
         break;
    case SERVICE_CONTROL_INTERROGATE:
         Result = "SERVICE_CONTROL_INTERROGATE";
         break;
    case SERVICE_CONTROL_SHUTDOWN:
         Result = "SERVICE_CONTROL_SHUTDOWN";
         break;
    // Windows 2000 specific code
    case SERVICE_CONTROL_PARAMCHANGE:
         Result = "SERVICE_CONTROL_PARAMCHANGE";
         break;
    // User-defined control codes
    case CLIENT_SERVICE_CONTROL_RESTART:
         Result = "CLIENT_SERVICE_CONTROL_RESTART";
         break;
    case CLIENT_SERVICE_CONTROL_FETCH:
         Result = "CLIENT_SERVICE_CONTROL_FETCH";
         break;
    case CLIENT_SERVICE_CONTROL_FLUSH:
         Result = "CLIENT_SERVICE_CONTROL_FLUSH";
         break;
    case CLIENT_SERVICE_CONTROL_UPDATE:
         if ( pcfg.ServiceToShow == serviceClient )
           Result = "CLIENT_SERVICE_CONTROL_UPDATE";
         else
           Result = "PROXY_SERVICE_CONTROL_CONNECT";
         break;
    case CLIENT_SERVICE_CONTROL_CAPSSTAT:
         Result = "CLIENT_SERVICE_CONTROL_CAPSSTAT";
         break;
    default:
      Result = "Unknown code";
  }
  return Result;
}

//------------------------------------------------------------------------------
// Gets the resulting status code that should result from the action dwControl.
//------------------------------------------------------------------------------
DWORD __fastcall TMainForm::GetResultingStatusFromControlCode(DWORD dwControl)
{
  switch ( dwControl ) {
    // Standard control codes
    case SERVICE_CONTROL_STOP:
         return SERVICE_STOPPED;
    case SERVICE_CONTROL_PAUSE:
         return SERVICE_PAUSED;
    case SERVICE_CONTROL_CONTINUE:
         return SERVICE_RUNNING;
    case SERVICE_CONTROL_INTERROGATE:
         return 0;
    case SERVICE_CONTROL_SHUTDOWN:
         return SERVICE_STOPPED;
    // Windows 2000 specific code
    case SERVICE_CONTROL_PARAMCHANGE:
         return 0;
    default:
      return 0;
    }
}

//------------------------------------------------------------------------------
// Shows the add computer form where a name can be entered.
//------------------------------------------------------------------------------
void __fastcall TMainForm::AddPCButtonClick(TObject* Sender)
{
  TListItem* L;
  bool addAnyWay = true; // Add a non-NT machine if add only NT machines is selected?
  // Declaring the following bools static should not be necessary; however, if
  // they are not declared static, their value will be reset to 0 and manual adding
  // computers will fail in a release version of the program (the debug version
  // works OK). Why this is so escapes me. Compiler bug?
  static bool addToClients = true;
  static bool addToProxies = true;
  char newName[MAX_COMPUTERNAME_LENGTH + 1];
  TModalResult mrRes;
  TAddComputerForm* AddComputerForm;

  memset(newName, 0, sizeof(newName));
  AddComputerForm = new TAddComputerForm(this, newName, sizeof(newName), &addToClients, &addToProxies);
  if ( AddComputerForm ) {
    mrRes = AddComputerForm->ShowModal();
    if ( (mrRes == mrOk) && (addToClients || addToProxies) ) {
      // See if it is an NT machine if we want to add only NT machines
      if (pcfg.addOnlyNTMachines) {
        if (GetRemotePlatformType(newName) < 2000) {
          if (Application->MessageBox("This machine appears not to be running windows NT or 2000, add anyway?", Application->Title.c_str(), MB_YESNO | MB_ICONWARNING) == ID_NO) {
            addAnyWay = false;
          }
        }
      }
      if ( addAnyWay ) {
        if ( addToClients && !NameIsDouble(newName, clientComputersListView) ) {
          // This prevents errors with indices
          clientComputersListView->SortType = stNone;
          // Computername in listitem
          L = clientComputersListView->Items->Add();
          L->Caption = AnsiString(newName);
          // Empty subitem for status
          L->SubItems->Add("");
          // Empty subitem for service path
          L->SubItems->Add("");
          // Add subitem for client version
          L->SubItems->Add("");
          // Add subitem for email address
          L->SubItems->Add("");
          // We check the new computer after adding
          L->Checked = true;
          // Update the status
          UpdateStatus(clientComputersListView->Items->IndexOf(L), false, true, clientComputersListView);
        }
        if ( addToProxies && !NameIsDouble(newName, proxyComputersListView) ) {
          proxyComputersListView->SortType = stNone;
          // Computername in listitem
          L = proxyComputersListView->Items->Add();
          L->Caption = AnsiString(newName);
          // Empty subitem for status
          L->SubItems->Add("");
          // Empty subitem for service path
          L->SubItems->Add("");
          // Add subitem for client version
          L->SubItems->Add("");
          // Add subitem for email address
          L->SubItems->Add("");
          // We check the new computer after adding
          L->Checked = true;
          // Update the status
          UpdateStatus(proxyComputersListView->Items->IndexOf(L), false, true, proxyComputersListView);
        }
      }
    }
  }
  // Store the names in the configuration
  StoreComputerNames();
}

//------------------------------------------------------------------------------
// Returns true if a name already exists in the list, otherwise false.
//------------------------------------------------------------------------------
bool __fastcall TMainForm::NameIsDouble(const char* name, TListView* view)
{
  int i;
  AnsiString temp = LowerCase(name);

  for (i = 0; i < view->Items->Count; i++) {
    if (temp == LowerCase(view->Items->Item[i]->Caption))
      return true;
  }
  return false;
}

//------------------------------------------------------------------------------
// Removes the selected PC from the list.
//------------------------------------------------------------------------------
void __fastcall TMainForm::RemPCButtonClick(TObject* Sender)
{
  int i;

  for(i = 0; i < activeListView->Items->Count; i++) {
    if ( activeListView->Items->Item[i]->Selected ) {
      activeListView->Items->Item[i]->SubItems->Delete(lEmailIndex); // Delete client email
      activeListView->Items->Item[i]->SubItems->Delete(lVersionIndex); // Delete client version number
      activeListView->Items->Item[i]->SubItems->Delete(lPathIndex); // Delete service path
      activeListView->Items->Item[i]->SubItems->Delete(lStatusIndex); // Delete statusline
      activeListView->Items->Delete(i);                    // Delete computername
      // Go back since the ListBox count has now decreased
      i--;
    }
  }
  // Store the names in the configuration
  StoreComputerNames();
}

//------------------------------------------------------------------------------
// Get the status of the selected computer
//------------------------------------------------------------------------------
void __fastcall TMainForm::ConfigButtonClick(TObject* Sender)
{
  int i;
  char buffer[2048];
  char remoteMachineName[MAX_PATH];
  // Config params
  DWORD dwServiceType;
  DWORD dwStartType;
  char lpBinaryPathName[MAX_PATH];
  char lpServiceStartName[MAX_PATH];
  char lpDisplayName[MAX_PATH];
  char* lpServiceAccountName1;
  char* lpPassword1;
  DWORD bytesNeeded;
  TConfigForm* ConfigForm;
  bool doChangeConfig = false; // Is set to true when the config should be changed
  bool canChangeConfig; // Is set to false when we can't change the config
  ChangeServiceConfigData serviceConfigData;
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  char dependencies[7];

  // Set dependency to TCP/IP service
  memset(dependencies, 0, sizeof(dependencies));
  strcpy(dependencies, "Tcpip");

  if ( !activeListView->SelCount ) {
    Application->MessageBox("No computers are selected.", Application->Title.c_str(), MB_OK);
  } else {
    for (i = 0; i < activeListView->Items->Count; i++) {
      if ( activeListView->Items->Item[i]->Selected && activeListView->Items->Item[i]->Checked ) {
        strncpy(remoteMachineName, activeListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
        Screen->Cursor = crHourGlass;
        if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) == 0 ) {
          // We can't get SC_MANAGER_ALL_ACCESS, try SC_MANAGER_CONNECT for read only access.
          canChangeConfig = false;
          if ( (hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_CONNECT)) == 0 ) {
            // Set it explicitly to NULL since the RSCC_OpenSCManager doesn't reset ir if it fails.
            hscManager = NULL;
          }
        } else canChangeConfig = true;
        if ( hscManager ) {
          if ( canChangeConfig ) { // Try to get a service handle with ALL_ACCESS
            if ( (hService = OpenService(hscManager, cfg->ServiceName, SERVICE_ALL_ACCESS)) == NULL )
              hService = NULL; // Reset value. This is necessary since the OpenService calls does not reset it if it fails.
          } else { // Try to get a read-only service handle.
            if ( (hService = OpenService(hscManager, cfg->ServiceName, SERVICE_QUERY_CONFIG)) == NULL )
              hService = NULL;
          }
          if ( hService ) {
            memset(serviceConfigData.lpPassword, 0, sizeof(serviceConfigData.lpPassword));
            QueryServiceConfig(hService, (QUERY_SERVICE_CONFIG*)buffer, sizeof(buffer), &bytesNeeded);
            // Save the data
            dwServiceType = ((QUERY_SERVICE_CONFIG*)buffer)->dwServiceType;
            dwStartType = ((QUERY_SERVICE_CONFIG*)buffer)->dwStartType;
            strcpy(lpBinaryPathName, ((QUERY_SERVICE_CONFIG*)buffer)->lpBinaryPathName);
            strcpy(lpServiceStartName, ((QUERY_SERVICE_CONFIG*)buffer)->lpServiceStartName);
            strcpy(lpDisplayName, ((QUERY_SERVICE_CONFIG*)buffer)->lpDisplayName);
            // Show configurationform
            ConfigForm = new TConfigForm(this,
                                         canChangeConfig,
                                         dwServiceType,
                                         dwStartType,
                                         lpBinaryPathName,
                                         lpServiceStartName,
                                         lpDisplayName,
                                         remoteMachineName,
                                         &doChangeConfig,
                                         &serviceConfigData);
            if ( ConfigForm ) {
              ConfigForm->ShowModal();
              delete ConfigForm;
            } else {
              ShowErrorMessage("Error creating form", NULL);
            }
            if ( doChangeConfig ) {
              // Check account data. NULL means no change in account.
              if ( strlen(serviceConfigData.lpServiceStartName) > 0 )
                lpServiceAccountName1 = serviceConfigData.lpServiceStartName;
              else
                lpServiceAccountName1 = NULL;
              // Check password data. NULL means no change.
              if ( strlen(serviceConfigData.lpPassword) > 0 )
                lpPassword1 = serviceConfigData.lpPassword;
              else if ( lpServiceAccountName1 )
                lpPassword1 = ""; // Empty password, we can't use NULL here
              else
                lpPassword1 = NULL;
              // Change the config
              if ( !ChangeServiceConfig(hService,
                                        serviceConfigData.dwServiceType,
                                        serviceConfigData.dwStartType,
                                        serviceConfigData.dwErrorControl,
                                        serviceConfigData.lpBinaryPathName,
                                        NULL, NULL, (LPCTSTR)dependencies,
                                        lpServiceAccountName1,
                                        lpPassword1,
                                        serviceConfigData.lpDisplayName) )
                ShowErrorMessage(remoteMachineName, NULL);
              // Show if something has changed
              UpdateStatus(i, false, false, activeListView);
            }
            Screen->Cursor = crDefault;
          } else {
            Screen->Cursor = crDefault;
            ShowErrorMessage(remoteMachineName, NULL);
          }
          if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
          if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
        } else {
          ShowErrorMessage(remoteMachineName, NULL);
        }
      }
    }
  }
  Screen->Cursor = crDefault;
}

//------------------------------------------------------------------------------
// Edit the inifile on the selected remote computer(s)
//------------------------------------------------------------------------------
void __fastcall TMainForm::EditIniButtonClick(TObject* Sender)
{
  int i;
  unsigned int  j, k, n;
  char* p;
  char iniFileName[MAX_PATH], tempFileName[MAX_PATH], tempFileName2[MAX_PATH];
  char errMsg[MAX_PATH + 16];
  TEditForm* EditForm;

  if ( !activeListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    for (i = 0; i < activeListView->Items->Count; i++) {
      if ( activeListView->Items->Item[i]->Selected && activeListView->Items->Item[i]->Checked ) {
        // We already have the exe name, now derive the ini filename:
        strncpy(tempFileName, activeListView->Items->Item[i]->SubItems->Strings[lPathIndex].c_str(), sizeof(tempFileName) - 1);
        // Make filename lowercase
        for (k = 0; k < strlen(tempFileName); k++) tempFileName[k] = (char)tolower(tempFileName[k]);
        // Remove possible quotes from the name (could happen on existing installs)
        memset(tempFileName2, 0, sizeof(tempFileName2));
        for (n = 0, k = 0; k < strlen(tempFileName); k++) {
          if ( tempFileName[k] != '\"' ) {
            tempFileName2[n] = tempFileName[k];
            n++;
          }
        }
        strcpy(iniFileName, "\\\\");
        // Add computer name
        strcat(iniFileName, activeListView->Items->Item[i]->Caption.c_str());
        strcat(iniFileName, "\\");
        // Add filename part
        strcat(iniFileName, tempFileName2);
        // Replace .exe by .ini. This also removes the bootparams part.
        p = strrchr(iniFileName, '.');
        if ( p ) *p = 0;
        strcat(iniFileName, ".ini");
        // Replace first : by $ to get network name
        for (j = 0; j < strlen(iniFileName); j++) {
          if ( iniFileName[j] == ':' ) {
            iniFileName[j] = '$';
            break;
          }
        }
        if ( FileExists(iniFileName) ) {
          EditForm = new TEditForm(this, iniFileName);
          if ( EditForm ) {
            EditForm->ShowModal();
            delete EditForm;
          }
        } else {
          // Only warn if the service manager is present, the service is
          // installed and we STILL can't open the inifile.
          if ( IsServiceInstalled(activeListView->Items->Item[i]->Caption.c_str()) &&
                IsServiceManagerInstalled(activeListView->Items->Item[i]->Caption.c_str()) ) {
            strcpy(errMsg, "File not found: ");
            strcat(errMsg, iniFileName);
            Application->MessageBox(errMsg, Application->Title.c_str(), MB_OK);
          }
        }
      }
    }
  }
}

//------------------------------------------------------------------------------
// Update the status information for all computers which are checked for the
// active listview.
//------------------------------------------------------------------------------
void __fastcall TMainForm::UpdateButtonClick(TObject* Sender)
{
  UpdateStatus(0, true, true, activeListView);
}

//------------------------------------------------------------------------------
//Creates and shows the settings form
//------------------------------------------------------------------------------
void __fastcall TMainForm::DefaultButtonClick(TObject* Sender)
{
  TDefaultsForm* DefaultsForm = new TDefaultsForm(this, cfg);
  if ( DefaultsForm ) {
    DefaultsForm->ShowModal();
    delete DefaultsForm;
  }
  // Adapt listview captions if required
  if ( strcmp(clientData.DestinationKey, "id") )
    clientComputersListView->Columns->Items[lEmailIndex + 1]->Caption = clientData.DestinationKey;
  else
    clientComputersListView->Columns->Items[lEmailIndex + 1]->Caption = "Email";
  // Caption of the the last proxy listview column
  proxyComputersListView->Columns->Items[lEmailIndex + 1]->Caption = proxyData.DestinationKey;
}

//------------------------------------------------------------------------------
// Add (new) network computers
//------------------------------------------------------------------------------
void __fastcall TMainForm::NetworkButtonClick(TObject* Sender)
{
  int i;
  int initialClientCount = clientComputersListView->Items->Count;
  int initialProxyCount  = proxyComputersListView->Items->Count;

  GetNetworkComputerNames(false, false);
  // See which client checkboxes need to be checked
  for (i = initialClientCount; i < clientComputersListView->Items->Count; i++) {
    if ( ProgramSettingsFile->ReadInteger(ComputerNamesIniSection, clientComputersListView->Items->Item[i]->Caption, 0) == 1 )
      clientComputersListView->Items->Item[i]->Checked = true;
  }
  // See which proxy checkboxes need to be checked
  for (i = initialProxyCount; i < proxyComputersListView->Items->Count; i++) {
    if ( ProgramSettingsFile->ReadInteger(ProxyComputerNamesIniSection, proxyComputersListView->Items->Item[i]->Caption, 0) == 1 )
      proxyComputersListView->Items->Item[i]->Checked = true;
  }
}

//------------------------------------------------------------------------------
// Edit the use account under which the program tries to run
//------------------------------------------------------------------------------
void __fastcall TMainForm::SwitchAccountButtonClick(TObject* Sender)
{
  char* domainName;
  bool Change = false;  

  TAccountForm* AccountForm = new TAccountForm(this,
                                               pcfg.Username,
                                               pcfg.Domain,
                                               pcfg.Password,
                                               sizeof(pcfg.Username),
                                               sizeof(pcfg.Domain),
                                               sizeof(pcfg.Password),
                                               &pcfg.SwitchUserID,
                                               &Change);
  if ( AccountForm ) {
    AccountForm->ShowModal();
    delete AccountForm;
  }
  if ( Change ) {
    // Drop priviliges
    if (hToken && !CloseHandle(hToken) ) ShowErrorMessage("CloseHandle", NULL);
    if ( pcfg.SwitchUserID && !RevertToSelf() ) ShowErrorMessage("RevertToSelf", NULL);
    // Domain name need not be specified
    if ( pcfg.Domain && strlen(pcfg.Domain) ) domainName = pcfg.Domain;
    else domainName = NULL;

    // The SE_TCB_NAME privilige is required for this call to work.
    if ( !LogonUser(pcfg.Username, domainName, pcfg.Password,
                    LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, &hToken) )
      ShowErrorMessage("LogonUser", NULL);

    if ( hToken ) {
      if ( !ImpersonateLoggedOnUser(hToken) ) {
        ShowErrorMessage("ImpersonateLoggedOnUser", NULL);
      } else
        UpdateStatus(0, true, true, activeListView);
    }
  }
}

//------------------------------------------------------------------------------
// Show the helpform
//------------------------------------------------------------------------------
void __fastcall TMainForm::HelpButtonClick(TObject* Sender)
{
  THelpForm* HelpForm = new THelpForm(this);
  if ( HelpForm ) {
    HelpForm->ShowModal();
    delete HelpForm;
  }
}

//------------------------------------------------------------------------------
// Show program information
//------------------------------------------------------------------------------
void __fastcall TMainForm::AboutButtonClick(TObject* Sender)
{
  AboutForm->ShowModal();
}

//------------------------------------------------------------------------------
// See which computer is selected, store this in the computername menuitem caption.
//------------------------------------------------------------------------------
void __fastcall TMainForm::ComputersListViewMouseDown(TObject* Sender, TMouseButton Button, TShiftState Shift, int X, int Y)
{
  // Find the computer on which the mouse button was downed
  CurrActiveItem = activeListView->GetItemAt(X, Y);
  // Store this in the popup menu upper caption.
  if ( CurrActiveItem )
    Computername1->Caption = CurrActiveItem->Caption;
  else
    Computername1->Caption = "No computer selected";
}

//------------------------------------------------------------------------------
// Adapt the listbox: select ONLY the computer that is clicked on so all
// methods only work on this one.
//------------------------------------------------------------------------------
void __fastcall TMainForm::RsccPopupMenuPopup(TObject* Sender)
{
  int i;
  bool found = false;
  // Find out which computer is clicked on and select only that item
  for (i = 0; i < activeListView->Items->Count; i++) {
    if ( activeListView->Items->Item[i]->Caption != Computername1->Caption )
      activeListView->Items->Item[i]->Selected = false;
    else {
      activeListView->Items->Item[i]->Selected = true;
      found = true; // Fount at least one match
      break;
    }
  }
  // No computers selected
  if ( !found || !activeListView->Items->Item[i]->Checked ) {
    Installservice2->Enabled = false;
    Removeservice2->Enabled = false;
    Reinstallservice2->Enabled = false;
    Updateservice2->Enabled = false;
    Startservice2->Enabled = false;
    Stopservice2->Enabled = false;
    ReloadServiceConfiguration2->Enabled = false;
    Client2->Enabled = false;
    Proxy2->Enabled = false;
    Configureservice2->Enabled = false;
    EditIni2->Enabled = false;
    Logfile2->Enabled = false;
  // No service manager found
  } else if ( !IsServiceManagerInstalled(Computername1->Caption.c_str()) ) {
    Installservice2->Enabled = false;
    Removeservice2->Enabled = false;
    Reinstallservice2->Enabled = false;
    Updateservice2->Enabled = false;
    Startservice2->Enabled = false;
    Stopservice2->Enabled = false;
    ReloadServiceConfiguration2->Enabled = false;
    Client2->Enabled = false;
    Proxy2->Enabled = false;
    Configureservice2->Enabled = false;
    EditIni2->Enabled = false;
    Logfile2->Enabled = false;
  } else {
    // Not installed
    if ( !IsServiceInstalled(Computername1->Caption.c_str()) ) {
      Installservice2->Enabled = true;
      Removeservice2->Enabled = false;
      Reinstallservice2->Enabled = false;
      Updateservice2->Enabled = false;
      Startservice2->Enabled = false;
      Stopservice2->Enabled = false;
      ReloadServiceConfiguration2->Enabled = false;
      Client2->Enabled = false;
      Proxy2->Enabled = false;
      Configureservice2->Enabled = false;
      EditIni2->Enabled = false;
      Logfile2->Enabled = false;
    // Installed but not running
    } else if ( !IsServiceRunning(Computername1->Caption.c_str()) ) {
      Installservice2->Enabled = false;
      Removeservice2->Enabled = true;
      Reinstallservice2->Enabled = true;
      Updateservice2->Enabled = true;
      Startservice2->Enabled = true;
      Stopservice2->Enabled = false;
      ReloadServiceConfiguration2->Enabled = false;
      Client2->Enabled = false;
      Proxy2->Enabled = false;
      Configureservice2->Enabled = true;
      EditIni2->Enabled = true;
      Logfile2->Enabled = true;
    // Instaled and running
    } else {
      Installservice2->Enabled = false;
      Removeservice2->Enabled = true;
      Reinstallservice2->Enabled = true;
      Updateservice2->Enabled = true;
      Startservice2->Enabled = false;
      Stopservice2->Enabled = true;
      ReloadServiceConfiguration2->Enabled = true;
      Client2->Enabled = ClientRadioButton->Checked;
      Proxy2->Enabled = PerProxyRadioButton->Checked;
      Configureservice2->Enabled = true;
      EditIni2->Enabled = true;
      Logfile2->Enabled = true;
    }
  }
}

//------------------------------------------------------------------------------
// Sort the list depending on which column is clicked
//------------------------------------------------------------------------------
void __fastcall TMainForm::clientComputersListViewColumnClick(TObject* Sender, TListColumn* Column)
{
  ColumnClicked = Column->Index;
  // Set to stNone to assure that the sorting routine will be called
  clientComputersListView->SortType = stNone;
  clientComputersListView->SortType = stText;
}

//------------------------------------------------------------------------------
// Sort the list depending on which column is clicked
//------------------------------------------------------------------------------
void __fastcall TMainForm::proxyComputersListViewColumnClick(TObject* Sender, TListColumn* Column)
{
  ColumnClicked = Column->Index;
  // Set to stNone to assure that the sorting routine will be called
  proxyComputersListView->SortType = stNone;
  proxyComputersListView->SortType = stText;
}

//------------------------------------------------------------------------------
// Compare 2 listview items
//------------------------------------------------------------------------------
void __fastcall TMainForm::ComputersListViewCompare(TObject* Sender, TListItem* Item1, TListItem* Item2, int Data, int& Compare)
{
  AnsiString s1, s2;

  // Alphabetical sorting
  if ( !ColumnClicked )
    Compare = strcmp(Item1->Caption.c_str(), Item2->Caption.c_str());
  else {
    s1 = Item1->SubItems->Strings[ColumnClicked - 1];
    s2 = Item2->SubItems->Strings[ColumnClicked - 1];
    Compare = strcmp(s1.c_str(), s2.c_str());
  }
}

//------------------------------------------------------------------------------
// Shows the logfile.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Logfile1Click(TObject* Sender)
{
  int i;
  unsigned int  j, k, n;
  char* p;
  char iniFileName[MAX_PATH], tempFileName[MAX_PATH], tempFileName2[MAX_PATH];
  char errMsg[MAX_PATH + 16];
  TIniFile* serviceIniFile;
  TViewLogFileForm* ViewLogFileForm;
  TViewLogFileForm* l;
  bool logFileDefined = true;  // Set to false if the inifile defined no logfile.
  AnsiString LogFileName = ""; // Logfile name
  AnsiString path = "";        // Path to logfile
  AnsiString proxyLogfileRotation = "startup";
  SYSTEMTIME timeStruct;
  char tempYear[8], tempMonth[8], tempDay[8], tempHour[8];
  char rc5ActiveIniSection[32];

  strcpy(rc5ActiveIniSection, "rc5");
  // For RC5-64 no "-" was written in the logfile
  if ( !((pcfg.activeRC5Challenge.c_str()[0] == '6') && (pcfg.activeRC5Challenge.c_str()[1] == '4')))
    strcat(rc5ActiveIniSection, "-");
  strcat(rc5ActiveIniSection, pcfg.activeRC5Challenge.c_str());

  if ( !activeListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    for (i = 0; i < activeListView->Items->Count; i++) {
      // We only try to find logfiles if the computer is both selected AND checked.
      if ( activeListView->Items->Item[i]->Selected && activeListView->Items->Item[i]->Checked ) {
        // We already have the exe name, now derive the ini filename:
        strncpy(tempFileName, activeListView->Items->Item[i]->SubItems->Strings[lPathIndex].c_str(), sizeof(tempFileName) - 1);
        // Make filename lowercase
        for (k = 0; k < strlen(tempFileName); k++) tempFileName[k] = (char)tolower(tempFileName[k]);
        // Remove possible quotes from the name (could happen on existing installs)
        memset(tempFileName2, 0, sizeof(tempFileName2));
        for (n = 0, k = 0; k < strlen(tempFileName); k++) {
          if ( tempFileName[k] != '\"' ) {
            tempFileName2[n] = tempFileName[k];
            n++;
          }
        }
        strcpy(iniFileName, "\\\\");
        // Add computer name
        strcat(iniFileName, activeListView->Items->Item[i]->Caption.c_str());
        strcat(iniFileName, "\\");
        // Add filename part
        strcat(iniFileName, tempFileName2);
        // Replace .exe by .ini. This also removes the bootparams part.
        p = strrchr(iniFileName, '.');
        if ( p ) *p = 0;
        strcat(iniFileName, ".ini");
        // Replace first : by $ to get network name
        for (j = 0; j < strlen(iniFileName); j++) {
          if ( iniFileName[j] == ':' ) {
            iniFileName[j] = '$';
            break;
          }
        }
        if ( FileExists(iniFileName) ) { // Find the logfile
          GetSystemTime(&timeStruct); // Get time in UTC
          sprintf(tempYear, "%04d", timeStruct.wYear);
          sprintf(tempMonth, "%02d", timeStruct.wMonth);
          sprintf(tempDay, "%02d", timeStruct.wDay);
          sprintf(tempHour, "%02d", timeStruct.wHour);
          // Obtain the filepath
          path = ExtractFilePath(iniFileName);
          // Make inifile to read the name of the logfile.
          serviceIniFile = new TIniFile(iniFileName);
          if ( serviceIniFile ) {
            // Now make the distinction between clients and proxies since they log different:
            if ( pcfg.ServiceToShow == serviceProxy ) { // personal proxy
              // See which logfile we want to see, and how the rotation is handled.
              if ( pcfg.whichProxyLogFile == conLogFile ) {
                LogFileName = serviceIniFile->ReadString("console", "logfileconsole", "");
                proxyLogfileRotation = serviceIniFile->ReadString("console", "logfileconsolerotation", "");
              }
              else if ( pcfg.whichProxyLogFile == rc5LogFile ) {
                LogFileName = serviceIniFile->ReadString(rc5ActiveIniSection, "logfilekeyblock", "");
                proxyLogfileRotation = serviceIniFile->ReadString(rc5ActiveIniSection, "logfilekeyblockrotation", "");
              }
              else if ( pcfg.whichProxyLogFile == ogrLogFile ) {
                LogFileName = serviceIniFile->ReadString("ogr", "logfilekeyblock", "");
                proxyLogfileRotation = serviceIniFile->ReadString("ogr", "logfilekeyblockrotation", "");
              }
              else if ( pcfg.whichProxyLogFile == ogrp2LogFile ) {
                LogFileName = serviceIniFile->ReadString("ogrp2", "logfilekeyblock", "");
                proxyLogfileRotation = serviceIniFile->ReadString("ogrp2", "logfilekeyblockrotation", "");
              }
              else if ( pcfg.whichProxyLogFile == ogrngLogFile ) {
                LogFileName = serviceIniFile->ReadString("ogrng", "logfilekeyblock", "");
                proxyLogfileRotation = serviceIniFile->ReadString("ogrng", "logfilekeyblockrotation", "");
              }
              if ( LogFileName == "" ) {
                Application->MessageBox("No logfile defined in proxy inifile.", Application->Title.c_str(), MB_OK);
                logFileDefined = false;
              }
              // Get the logfile name expansions.
              if ( proxyLogfileRotation == "yearly" ) {
                LogFileName = LogFileName + AnsiString(tempYear) + ".log";
              } else if ( proxyLogfileRotation == "monthly" ) {
                LogFileName = LogFileName + AnsiString(tempYear) + AnsiString(tempMonth) + ".log";
              } else if ( proxyLogfileRotation == "daily" ) {
                LogFileName = LogFileName + AnsiString(tempYear) + AnsiString(tempMonth) + AnsiString(tempDay) + ".log";
              } else if ( proxyLogfileRotation == "hourly" ) {
                LogFileName = LogFileName + AnsiString(tempYear) + AnsiString(tempMonth) + AnsiString(tempDay) + "-" + AnsiString(tempHour) + ".log";
              }
              // Add the path to get the full filename and path. But only if the
              // LogfileName is not an UNC path
              if ( strncmp(LogFileName.c_str(), "\\\\", 2) ) {
                LogFileName = path + LogFileName;
              }
            } else if ( pcfg.ServiceToShow == serviceClient ) { // Client
              LogFileName = FindClientLogfileName(serviceIniFile, iniFileName, &logFileDefined);
            }
            delete serviceIniFile;
          }
          // Show the logfile on a separate screen
          if ( logFileDefined ) {
            if ( FileExists(LogFileName) ) {
              l = CheckForDoubleFile(LogFileName);
              if ( !l ) {
                ViewLogFileForm = new TViewLogFileForm(
                        this,
                        LogFileName,
                        1000 * pcfg.LogRefreshTime, // milliseconds
                        pcfg.autoRefreshLogs,
                        ((pcfg.whichProxyLogFile == conLogFile) && (pcfg.ServiceToShow == serviceProxy)),
                        pcfg.activeRC5Challenge);
                if ( ViewLogFileForm ) {
                  // Add new window to child list for closing and deleting on app termination
                  AddNode(viewLogFilesChildren, ViewLogFileForm, LogFileName);
                  // Set main form for beeing able to call SendMessage there
                  ViewLogFileForm->mainForm = this;
                  // Show the window non-modal
                  ViewLogFileForm->Show();
                }
              } else {
                if ( l->WindowState == wsMinimized ) l->WindowState = wsNormal;
                l->SetFocus();
              }
            } else {
              AnsiString errorMsg = "Could not find logfile " + LogFileName;
              Application->MessageBox(errorMsg.c_str(), Application->Title.c_str(), MB_OK);
            }
          }
        } else {
          // Only warn if the service manager is present, the service is
          // installed and we STILL can't open the inifile.
          if ( IsServiceInstalled(activeListView->Items->Item[i]->Caption.c_str()) &&
               IsServiceManagerInstalled(activeListView->Items->Item[i]->Caption.c_str()) ) {
            strcpy(errMsg, "Service inifile not found: ");
            strcat(errMsg, iniFileName);
            Application->MessageBox(errMsg, Application->Title.c_str(), MB_OK);
           }
        }
      }
    }
  }
}

//------------------------------------------------------------------------------
// Finds the name of a client logfile. Code in this function is token and
// adapted from Logstuff.cpp from the client source, thanks to Cyrus Patel.
//
// - If the rotation period is monthly, or the number of days between
//   rotations is >= 28 && <= 31, then the log filename is
//   <prefix><YY><monthname>.log (where <YY> is the last two
//   digits of the year, '99', '00' etc, and <monthname> is
//   "jan", "feb" etc)
// - If the rotation period is yearly/annually, or number of days
//   between rotations is 365, then the log filename is
//   <prefix><year>.log (where <year> is '1999', '2000' etc)
// - If the rotation period is weekly, or the number of days
//   between rotations is 7, then the log filename is
//   <prefix><YY>w<WW> (where <YY> is '99','00' etc, and <WW>
//   is the week-of-the-year (eg, Jan 1-7 == week 1)
// - For all other periods, the log filename is
//   <prefix><YYMMDD>.log (where YYMMDD is the two digit year,
//   two digit month, two digit day)
//
// When parsing the "period" string from the .ini, only the first letter is
// checked, ie "m" for monthly, "d" for daily, "y" for yearly, "w" for weekly
// etc. ("an" is also accepted for yearly).
//
// For periodic logfiles, the period is determined from:
// a) convert today's date to jdn_today
// b) jdn_period_start = jdn_today - (jdn_today % interval)
// c) convert jdn_period_start to a date.
//------------------------------------------------------------------------------
AnsiString __fastcall TMainForm::FindClientLogfileName(TIniFile* clientIniFile, char iniFileName[], bool* logFileDefined)
{
  AnsiString LogFileBaseName = "", LogFileName = "";
  AnsiString clientLogfileRotation = "";
  AnsiString logfileLimitStr = "";
  int logfileLimit;
  char datePartOfLogFileName[MAX_PATH];
  TSearchRec filerec;

  if ( clientIniFile ) {
    LogFileBaseName = clientIniFile->ReadString("logging", "log-file", "");
    clientLogfileRotation = clientIniFile->ReadString("logging", "log-file-type", "");
    logfileLimitStr = clientIniFile->ReadString("logging", "log-file-limit", "");
    logfileLimit = StrToIntDef(logfileLimitStr, -1); // Try to get the number of days entered
    if ( logfileLimitStr.Length() && logfileLimit == -1 ) { // Conversion failed, so limit was not entered as a number
      if ( logfileLimitStr[1] == 'm' )
        logfileLimit = 30;
      else if ( logfileLimitStr[1] == 'y' )
        logfileLimit = 365;
      else if ((logfileLimitStr.Length() >= 2) && (logfileLimitStr[1] == 'a') && (logfileLimitStr[2] == 'n'))
        logfileLimit = 365;
      else if ( logfileLimitStr[1] == 'w' )
        logfileLimit = 7;
      else
        logfileLimit = 1; // Default if no valid value is entered
    }
  }
  if (clientLogfileRotation == "rotate") {
    LogFileBaseName = ExtractFilePath(iniFileName) + LogFileBaseName;
  } else if ((LogFileBaseName == "") || (clientLogfileRotation == "none")) {
    Application->MessageBox("No logfile defined in client inifile.", Application->Title.c_str(), MB_OK);
    *logFileDefined = false;
  } else {
    LogFileBaseName = ExtractFilePath(iniFileName) + LogFileBaseName;
  }
  // Expand logfile name.
  if ( clientLogfileRotation == "rotate" ) {
    int tm_year = 0, tm_mon = 0, tm_mday = 0, tm_yday = 0;
    if (logfileLimit > 0 ) {
      time_t ttime = time(NULL);
      struct tm* currtm = localtime(&ttime);
      if (currtm) {
        if (currtm->tm_mon  >= 0  && currtm->tm_mon  < 12 &&
            currtm->tm_year >= 70 && currtm->tm_year <= (9999-1900) &&
            currtm->tm_mday >= 1  && currtm->tm_mday <= 31 &&
            currtm->tm_yday >= 0  && currtm->tm_yday <= 366) {
          tm_year = currtm->tm_year; // years since 1900
          tm_mon  = currtm->tm_mon;  // months since January [0,11]
          tm_mday = currtm->tm_mday; // day of the month [1,31]
          tm_yday = currtm->tm_yday; // days since January 1 [0, 365]
        }
      }
    }
    if (tm_mday != 0) {
      if ( logfileLimit >= 28 && logfileLimit <= 31 ) { // monthly
        static const char* monnames[] = { "jan","feb","mar","apr","may","jun", "jul","aug","sep","oct","nov","dec" };
        sprintf(datePartOfLogFileName, "%02d%s.log", (tm_year%100), monnames[tm_mon]);
        LogFileName = LogFileBaseName + datePartOfLogFileName;
      }
      else if (logfileLimit == 365 ) { // annually
        sprintf(datePartOfLogFileName, "%04d.log", tm_year + 1900);
        LogFileName = LogFileBaseName + datePartOfLogFileName;
      }
      else if (logfileLimit == 7 ) { // weekly
        // we intentionally don't use tm_wday. Technically, week 1 is the first
        // week with a monday in it, but we don't care about that here.
        sprintf(datePartOfLogFileName, "%02dw%02d.log", (tm_year%100), (tm_yday+1+6)/7);
        LogFileName = LogFileBaseName + datePartOfLogFileName;
      }
      else { // anything else: daily = 1, fortnightly = 14 etc
        int year  = tm_year + 1900;
        int month = tm_mon + 1;
        int day   = tm_mday;
        if (logfileLimit > 1) { // not daily - so date stamp may be in the
                                // past. Use jdn to move back to that date.
          // What is 'jdn'?: Julian Day Numbers (JDN) are used by
          // astronomers as a date/time measure independent of calendars and
          // convenient for computing the elapsed time between dates.  The JDN
          // for any date/time is the number of days (including fractional
          // days) elapsed since noon, 1 Jan 4713 BC.  Julian Day Numbers were
          // originated by Joseph Justus Scaliger (1540-1609) in 1582 and named
          // after his father Julius, not after Julius Caesar. They are not to the
          // related Julian calendar.
          //
          // The macros used below assume a Gregorian calendar.
          //
          // Based on formulae originally posted by
          // Tom Van Flandern metares@well.sf.ca.us in sci.astro
          // http://www.deja.com/dnquery.xp?QRY=julian+sci.astro+calculating&ST=MS
          // http://world.std.com/FAQ/Other/calendar-FAQ.txt
          //
          // Check date is 1 Jan 2000 ==> JDN 2451545
          #define _ymd2jdn( yy, mm, dd, __j ) {   \
            long __m = (mm); /*signed!*/          \
            long __a = (14-(__m))/12;             \
            long __y = (yy)+4800-__a;             \
            __m = __m + 12*__a - 3;               \
            __j = ((long)(dd)) + (153*__m+2)/5 +  \
                  __y*365 + __y/4 - __y/100 +     \
                  __y/400 - 32045L;               \
            }
          #define _jdn2ymd( __j, yy, mm, dd ) {   \
              long __a = (__j) + 32044L;          \
              long __b = (4*__a+3)/146097L;       \
              long __c = __a - (__b*146097L)/4;   \
              long __d = (4*__c+3)/1461L;         \
              long __e = __c - (1461L*__d)/4;     \
              long __f = (5*__e+2)/153L;          \
              dd = __e - (153L*__f+2)/5 + 1;      \
              mm = __f + 3 - 12*(__f/10);         \
              yy = __b*100 + __d - 4800 + __f/10; \
          }
          unsigned long jdn;
          _ymd2jdn( year, month, day, jdn );
          jdn -= (jdn % logfileLimit); // backoff to beginning of period
          _jdn2ymd( jdn, year, month, day );
        } // not daily
        sprintf(datePartOfLogFileName, "%02d%02d%02d.log", (year%100), month, day);
        LogFileName = LogFileBaseName + datePartOfLogFileName;
      }
    } // if (tm_mday != 0)
    // It can be that a file cannot be found, for example when near the rotation
    // period the time on the remote computer and the computer rscc runs on differ.
    // Then, try FindFirst() - FindNext() as a last fallback.
    if ( !FileExists(LogFileName) ) {
      if ( !FindFirst(LogFileBaseName + "*", faAnyFile, filerec) ) {
        while ( !FindNext(filerec) ) { }
        Application->MessageBox(AnsiString("Could not find file " + LogFileName + "\nOpening existing file " + filerec.Name).c_str(), Application->Title.c_str(), MB_OK);
        LogFileName = ExtractFilePath(iniFileName) + filerec.Name;
      }
      FindClose(filerec);
    }
  } else { // No rotating logfile, basename == complete name
    LogFileName = LogFileBaseName;
  }
  return LogFileName;
}

//------------------------------------------------------------------------------
// View the debug file
//------------------------------------------------------------------------------
void __fastcall TMainForm::ViewDebugFile1Click(TObject* Sender)
{
  if ( FileExists(tracefile) ) {
    TViewLogFileForm* l = CheckForDoubleFile(tracefile);
    if ( !l ) {
      TViewLogFileForm* ViewLogFileForm = new TViewLogFileForm(this, tracefile, 10000, false, false, "");
      if ( ViewLogFileForm ) {
        // Add new window to child list for closing and deleting on app termination
        AddNode(viewLogFilesChildren, ViewLogFileForm, tracefile);
        // Set main form for beeing able to call SendMessage there
        ViewLogFileForm->mainForm = this;
        // Show the window non-modal
        ViewLogFileForm->Show();
      }
    } else {
      if ( l->WindowState == wsMinimized ) l->WindowState = wsNormal;
      l->SetFocus();
    }
  } else {
    AnsiString errMsg = "File \"" + tracefile + "\" with debug information not found";
    Application->MessageBox(errMsg.c_str(), Application->Title.c_str(), MB_OK);
  }
}

//------------------------------------------------------------------------------
// Adds a pointer to a form to the list of open screens, and adds a menuitem
// to the window menu. This is only done if the file is not yet opened. If it
// is already open, the open window is shown.
//------------------------------------------------------------------------------
void __fastcall TMainForm::AddNode(TList* l, TObject* o, AnsiString caption)
{
  TMenuItem* item = new TMenuItem(RsccMainMenu);
  ((TViewLogFileForm*)o)->windowMenuItem = item;
  item->Caption = caption;
  item->OnClick = WindowClick;
  item->Tag = (int)o; // Store the pointer to the form so we can easily access
                      // it when the menuitem is clicked.
  Window1->Add(item);
  l->Add(o);
}

//------------------------------------------------------------------------------
// A menuitem in the window menu is clicked. Bring the corresponding form to
// the foreground.
//------------------------------------------------------------------------------
void __fastcall TMainForm::WindowClick(TObject* Sender)
{
  TViewLogFileForm* l = (TViewLogFileForm*)((TMenuItem*)Sender)->Tag;
  if (l) {
    if (l->WindowState == wsMinimized) l->WindowState = wsNormal;
    l->SetFocus();
  }
}

//------------------------------------------------------------------------------
// Checks is a logfileform with the given caption already exists in the list.
// If it does, it returns a pointer to it. Else it returns NULL.
//------------------------------------------------------------------------------
TViewLogFileForm* __fastcall TMainForm::CheckForDoubleFile(AnsiString caption)
{
  for (int i = 0; i < viewLogFilesChildren->Count; i++) {
    if (((TViewLogFileForm*)viewLogFilesChildren->Items[i])->windowMenuItem->Caption == caption)
      return (TViewLogFileForm*)viewLogFilesChildren->Items[i];
  }
  return NULL;
}

//------------------------------------------------------------------------------
// Check if we have to start or stop all services due to set start- and stop
// times. If any status is to be changed, the screen is updated.
//------------------------------------------------------------------------------
void __fastcall TMainForm::PeriodicStartStopTimerTimer(TObject* Sender)
{
  int i;
  int starttime, stoptime, currtime;
  bool shouldstart;               // true: start services, false: stop services
  bool useStartTime, useStopTime; // Should we start or stop at all?
  bool shouldUpdateScreen = false;
  TListItem* L;
  SYSTEMTIME timeStruct;

  // Retrieve the current date and time. Get local time - no conversion to UTC.
  GetLocalTime(&timeStruct);
  // Time is calculated in minutes
  currtime = 60 * timeStruct.wHour;
  currtime += timeStruct.wMinute;
  // Test on which selected times we need to check
  if ((timeStruct.wDayOfWeek == 0) || (timeStruct.wDayOfWeek == 6)) {
    if (!pcfg.startOnWeekends && !pcfg.stopOnWeekends)
      return;
    starttime = 60 * pcfg.startTimeWeekends.wHour;
    stoptime  = 60 * pcfg.stopTimeWeekends.wHour;
    starttime += pcfg.startTimeWeekends.wMinute;
    stoptime  += pcfg.stopTimeWeekends.wMinute;
    useStartTime = pcfg.startOnWeekends;
    useStopTime  = pcfg.stopOnWeekends;
  } else {
    if (!pcfg.startOnWeekdays && !pcfg.stopOnWeekdays)
      return;
    starttime = 60 * pcfg.startTimeWeekdays.wHour;
    stoptime  = 60 * pcfg.stopTimeWeekdays.wHour;
    starttime += pcfg.startTimeWeekdays.wMinute;
    stoptime  += pcfg.stopTimeWeekdays.wMinute;
    useStartTime = pcfg.startOnWeekdays;
    useStopTime  = pcfg.stopOnWeekdays;
  }
  // The 2 times divide the day in 3 pieces. Depending on which time is
  // earlier, start- or stop signals need to be given.
  if (useStartTime && useStopTime) {
    if (starttime == stoptime) // not a usefull setting.
      return;
    if (starttime > stoptime) {
      if (currtime < stoptime) shouldstart = true;
      else if (currtime >= starttime) shouldstart = true;
      else if ((currtime >= stoptime) && (currtime < starttime)) shouldstart = false;
    } else if (starttime < stoptime) {
      if (currtime < starttime) shouldstart = false;
      else if (currtime >= stoptime) shouldstart = false;
      else if ((currtime >= starttime) && (currtime < stoptime)) shouldstart = true;
    }
  } else if (useStartTime) {
    if (currtime >= starttime) shouldstart = true;
    else shouldstart = false;
  } else if (useStopTime) {
    if (currtime >= stoptime) shouldstart = false;
    else shouldstart = true;
  }
  // Loop through the list items
  if ((shouldstart) && (useStartTime)) { // Start
    // First start proxies if required
    if (pcfg.startStopProxies) {
      for (i = 0; i < proxyComputersListView->Items->Count; i++) {
        L = proxyComputersListView->Items->Item[i];
        if (L->Checked)
          if (GetServiceStatus(L->Caption.c_str(), proxyData.ServiceName) == SERVICE_STOPPED) {
            StartServiceQuitly(i, UPD_PROXY);
            shouldUpdateScreen = true;
          }
      }
    }
    // Then start clients
    if (pcfg.startStopClients) {
      for (i = 0; i < clientComputersListView->Items->Count; i++) {
        L = clientComputersListView->Items->Item[i];
        if (L->Checked)
          if (GetServiceStatus(L->Caption.c_str(), clientData.ServiceName) == SERVICE_STOPPED) {
            StartServiceQuitly(i, UPD_CLIENT);
            shouldUpdateScreen = true;
          }
      }
    }
  }
  else if (useStopTime) { // Stop
    // First stop all clients
    if (pcfg.startStopClients) {
      for (i = 0; i < clientComputersListView->Items->Count; i++) {
        L = clientComputersListView->Items->Item[i];
        if (L->Checked)
          if (GetServiceStatus(L->Caption.c_str(), clientData.ServiceName) == SERVICE_RUNNING) {
            StopServiceQuitly(i, UPD_CLIENT);
            shouldUpdateScreen = true;
          }
      }
    }
    // Then stop the proxies
    if (pcfg.startStopProxies) {
      for (i = 0; i < proxyComputersListView->Items->Count; i++) {
        L = proxyComputersListView->Items->Item[i];
        if (L->Checked)
          if (GetServiceStatus(L->Caption.c_str(), proxyData.ServiceName) == SERVICE_RUNNING) {
            StopServiceQuitly(i, UPD_PROXY);
            shouldUpdateScreen = true;
          }
      }
    }
  }
  // Update status info for all checked lines
  if (pcfg.startStopClients || pcfg.startStopProxies) {
    if (shouldUpdateScreen) {
      Sleep(1000); // Wait a second for services to reach status
      UpdateStatus(0, true, true, activeListView);
    }
  }
}

//------------------------------------------------------------------------------
// For starting services in the background. index is the index in the proxy- or
// client listview, proxyclient determines wether the client or proxy listview
// is active. 0 == proxy, 1 == client.
//------------------------------------------------------------------------------
void __fastcall TMainForm::StartServiceQuitly(int index, int proxyclient)
{
  char remoteMachineName[MAX_PATH];
  char usedServiceName[256];
  TListView* usedListView;
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;

  if (proxyclient == 0) {
    usedListView = proxyComputersListView;
    strcpy(usedServiceName, proxyData.ServiceName);
  } else {
    usedListView = clientComputersListView;
    strcpy(usedServiceName, clientData.ServiceName);
  }
  strncpy(remoteMachineName, usedListView->Items->Item[index]->Caption.c_str(), sizeof(remoteMachineName) - 1);
  if ((hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0) {
    hService = OpenService(hscManager, usedServiceName, SERVICE_ALL_ACCESS);
    if (hService) {
      RSCC_StartService(hService, 0, NULL, pcfg.writeDebugMessages, remoteMachineName);
      CloseServiceHandle(hService);
    }
    if (hscManager) CloseServiceHandle(hscManager);
  }
}

//------------------------------------------------------------------------------
// For stopping services in the background. index is the index in the proxy- or
// client listview, proxyclient determines wether the client or proxy listview
// is active. 0 == proxy, 1 == client.
//------------------------------------------------------------------------------
void __fastcall TMainForm::StopServiceQuitly(int index, int proxyclient)
{
  char remoteMachineName[MAX_PATH];
  char usedServiceName[256];
  TListView* usedListView;

  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  SERVICE_STATUS serviceStatus;

  if (proxyclient == 0) {
    usedListView = proxyComputersListView;
    strcpy(usedServiceName, proxyData.ServiceName);
  } else {
    usedListView = clientComputersListView;
    strcpy(usedServiceName, clientData.ServiceName);
  }
  strncpy(remoteMachineName, usedListView->Items->Item[index]->Caption.c_str(), sizeof(remoteMachineName) - 1);
  if ((hscManager = RSCC_OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0) {
    hService = OpenService(hscManager, usedServiceName, SERVICE_ALL_ACCESS);
    if (hService) {
      RSCC_ControlService(hService, SERVICE_CONTROL_STOP, &serviceStatus, pcfg.writeDebugMessages, remoteMachineName);
      CloseServiceHandle(hService);
    }
    if (hscManager) CloseServiceHandle(hscManager);
  }
}

//------------------------------------------------------------------------------
// TNetworkScanThread methods
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Constructor. Stores the owner.
//------------------------------------------------------------------------------
__fastcall TNetworkScanThread::TNetworkScanThread(bool createSuspended,
                                                  bool aRunUpdateAfterwards,
                                                  bool aScanOutsideDomain,
                                                  TMainForm* Owner): TThread(createSuspended)
{
  OwnerForm = Owner;
  fRunUpdateAfterwards = aRunUpdateAfterwards;
  fScanOutsideDomain = aScanOutsideDomain;
  FreeOnTerminate = true; // So we don't have to delete the thread explicitly
}

//------------------------------------------------------------------------------
// Destructor
//------------------------------------------------------------------------------
__fastcall TNetworkScanThread::~TNetworkScanThread()
{
}

//------------------------------------------------------------------------------
// Execute method. Tries to run the thread.
//------------------------------------------------------------------------------
void __fastcall TNetworkScanThread::Execute()
{
  AnsiString errText;

  try {
    OwnerForm->SetThreadWaitText("Initializing...", "");
    if (fScanOutsideDomain)
      FindNetworkComputerNames(NULL);
    else
      FindNetworkComputerNames();
    if (fRunUpdateAfterwards)
      SendMessage(OwnerForm->Handle, WM_SCAN_THREAD_READY, DO_UPDATE_STATUS, 0);
    else
      SendMessage(OwnerForm->Handle, WM_SCAN_THREAD_READY, DO_NOT_UPDATE_STATUS, 0);
  }
  catch (Exception& exception) {
    errText = "Error running network scan thread: " + exception.Message;
    MessageBox(NULL, errText.c_str(), Application->Title.c_str(), MB_OK);
  }
}

//------------------------------------------------------------------------------
// Find the network computer names in the local domain and add them to the
// listview(s).
//------------------------------------------------------------------------------
void __fastcall TNetworkScanThread::FindNetworkComputerNames()
{
  LPSERVER_INFO_101 si = NULL;
  LPSERVER_INFO_101 tmpsi;
  DWORD level = 101;
  DWORD entriesRead = 0;
  DWORD totalEntries = 0;
  DWORD resumeHandle = 0;
  NET_API_STATUS retVal;
  unsigned i;
  char ComputerName[MAX_COMPUTERNAME_LENGTH + 1];
  bool addMachine;
  long ver = 0;
  TListItem* L;

  retVal = NetServerEnum(NULL,
                         level,
                         (LPBYTE*)(&si),
                         MAX_PREFERRED_LENGTH,
                         &entriesRead,
                         &totalEntries,
                         SV_TYPE_WORKSTATION,
                         NULL,
                         &resumeHandle);

  if ((retVal == NERR_Success) || (retVal == ERROR_MORE_DATA)) {
    if ((tmpsi = si) != NULL) {
      // Now add all servers c.q. all NT machines to the listviews.
      for (i = 0; i < entriesRead; i++) {
        if (!tmpsi) {
          ShowErrorMessage("NetServerEnum", NULL);
          break;
        }
        if ( OwnerForm->AddOnlyNTMachinesInView() ) {
          if ((tmpsi->sv101_type & (SV_TYPE_NT | SV_TYPE_WINDOWS)) != 0 ) {
            ver = (tmpsi->sv101_version_major * 100) + (tmpsi->sv101_version_minor);
            if ( (tmpsi->sv101_type & SV_TYPE_NT) != 0 ) ver += 2000;
          }
          addMachine = (ver >= 2000);
        } else {
          addMachine = true;
        }
        UnicodeToAnsi(tmpsi->sv101_name, ComputerName, sizeof(ComputerName));
        OwnerForm->SetThreadWaitText("Reading computer names...", LowerCase(ComputerName));
        if ( addMachine && !OwnerForm->NameIsDouble(ComputerName, OwnerForm->clientComputersListView) ) {
          // Add the computer name listitem to the client listview
          L = OwnerForm->clientComputersListView->Items->Add();
          L->Caption = LowerCase(ComputerName);
          // Add subitem for status
          L->SubItems->Add("");
          // Add subitem for service path
          L->SubItems->Add("");
          // Add sunbitem for client version
          L->SubItems->Add("");
          // Add sunbitem for email version
          L->SubItems->Add("");
        }
        if ( addMachine && !OwnerForm->NameIsDouble(ComputerName, OwnerForm->proxyComputersListView) ) {
          // Add the computer name listitem to the proxy listview
          L = OwnerForm->proxyComputersListView->Items->Add();
          L->Caption = LowerCase(ComputerName);
          // Add subitem for status
          L->SubItems->Add("");
          // Add subitem for service path
          L->SubItems->Add("");
          // Add sunbitem for proxy version
          L->SubItems->Add("");
          // Add sunbitem for ipaddress version
          L->SubItems->Add("");
        }
        tmpsi++;
      }
    }
    if (retVal == ERROR_MORE_DATA) ShowErrorMessage("NetServerEnum", NULL);
  }
  else
    ShowErrorMessage("NetServerEnum", NULL);

  if (si) NetApiBufferFree(si);
}

//------------------------------------------------------------------------------
// Find the network computer names and add them to the listview.
// Old code, works much slower than using NetServerEnum() but also lists
// computers outside the local domain.
//------------------------------------------------------------------------------
void __fastcall TNetworkScanThread::FindNetworkComputerNames(LPNETRESOURCE lpnr)
{
  DWORD ResultEnum;
  HANDLE hEnum;
  DWORD cbBuffer = 16384;        // 16K is a good size
  DWORD i, entries = 0xFFFFFFFF; // enumerate all possible entries
  LPNETRESOURCE lpnrLocal;       // pointer to enumerated structures
  char ComputerName[MAX_COMPUTERNAME_LENGTH + 1];
  bool addMachine;
  TListItem* L;

  if ( WNetOpenEnum(RESOURCE_GLOBALNET, RESOURCETYPE_ANY, 0, lpnr, &hEnum) != NO_ERROR ) {
    ShowErrorMessage("WNetOpenEnum", NULL);
    return;
  }

  do {
    // Allocate memory for NETRESOURCE structures.
    lpnrLocal = (LPNETRESOURCE)GlobalAlloc(GPTR, cbBuffer);
    if ( !lpnrLocal ) {
      ShowErrorMessage("GlobalAlloc", NULL);
    } else {
      ResultEnum = WNetEnumResource(hEnum, &entries, lpnrLocal, &cbBuffer);
      if (ResultEnum == NO_ERROR) {
        for (i = 0; i < entries; i++) {
          // We add only computer names
          if ( (lpnrLocal[i].lpRemoteName) && (lpnrLocal[i].lpRemoteName[0] == '\\') ) {
            strncpy(ComputerName, lpnrLocal[i].lpRemoteName + 2, sizeof(ComputerName) - 1);
            OwnerForm->SetThreadWaitText("Reading computer names...", AnsiString(ComputerName).LowerCase());
            if ( OwnerForm->AddOnlyNTMachinesInView() ) {
              addMachine = ( GetRemotePlatformType((LPTSTR)ComputerName) >= 2000 );
            } else {
              addMachine = true;
            }
            if ( addMachine && !OwnerForm->NameIsDouble(ComputerName, OwnerForm->clientComputersListView) ) {
              // Add the computer name listitem to the client listview
              L = OwnerForm->clientComputersListView->Items->Add();
              L->Caption = LowerCase(ComputerName);
              // Add subitem for status
              L->SubItems->Add("");
              // Add subitem for service path
              L->SubItems->Add("");
              // Add sunbitem for client version
              L->SubItems->Add("");
              // Add sunbitem for email version
              L->SubItems->Add("");
            }
            if ( addMachine && !OwnerForm->NameIsDouble(ComputerName, OwnerForm->proxyComputersListView) ) {
              // Add the computer name listitem to the proxy listview
              L = OwnerForm->proxyComputersListView->Items->Add();
              L->Caption = LowerCase(ComputerName);
              // Add subitem for status
              L->SubItems->Add("");
              // Add subitem for service path
              L->SubItems->Add("");
              // Add sunbitem for proxy version
              L->SubItems->Add("");
              // Add sunbitem for ipaddress version
              L->SubItems->Add("");
            }
          }
          // If this NETRESOURCE is a container AND it is not a directory,
          // call the function recursively. We also check on the existence
          // of lpnrLocal[i].lpRemoteName - it is sometimes NULL.
          if ( (RESOURCEUSAGE_CONTAINER == (lpnrLocal[i].dwUsage & RESOURCEUSAGE_CONTAINER)) &&
               (lpnrLocal[i].lpRemoteName) && (lpnrLocal[i].lpRemoteName[0] != '\\') ) {
            FindNetworkComputerNames(&lpnrLocal[i]);
          }
        }
      }
      else if (ResultEnum != ERROR_NO_MORE_ITEMS) {
        ShowErrorMessage("WNetEnumResource", NULL);
        GlobalFree((HGLOBAL)lpnrLocal);
        break;
      }
      GlobalFree((HGLOBAL)lpnrLocal);
    }
  }
  while( ResultEnum != ERROR_NO_MORE_ITEMS && !Terminated );

  if ( WNetCloseEnum(hEnum) != NO_ERROR ) ShowErrorMessage("WNetCloseEnum", NULL);
  return;
}

//------------------------------------------------------------------------------


