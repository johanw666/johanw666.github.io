//------------------------------------------------------------------------------
// This file is part of Remote Service Control Center by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: base64.h
//------------------------------------------------------------------------------
#ifndef Base64H
#define Base64H
//------------------------------------------------------------------------------
void Base64Encode(const char inS[], char outS[], size_t inbuff_size, size_t outbuff_size);
void Base64Decode(const char inS[], char outS[], size_t inbuff_size, size_t outbuff_size);
//------------------------------------------------------------------------------
#endif

