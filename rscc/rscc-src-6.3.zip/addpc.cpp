//------------------------------------------------------------------------------
// This file is part of Remote Service Control Center by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: addpc.cpp
//
// Contains the code for the form that alows for the manual addition of a
// computer to the list.
//------------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "addpc.h"
#include "scc.h"
//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

//------------------------------------------------------------------------------
__fastcall TAddComputerForm::TAddComputerForm(TComponent* Owner): TForm(Owner)
{
}

//------------------------------------------------------------------------------
__fastcall TAddComputerForm::TAddComputerForm(TComponent* Owner,
                                              char*       computerName,
                                              size_t      buffLength,
                                              bool*       addToClients,
                                              bool*       addToProxies): TForm(Owner)
{
  fComputerName = computerName;
  fBuffLength   = buffLength;
  fAddToClients = addToClients;
  fAddToProxies = addToProxies;
  // Longer names don't fit in the buffer
  ComputerNameEdit->MaxLength = buffLength - 1;
}

//------------------------------------------------------------------------------
void __fastcall TAddComputerForm::OKButtonClick(TObject* Sender)
{
  if ( ComputerNameEdit->Text != "" ) {
    *fAddToClients = AddToClientsCheckBox->Checked;
    *fAddToProxies = AddToProxiesCheckBox->Checked;
    strncpy(fComputerName, ComputerNameEdit->Text.c_str(), fBuffLength - 1);
  } else {
    *fAddToClients = false;
    *fAddToProxies = false;
  }
  ModalResult = mrOk;
}

//------------------------------------------------------------------------------
void __fastcall TAddComputerForm::FormShow(TObject* Sender)
{
  // Position the form
  Top = MainForm->Top + 0.5 * (MainForm->Height - Height);
  Left = MainForm->Left + 0.5 * (MainForm->Width - Width);
  ComputerNameEdit->SetFocus();
}

//------------------------------------------------------------------------------
// Allow enter to add a name and escape to close the form.
//------------------------------------------------------------------------------
void __fastcall TAddComputerForm::ComputerNameEditKeyPress(TObject* Sender, char& Key)
{
  if ( Key == VK_RETURN ) OKButtonClick(Sender);
  else if ( Key == VK_ESCAPE ) ModalResult = mrCancel;
}
//------------------------------------------------------------------------------

