//------------------------------------------------------------------------------
// This file is part of Remote Service Control Center by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: config.cpp
//
// Contains code to change the configuration of an installed client.
//------------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "config.h"
//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

//------------------------------------------------------------------------------
// Default constructor. Made private so it won't get called.
//------------------------------------------------------------------------------
__fastcall TConfigForm::TConfigForm(TComponent* Owner): TForm(Owner)
{
}

//------------------------------------------------------------------------------
// Constructor. Initializes all variables.
//------------------------------------------------------------------------------
__fastcall TConfigForm::TConfigForm(TComponent* Owner,
                                    bool aCanChangeConfig,
                                    DWORD aDwServiceType,
                                    DWORD aDwStartType,
                                    char aLpBinaryPathName[],
                                    char aLpServiceStartName[],
                                    char aLpDisplayName[],
                                    char aComputerName[],
                                    bool* doChangeConfig,
                                    ChangeServiceConfigData* aServiceConfigData): TForm(Owner)
{
  changeConfig = doChangeConfig;
  *changeConfig = false;
  fServiceConfigData = aServiceConfigData;
  strcpy(computerName, aComputerName);

  fDwServiceType = aDwServiceType;
  fDwStartType = aDwStartType;
  strcpy(fLpBinaryPathName, aLpBinaryPathName);
  strcpy(fLpServiceStartName, aLpServiceStartName);
  strcpy(fLpDisplayName, aLpDisplayName);

  Caption = AnsiString("Configuration of " + AnsiString(aComputerName));
  // Set the edits
  DisplayNameEdit->Text = AnsiString(fLpDisplayName);
  ExeNameEdit->Text = AnsiString(fLpBinaryPathName);
  AccountEdit->Text = AnsiString(fLpServiceStartName);
  AccountLabel2->Caption = "(Current account is " + AnsiString(fLpServiceStartName) + ")";
  // Startup types
  if ( fDwStartType == SERVICE_AUTO_START ) AutoRadioButton->Checked = true;
  else ManualRadioButton->Checked = true;
  // Position the form
  if ( Owner ) {
    Top = ((TForm*)Owner)->Top + (((TForm*)Owner)->Height - Height);
    if ( Top < 0 ) Top = 0;
    Left = ((TForm*)Owner)->Left + 0.5 * (((TForm*)Owner)->Width - Width);
  } else Position = poScreenCenter;

  // We don't hav epermissions to change the config:
  if ( !aCanChangeConfig ) {
    ChangeButton->Enabled = false;
    FileGroupBox->Enabled = false;
    StartupGroupBox->Enabled = false;
    AccountGroupBox->Enabled = false;
    Caption = Caption + " (read only)";
  }
}

//------------------------------------------------------------------------------
// OK pressed. If the configuration has changed, apply the changes.
//------------------------------------------------------------------------------
void __fastcall TConfigForm::ChangeButtonClick(TObject* Sender)
{
  *changeConfig = true;
  fServiceConfigData->dwServiceType = SERVICE_WIN32_OWN_PROCESS;
  if ( AutoRadioButton->Checked ) fServiceConfigData->dwStartType = SERVICE_AUTO_START;
  else fServiceConfigData->dwStartType = SERVICE_DEMAND_START;
  fServiceConfigData->dwErrorControl = SERVICE_ERROR_IGNORE;
  strcpy(fServiceConfigData->lpBinaryPathName, ExeNameEdit->Text.c_str());
  strcpy(fServiceConfigData->lpDisplayName, DisplayNameEdit->Text.c_str());
  // Empty strings will be set to NULL values in scc.cpp, so the account info
  // is not changed.
  if ( DefaultRadioButton->Checked ) {
    strcpy(fServiceConfigData->lpServiceStartName, "");
    strcpy(fServiceConfigData->lpPassword, "");
  } else {
    strcpy(fServiceConfigData->lpServiceStartName, AccountEdit->Text.c_str());
    strcpy(fServiceConfigData->lpPassword, PasswordEdit->Text.c_str());
  }
  Close();
}

//------------------------------------------------------------------------------
// Cancel pressed. Don't change the configuration
//------------------------------------------------------------------------------
void __fastcall TConfigForm::CancelButtonClick(TObject* Sender)
{
  Close();
}

//------------------------------------------------------------------------------
// Check if you want to be able to edit the exe path. Extra step included to
// assure you know what you're doing.
//------------------------------------------------------------------------------
void __fastcall TConfigForm::EditExeCheckBoxClick(TObject* Sender)
{
  if ( EditExeCheckBox->Checked ) {
    Application->MessageBox("Warning: changing the executable or the startup parameters can result in a disfunctioning client!", Application->Title.c_str(), MB_OK|MB_ICONWARNING);
    ExeNameEdit->Enabled = true;
  }
  else ExeNameEdit->Enabled = false;
}

//------------------------------------------------------------------------------
// See if we need to enable the account change inputs
//------------------------------------------------------------------------------
void __fastcall TConfigForm::RadioButtonClick(TObject *Sender)
{
  if ( DefaultRadioButton->Checked ) {
    AccountEdit->Enabled = false;
    PasswordEdit->Enabled = false;
    AccountLabel->Enabled = false;
    PasswordLabel->Enabled = false;
  } else {
    AccountEdit->Enabled = true;
    PasswordEdit->Enabled = true;
    AccountLabel->Enabled = true;
    PasswordLabel->Enabled = true;
  }
}

//------------------------------------------------------------------------------

