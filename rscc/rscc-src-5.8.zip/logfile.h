//------------------------------------------------------------------------------
// This file is part of Remote Service Control Center by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: logfile.h
//------------------------------------------------------------------------------
#ifndef logfileH
#define logfileH
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>

#include "scc.h"
//------------------------------------------------------------------------------
class TViewLogFileForm: public TForm
{
__published:
  TMemo* LogFileMemo;
  TPanel* Panel1;
  TPanel* Panel2;
  TButton* CloseButton;
  TButton* RefreshButton;
  TTimer* RefreshTimer;
  TCheckBox* FilterRC5CheckBox;
  TCheckBox* FilterOGRCheckBox;
  TCheckBox* FilterOGRP2CheckBox;
  TLabel* RC5SentLabel;
  TLabel* OGRSentLabel;
  TLabel* OGRP2SentLabel;
  TTimer* SetCursorTimer;
  void __fastcall CloseButtonClick(TObject* Sender);
  void __fastcall RefreshText(TObject* Sender);
  void __fastcall FilterCheckBoxClick(TObject* Sender);
  void __fastcall CloseButtonKeyDown(TObject* Sender, WORD& Key, TShiftState Shift);
  void __fastcall SetCursorTimerTimer(TObject* Sender);
  void __fastcall FormClose(TObject* Sender, TCloseAction& Action);
    
private:
  __fastcall TViewLogFileForm(TComponent* Owner);
  void __fastcall SetCursorPos(void);
  AnsiString LogFileName;
  AnsiString RC5Challenge;
  bool fProxyConlogFile;
public:
  TMainForm* mainForm; // Needed for SendMessage of the close notification.
                       // We can't simply cast Owner to a TMainForm* since
                       // mainForm can be NULL and setting Owner to NULL causes
                       // problems.
  TMenuItem* windowMenuItem;
  __fastcall TViewLogFileForm(TComponent* Owner,
                              AnsiString aLogFileName,
                              int  aLogRefreshTime,
                              bool autoRefresh,
                              bool aProxyConlogFile,
                              AnsiString aRC5Challenge);
};
//------------------------------------------------------------------------------
#endif
