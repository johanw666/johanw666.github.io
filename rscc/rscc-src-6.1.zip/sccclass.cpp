//------------------------------------------------------------------------------
// This file is part of Remote Service Control Center by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: sccclsss.cpp
//
// Contains the classes that describe the program configuraton and the data
// stored about the default client/proxy installation parameters.
//------------------------------------------------------------------------------
#include <stdio.h>
#include <vcl.h>
#pragma hdrstop

#include "sccclass.h"
#include "defsetup.h"
#include "password.h"
#include "Base64.h"
// Delphi crypto modules
#include "DCPcrypt.hpp"
#include "RC5.hpp"
#include "SHA1.hpp"

// Default password if none chosen.
const char DefaultPassword[] = "remoteservicecontrolcenter";
// Inifile keys
const AnsiString ComputerNamesIniSection = "Computers";
const AnsiString ProxyComputerNamesIniSection = "ProxyComputers";
const AnsiString SwitchUser = "SwitchUser";
const AnsiString ProgramIniSection = "General";
const AnsiString ReadNetworkIdent = "ReadNetwork";
const AnsiString DestinationKey = "DestinationKey";
const AnsiString DestinationSection = "DestinationSection";
const AnsiString UpdateAfterStart = "UpdateAfterStart";
const AnsiString ServiceStartUp = "ServiceStartUp";
const AnsiString serviceClient = "Client";
const AnsiString serviceProxy = "Proxy";
const AnsiString MaxWaitTime = "MaxWaitTime";
const AnsiString LogRefreshTime = "LogRefreshTime";
const AnsiString MinimizeToSystray = "MinimizeToSysTray";
const AnsiString LogFileProxy = "LogFileProxy";
const AnsiString conLogFile = "console";
const AnsiString rc5LogFile = "rc5";
const AnsiString ogrLogFile = "ogr";
const AnsiString ogrp2LogFile = "ogrp2";
const AnsiString ActiveRC5Challenge = "RC5Challenge";
const AnsiString AutoRefreshLogs = "AutoRefreshLogs";
const AnsiString ShowButtons = "ShowButtons";
const AnsiString SelectWholeLine = "SelectWholeLine";
const AnsiString ShowSettings = "ShowSettings";
const AnsiString UseSecureCipher = "UseSecureCipher";
const AnsiString AddOnlyNTMachines = "AddOnlyNTMachines";
const AnsiString WriteDebugMessages = "WriteDebugMessages";
const AnsiString AllowNonDomain = "AllowNonDomain";
const AnsiString ScanOutsideDomain = "ScanOutsideDomain";
const AnsiString StartStopClients = "StartStopClients";
const AnsiString StartStopProxies = "StartStopProxies";
const AnsiString StartOnWeekdays = "StartOnWeekdays";
const AnsiString StopOnWeekdays = "StopOnWeekdays";
const AnsiString StartOnWeekends = "StartOnWeekends";
const AnsiString StopOnWeekends = "StopOnWeekends";
const AnsiString StartTimeWeekdays = "StartTimeWeekdays";
const AnsiString StopTimeWeekdays = "StopTimeWeekdays";
const AnsiString StartTimeWeekends = "StartTimeWeekends";
const AnsiString StopTimeWeekends = "StopTimeWeekends";
const AnsiString TopPos = "FormTop";
const AnsiString LeftPos = "FormLeft";
const AnsiString FormHeight = "FormHeight";
const AnsiString FormWidth = "FormWidth";
const AnsiString NameColumnWidth = "NameColumnWidth";
const AnsiString StatusColumnWidth = "StatusColumnWidth";
const AnsiString PathColumnWidth = "PathColumnWidth";
const AnsiString VersionColumnWidth = "VersionColumnWidth";
const AnsiString EmailColumnWidth = "EmailColumnWidth";
const AnsiString pNameColumnWidth = "pNameColumnWidth";
const AnsiString pStatusColumnWidth = "pStatusColumnWidth";
const AnsiString pPathColumnWidth = "pPathColumnWidth";
const AnsiString pVersionColumnWidth = "pVersionColumnWidth";
const AnsiString pEmailColumnWidth = "pEmailColumnWidth";

//------------------------------------------------------------------------------
// ServiceParams methods.
//------------------------------------------------------------------------------

__fastcall ServiceParams::ServiceParams()
{
}

__fastcall ServiceParams::~ServiceParams()
{
}

//------------------------------------------------------------------------------
// Assignment operator.
//------------------------------------------------------------------------------
const ServiceParams& __fastcall ServiceParams::operator=(const ServiceParams& cfg2)
{
  ServiceParams& from = (ServiceParams&)cfg2;
  // Copy the contents of the "from" object to the receiving object.
  strcpy(IniSection, from.IniSection);
  strcpy(ExeFrom, from.ExeFrom);
  strcpy(IniFrom, from.IniFrom);
  strcpy(DirectoryTo, from.DirectoryTo);
  strcpy(RemoteName, from.RemoteName);
  strcpy(ServiceName, from.ServiceName);
  strcpy(DisplayName, from.DisplayName);
  strcpy(BootParams, from.BootParams);
  StartOnInstall = from.StartOnInstall;
  StartOnBoot = from.StartOnBoot;
  strncpy(DestinationSection, from.DestinationSection, sizeof(DestinationSection) - 1);
  strncpy(DestinationKey, from.DestinationKey, sizeof(DestinationKey) - 1);

  return *this;
}

//------------------------------------------------------------------------------
bool __fastcall ServiceParams::operator==(const ServiceParams& cfg2) const
{
  return Compare(cfg2);
}

//------------------------------------------------------------------------------
bool __fastcall ServiceParams::operator!=(const ServiceParams& cfg2) const
{
  return !Compare(cfg2);
}

//------------------------------------------------------------------------------
// Comparing function for operator== and !=. Returns true if equal, false if not.
//------------------------------------------------------------------------------
bool __fastcall ServiceParams::Compare(const ServiceParams& cfg2) const
{
  return(
  !strcmp(IniSection, cfg2.IniSection) &&
  !strcmp(ExeFrom, cfg2.ExeFrom) &&
  !strcmp(IniFrom, cfg2.IniFrom) &&
  !strcmp(DirectoryTo, cfg2.DirectoryTo) &&
  !strcmp(RemoteName, cfg2.RemoteName) &&
  !strcmp(ServiceName, cfg2.ServiceName) &&
  !strcmp(DisplayName, cfg2.DisplayName) &&
  !strcmp(BootParams, cfg2.BootParams) &&
  (StartOnInstall == cfg2.StartOnInstall) &&
  (StartOnBoot == cfg2.StartOnBoot) &&
  !strncmp(DestinationSection, cfg2.DestinationSection, sizeof(DestinationSection) - 1) &&
  !strncmp(DestinationKey, cfg2.DestinationKey, sizeof(DestinationKey) - 1)
  );
}

//------------------------------------------------------------------------------
// Write settings to a defined inifile.
//------------------------------------------------------------------------------
void __fastcall ServiceParams::SaveSettings(TIniFile* file)
{
  if ( file && strlen(IniSection) ) {
    file->WriteString(IniSection, "ExeFrom", ExeFrom);
    file->WriteString(IniSection, "IniFrom", IniFrom);
    file->WriteString(IniSection, "DirectoryTo", DirectoryTo);
    file->WriteString(IniSection, "RemoteName", RemoteName);
    file->WriteString(IniSection, "ServiceName", ServiceName);
    file->WriteString(IniSection, "DisplayName", DisplayName);
    file->WriteString(IniSection, "BootParams", BootParams);
    // Startup values
    file->WriteBool(IniSection, "StartOnInstall", StartOnInstall);
    file->WriteBool(IniSection, "StartOnBoot", StartOnBoot);
    // Inifile sections
    file->WriteString(IniSection, "DestinationSection", DestinationSection);
    file->WriteString(IniSection, "DestinationKey", DestinationKey);
  }
}

//------------------------------------------------------------------------------
// Read settings from inifile.
//------------------------------------------------------------------------------
void __fastcall ServiceParams::ReadSettings(TIniFile* file)
{
  if ( file && strlen(IniSection) ) {
    strcpy(ExeFrom, file->ReadString(IniSection, "ExeFrom", "").c_str());
    strcpy(IniFrom, file->ReadString(IniSection, "IniFrom", "").c_str());
    strcpy(DirectoryTo, file->ReadString(IniSection, "DirectoryTo", "").c_str());
    strcpy(RemoteName, file->ReadString(IniSection, "RemoteName", "").c_str());
    strcpy(ServiceName, file->ReadString(IniSection, "ServiceName", "").c_str());
    strcpy(DisplayName, file->ReadString(IniSection, "DisplayName", "").c_str());
    strcpy(BootParams, file->ReadString(IniSection, "BootParams", "").c_str());
    // Inifile section
    strcpy(DestinationSection, file->ReadString(IniSection, "DestinationSection", "").c_str());
    strcpy(DestinationKey, file->ReadString(IniSection, "DestinationKey", "").c_str());
    // Startup values
    StartOnInstall = file->ReadBool(IniSection, "StartOnInstall", true);
    StartOnBoot = file->ReadBool(IniSection, "StartOnBoot", true);
  }
}

//------------------------------------------------------------------------------
// This method checks if there is sufficient information available to create a service
//------------------------------------------------------------------------------
bool ServiceParams::IsSufficientDataAvailable()
{
  char errMsg[1024];

  if ( !strlen(DirectoryTo) || !strlen(ExeFrom) || !strlen(IniFrom) ||
       !strlen(RemoteName)  || !strlen(ServiceName) || !strlen(DisplayName) ) {
    strcpy(errMsg, "Some of the required parameters for this operation are not defined:\n\n");
    if ( !strlen(ExeFrom) )     strcat(errMsg, " - Executable to use\n");
    if ( !strlen(IniFrom) )     strcat(errMsg, " - Inifile to use\n");
    if ( !strlen(DirectoryTo) ) strcat(errMsg, " - Destination path on remote computer\n");
    if ( !strlen(DisplayName) ) strcat(errMsg, " - Service display name\n");
    if ( !strlen(ServiceName) ) strcat(errMsg, " - Service name");
    if ( !strlen(RemoteName) )  strcat(errMsg, " - Program executable name on remote computer\n");
    strcat(errMsg, "\nSelect \"Default setup\" to set them.");
    if ( Application->MessageBox(errMsg, "Insufficient data available to create the service", MB_YESNO) == IDYES ) {
      TDefaultsForm* DefaultsForm = new TDefaultsForm(NULL, this);
      if ( DefaultsForm ) {
        DefaultsForm->ShowModal();
        delete DefaultsForm;
      }
    }
    return false;
  }
  else return true;
}

//------------------------------------------------------------------------------
// End of ServiceParams methods.
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// ProgramCfg methods.
//------------------------------------------------------------------------------
__fastcall ProgramCfg::ProgramCfg()
{
  // Initialise the login info with 0
  memset(Username, 0, sizeof(Username));
  memset(Domain, 0, sizeof(Domain));
  memset(Password, 0, sizeof(Password));
  memset(ProgramPassword, 0, sizeof(ProgramPassword));
  // List to store the computer names with clients in
  clientComputerNameList = new TStringList;
  // List to store the computer names with proxies in
  proxyComputerNameList = new TStringList;
}

//------------------------------------------------------------------------------
// Destructor. Clears the fields with the login info and deletes the lists.
//------------------------------------------------------------------------------
__fastcall ProgramCfg::~ProgramCfg()
{
  // Clear the login info
  memset(Username, 0, sizeof(Username));
  memset(Domain, 0, sizeof(Domain));
  memset(Password, 0, sizeof(Password));
  memset(ProgramPassword, 0, sizeof(ProgramPassword));
  delete clientComputerNameList;
  delete proxyComputerNameList;
}

//------------------------------------------------------------------------------
// Assignment operator.
//------------------------------------------------------------------------------
const ProgramCfg& __fastcall ProgramCfg::operator=(const ProgramCfg& cfg2)
{
  int i;

  ProgramCfg& from = (ProgramCfg&)cfg2;
  // Copy the contents of the "from" object to the receiving object.
  readNetworkNamesAfterStart = from.readNetworkNamesAfterStart;
  updateStatusAfterStart = from.updateStatusAfterStart;
  minimizeToSystray = from.minimizeToSystray;
  MaxWaitTime = from.MaxWaitTime;
  LogRefreshTime = from.LogRefreshTime;
  SwitchUserID = from.SwitchUserID;
  useSecureCipher = from.useSecureCipher;
  whichProxyLogFile = from.whichProxyLogFile;
  activeRC5Challenge = from.activeRC5Challenge;
  ServiceToShow = from.ServiceToShow;
  autoRefreshLogs = from.autoRefreshLogs;
  showButtons = from.showButtons;
  showSettings = from.showSettings;
  selectWholeLine = from.selectWholeLine;
  addOnlyNTMachines = from.addOnlyNTMachines;
  writeDebugMessages = from.writeDebugMessages;
  allowNonDomain = from.allowNonDomain;
  scanOutsideDomain = from.scanOutsideDomain;
  // Periodic start/stop times
  startStopClients = from.startStopClients;
  startStopProxies = from.startStopProxies;
  startOnWeekdays = from.startOnWeekdays;
  stopOnWeekdays = from.stopOnWeekdays;
  startOnWeekends = from.startOnWeekends;
  stopOnWeekends = from.stopOnWeekends;
  startTimeWeekdays = from.startTimeWeekdays;
  stopTimeWeekdays = from.stopTimeWeekdays;
  startTimeWeekends = from.startTimeWeekends;
  stopTimeWeekends = from.stopTimeWeekends;
  // Login data
  strncpy(Username, from.Username, sizeof(Username) - 1);
  strncpy(Domain, from.Domain, sizeof(Domain) - 1);
  strncpy(Password, from.Password, sizeof(Password) - 1);
  strcpy(ProgramPassword, from.ProgramPassword);
  // Computer names
  clientComputerNameList->Clear();
  for (i = 0; i < from.clientComputerNameList->Count; i++) {
    clientComputerNameList->Add(from.clientComputerNameList->Strings[i]);
    clientComputerNameList->Objects[i] = from.clientComputerNameList->Objects[i];
  }
  proxyComputerNameList->Clear();
  for (i = 0; i < from.proxyComputerNameList->Count; i++) {
    proxyComputerNameList->Add(from.proxyComputerNameList->Strings[i]);
    proxyComputerNameList->Objects[i] = from.proxyComputerNameList->Objects[i];
  }
  return *this;
}

//------------------------------------------------------------------------------
// operator==. Returns true if both are equal, false if unequal.
//------------------------------------------------------------------------------
bool __fastcall ProgramCfg::operator==(const ProgramCfg& cfg2) const
{
  return Compare(cfg2);
}

//------------------------------------------------------------------------------
// operator!=. Returns true if both are unequal, false if equal.
//------------------------------------------------------------------------------
bool __fastcall ProgramCfg::operator!=(const ProgramCfg& cfg2) const
{
  return !Compare(cfg2);
}

//------------------------------------------------------------------------------
// Compare operation for SYSTEMTIME. Returns true if cfg1 equals cfg2, false
// otherwise.
//------------------------------------------------------------------------------
bool __fastcall CompareSystemTime(const SYSTEMTIME& cfg1, const SYSTEMTIME& cfg2)
{
  return((cfg1.wYear == cfg2.wYear) &&
         (cfg1.wMonth == cfg2.wMonth) &&
         (cfg1.wDayOfWeek == cfg2.wDayOfWeek) &&
         (cfg1.wDay == cfg2.wDay) &&
         (cfg1.wHour == cfg2.wHour) &&
         (cfg1.wMinute == cfg2.wMinute) &&
         (cfg1.wSecond == cfg2.wSecond) &&
         (cfg1.wMilliseconds == cfg2.wMilliseconds));
}

//------------------------------------------------------------------------------
// Comparing function for operator== and !=. Returns true if both are equal,
// false if not.
//------------------------------------------------------------------------------
bool __fastcall ProgramCfg::Compare(const ProgramCfg& cfg2) const
{
  int i;
  bool computerCmp = true;
  // Compare the stored computer names.
  // Check if both client configs have an equal number of names.
  if ( clientComputerNameList->Count != cfg2.clientComputerNameList->Count ) {
    computerCmp = false;
  } else { // If so, check if they are equal
    for (i = 0; i < clientComputerNameList->Count; i++) {
      if ((clientComputerNameList->Strings[i] != cfg2.clientComputerNameList->Strings[i]) ||
          (clientComputerNameList->Objects[i] != cfg2.clientComputerNameList->Objects[i])) {
        computerCmp = false;
        break;
      }
    }
  }
  // Check if both proxy configs have an equal number of names.
  if ( proxyComputerNameList->Count != cfg2.proxyComputerNameList->Count ) {
    computerCmp = false;
  } else { // If so, check if they are equal
    for (i = 0; i < proxyComputerNameList->Count; i++) {
      if ((proxyComputerNameList->Strings[i] != cfg2.proxyComputerNameList->Strings[i]) ||
          (proxyComputerNameList->Objects[i] != cfg2.proxyComputerNameList->Objects[i])) {
        computerCmp = false;
        break;
      }
    }
  }
  return(computerCmp &&
  (readNetworkNamesAfterStart == cfg2.readNetworkNamesAfterStart) &&
  (updateStatusAfterStart == cfg2.updateStatusAfterStart) &&
  (minimizeToSystray == cfg2.minimizeToSystray) &&
  (MaxWaitTime == cfg2.MaxWaitTime) &&
  (LogRefreshTime == cfg2.LogRefreshTime) &&
  (SwitchUserID == cfg2.SwitchUserID) &&
  (useSecureCipher == cfg2.useSecureCipher) &&
  (whichProxyLogFile == cfg2.whichProxyLogFile) &&
  (ServiceToShow == cfg2.ServiceToShow) &&
  (autoRefreshLogs == cfg2.autoRefreshLogs) &&
  (showButtons == cfg2.showButtons) &&
  (showSettings == cfg2.showSettings) &&
  (selectWholeLine == cfg2.selectWholeLine) &&
  (addOnlyNTMachines == cfg2.addOnlyNTMachines) &&
  (writeDebugMessages == cfg2.writeDebugMessages) &&
  (allowNonDomain == cfg2.allowNonDomain) &&
  (scanOutsideDomain == cfg2.scanOutsideDomain) &&
  (activeRC5Challenge == cfg2.activeRC5Challenge) &&
  (startStopClients == cfg2.startStopClients) &&
  (startStopProxies == cfg2.startStopProxies) &&
  (startOnWeekdays == cfg2.startOnWeekdays) &&
  (stopOnWeekdays == cfg2.stopOnWeekdays) &&
  (startOnWeekends == cfg2.startOnWeekends) &&
  (stopOnWeekends == cfg2.stopOnWeekends) &&
  CompareSystemTime(startTimeWeekdays, cfg2.startTimeWeekdays) &&
  CompareSystemTime(stopTimeWeekdays, cfg2.stopTimeWeekdays) &&
  CompareSystemTime(startTimeWeekends, cfg2.startTimeWeekends) &&
  CompareSystemTime(stopTimeWeekends, cfg2.stopTimeWeekends) &&
  !strcmp(ProgramPassword, cfg2.ProgramPassword) &&
  !strncmp(Username, cfg2.Username, sizeof(Username) - 1) &&
  !strncmp(Domain, cfg2.Domain, sizeof(Domain) - 1) &&
  !strncmp(Password, cfg2.Password, sizeof(Password) - 1));
}

//------------------------------------------------------------------------------
// Write settings to inifile.  When RC5 encryption is used, we
// also store the SHA1 hash of the login data.
//------------------------------------------------------------------------------
void __fastcall ProgramCfg::SaveSettings(TIniFile* aIniFile)
{
  TPasswordForm* PwdForm;
  TDCP_rc5* Cipher;
  TDCP_sha1* Hash;
  char CryptBuffer[256], Base64Buffer[256];
  char HashBuffer[256], PasswordHash[20];
  char Digest[21]; // Digest is 21 chars for terminating 0 since Base64Encode needs a string.
  char IniTime[8];

  // Program behaviour
  aIniFile->WriteBool(ProgramIniSection, ReadNetworkIdent, readNetworkNamesAfterStart);
  aIniFile->WriteBool(ProgramIniSection, UpdateAfterStart, updateStatusAfterStart );
  aIniFile->WriteBool(ProgramIniSection, MinimizeToSystray, minimizeToSystray);
  aIniFile->WriteBool(ProgramIniSection, ShowButtons, showButtons);
  aIniFile->WriteBool(ProgramIniSection, ShowSettings, showSettings);
  aIniFile->WriteBool(ProgramIniSection, SelectWholeLine, selectWholeLine);
  // Proxy logfile
  aIniFile->WriteString(ProgramIniSection, LogFileProxy, whichProxyLogFile);
  aIniFile->WriteBool(ProgramIniSection, AutoRefreshLogs, autoRefreshLogs);
  aIniFile->WriteString(ProgramIniSection, ActiveRC5Challenge, activeRC5Challenge);
  // Periodic start/stop times
  aIniFile->WriteBool(ProgramIniSection, StartStopClients, startStopClients);
  aIniFile->WriteBool(ProgramIniSection, StartStopProxies, startStopProxies);
  aIniFile->WriteBool(ProgramIniSection, StartOnWeekdays, startOnWeekdays);
  aIniFile->WriteBool(ProgramIniSection, StopOnWeekdays, stopOnWeekdays);
  aIniFile->WriteBool(ProgramIniSection, StartOnWeekends, startOnWeekends);
  aIniFile->WriteBool(ProgramIniSection, StopOnWeekends, stopOnWeekends);
  sprintf(IniTime, "%02d:%02d", startTimeWeekdays.wHour, startTimeWeekdays.wMinute);
  aIniFile->WriteString(ProgramIniSection, StartTimeWeekdays, IniTime);
  sprintf(IniTime, "%02d:%02d", stopTimeWeekdays.wHour, stopTimeWeekdays.wMinute);
  aIniFile->WriteString(ProgramIniSection, StopTimeWeekdays, IniTime);
  sprintf(IniTime, "%02d:%02d", startTimeWeekends.wHour, startTimeWeekends.wMinute);
  aIniFile->WriteString(ProgramIniSection, StartTimeWeekends, IniTime);
  sprintf(IniTime, "%02d:%02d", stopTimeWeekends.wHour, stopTimeWeekends.wMinute);
  aIniFile->WriteString(ProgramIniSection, StopTimeWeekends, IniTime);
  // See if we start with client or proxy data
  if ( ServiceToShow == serviceProxy )
    aIniFile->WriteString(ProgramIniSection, ServiceStartUp, serviceProxy);
  else
    aIniFile->WriteString(ProgramIniSection, ServiceStartUp, serviceClient);
  // Do we want to run the program as a different user?
  aIniFile->WriteBool(ProgramIniSection, SwitchUser, SwitchUserID);
  aIniFile->WriteBool(ProgramIniSection, AddOnlyNTMachines, addOnlyNTMachines);
  aIniFile->WriteBool(ProgramIniSection, WriteDebugMessages, writeDebugMessages);
  aIniFile->WriteBool(ProgramIniSection, AllowNonDomain, allowNonDomain);
  aIniFile->WriteBool(ProgramIniSection, ScanOutsideDomain, scanOutsideDomain);
  // How do we want to encrypt the login data
  aIniFile->WriteBool(ProgramIniSection, UseSecureCipher, useSecureCipher);
  // Encrypt the user data
  if ( !useSecureCipher ) { // Use a fixed password
    strcpy(ProgramPassword, DefaultPassword);
  } else { // Encrypt login data with RC5
    // Ask for password if none set
    if ( !strlen(ProgramPassword) || !strcmp(ProgramPassword, DefaultPassword) ) {
      PwdForm = new TPasswordForm(NULL, ProgramPassword, sizeof(ProgramPassword) - 1, true, "New program password unknown, please enter");
      if ( PwdForm ) {
        PwdForm->ShowModal();
        delete PwdForm;
      }
    }
  }
  if ( strlen(Username) ) { // If account data used
    // Create an instance of the RC5 class
    Cipher = new TDCP_rc5(NULL);
    // Initialise the RC5 cipher with the password
    GetHashFromPassword(ProgramPassword, PasswordHash, sizeof(PasswordHash));
    Cipher->Init(PasswordHash, sizeof(PasswordHash) * 8, NULL);  // remember key size is in BITS
    // Username
    memset(CryptBuffer, 0, sizeof(CryptBuffer));
    Cipher->EncryptCBC(Username, CryptBuffer, sizeof(Username));
    CryptBuffer[sizeof(Username)] = 0; // Zero-terminate string
    Base64Encode(CryptBuffer, Base64Buffer, sizeof(Username), sizeof(Base64Buffer));
    aIniFile->WriteString(ProgramIniSection, "Account", Base64Buffer);
    // Password
    memset(CryptBuffer, 0, sizeof(CryptBuffer));
    Cipher->EncryptCBC(Password, CryptBuffer, sizeof(Password));
    CryptBuffer[sizeof(Password)] = 0; // Zero-terminate string
    Base64Encode(CryptBuffer, Base64Buffer, sizeof(Password), sizeof(Base64Buffer));
    aIniFile->WriteString(ProgramIniSection, "Password", Base64Buffer);
    // Domain
    memset(CryptBuffer, 0, sizeof(CryptBuffer));
    Cipher->EncryptCBC(Domain, CryptBuffer, sizeof(Domain));
    CryptBuffer[sizeof(Domain)] = 0; // Zero-terminate string
    Base64Encode(CryptBuffer, Base64Buffer, sizeof(Domain), sizeof(Base64Buffer));
    aIniFile->WriteString(ProgramIniSection, "Domain", Base64Buffer);
    Cipher->Burn();
    delete Cipher;
    // Save a hashed value of the login data:
    memset(HashBuffer, 0, sizeof(HashBuffer));
    memset(Digest, 0, sizeof(Digest));
    strcpy(HashBuffer, Username);
    strcat(HashBuffer, Password);
    strcat(HashBuffer, Domain);
    Hash = new TDCP_sha1(NULL);
    Hash->Init();
    Hash->Update(HashBuffer, strlen(HashBuffer));
    Hash->Final(Digest); // Get hash value of the login data
    Base64Encode(Digest, Base64Buffer, sizeof(Digest), sizeof(Base64Buffer));
    aIniFile->WriteString(ProgramIniSection, "Check", Base64Buffer);
    delete Hash;
  } else { // Empty the login strings
    aIniFile->WriteString(ProgramIniSection, "Account", "");
    aIniFile->WriteString(ProgramIniSection, "Password", "");
    aIniFile->WriteString(ProgramIniSection, "Domain", "");
    aIniFile->WriteString(ProgramIniSection, "Check", "");
    useSecureCipher = false;
    aIniFile->WriteBool(ProgramIniSection, UseSecureCipher, useSecureCipher);
  }
  // Store the computer names
  WriteComputerNames(aIniFile);
}

//------------------------------------------------------------------------------
// Get a SHA1 hash from the password to use as password ofor the RC5 cipher.
// This is more secure. buffsize contains the size of aPasswordHash.
//------------------------------------------------------------------------------
void __fastcall ProgramCfg::GetHashFromPassword(char aPassword[], char aPasswordHash[], size_t buffsize)
{
  memset(aPasswordHash, 0, buffsize);
  TDCP_sha1* Hash = new TDCP_sha1(NULL);
  if ( Hash ) {
    Hash->Init();
    Hash->Update(aPassword, strlen(aPassword));
    Hash->Final(aPasswordHash);
    delete Hash;
  }
}

//------------------------------------------------------------------------------
// Writes the stored computernames to the program inifile.
//------------------------------------------------------------------------------
void __fastcall ProgramCfg::WriteComputerNames(TIniFile* aIniFile)
{
  int i;
  // First delete all client computer names
  aIniFile->EraseSection(ComputerNamesIniSection);
  // Now write them out again
  for (i = 0; i < clientComputerNameList->Count; i++)
    aIniFile->WriteInteger(ComputerNamesIniSection, clientComputerNameList->Strings[i], (int)clientComputerNameList->Objects[i]);
  // First delete all proxy computer names
  aIniFile->EraseSection(ProxyComputerNamesIniSection);
  for (i = 0; i < proxyComputerNameList->Count; i++)
    aIniFile->WriteInteger(ProxyComputerNamesIniSection, proxyComputerNameList->Strings[i], (int)proxyComputerNameList->Objects[i]);
}

//------------------------------------------------------------------------------
// Read settings from inifile. When RC5 encryption is used, we check
// if the stored SHA1 hash of the login data matches.
//------------------------------------------------------------------------------
void __fastcall ProgramCfg::ReadSettings(TIniFile* aIniFile)
{
  AnsiString AccountCheck;
  bool askForPassword;
  int i;
  AnsiString IniTime;
  int passwordResult = 0;

  TPasswordForm* PwdForm;
  // Read all computernames from the ini file
  aIniFile->ReadSection(ComputerNamesIniSection, clientComputerNameList);
  aIniFile->ReadSection(ProxyComputerNamesIniSection, proxyComputerNameList);
  // Read if they are checked or not. Store this in the Object part of the StringList.
  for (i = 0; i < clientComputerNameList->Count; i++)
    clientComputerNameList->Objects[i] = (TObject*)aIniFile->ReadInteger(ComputerNamesIniSection, clientComputerNameList->Strings[i], 0);
  for (i = 0; i < proxyComputerNameList->Count; i++)
    proxyComputerNameList->Objects[i] = (TObject*)aIniFile->ReadInteger(ProxyComputerNamesIniSection, proxyComputerNameList->Strings[i], 0);
  // Check if we should read network names. Default is false.
  readNetworkNamesAfterStart = aIniFile->ReadBool(ProgramIniSection, ReadNetworkIdent, false);
  // Check how the program should minimize
  minimizeToSystray = aIniFile->ReadBool(ProgramIniSection, MinimizeToSystray, false);
  // Check which proxy logfile we want to see and if we want it to auto-refresh
  whichProxyLogFile = aIniFile->ReadString(ProgramIniSection, LogFileProxy, conLogFile);
  // Do we want logfiles to auto-refresh?
  autoRefreshLogs = aIniFile->ReadBool(ProgramIniSection, AutoRefreshLogs, true);
  // Which RC5 challenge is currently active?
  activeRC5Challenge = aIniFile->ReadString(ProgramIniSection, ActiveRC5Challenge, activeRC5Challenge);
  // Do we want to see the buttonpanel and settingspanel
  showButtons = aIniFile->ReadBool(ProgramIniSection, ShowButtons, true);
  showSettings = aIniFile->ReadBool(ProgramIniSection, ShowSettings, true);
  selectWholeLine = aIniFile->ReadBool(ProgramIniSection, SelectWholeLine, true);
  // Which service do we show on program start?
  ServiceToShow = aIniFile->ReadString(ProgramIniSection, ServiceStartUp, serviceClient);
  // Maximum time we wait on the service to obtain a certain state
  MaxWaitTime = aIniFile->ReadInteger(ProgramIniSection, MaxWaitTime, 5);
  // Refreshtime for the logfile
  LogRefreshTime = aIniFile->ReadInteger(ProgramIniSection, LogRefreshTime, 60);
  // See if we want to switch to another accocunt. Default is we don't.
  SwitchUserID = aIniFile->ReadBool(ProgramIniSection, SwitchUser, false);
  // See if we update the statusinfo after start.
  updateStatusAfterStart = aIniFile->ReadBool(ProgramIniSection, UpdateAfterStart, true);
  // What do we want to see in "rescan network"?
  addOnlyNTMachines = aIniFile->ReadBool(ProgramIniSection, AddOnlyNTMachines, true);
  // Do we want to write debug messages?
  writeDebugMessages = aIniFile->ReadBool(ProgramIniSection, WriteDebugMessages, false);
  // Do we allow local machines not in domain?
  allowNonDomain = aIniFile->ReadBool(ProgramIniSection, AllowNonDomain, false);
  // Do we allow scanning the network outside the local domain?
  scanOutsideDomain = aIniFile->ReadBool(ProgramIniSection, ScanOutsideDomain, false);
  // See how we want to encrypt the login data
  useSecureCipher = aIniFile->ReadBool(ProgramIniSection, UseSecureCipher, false);
  // Read periodic start/stop times
  startStopClients = aIniFile->ReadBool(ProgramIniSection, StartStopClients, false);
  startStopProxies = aIniFile->ReadBool(ProgramIniSection, StartStopProxies, false);
  startOnWeekdays = aIniFile->ReadBool(ProgramIniSection, StartOnWeekdays, false);
  stopOnWeekdays  = aIniFile->ReadBool(ProgramIniSection, StopOnWeekdays, false);
  startOnWeekends = aIniFile->ReadBool(ProgramIniSection, StartOnWeekends, false);
  stopOnWeekends  = aIniFile->ReadBool(ProgramIniSection, StopOnWeekends, false);
  memset(&startTimeWeekdays, 0, sizeof(SYSTEMTIME));
  memset(&stopTimeWeekdays, 0, sizeof(SYSTEMTIME));
  memset(&startTimeWeekends, 0, sizeof(SYSTEMTIME));
  memset(&stopTimeWeekends, 0, sizeof(SYSTEMTIME));
  IniTime = aIniFile->ReadString(ProgramIniSection, StartTimeWeekdays, "00:00");
  sscanf(IniTime.c_str(), "%02d:%02d", &startTimeWeekdays.wHour, &startTimeWeekdays.wMinute);
  startTimeWeekdays.wDayOfWeek = 1;
  IniTime = aIniFile->ReadString(ProgramIniSection, StopTimeWeekdays, "00:00");
  sscanf(IniTime.c_str(), "%02d:%02d", &stopTimeWeekdays.wHour, &stopTimeWeekdays.wMinute);
  stopTimeWeekdays.wDayOfWeek = 5;
  IniTime = aIniFile->ReadString(ProgramIniSection, StartTimeWeekends, "00:00");
  sscanf(IniTime.c_str(), "%02d:%02d", &startTimeWeekends.wHour, &startTimeWeekends.wMinute);
  startTimeWeekends.wDayOfWeek = 6;
  IniTime = aIniFile->ReadString(ProgramIniSection, StopTimeWeekends, "00:00");
  sscanf(IniTime.c_str(), "%02d:%02d", &stopTimeWeekends.wHour, &stopTimeWeekends.wMinute);
  stopTimeWeekends.wDayOfWeek = 0;
  // Read account data if stored.
  AccountCheck = aIniFile->ReadString(ProgramIniSection, "Account", "");
  try {
    if ( AccountCheck.Length() ) {
      if ( !useSecureCipher ) { // Use default password
        strcpy(ProgramPassword, DefaultPassword);
          ReadEncryptedLoginData(aIniFile);
      } else {
        // Ask for password first. Continue asking until the user pressed no or the
        // correct password is entered.
        askForPassword = true;
        do {
          PwdForm = new TPasswordForm(NULL, ProgramPassword, sizeof(ProgramPassword) - 1, false, "Please enter program password to access logon data");
          if ( PwdForm ) {
            passwordResult = PwdForm->ShowModal();
            delete PwdForm;
          }
          if ( passwordResult == mrOk ) {
            if ( !ReadEncryptedLoginData(aIniFile) ) { // Wrong password
              if ( Application->MessageBox("Wrong password entered, retry?", Application->Title.c_str(), MB_YESNO) == ID_NO ) {
                askForPassword = false;
                Application->MessageBox("Incorrect password, this program will not run as another user.", Application->Title.c_str(), MB_OK);
                // Clear the login data
                memset(Username, 0, sizeof(Username));
                memset(Domain, 0, sizeof(Domain));
                memset(Password, 0, sizeof(Password));
                memset(ProgramPassword, 0, sizeof(ProgramPassword));
                SwitchUserID = false;
                useSecureCipher = false;
                strcpy(ProgramPassword, DefaultPassword);
              }
            } else { // Good password entered
              askForPassword = false;
            }
          } else if ( passwordResult == mrCancel ) {
            Application->MessageBox("Cancel pressed, this program will not run as another user.", Application->Title.c_str(), MB_OK);
          }
        } while ( askForPassword && (passwordResult != mrCancel) );
      }
    }
  } catch (Exception& exception) { // Error in Base64 stuff
    // Clear the login data
    memset(Username, 0, sizeof(Username));
    memset(Domain, 0, sizeof(Domain));
    memset(Password, 0, sizeof(Password));
    memset(ProgramPassword, 0, sizeof(ProgramPassword));
    SwitchUserID = false;
    useSecureCipher = false;
    // Set default password
    strcpy(ProgramPassword, DefaultPassword);
    Application->ShowException(&exception);
  }
}

//------------------------------------------------------------------------------
// Read the encrypted login data. Returns true if the decrypted data matches
// the stored hash.
//------------------------------------------------------------------------------
bool __fastcall ProgramCfg::ReadEncryptedLoginData(TIniFile* aIniFile)
{
  AnsiString readText, storedHashString;
  TDCP_rc5* Cipher;
  TDCP_sha1* Hash;
  char CryptBuffer[256], Base64Buffer[256];
  char HashBuffer[256], PasswordHash[20];
  char Digest[21]; // Digest is 21 chars for terminating 0 since Base64Encode needs a string.

  // Read the account data with RC5
  Cipher = new TDCP_rc5(NULL); // Create an instance of the RC5 class
  // Initialise the RC5 cipher with the password
  GetHashFromPassword(ProgramPassword, PasswordHash, sizeof(PasswordHash));
  Cipher->Init(PasswordHash, sizeof(PasswordHash) * 8, NULL);  // remember key size is in BITS
  // Username
  memset(CryptBuffer, 0, sizeof(CryptBuffer));
  readText = aIniFile->ReadString(ProgramIniSection, "Account", "");
  Base64Decode(readText.c_str(), CryptBuffer, readText.Length(), sizeof(CryptBuffer));
  Cipher->DecryptCBC(CryptBuffer, Username, sizeof(Username));
  // Password
  memset(CryptBuffer, 0, sizeof(CryptBuffer));
  readText = aIniFile->ReadString(ProgramIniSection, "Password", "");
  Base64Decode(readText.c_str(), CryptBuffer, readText.Length(), sizeof(CryptBuffer));
  Cipher->DecryptCBC(CryptBuffer, Password, sizeof(Password));
  // Domain
  memset(CryptBuffer, 0, sizeof(CryptBuffer));
  readText = aIniFile->ReadString(ProgramIniSection, "Domain", "");
  Base64Decode(readText.c_str(), CryptBuffer, readText.Length(), sizeof(CryptBuffer));
  Cipher->DecryptCBC(CryptBuffer, Domain, sizeof(Domain));
  Cipher->Burn();
  delete Cipher;
  // Check the hash of the CRC of the login info:
  storedHashString = aIniFile->ReadString(ProgramIniSection, "Check", "");
  memset(HashBuffer, 0, sizeof(HashBuffer));
  memset(Digest, 0, sizeof(Digest));
  // Hashbuffer is of the form loginpassworddomain
  strcpy(HashBuffer, Username);
  strcat(HashBuffer, Password);
  strcat(HashBuffer, Domain);
  Hash = new TDCP_sha1(NULL);
  Hash->Init();
  Hash->Update(HashBuffer, strlen(HashBuffer));
  Hash->Final(Digest);
  delete Hash;
  Base64Encode(Digest, Base64Buffer, sizeof(Digest), sizeof(Base64Buffer));
  if ( storedHashString != AnsiString(Base64Buffer) )
    return false; // They do not match
  else
    return true;
}

//------------------------------------------------------------------------------
// End of ProgramCfg methods.
//------------------------------------------------------------------------------

