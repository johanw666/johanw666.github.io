//------------------------------------------------------------------------------
// This file is part of Remote Service Control Center by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: sccclass.h
//------------------------------------------------------------------------------
// Unit with supporting classes for the main program
//------------------------------------------------------------------------------
#ifndef sccclassH
#define sccclassH

#include <inifiles.hpp>

// Default password if none chosen.
extern const char DefaultPassword[];
// Inifile keys
extern const AnsiString ComputerNamesIniSection;
extern const AnsiString ProxyComputerNamesIniSection;
extern const AnsiString SwitchUser;
extern const AnsiString ProgramIniSection;
extern const AnsiString ReadNetworkIdent;
extern const AnsiString DestinationKey;
extern const AnsiString DestinationSection;
extern const AnsiString UpdateAfterStart;
extern const AnsiString ServiceStartUp;
extern const AnsiString serviceClient;
extern const AnsiString serviceProxy;
extern const AnsiString MaxWaitTime;
extern const AnsiString LogRefreshTime;
extern const AnsiString MinimizeToSystray;
extern const AnsiString LogFileProxy;
extern const AnsiString conLogFile;
extern const AnsiString rc5LogFile;
extern const AnsiString ogrLogFile;
extern const AnsiString ogrp2LogFile;
extern const AnsiString ActiveRC5Challenge;
extern const AnsiString AutoRefreshLogs;
extern const AnsiString ShowSettings;
extern const AnsiString ShowButtons;
extern const AnsiString SelectWholeLine;
extern const AnsiString UseSecureCipher;
extern const AnsiString AddOnlyNTMachines;
extern const AnsiString WriteDebugMessages;
extern const AnsiString AllowNonDomain;
extern const AnsiString ScanOutsideDomain;
extern const AnsiString StartStopClients;
extern const AnsiString StartStopProxies;
extern const AnsiString StartOnWeekdays;
extern const AnsiString StopOnWeekdays;
extern const AnsiString StartOnWeekends;
extern const AnsiString StopOnWeekends;
extern const AnsiString StartTimeWeekdays;
extern const AnsiString StopTimeWeekdays;
extern const AnsiString StartTimeWeekends;
extern const AnsiString StopTimeWeekends;
extern const AnsiString TopPos;
extern const AnsiString LeftPos;
extern const AnsiString FormHeight;
extern const AnsiString FormWidth;
extern const AnsiString NameColumnWidth;
extern const AnsiString StatusColumnWidth;
extern const AnsiString PathColumnWidth;
extern const AnsiString VersionColumnWidth;
extern const AnsiString EmailColumnWidth;
extern const AnsiString pNameColumnWidth;
extern const AnsiString pStatusColumnWidth;
extern const AnsiString pPathColumnWidth;
extern const AnsiString pVersionColumnWidth;
extern const AnsiString pEmailColumnWidth;

//------------------------------------------------------------------------------
// Struct to store the service paramaters
//------------------------------------------------------------------------------
class ServiceParams
{
private:
  // Comparing function for operator== and !=
  bool __fastcall Compare(const ServiceParams& cfg2) const;
public:
  __fastcall ServiceParams(void);
  __fastcall ~ServiceParams();
  const ServiceParams& __fastcall operator=(const ServiceParams& cfg2);
  bool __fastcall operator==(const ServiceParams& cfg2) const;
  bool __fastcall operator!=(const ServiceParams& cfg2) const;
  // Check data before installing the service
  bool IsSufficientDataAvailable(void);
  // Read and store data to inifile.
  void __fastcall SaveSettings(TIniFile* file);
  void __fastcall ReadSettings(TIniFile* file);
  // Data
  char IniSection[32];         // Section in the inifile to store the params.
  char ExeFrom[MAX_PATH];      // Path and name of the executable to copy to the remote machine
  char IniFrom[MAX_PATH];      // Path and name of the inifile to copy to the remote machine
  char DirectoryTo[MAX_PATH];  // Directory on the remote machine to copy the file to
  char RemoteName[MAX_PATH];   // The name of the executable on the remote computer (without extension)
  char ServiceName[256];       // Service name
  char DisplayName[MAX_PATH];  // Service display name
  char BootParams[256];
  // Startup values
  bool StartOnInstall;         // true means start service after install
  bool StartOnBoot;            // true means start on PC boot
  char DestinationSection[64]; // Section in inifile to lookup in 4rth column
  char DestinationKey[64];     // Field in inifile to lookup in 4rth column
};

//------------------------------------------------------------------------------
// Data to call ChangeServiceConfig with
//------------------------------------------------------------------------------
struct ChangeServiceConfigData
{
  DWORD dwServiceType;             // type of service
  DWORD dwStartType;               // when to start service
  DWORD dwErrorControl;            // severity if service fails to start
  char lpBinaryPathName[MAX_PATH]; // pointer to service binary file name
  char lpDisplayName[MAX_PATH];    // pointer to display name
  char lpServiceStartName[MAX_PATH]; // Pointer to account name for service
  char lpPassword[MAX_PATH];       // Pointer to password
};

//------------------------------------------------------------------------------
// Data that describes type configuration of the program. This data is saved
// to the inifile.
//------------------------------------------------------------------------------
class ProgramCfg
{
private:
  void __fastcall GetHashFromPassword(char aPassword[], char aPasswordHash[], size_t buffsize);
  // Comparing function for operator== and !=
  bool __fastcall Compare(const ProgramCfg& cfg2) const;
  bool __fastcall ReadEncryptedLoginData(TIniFile* aIniFile);
  void __fastcall WriteComputerNames(TIniFile* aIniFile);
public:
  __fastcall ProgramCfg(void);
  __fastcall ~ProgramCfg();
  const ProgramCfg& __fastcall operator=(const ProgramCfg& cfg2);
  bool __fastcall operator==(const ProgramCfg& cfg2) const;
  bool __fastcall operator!=(const ProgramCfg& cfg2) const;
  // Read and store data to inifile.
  void __fastcall SaveSettings(TIniFile* aIniFile);
  void __fastcall ReadSettings(TIniFile* aIniFile);
  // Data
  bool readNetworkNamesAfterStart;
  bool updateStatusAfterStart;
  bool minimizeToSystray;
  int MaxWaitTime;      // Maximum time to wait for timeout
  int LogRefreshTime;   // Time interval for logfiles to refresh
  bool SwitchUserID;    // True: try to gain extra priviliges; false: don't.
  bool useSecureCipher; // True: use RC5 to encrypt the login data with a password.
  char ProgramPassword[128]; // Password to encrypt login data with
  AnsiString whichProxyLogFile; // Which proxy logfile to show
  AnsiString ServiceToShow; // Service to show on startup
  AnsiString activeRC5Challenge; // Which RC5 challenge (64, 72, ...) used for logfile lines
  bool autoRefreshLogs;
  bool showButtons;
  bool showSettings;
  bool selectWholeLine;
  bool addOnlyNTMachines;
  bool writeDebugMessages;
  bool allowNonDomain;
  bool scanOutsideDomain;
  // Data regarding the starting/stopping the services periodically
  bool startStopClients;
  bool startStopProxies;
  bool startOnWeekdays;
  bool stopOnWeekdays;
  bool startOnWeekends;
  bool stopOnWeekends;
  SYSTEMTIME startTimeWeekdays;
  SYSTEMTIME stopTimeWeekdays;
  SYSTEMTIME startTimeWeekends;
  SYSTEMTIME stopTimeWeekends;
  // Login data
  char Username[64];  // string that specifies the user name
  char Domain[64];    // string that specifies the domain or server
  char Password[128]; // string that specifies the password
  // Computer names
  TStringList* clientComputerNameList;
  TStringList* proxyComputerNameList;
};


//---------------------------------------------------------------------------
#endif

