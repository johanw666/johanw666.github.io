//------------------------------------------------------------------------------
// This file is part of Remote Service Control Center by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: scc.h
//------------------------------------------------------------------------------
#ifndef sccH
#define sccH
//------------------------------------------------------------------------------
#include <stdarg.h>
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <inifiles.hpp>
#include <ExtCtrls.hpp>
#include <Mask.hpp>
#include <Menus.hpp>
#include <ComCtrls.hpp>

#include "sccclass.h"
//------------------------------------------------------------------------------
// Program constants
//------------------------------------------------------------------------------
// How did the program exit (used for saving its settings)
const int PRG_CLOSE_OTHER  = 0; // Other close command (like the caption bar button)
const int PRG_CLOSE_EXIT   = 1; // Exit button pressed
const int PRG_CLOSE_CANCEL = 2; // Cancel button pressed
// User defined message
const UINT WM_SCAN_THREAD_READY   = WM_USER + 1; // Network scan ready notification
const UINT WM_TRAYNOTIFY          = WM_USER + 2; // Double click on the tray icon
const UINT WM_CLOSE_VIEW_LOGFILE  = WM_USER + 3; // logfile view form close notification
// Update status
const WPARAM DO_NOT_UPDATE_STATUS = 0;
const WPARAM DO_UPDATE_STATUS     = 1;
// System tray
const int IDC_TRAY1 = 1005;
// Automatic start/stop functions
const int UPD_PROXY = 0;
const int UPD_CLIENT = 1;

//------------------------------------------------------------------------------
// generic error message handler
void __fastcall ShowErrorMessage(char aHeaderText[], DWORD* errCode);
void __fastcall GetErrormessage(DWORD* errCode, char* buffer, size_t buffSize);
// Get the type of a remote server
long __fastcall GetRemotePlatformType(const char* servername);
// Conversion to- and from unicode (required for GetRemotePlatformType).
const char* UnicodeToAnsi(const void* ustr, char* outbuf, size_t bufflen);
LPCWSTR AnsiToUnicode(const char* astr, wchar_t* outbuf, size_t bufflen);

// Debug functions.
void __fastcall WriteDebugString(char* fileName, char* msg);
extern AnsiString tracefile;

// The main form and all its functionality
class TMainForm: public TForm
{
__published:
  TListView* clientComputersListView;
  TListView* proxyComputersListView;
  TPanel* SettingsPanel;
  TPanel* ButtonPanel;
  TPanel* Panel4;
  TButton* ExitButton;
  TButton* InstallButton;
  TButton* RemoveButton;
  TButton* StartButton;
  TButton* StopButton;
  TButton* AddPCButton;
  TButton* RemPCButton;
  TButton* ConfigButton;
  TButton* EditIniButton;
  TButton* UpdateButton;
  TButton* DefaultButton;
  TGroupBox* ServiceGroupBox;
  TRadioButton* ClientRadioButton;
  TRadioButton* PerProxyRadioButton;
  TButton* CancelButton;
  TButton* HelpButton;
  TButton* NetworkButton;
  TMainMenu* RsccMainMenu;
  TPopupMenu* RsccPopupMenu;
  TMenuItem* File1;
  TMenuItem* Exit1;
  TMenuItem* Service1;
  TMenuItem* Installservice1;
  TMenuItem* Removeservice1;
  TMenuItem* Stopservice1;
  TMenuItem* Addcomputer1;
  TMenuItem* Removecomputers1;
  TMenuItem* Configure1;
  TMenuItem* Updatestatus1;
  TMenuItem* Defaultsetup1;
  TMenuItem* Addnetworkedcomputers1;
  TMenuItem* Help1;
  TMenuItem* About1;
  TMenuItem* Help2;
  TMenuItem* Startservice1;
  TMenuItem* Cancel1;
  TMenuItem* Installservice2;
  TMenuItem* Removeservice2;
  TMenuItem* Startservice2;
  TMenuItem* Stopservice2;
  TMenuItem* Computername1;
  TMenuItem* N1;
  TMenuItem* Configureservice2;
  TMenuItem* Computers1;
  TMenuItem* EditIni2;
  TMenuItem* EditIni1;
  TButton*   SwitchAccountButton;
  TMenuItem* AccountItem1;
  TMenuItem* Updateservice1;
  TButton* ReinstallServiceButton;
  TMenuItem* Updateservice2;
  TButton* UpdateServiceButton;
  TMenuItem* Reinstallservice1;
  TMenuItem* Reinstallservice2;
  TMenuItem* Preferences1;
  TMenuItem* Logfile2;
  TMenuItem* Logfile1;
  TMenuItem* BAR0;
  TMenuItem* BAR1;
  TMenuItem* BAR2;
  TMenuItem* BAR3;
  TMenuItem* BAR4;
  TButton* LogfileButton;
  TPopupMenu* TrayPopupMenu;
  TMenuItem* Closeprogram3;
  TMenuItem* Exitprogram3;
  TMenuItem* Restore3;
  TMenuItem* N2;
  TMenuItem* Progname3;
  TMenuItem* Savesettings1;
  TMenuItem* DefaultPassword1;
  TMenuItem* Password1;
  TMenuItem* ShowButtons1;
  TMenuItem* ShowSettings1;
  TMenuItem* ReloadServiceConfiguration1;
  TMenuItem* ReloadServiceConfiguration2;
  TMenuItem* Client1;
  TMenuItem* Fetch1;
  TMenuItem* Flush1;
  TMenuItem* Update1;
  TMenuItem* Proxy1;
  TMenuItem* Connect1;
  TMenuItem* Client2;
  TMenuItem* Proxy2;
  TMenuItem* Fetch2;
  TMenuItem* Flush2;
  TMenuItem* Update2;
  TMenuItem* Connect2;
  TMenuItem* settings1;
  TButton* MinimizeButton;
  TMenuItem* ViewDebugFile1;
  TMenuItem* Pauseservice1;
  TMenuItem* Continueservice1;
  TMenuItem* BAR5;
  TMenuItem* Localproxyconnect1;
  TMenuItem* Localproxyshutdown1;
  TMenuItem* Localproxyreload1;
  TMenuItem* BAR6;
  TMenuItem* Localproxyconnect2;
  TMenuItem* Localproxyshutdown2;
  TMenuItem* Localproxyreload2;
  TMenuItem* BAR7;
  TMenuItem* ViewConlog1;
  TMenuItem* ViewRC5log1;
  TMenuItem* ViewOGRlog1;
  TMenuItem* ViewOGRP2log1;
  TMenuItem* BAR8;
  TMenuItem* UncheckAll1;
  TMenuItem* CheckAll1;
  TMenuItem* Window1;
  TPanel* WaitThreadPanel;
  TLabel* WaitThreadLabel;
  TLabel* InfoThreadLabel;
  TPanel* WaitUpdatePanel;
  TLabel* WaitUpdateLabel;
  TLabel* InfoUpdateLabel;
  TTimer* PeriodicStartStopTimer;
  void __fastcall FormShow(TObject* Sender);
  void __fastcall FormClose(TObject* Sender, TCloseAction& Action);
  void __fastcall DefaultButtonClick(TObject* Sender);
  void __fastcall ExitButtonClick(TObject* Sender);
  void __fastcall AddPCButtonClick(TObject* Sender);
  void __fastcall RemPCButtonClick(TObject* Sender);
  void __fastcall InstallButtonClick(TObject* Sender);
  void __fastcall RadioButtonClick(TObject* Sender);
  void __fastcall UpdateButtonClick(TObject* Sender);
  void __fastcall UpdateServiceButtonClick(TObject* Sender);
  void __fastcall AboutButtonClick(TObject* Sender);
  void __fastcall ConfigButtonClick(TObject* Sender);
  void __fastcall RemoveButtonClick(TObject* Sender);
  void __fastcall StopButtonClick(TObject* Sender);
  void __fastcall StartButtonClick(TObject* Sender);
  void __fastcall CancelButtonClick(TObject* Sender);
  void __fastcall NetworkButtonClick(TObject* Sender);
  void __fastcall ComputersListViewKeyDown(TObject* Sender, WORD& Key, TShiftState Shift);
  void __fastcall HelpButtonClick(TObject* Sender);
  void __fastcall RsccPopupMenuPopup(TObject* Sender);
  void __fastcall ComputersListViewMouseDown(TObject* Sender, TMouseButton Button, TShiftState Shift, int X, int Y);
  void __fastcall ComputersListViewClick(TObject* Sender);
  void __fastcall EditIniButtonClick(TObject* Sender);
  void __fastcall SwitchAccountButtonClick(TObject* Sender);
  void __fastcall ReinstallServiceButtonClick(TObject* Sender);
  void __fastcall clientComputersListViewColumnClick(TObject* Sender, TListColumn* Column);
  void __fastcall proxyComputersListViewColumnClick(TObject* Sender, TListColumn* Column);
  void __fastcall ComputersListViewCompare(TObject* Sender, TListItem* Item1, TListItem* Item2, int Data, int& Compare);
  void __fastcall Logfile1Click(TObject* Sender);
  void __fastcall Restore3Click(TObject* Sender);
  void __fastcall Savesettings1Click(TObject* Sender);
  void __fastcall DefaultPassword1Click(TObject* Sender);
  void __fastcall Password1Click(TObject* Sender);
  void __fastcall ShowButtons1Click(TObject* Sender);
  void __fastcall ShowSettings1Click(TObject* Sender);
  void __fastcall ReloadServiceConfiguration1Click(TObject* Sender);
  void __fastcall Fetch1Click(TObject* Sender);
  void __fastcall Flush1Click(TObject* Sender);
  void __fastcall Update1Click(TObject* Sender);
  void __fastcall Connect1Click(TObject* Sender);
  void __fastcall settings1Click(TObject* Sender);
  void __fastcall MinimizeButtonClick(TObject* Sender);
  void __fastcall ViewDebugFile1Click(TObject* Sender);
  void __fastcall Pauseservice1Click(TObject* Sender);
  void __fastcall Continueservice1Click(TObject* Sender);
  void __fastcall Localproxyconnect1Click(TObject* Sender);
  void __fastcall Localproxyshutdown1Click(TObject* Sender);
  void __fastcall Localproxyreload1Click(TObject* Sender);
  void __fastcall ViewConLog1Click(TObject* Sender);
  void __fastcall ViewRC5Log1Click(TObject* Sender);
  void __fastcall ViewOGRLog1Click(TObject* Sender);
  void __fastcall ViewOGRP2log1Click(TObject* Sender);  
  void __fastcall CheckAll1Click(TObject* Sender);
  void __fastcall UncheckAll1Click(TObject* Sender);
  void __fastcall PeriodicStartStopTimerTimer(TObject* Sender);
private:
  DWORD __fastcall GetWin32Platform(char* versionText, size_t buffSize);
  void __fastcall ReadDefaultsFromIni(ServiceParams* aCfg);
  void __fastcall ReadComputerNames(void);
  bool __fastcall IsServiceManagerInstalled(char aComputername[]);
  bool __fastcall IsServiceInstalled(char aComputerName[]);
  bool __fastcall IsServiceRunning(char aComputername[]);
  void __fastcall GetNetworkComputerNames(bool waitForResult, bool aRunUpdateAfterwards);
  bool __fastcall WaitForServiceToReachStatus(SC_HANDLE aHService, DWORD aServiceStatus, int max_wait_seconds, char aMachineName[]);
  void __fastcall ReadIniSettings(void);
  void __fastcall SaveIniSettings(void);
  DWORD __fastcall GetServiceStatus(char aComputerName[], char aServiceName[]);
  void __fastcall EnableClientOrProxySpecificOptions(bool enableClientOptions, bool enableProxyOptions);
  void __fastcall GetServicePath(char computerName[], char* servicePathBuffer, size_t buffSize);
  void __fastcall GetExecutableName(char aComputerName[], char aPathName[], char networkPath[]);
  void __fastcall UpdateStatus(int index, bool updateAll, bool alwaysUpdateVersionAndIni, TListView* viewToUpdate);
  void __fastcall StoreComputerNames(void);
  void __fastcall FillListOfBufferFiles(char* remoteIniFileName, char* remoteMachineName, TStringList* oldNames, TStringList* newNames);
  char* __fastcall ExtractFileNameWithoutExt(const char* aFileName, char* buffer, size_t buffSize);
  AnsiString __fastcall FindClientLogfileName(TIniFile* clientIniFile, char iniFileName[], bool* logFileDefined);
  AnsiString __fastcall ServiceStateDescription(DWORD serviceState);
  AnsiString __fastcall ControlcodeDescription(DWORD dwControl);
  DWORD __fastcall GetResultingStatusFromControlCode(DWORD dwControl);
  bool __fastcall CheckResponseFromClient(DWORD dwControl, DWORD responseCode);
  void __fastcall SendSignalToRemoteService(DWORD dwControl);
  void __fastcall SendStandardSignalToRemoteService(DWORD dwControl);
  // Default info when starting up rscc
  void __fastcall SetClientDefaults(void);
  void __fastcall SetProxyDefaults(void);
  bool __fastcall SetServiceDefaults(ServiceParams* spars);
  // Infocreen when lengthy network stuff is in progress
  void __fastcall ShowThreadWaitInfo(void);
  void __fastcall HideThreadWaitInfo(void);
  void __fastcall ShowUpdateWaitInfo(void);
  void __fastcall HideUpdateWaitInfo(void);
  void __fastcall SetUpdateWaitText(AnsiString label, AnsiString info);
  // Logscreen
  void __fastcall AddNode(TList* l, TObject* o, AnsiString caption);
  class TViewLogFileForm* __fastcall CheckForDoubleFile(AnsiString caption);
  void __fastcall WindowClick(TObject* Sender);
  // Functions that offer debug options
  BOOL RSCC_ControlService(SC_HANDLE hService, DWORD dwControl, LPSERVICE_STATUS lpServiceStatus, bool writedebuginfo, char* computername);
  BOOL RSCC_StartService(SC_HANDLE hService, DWORD dwNumServiceArgs, LPCTSTR* lpServiceArgVectors, bool writedebuginfo, char* computername);
  BOOL RSCC_CopyFile(LPCTSTR lpExistingFileName, LPCTSTR lpNewFileName, BOOL bFailIfExists, bool writedebuginfo);
  BOOL RSCC_DeleteFile(LPCTSTR lpFileName, bool writedebuginfo);
  BOOL RSCC_MoveFileEx(LPCTSTR lpExistingFileName, LPCTSTR lpNewFileName, DWORD dwFlags, bool writedebuginfo);
  // Extra check to prevent long timeouts
  SC_HANDLE RSCC_OpenSCManager(LPCTSTR lpMachineName, LPCTSTR lpDatabaseName, DWORD dwDesiredAccess);
  // Check if a given computername still exists on the network
  bool __fastcall IsComputerOnlineAndNT(const char* lpMachineName);
  // For starting and stopping services in the background
  void __fastcall StartServiceQuitly(int index, int proxyclient);
  void __fastcall StopServiceQuitly(int index, int proxyclient);
  // For browsing the network neighbourhood
  DWORD ListType, ResourceType;
  // Default settings
  ServiceParams clientData;
  ServiceParams proxyData;
  ServiceParams* cfg;  // Points to active ServiceParams instance
  ServiceParams orgClientData;
  ServiceParams orgProxyData;
  ProgramCfg orgpcfg; // Program configuration data that was read at program start
  ProgramCfg pcfg; // Current program configuration data
  TListItem* CurrActiveItem; // Used to carry selected item info
  int ColumnClicked; // Used to see on which column in the listview is clicked
  TListView* activeListView; // Points to the currently active listview
  TList* viewLogFilesChildren;
  // Store default settings
  TIniFile* ProgramSettingsFile;
  AnsiString iniFileName;
  int prgCloseReason; // How did the program reach its FormClose handler
  bool NetworkScanThreadIsRunning; // True if the network is being scanned
  void __fastcall WMCloseViewLog(TMessage& Message);
  // Used to gain more priviliges if required
  HANDLE hToken;
  // Used for minimize to systray methods
  Graphics::TIcon* TrayIcon;
  void __fastcall WMTrayNotify(TMessage& Msg);
  void __fastcall RemoveIcon();
  void __fastcall AddIcon();
  void __fastcall AppOnMinimize(TObject* Sender);
  void __fastcall AppOnRestore(TObject* Sender);
public:
  __fastcall TMainForm(TComponent* Owner);
  __fastcall ~TMainForm();
  bool __fastcall AddOnlyNTMachinesInView(void);
  void __fastcall SetThreadWaitText(AnsiString label, AnsiString info);
  bool __fastcall NameIsDouble(const char* name, TListView* view);
  bool __fastcall Requires_SeTcbPrivilege(void);    
protected:
  void __fastcall WMScanThreadReady(TMessage& Message);

  BEGIN_MESSAGE_MAP
    MESSAGE_HANDLER(WM_SCAN_THREAD_READY, TMessage, WMScanThreadReady)
    MESSAGE_HANDLER(WM_TRAYNOTIFY, TMessage, WMTrayNotify)
    MESSAGE_HANDLER(WM_CLOSE_VIEW_LOGFILE, TMessage, WMCloseViewLog)
  END_MESSAGE_MAP(TControl)
};

//------------------------------------------------------------------------------
// The thread that reads the network computer names
//------------------------------------------------------------------------------
class TNetworkScanThread: public TThread
{
public:
  __fastcall TNetworkScanThread(bool createSuspended,  // true = start after Resume method called
                                bool aRunUpdateAfterwards,
                                bool aScanOutsideDomain,
                                TMainForm* Owner);     // Owning form
  __fastcall ~TNetworkScanThread();
  void __fastcall Execute(void);

private:
  TMainForm* OwnerForm;
  bool fRunUpdateAfterwards;
  bool fScanOutsideDomain;
  void __fastcall FindNetworkComputerNames(void);
  void __fastcall FindNetworkComputerNames(LPNETRESOURCE lpnr);
};

//---------------------------------------------------------------------------
extern PACKAGE TMainForm* MainForm;
//---------------------------------------------------------------------------
#endif

