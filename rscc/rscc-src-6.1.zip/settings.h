//------------------------------------------------------------------------------
// This file is part of Remote Service Control Center by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: settings.h
//------------------------------------------------------------------------------
#ifndef settingsH
#define settingsH
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>

#include "sccclass.h"
#include <Mask.hpp>
//------------------------------------------------------------------------------
class TSettingsForm: public TForm
{
__published:
  TPanel* Panel1;
  TPanel* Panel2;
  TGroupBox* GUIGroupBox;
  TGroupBox* ProxyLogfilesGroupBox;
  TGroupBox* SettingsGroupBox;
  TLabel* Label1;
  TLabel* Label2;
  TLabel* Label3;
  TLabel* Label4;
  TEdit* WaitTimeEdit;
  TEdit* LogRefreshEdit;
  TButton* OKButton;
  TButton* CancelButton;
  TRadioButton* ViewConlog1;
  TRadioButton* ViewRC5Log1;
  TRadioButton* ViewOGRLog1;
  TRadioButton* ViewOGRP2Log1;  
  TCheckBox* FindComputers1;
  TCheckBox* UpdateStatusOnStart1;
  TCheckBox* Minimizetosystray1;
  TCheckBox* ScanOnlyForNT;
  TGroupBox* WhichServiceGroupBox;
  TRadioButton* ClientRadioButton;
  TRadioButton* PerProxyRadioButton;
  TCheckBox* DebugCheckBox;
  TCheckBox* DefaultPasswordCheckBox;
  TCheckBox* Selectline1;
  TGroupBox* GeneralLogfilesGroupBox;
  TCheckBox* AutoRefreshLogs1;
  TEdit* RC5ChallangeEdit;
  TLabel* RC5Label;
  TGroupBox* PeriodicGroupBox;
  TGroupBox* WeekdaysGroupBox;
  TGroupBox* WeekendsGroupBox;
  TCheckBox* StartWeekdaysCheckBox;
  TCheckBox* StopWeekdaysCheckBox;
  TCheckBox* StartWeekendsCheckBox;
  TCheckBox* StopWeekendsCheckBox;
  TMaskEdit* WeekdaysStartEdit;
  TMaskEdit* WeekdaysStopEdit;
  TMaskEdit* WeekendsStartEdit;
  TMaskEdit* WeekendsStopEdit;
  TCheckBox* StartStopClientsCheckBox;
  TCheckBox* StartStopProxiesCheckBox;
  TCheckBox* LocalCheckBox;
  TCheckBox* ScanOutsideDomainCheckBox;
  void __fastcall WaitTimeEditExit(TObject* Sender);
  void __fastcall LogRefreshEditExit(TObject* Sender);
  void __fastcall CancelButtonClick(TObject* Sender);
  void __fastcall OKButtonClick(TObject* Sender);
    
    
private:
  __fastcall TSettingsForm(TComponent* Owner);
  ProgramCfg* newPcfg;
public:
  __fastcall TSettingsForm(TComponent* Owner, ProgramCfg* pcfg);
};
//------------------------------------------------------------------------------
#endif

