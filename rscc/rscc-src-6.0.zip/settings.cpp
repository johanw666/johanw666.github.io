//------------------------------------------------------------------------------
// This file is part of Remote Service Control Center by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: settings.cpp
//
// Contains the form to change the program settings.
//------------------------------------------------------------------------------
#include <stdio.h>
#include <vcl.h>
#pragma hdrstop

#include "settings.h"
#include "scc.h" // for tracefile
//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

//------------------------------------------------------------------------------
// Standatrd constructor, not to be used. Private.
//------------------------------------------------------------------------------
__fastcall TSettingsForm::TSettingsForm(TComponent* Owner): TForm(Owner)
{
}

//------------------------------------------------------------------------------
// Constructor
//------------------------------------------------------------------------------
__fastcall TSettingsForm::TSettingsForm(TComponent* Owner, ProgramCfg* pcfg): TForm(Owner)
{
  char timestring[8];

  // Store pointer to program settings
  newPcfg = pcfg;
  // Set controls
  FindComputers1->Checked       = pcfg->readNetworkNamesAfterStart;
  UpdateStatusOnStart1->Checked = pcfg->updateStatusAfterStart;
  Minimizetosystray1->Checked   = pcfg->minimizeToSystray;
  ScanOnlyForNT->Checked        = pcfg->addOnlyNTMachines;
  DebugCheckBox->Checked        = pcfg->writeDebugMessages;
  LocalCheckBox->Checked        = pcfg->allowNonDomain;
  DefaultPasswordCheckBox->Checked = !pcfg->useSecureCipher;
  Selectline1->Checked          = pcfg->selectWholeLine;
  if ( pcfg->whichProxyLogFile == conLogFile ) ViewConlog1->Checked = true;
  else if ( pcfg->whichProxyLogFile == rc5LogFile ) ViewRC5Log1->Checked = true;
  else if ( pcfg->whichProxyLogFile == ogrLogFile ) ViewOGRLog1->Checked = true;
  else if ( pcfg->whichProxyLogFile == ogrp2LogFile ) ViewOGRP2Log1->Checked = true;
  AutoRefreshLogs1->Checked = pcfg->autoRefreshLogs;
  WaitTimeEdit->Text = IntToStr(pcfg->MaxWaitTime);
  LogRefreshEdit->Text = IntToStr(pcfg->LogRefreshTime);
  RC5ChallangeEdit->Text = pcfg->activeRC5Challenge;
  // Periodic start/stop
  StartStopClientsCheckBox->Checked = pcfg->startStopClients;
  StartStopProxiesCheckBox->Checked = pcfg->startStopProxies;
  StartWeekdaysCheckBox->Checked = pcfg->startOnWeekdays;
  StopWeekdaysCheckBox->Checked = pcfg->stopOnWeekdays;
  StartWeekendsCheckBox->Checked = pcfg->startOnWeekends;
  StopWeekendsCheckBox->Checked = pcfg->stopOnWeekends;
  sprintf(timestring, "%02d:%02d", pcfg->startTimeWeekdays.wHour, pcfg->startTimeWeekdays.wMinute);
  WeekdaysStartEdit->Text = timestring;
  sprintf(timestring, "%02d:%02d", pcfg->stopTimeWeekdays.wHour, pcfg->stopTimeWeekdays.wMinute);
  WeekdaysStopEdit->Text = timestring;
  sprintf(timestring, "%02d:%02d", pcfg->startTimeWeekends.wHour, pcfg->startTimeWeekends.wMinute);
  WeekendsStartEdit->Text = timestring;
  sprintf(timestring, "%02d:%02d", pcfg->stopTimeWeekends.wHour, pcfg->stopTimeWeekends.wMinute);
  WeekendsStopEdit->Text = timestring;
  // Service
  if ( pcfg->ServiceToShow == serviceClient ) ClientRadioButton->Checked = true;
  else if ( pcfg->ServiceToShow == serviceProxy ) PerProxyRadioButton->Checked = true;
  // Position the form
  if ( Owner ) {
    Top = ((TForm*)Owner)->Top + (((TForm*)Owner)->Height - Height);
    if ( Top < 0 ) Top = 0;
    Left = ((TForm*)Owner)->Left + 0.5 * (((TForm*)Owner)->Width - Width);
  } else Position = poScreenCenter;
  // Name logfile:
  DebugCheckBox->Caption = "Write debug messages in " + ExtractFileName(AnsiString(tracefile));
}

//------------------------------------------------------------------------------
// Change the maximun time the program waits for a service to reach a certain
// status. If the desired status is not reached after this time a timeout error
// is given.
//------------------------------------------------------------------------------
void __fastcall TSettingsForm::WaitTimeEditExit(TObject* Sender)
{
  try {
    StrToInt(WaitTimeEdit->Text);
  } catch ( ... ) {
    Application->MessageBox("You can only enter numbers here", Application->Title.c_str(), MB_OK);
    WaitTimeEdit->Text = "5";
    WaitTimeEdit->SetFocus();
  }
}

//------------------------------------------------------------------------------
// Change the refresh rate for the logfiles.
//------------------------------------------------------------------------------
void __fastcall TSettingsForm::LogRefreshEditExit(TObject* Sender)
{
  try {
    StrToInt(LogRefreshEdit->Text);
  } catch ( ... ) {
    Application->MessageBox("You can only enter numbers here", Application->Title.c_str(), MB_OK);
    LogRefreshEdit->Text = "60";
    LogRefreshEdit->SetFocus();
  }
}

//------------------------------------------------------------------------------
// Close form without saving
//------------------------------------------------------------------------------
void __fastcall TSettingsForm::CancelButtonClick(TObject* Sender)
{
  Close();
}

//------------------------------------------------------------------------------
// Close form and store the data
//------------------------------------------------------------------------------
void __fastcall TSettingsForm::OKButtonClick(TObject* Sender)
{
  newPcfg->readNetworkNamesAfterStart = FindComputers1->Checked;
  newPcfg->updateStatusAfterStart     = UpdateStatusOnStart1->Checked;
  newPcfg->minimizeToSystray          = Minimizetosystray1->Checked;
  newPcfg->addOnlyNTMachines          = ScanOnlyForNT->Checked;
  newPcfg->writeDebugMessages         = DebugCheckBox->Checked;
  newPcfg->allowNonDomain             = LocalCheckBox->Checked;
  newPcfg->selectWholeLine            = Selectline1->Checked;
  newPcfg->useSecureCipher            = !DefaultPasswordCheckBox->Checked;
  if ( ViewConlog1->Checked ) newPcfg->whichProxyLogFile = conLogFile;
  else if ( ViewRC5Log1->Checked ) newPcfg->whichProxyLogFile = rc5LogFile;
  else if ( ViewOGRLog1->Checked ) newPcfg->whichProxyLogFile = ogrLogFile;
  else if ( ViewOGRP2Log1->Checked ) newPcfg->whichProxyLogFile = ogrp2LogFile;
  newPcfg->autoRefreshLogs = AutoRefreshLogs1->Checked;
  newPcfg->MaxWaitTime = StrToInt(WaitTimeEdit->Text);
  newPcfg->LogRefreshTime = StrToInt(LogRefreshEdit->Text);
  newPcfg->activeRC5Challenge = RC5ChallangeEdit->Text;
  // Periodic start/stop
  newPcfg->startStopClients = StartStopClientsCheckBox->Checked;
  newPcfg->startStopProxies = StartStopProxiesCheckBox->Checked;
  newPcfg->startOnWeekdays = StartWeekdaysCheckBox->Checked;
  newPcfg->stopOnWeekdays = StopWeekdaysCheckBox->Checked;
  newPcfg->startOnWeekends = StartWeekendsCheckBox->Checked;
  newPcfg->stopOnWeekends = StopWeekendsCheckBox->Checked;
  sscanf(WeekdaysStartEdit->Text.c_str(), "%02d:%02d", &newPcfg->startTimeWeekdays.wHour, &newPcfg->startTimeWeekdays.wMinute);
  sscanf(WeekdaysStopEdit->Text.c_str(), "%02d:%02d", &newPcfg->stopTimeWeekdays.wHour, &newPcfg->stopTimeWeekdays.wMinute);
  sscanf(WeekendsStartEdit->Text.c_str(), "%02d:%02d", &newPcfg->startTimeWeekends.wHour, &newPcfg->startTimeWeekends.wMinute);
  sscanf(WeekendsStopEdit->Text.c_str(), "%02d:%02d", &newPcfg->stopTimeWeekends.wHour, &newPcfg->stopTimeWeekends.wMinute);
  // Service
  if ( ClientRadioButton->Checked ) newPcfg->ServiceToShow = serviceClient;
  else if ( PerProxyRadioButton->Checked ) newPcfg->ServiceToShow = serviceProxy;
  Close();
}

//------------------------------------------------------------------------------


