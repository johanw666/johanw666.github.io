
#if !defined( _MULTISWAP_H_ )
#define _MULTISWAP_H_

typedef struct multiswapkey_st {
	struct {
		int multikey[5];
		int multiinv[5];
		int additive;
	} round[2];
} MULTISWAPKEY;

void MultiSwapSetKey(MULTISWAPKEY * out, unsigned int *datain);
void MultiSwapEncode(MULTISWAPKEY * key, unsigned int *state,
		     unsigned int *datain, unsigned int *dataout);
void MultiSwapMAC(MULTISWAPKEY * key, unsigned int *data, int num64bits,
		  unsigned int *out);
void MultiSwapDecode(MULTISWAPKEY * key, unsigned int *state,
		     unsigned int *datain, unsigned int *dataout);

#endif
