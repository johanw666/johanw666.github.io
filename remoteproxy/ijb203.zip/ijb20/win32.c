char *win32_rcs = "$Id: win32.c,v 2.0 2001/03/30 11:50:00 johanw Exp $";
/* Written and copyright 1997 Anonymous Coders and Junkbusters Corporation.
 * Distributed under the GNU General Public License; see the README file.
 * This code comes with NO WARRANTY. http://www.junkbusters.com/ht/en/gpl.html
 */
#ifdef _WIN32

#include <stdio.h>
#ifdef REGEX
#include "gnu_regex.h"
#endif
#include <windows.h>
#include "jcc.h"

extern int hideConsole;
void InitWin32()
{
  WORD wVersionRequested;
  WSADATA wsaData;

#ifndef NT_SERVICE
  /* This is only relevant for non-service win32 executables. */
  SetProcessShutdownParameters(0x100, SHUTDOWN_NORETRY);
  if (hideConsole) {
    FreeConsole();
  }
#endif
  wVersionRequested = MAKEWORD(2, 0);
  if (WSAStartup(wVersionRequested, &wsaData) != 0) {
    exit(1);
  }
}

char *win32_blurb =
"Internet Junkbuster Proxy(TM) Version " VERSION " for Windows is Copyright (C) 1997-8\n"
"by Junkbusters Corp.  This is free software; it may be used and copied under\n"
"the GNU General Public License: http://www.junkbusters.com/ht/en/gpl.html.\n"
"This program comes with ABSOLUTELY NO WARRANTY OF ANY KIND.\n"
"\n"
"For information about how to to configure the proxy and your browser, see\n"
"        http://www.junkbusters.com/ht/en/ijbwin.html#v" VERSION_MAJOR "\n"
"\n"
"The Internet Junkbuster Proxy(TM) is running and ready to serve!\n"
;

#endif

#ifdef NT_SERVICE
SERVICE_STATUS_HANDLE serviceStatusHandle;
HANDLE killServiceEvent;
HANDLE thread_handle;
DWORD serviceCurrentStatus;
int serviceRunning;
int servicePaused;


/* defined in jcc.c */
extern char* haddr;
extern int   hport;

/*----------------------------------------------------------------------------
 ServiceMain is called when the Service Control Manager wants to
 launch the service. It should not return until the service has
 stopped. To accomplish this, for this example, it waits blocking
 on an event just before the end of the function. That event gets
 set by the function which terminates the service above. Also, if
 there is an error starting the service, ServiceMain returns immediately
 without launching the main service thread, terminating the service.
----------------------------------------------------------------------------*/
void ServiceMain(DWORD argc, LPTSTR* argv)
{
  DWORD errCode = 0;

  /* First we must call the Registration function */
  serviceStatusHandle = RegisterServiceCtrlHandler(SERVICE_NAME, (LPHANDLER_FUNCTION)ServiceCtrlHandler);
  if (!serviceStatusHandle) {
    errCode = GetLastError();
    fprintf(logfp, "No serviceStatusHandle created, error = %d\n", errCode);
    TerminateService(errCode);
    return;
  }
  /* Next Notify the Service Control Manager of progress */
  if ( !UpdateSCMStatus(SERVICE_START_PENDING, NO_ERROR, 0, 1, 5000) ) {
    fprintf(logfp, "UpdateSCMStatus failed, error = %d\n", errCode);
    TerminateService(errCode);
    return;
  }
  /* Now create the service termination event to block on */
  killServiceEvent = CreateEvent(0, TRUE, FALSE, 0);
  if (!killServiceEvent) {
    errCode = GetLastError();
    fprintf(logfp, "No killServiceEvent created, error = %d\n", errCode);
    TerminateService(errCode);
    return;
  }
  /* Notify the SCM of progress again */
  if ( !UpdateSCMStatus(SERVICE_START_PENDING, NO_ERROR, 0, 2, 1000) ) {
    errCode = GetLastError();
    fprintf(logfp, "UpdateSCMStatus failed, error = %d\n", errCode);
    TerminateService(errCode);
    return;
  }
  /* Start the service execution thread */
  if ( !StartServiceThread() ) {
    fprintf(logfp, "StartServiceThread failed, error = %d\n", errCode);
    return;
  }
  /* The service is now running.  Notify the SCM of this fact. */
  serviceCurrentStatus = SERVICE_RUNNING;
  if ( !UpdateSCMStatus(SERVICE_RUNNING, NO_ERROR, 0, 0, 0) ) {
    errCode = GetLastError();
    fprintf(logfp, "UpdateSCMStatus failed, error = %d\n", errCode);
    TerminateService(errCode);
  }
  /* Now just wait for our killed service signal, and then exit, which */
  /* terminates the service!                                           */
  WaitForSingleObject(killServiceEvent, INFINITE);
  TerminateService(0);
}

/*----------------------------------------------------------------------------
 Cleans up when the service stops.
----------------------------------------------------------------------------*/
void TerminateService(DWORD errCode)
{
  UpdateSCMStatus(SERVICE_STOPPED, errCode, 0, 0, 1000);
}

/*----------------------------------------------------------------------------
 This is the main thread of execution for the service while it is running.
----------------------------------------------------------------------------*/
DWORD ServiceExecutionThread(LPDWORD param)
{
  char buf[BUFSIZ];
  struct client_state* csp;
  int cfd, bfd;
  HANDLE child_id;
  DWORD id;

  cfd = -1;

  bfd = bind_port(haddr, hport);

  if ( bfd < 0 ) {
    fprintf(logfp, "%s: can't bind %s:%d: ", prog, haddr ? haddr : "INADDR_ANY", hport);
    fperror(logfp, "");
    fprintf(logfp, "There may be another junkbuster or some other proxy running on port %d\n", hport);
    exit(1);
  }

  while ( serviceRunning ) {
    sweep();

    if(DEBUG(CON)) {
      fprintf(logfp, "%s: accept connection ... ", prog);
    }

    cfd = accept_connection(bfd);
    if ( cfd < 0 ) {
      if(DEBUG(CON)) {
        fprintf(logfp, "%s: accept failed: ", prog);
        fperror(logfp, "");
      }
      continue;
    } else {
      if(DEBUG(CON)) {
        fprintf(logfp, "OK\n");
      }
    }

    csp = (struct client_state*) malloc(sizeof(*csp));

    if(csp == NULL) {
      fprintf(logfp, "%s: malloc(%d) for csp failed: ", prog, sizeof(*csp));
      fperror(logfp, "");
      close_socket(cfd);
      continue;
    }

    memset(csp, 0, sizeof(*csp));

    csp->active = 1;
    csp->cfd    = cfd;
    csp->sfd    =  -1;
    csp->ip_addr_str  = remote_ip_str;
    csp->ip_addr_long = remote_ip_long;

    /* add it to the list of clients */
    csp->next = clients->next;
    clients->next = csp;

    if(run_loader(csp)) {
      fprintf(logfp, "%s: a loader failed - must exit\n", prog);
      exit(1);
    }


    child_id = CreateThread(0, 0, (LPTHREAD_START_ROUTINE)serve, csp, 0, &id);

    if ( !child_id ) {  /* failed */
      fprintf(logfp, "%s: can't fork: ", prog);
      fperror(logfp, "");
      sprintf(buf , "%s: can't fork: errno = %d", prog, errno);
      write_socket(csp->cfd, buf, strlen(buf));
      close_socket(csp->cfd);
      csp->active = 0;
      Sleep(5000);
      continue;
    }
  }
  return 0;
}

/*----------------------------------------------------------------------------
 This starts the service by creating its execution thread.
----------------------------------------------------------------------------*/
int StartServiceThread()
{
  DWORD id;
  /* Start the service's thread */
  thread_handle = CreateThread(0, 0, (LPTHREAD_START_ROUTINE)ServiceExecutionThread, 0, 0, &id);

  if ( !thread_handle ) {
    return 0;
  } else {
    serviceRunning = 1;
    return 1;
  }
}

/*----------------------------------------------------------------------------
 This function updates the service status for the SCM 
----------------------------------------------------------------------------*/
int UpdateSCMStatus(DWORD dwCurrentState,
                    DWORD dwWin32ExitCode,
                    DWORD dwServiceSpecificExitCode,
                    DWORD dwCheckPoint,
                    DWORD dwWaitHint)
{
  int success;
  SERVICE_STATUS serviceStatus;
  /* Fill in all of the SERVICE_STATUS fields */
  serviceStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
  serviceStatus.dwCurrentState = dwCurrentState;
  /* If in the process of something, then accept */
  /* no control events, else accept anything     */
  if (dwCurrentState == SERVICE_START_PENDING) {
    serviceStatus.dwControlsAccepted = 0;
  } else {
    serviceStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_PAUSE_CONTINUE | SERVICE_ACCEPT_SHUTDOWN;
  }
  /* if a specific exit code is defined, set up the Win32 exit code properly */
  if (dwServiceSpecificExitCode == 0) {
    serviceStatus.dwWin32ExitCode = dwWin32ExitCode;
  } else {
    serviceStatus.dwWin32ExitCode = ERROR_SERVICE_SPECIFIC_ERROR;
  }
  serviceStatus.dwServiceSpecificExitCode = dwServiceSpecificExitCode;
  serviceStatus.dwCheckPoint = dwCheckPoint;
  serviceStatus.dwWaitHint = dwWaitHint;
  /* Pass the status record to the SCM */
  success = SetServiceStatus(serviceStatusHandle, &serviceStatus);
  if ( !success ) {
    KillService();
  }
  return success;
}

/*----------------------------------------------------------------------------
 Handles the events dispatched by the Service Control Manager.
----------------------------------------------------------------------------*/
void ServiceCtrlHandler(DWORD controlCode)
{
  char readText[16];
  
  switch(controlCode) {
    /* There is no START option because ServiceMain gets called on a start */
    case SERVICE_CONTROL_PAUSE:
      if (serviceRunning && !servicePaused) {
        UpdateSCMStatus(SERVICE_PAUSE_PENDING, NO_ERROR, 0, 1, 1000);
        servicePaused = 1;
        SuspendThread(thread_handle);
        serviceCurrentStatus = SERVICE_PAUSED;
      }
      break;
    case SERVICE_CONTROL_CONTINUE:
      if (serviceRunning && servicePaused) {
        UpdateSCMStatus(SERVICE_CONTINUE_PENDING, NO_ERROR, 0, 1, 1000);
        servicePaused = 0;
        ResumeThread(thread_handle);
        serviceCurrentStatus = SERVICE_RUNNING;
      }
      break;
    /* Update the current status for the SCM. */
    case SERVICE_CONTROL_INTERROGATE:
      /* This does nothing, here we will just fall through to the end
       * and send our current status.
       */
      break;
    /* For a shutdown, we can do cleanup but it must take place quickly
     * because the system will go down out from under us.
     * For this app we have time to stop here, which I do by just falling
     * through to the stop message.
     */
    case SERVICE_CONTROL_SHUTDOWN:
    case SERVICE_CONTROL_STOP:
      serviceCurrentStatus = SERVICE_STOP_PENDING;
      UpdateSCMStatus(SERVICE_STOP_PENDING, NO_ERROR, 0, 1, 5000);
      KillService();
      return;
    default:
      break;
  }
  UpdateSCMStatus(serviceCurrentStatus, NO_ERROR, 0, 0, 0);
}


/*----------------------------------------------------------------------------
 Set the killServiceEvent to allow ServiceMain to exit.
----------------------------------------------------------------------------*/
void KillService()
{
  serviceRunning = 0;
  SetEvent(killServiceEvent);
}

/*----------------------------------------------------------------------------
 Installs the service
----------------------------------------------------------------------------*/
void InstallService()
{
  char* c;
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  char progFileName[MAX_PATH];
  char iniFileName[MAX_PATH];
  char command[2*MAX_PATH];
  char* srv_login;
  char* srv_passwd;
  char dependencies[7];

  // Set dependency to TCP/IP service
  memset(dependencies, 0, sizeof(dependencies));
  strcpy(dependencies, "Tcpip");

  GetModuleFileName(GetModuleHandle(NULL), progFileName, sizeof(progFileName));
  GetModuleFileName(GetModuleHandle(NULL), iniFileName, sizeof(iniFileName));
  c = strrchr(iniFileName, '.');
  if ( c ) *c = 0;
  strcat(iniFileName, ".ini");
  strcpy(command, progFileName);
  strcat(command, " ");
  strcat(command, "\"");
  strcat(command, iniFileName);
  strcat(command, "\"");

  if ( strlen(login) )
    srv_login = login;
  else
    srv_login = NULL;

  if ( strlen(passwd) )
    srv_passwd = passwd;
  else if ( strlen(login) ) {
    strcpy(passwd, "");
    srv_passwd = passwd;
  } else
    srv_passwd = NULL;

  /* Open the service manager and install the service */
  if ( (hscManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
    hService = CreateService(hscManager, SERVICE_NAME, "Junkbuster Filtering Proxy Server",
                             SERVICE_ALL_ACCESS, SERVICE_WIN32_OWN_PROCESS,
                             SERVICE_AUTO_START, SERVICE_ERROR_IGNORE,
                             command, NULL, NULL, (LPCTSTR)dependencies,
                             srv_login, srv_passwd);
    if ( !hService )
      MessageBox(NULL, "Install error: no service handle created.\nPerhaps another Junkbusters is already running?", "Junkbuster", MB_OK|MB_ICONWARNING);
    else {
      if ( !StartService(hService, 0, NULL) )
        MessageBox(NULL, "Junkbuster service installed, error starting service.\nPerhaps another Junkbusters proxy is already running?", "Junkbuster", MB_OK|MB_ICONWARNING);
      else
        MessageBox(NULL, "Junkbuster service installed and running.", "Junkbuster", MB_OK|MB_ICONINFORMATION);

      CloseServiceHandle(hService);
    }
    CloseServiceHandle(hscManager);
  } else
    MessageBox(NULL, "Install error: no SCM handle obtained.", "Junkbuster", MB_OK|MB_ICONWARNING);
}

/*----------------------------------------------------------------------------
 Deinstalls the service
----------------------------------------------------------------------------*/
void UninstallService()
{
  BOOL retVal;
  DWORD errCode;
  SERVICE_STATUS serviceStatus;
  SC_HANDLE hscManager;
  SC_HANDLE hService;

  if ( (hscManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
    if ( (hService = OpenService(hscManager, SERVICE_NAME, SERVICE_ALL_ACCESS)) == NULL ) {
      hService = NULL;
      MessageBox(NULL, "No service handle obtained", "Uninstall error", MB_OK);
    }
    /* First stop the service. We check the return value separately because
      we don't want an errormessage when the service is already stopped. */
    if ( hService) {
      retVal = ControlService(hService, SERVICE_CONTROL_STOP, &serviceStatus);
      if ( !retVal) {
        errCode = GetLastError();
        if ( errCode != ERROR_SERVICE_NOT_ACTIVE )
          MessageBox(NULL, "Failed to stop running Junkbusters service", "Junkbusters", MB_OK|MB_ICONWARNING);
       }
       if ( !DeleteService(hService) )
         MessageBox(NULL, "Error uninstalling Junkbuster service", "Junkbusters", MB_OK|MB_ICONWARNING);
       else
         MessageBox(NULL, "Junkbuster service uninstalled.", "Junkbuster", MB_OK|MB_ICONINFORMATION);

      CloseServiceHandle(hService);
    }
    CloseServiceHandle(hscManager);
  } else
    MessageBox(NULL, "Error: No SCM handle obtained", "Junkbusters", MB_OK|MB_ICONWARNING);
}


/*----------------------------------------------------------------------------
 Tests the service
----------------------------------------------------------------------------*/
void TestService()
{
  DWORD errCode;
  char buffer[2048];
  char msg[2048];
  char sysname[64];
  char status[64];
  DWORD sysname_size;
  DWORD bytesNeeded;
  SERVICE_STATUS serviceStatus;
  SC_HANDLE hscManager;
  SC_HANDLE hService;

  if ( (hscManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
    if ( (hService = OpenService(hscManager, SERVICE_NAME, SERVICE_ALL_ACCESS)) == NULL ) {
      hService = NULL;
      MessageBox(NULL, "The Junkbusters service is not instaled on this system.", "Junkbusters", MB_OK|MB_ICONINFORMATION);
    }
    if ( hService) {
      QueryServiceConfig(hService, (QUERY_SERVICE_CONFIG*)buffer, sizeof(buffer), &bytesNeeded);
      QueryServiceStatus(hService, &serviceStatus);
      GetServiceStatus(serviceStatus.dwCurrentState, status, sizeof(status));
      sysname_size = sizeof(sysname);
      GetComputerName(sysname, &sysname_size);
      sprintf(msg, "Junkbusters configuration on computer %s:\n"
                   "_______________________________________________________\n\n"
                   "Service status:\t\t%s\n"
                   "Start at boot:\t\t%s\n"
                   "Command to start:\t\t%s\n"
                   "Account to run service:\t%s\n"
                   "Service display name:\t%s",
                   sysname,
                   status,
                   ((QUERY_SERVICE_CONFIG*)buffer)->dwStartType == SERVICE_AUTO_START ? "Yes" : "No",
                   ((QUERY_SERVICE_CONFIG*)buffer)->lpBinaryPathName,
                   ((QUERY_SERVICE_CONFIG*)buffer)->lpServiceStartName,
                   ((QUERY_SERVICE_CONFIG*)buffer)->lpDisplayName);
      MessageBox(NULL, msg, "Junkbusters", MB_OK|MB_ICONINFORMATION);
      CloseServiceHandle(hService);
    }
    CloseServiceHandle(hscManager);
  } else
    MessageBox(NULL, "Error: No SCM handle obtained", "Junkbusters", MB_OK|MB_ICONWARNING);
}

/* Returns a description of the service status */
void GetServiceStatus(DWORD status, char buffer[], size_t buff_size)
{
  switch(status) {
    case SERVICE_STOPPED:
      strncpy(buffer, "not running", buff_size);
      break;
    case SERVICE_START_PENDING:
      strncpy(buffer, "starting", buff_size);
      break;
    case SERVICE_STOP_PENDING:
      strncpy(buffer, "stopping", buff_size);
      break;
    case SERVICE_RUNNING:
      strncpy(buffer, "running", buff_size);
      break;
    case SERVICE_CONTINUE_PENDING:
      strncpy(buffer, "continue pending", buff_size);
      break;
    case SERVICE_PAUSE_PENDING:
      strncpy(buffer, "pause pending", buff_size);
      break;
    case SERVICE_PAUSED:
      strncpy(buffer, "paused", buff_size);
      break;
    default:
      strncpy(buffer, "unknown", buff_size);
  }
}

#endif

