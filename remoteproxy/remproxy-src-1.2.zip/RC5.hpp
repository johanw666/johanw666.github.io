// Borland C++ Builder
// Copyright (c) 1995, 1998 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'RC5.pas' rev: 3.00

#ifndef RC5HPP
#define RC5HPP
#include <DCPcrypt.hpp>
#include <SysUtils.hpp>
#include <Classes.hpp>
#include <SysInit.hpp>
#include <System.hpp>

//-- user supplied -----------------------------------------------------------

namespace Rc5
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TDCP_rc5;
class PASCALIMPLEMENTATION TDCP_rc5 : public Dcpcrypt::TDCP_blockcipher 
{
	typedef Dcpcrypt::TDCP_blockcipher inherited;
	
protected:
	Byte IV[8];
	Byte LB[8];
	int KeyData[26];
	void __fastcall Encrypt(const void *InBlock, void *OutBlock);
	void __fastcall Decrypt(const void *InBlock, void *OutBlock);
	
public:
	virtual void __fastcall Init(void *Key, int Size, void * IVector);
	virtual void __fastcall Burn(void);
	virtual void __fastcall Reset(void);
	virtual void __fastcall EncryptECB(const void *InBlock, void *OutBlock);
	virtual void __fastcall DecryptECB(const void *InBlock, void *OutBlock);
	virtual void __fastcall EncryptCBC(const void *InData, void *OutData, int Size);
	virtual void __fastcall DecryptCBC(const void *InData, void *OutData, int Size);
	virtual void __fastcall EncryptCFB(const void *InData, void *OutData, int Size);
	virtual void __fastcall DecryptCFB(const void *InData, void *OutData, int Size);
	__fastcall virtual TDCP_rc5(Classes::TComponent* AOwner);
public:
	/* TDCP_blockcipher.Destroy */ __fastcall virtual ~TDCP_rc5(void) { }
	
};

//-- var, const, procedure ---------------------------------------------------
#define NUMROUNDS (Byte)(12)

}	/* namespace Rc5 */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Rc5;
#endif
//-- end unit ----------------------------------------------------------------
#endif	// RC5
