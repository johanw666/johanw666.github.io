//------------------------------------------------------------------------------
// This file is part of Remote Proxy Controller by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: config.h
//------------------------------------------------------------------------------
#ifndef configH
#define configH
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>

#include "scc.h"
#include <Mask.hpp>

//------------------------------------------------------------------------------
class TConfigForm: public TForm
{
__published:
  TPanel* Panel1;
  TGroupBox* FileGroupBox;
  TLabel* DisplayNameLabel;
  TLabel* ExeLabel;
  TEdit* DisplayNameEdit;
  TCheckBox* EditExeCheckBox;
  TEdit* ExeNameEdit;
  TGroupBox* StartupGroupBox;
  TRadioButton* AutoRadioButton;
  TRadioButton* ManualRadioButton;
  TGroupBox* AccountGroupBox;
  TLabel* AccountLabel;
  TLabel* PasswordLabel;
  TLabel* AccountLabel3;
  TEdit* AccountEdit;
  TMaskEdit* PasswordEdit;
  TRadioButton* AccountRadioButton;
  TRadioButton* DefaultRadioButton;
    TPanel *Panel2;
    TButton *CancelButton;
    TButton *ChangeButton;
  void __fastcall ChangeButtonClick(TObject* Sender);
  void __fastcall CancelButtonClick(TObject* Sender);
  void __fastcall EditExeCheckBoxClick(TObject* Sender);
  void __fastcall RadioButtonClick(TObject* Sender);
  
private:
  char computerName[MAX_PATH];
  DWORD fDwServiceType;
  DWORD fDwStartType;
  char fLpBinaryPathName[MAX_PATH];
  char fLpServiceStartName[MAX_PATH];
  char fLpDisplayName[MAX_PATH];
  char fLpPassword[MAX_PATH];
  ChangeServiceConfigData* fServiceConfigData;
  bool* changeConfig;
  __fastcall TConfigForm(TComponent* Owner);

public:
  __fastcall TConfigForm(TComponent* Owner,
                         bool aCanChangeConfig,
                         DWORD aDwServiceType,
                         DWORD aDwStartType,
                         char aLpBinaryPathName[],
                         char aLpServiceStartName[],
                         char aLpDisplayName[],
                         char aComputerName[],
                         bool* doChangeConfig,
                         ChangeServiceConfigData* aServiceConfigData);
};
//------------------------------------------------------------------------------
#endif

