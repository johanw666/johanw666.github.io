//------------------------------------------------------------------------------
// This file is part of Remote Proxy Controller by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: sccclsss.h
//
// Unit with supporting classes for the main program
//------------------------------------------------------------------------------
#ifndef sccclassH
#define sccclassH

#include <inifiles.hpp>

// Default password if none chosen.
extern const char DefaultPassword[];
// Inifile keys
extern const AnsiString ComputerNamesIniSection;
extern const AnsiString SwitchUser;
extern const AnsiString ProgramIniSection;
extern const AnsiString ReadNetworkIdent;
extern const AnsiString UpdateAfterStart;
extern const AnsiString ServiceStartUp;
extern const AnsiString MaxWaitTime;
extern const AnsiString LogRefreshTime;
extern const AnsiString MinimizeToSystray;
extern const AnsiString AutoRefreshLogs;
extern const AnsiString ShowButtons;
extern const AnsiString SelectWholeLine;
extern const AnsiString UseSecureCipher;
extern const AnsiString AddOnlyNTMachines;
extern const AnsiString WriteDebugMessages;
extern const AnsiString TopPos;
extern const AnsiString LeftPos;
extern const AnsiString FormHeight;
extern const AnsiString FormWidth;
extern const AnsiString NameColumnWidth;
extern const AnsiString StatusColumnWidth;
extern const AnsiString PathColumnWidth;
extern const AnsiString VersionColumnWidth;
extern const AnsiString CommandColumnWidth;
extern const AnsiString ListenColumnWidth;
extern const AnsiString LogColumnWidth;

//------------------------------------------------------------------------------
// Struct to store the service paramaters
//------------------------------------------------------------------------------
class ServiceParams
{
private:
  // Comparing function for operator== and !=
  bool __fastcall Compare(const ServiceParams& cfg2) const;
public:
  __fastcall ServiceParams(void);
  __fastcall ~ServiceParams();
  const ServiceParams& __fastcall operator=(const ServiceParams& cfg2);
  bool __fastcall operator==(const ServiceParams& cfg2) const;
  bool __fastcall operator!=(const ServiceParams& cfg2) const;
  // Check data before installing the service
  bool IsSufficientDataAvailable(void);
  // Read and store data to inifile.
  void __fastcall SaveSettings(TIniFile* file);
  void __fastcall ReadSettings(TIniFile* file);
  // Data
  char IniSection[32];         // Section in the inifile to store the params.
  char ExeFrom[MAX_PATH];      // Path and name of the executable to copy to the remote machine
  char JbiniFrom[MAX_PATH];    // Path and name of junkbstr.ini
  char Sblockini[MAX_PATH];    // Path and name of sblock.ini
  char Saclfileini[MAX_PATH];  // Path and name of saclfile.ini
  char Scookieini[MAX_PATH];   // Path and name of scookie.ini
  char Sforwardini[MAX_PATH];  // Path and name of sforward.ini
  char Strustini[MAX_PATH];    // Path and name of strust.ini
  char DirectoryTo[MAX_PATH];  // Directory on the remote machine to copy the file to
  char RemoteName[MAX_PATH];   // The name of the executable on the remote computer (without extension)
  char ServiceName[256];       // Service name
  char DisplayName[MAX_PATH];  // Service display name
  // Startup values
  bool StartOnInstall;         // true means start service after install
  bool StartOnBoot;            // true means start on PC boot
  // Which inifiles
  bool useAutoIniFiles;        // true means extract other inifilenames from main
};

//------------------------------------------------------------------------------
// Data to call ChangeServiceConfig with
//------------------------------------------------------------------------------
struct ChangeServiceConfigData
{
  DWORD dwServiceType;             // type of service
  DWORD dwStartType;               // when to start service
  DWORD dwErrorControl;            // severity if service fails to start
  char lpBinaryPathName[MAX_PATH]; // pointer to service binary file name
  char lpDisplayName[MAX_PATH];    // pointer to display name
  char lpServiceStartName[MAX_PATH]; // Pointer to account name for service
  char lpPassword[MAX_PATH];       // Pointer to password
};

//------------------------------------------------------------------------------
// Data that describes type configuration of the program. This data is saved
// to the inifile.
//------------------------------------------------------------------------------
class ProgramCfg
{
private:
  void __fastcall GetHashFromPassword(char aPassword[], char aPasswordHash[], size_t buffsize);
  // Comparing function for operator== and !=
  bool __fastcall Compare(const ProgramCfg& cfg2) const;
  bool __fastcall ReadEncryptedLoginData(TIniFile* aIniFile);
  void __fastcall WriteComputerNames(TIniFile* aIniFile);
public:
  __fastcall ProgramCfg(void);
  __fastcall ~ProgramCfg();
  const ProgramCfg& __fastcall operator=(const ProgramCfg& cfg2);
  bool __fastcall operator==(const ProgramCfg& cfg2) const;
  bool __fastcall operator!=(const ProgramCfg& cfg2) const;
  // Read and store data to inifile.
  void __fastcall SaveSettings(TIniFile* aIniFile);
  void __fastcall ReadSettings(TIniFile* aIniFile);
  // Data
  bool readNetworkNamesAfterStart;
  bool updateStatusAfterStart;
  bool minimizeToSystray;
  int MaxWaitTime;      // Maximum time to wait for timeout
  int LogRefreshTime;   // Time interval for logfiles to refresh
  bool SwitchUserID;    // True: try to gain extra priviliges; false: don't.
  bool useSecureCipher; // True: use RC5 to encrypt the login data with a password.
  char ProgramPassword[128]; // Password to encrypt login data with
  bool autoRefreshLogs;
  bool showButtons;
  bool selectWholeLine;
  bool addOnlyNTMachines;
  bool writeDebugMessages;
  // Login data
  char Username[64];  // string that specifies the user name
  char Domain[64];    // string that specifies the domain or server
  char Password[128]; // string that specifies the password
  // Computer names
  TStringList* computerNameList;
};


//---------------------------------------------------------------------------
#endif

