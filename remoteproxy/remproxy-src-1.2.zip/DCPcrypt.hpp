// Borland C++ Builder
// Copyright (c) 1995, 1998 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'DCPcrypt.pas' rev: 3.00

#ifndef DCPcryptHPP
#define DCPcryptHPP
#include <Classes.hpp>
#include <SysInit.hpp>
#include <System.hpp>

//-- user supplied -----------------------------------------------------------

namespace Dcpcrypt
{
//-- type declarations -------------------------------------------------------
typedef Word *PWord;

typedef int *PDWord;

typedef int DWord;

typedef int TDWordArray[1024];

typedef TDWordArray *PDWordArray;

typedef Byte TByteArray[4096];

typedef TByteArray *PByteArray;

class DELPHICLASS TDCP_blockcipher;
class PASCALIMPLEMENTATION TDCP_blockcipher : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
protected:
	int fID;
	bool fInitialized;
	System::AnsiString fAlgorithm;
	int fBlockSize;
	int fMaxKeySize;
	System::AnsiString fNullStr;
	int fNullInt;
	
public:
	__property int ID = {read=fID, nodefault};
	__property bool Initialized = {read=fInitialized, nodefault};
	virtual void __fastcall Init(void *Key, int Size, void * IV) = 0;
	void __fastcall InitStr(const System::AnsiString Key);
	virtual void __fastcall Burn(void) = 0;
	virtual void __fastcall Reset(void) = 0;
	virtual void __fastcall EncryptECB(const void *InBlock, void *OutBlock) = 0;
	virtual void __fastcall DecryptECB(const void *InBlock, void *OutBlock) = 0;
	virtual void __fastcall EncryptCBC(const void *InData, void *OutData, int Size) = 0;
	virtual void __fastcall DecryptCBC(const void *InData, void *OutData, int Size) = 0;
	virtual void __fastcall EncryptCFB(const void *InData, void *OutData, int Size) = 0;
	virtual void __fastcall DecryptCFB(const void *InData, void *OutData, int Size) = 0;
	__fastcall virtual TDCP_blockcipher(Classes::TComponent* AOwner);
	__fastcall virtual ~TDCP_blockcipher(void);
	
__published:
	__property System::AnsiString Algorithm = {read=fAlgorithm, write=fNullStr};
	__property int BlockSize = {read=fBlockSize, write=fNullInt, nodefault};
	__property int MaxKeySize = {read=fMaxKeySize, write=fNullInt, nodefault};
};

class DELPHICLASS TDCP_hash;
class PASCALIMPLEMENTATION TDCP_hash : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
protected:
	int fID;
	bool fInitialized;
	System::AnsiString fAlgorithm;
	int fHashSize;
	System::AnsiString fNullStr;
	virtual void __fastcall SetHashSize(int Value);
	
public:
	__property int ID = {read=fID, nodefault};
	__property bool Initialized = {read=fInitialized, nodefault};
	virtual void __fastcall Init(void) = 0;
	virtual void __fastcall Burn(void) = 0;
	virtual void __fastcall Update(const void *Buffer, int Size) = 0;
	void __fastcall UpdateStr(const System::AnsiString Buffer);
	virtual void __fastcall Final(void *Digest) = 0;
	__fastcall virtual TDCP_hash(Classes::TComponent* AOwner);
	__fastcall virtual ~TDCP_hash(void);
	
__published:
	__property System::AnsiString Algorithm = {read=fAlgorithm, write=fNullStr};
	__property int HashSize = {read=fHashSize, write=SetHashSize, nodefault};
};

//-- var, const, procedure ---------------------------------------------------
#define DCPpage "DCPcrypt"
extern PACKAGE Word __fastcall LRot16(Word X, int c);
extern PACKAGE Word __fastcall RRot16(Word X, int c);
extern PACKAGE int __fastcall LRot32(int X, int c);
extern PACKAGE int __fastcall RRot32(int X, int c);
extern PACKAGE int __fastcall SwapDWord(int X);
extern PACKAGE void __fastcall XorBlock(PByteArray I1, PByteArray I2, PByteArray O1, int Len);

}	/* namespace Dcpcrypt */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Dcpcrypt;
#endif
//-- end unit ----------------------------------------------------------------
#endif	// DCPcrypt
