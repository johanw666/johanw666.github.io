//------------------------------------------------------------------------------
// This file is part of Remote Proxy Controller by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: defsetup.cpp
//
// Contains the code for the form that describes the proxy default nstallation
// parameters and allows the user to change them.
//------------------------------------------------------------------------------
#include <vcl.h>
#include <stdio.h>
#pragma hdrstop

#include "defsetup.h"
#include "edit.h"
#include "dirsel.h"
//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

//------------------------------------------------------------------------------
// Default constructor, not to be used.
//------------------------------------------------------------------------------
__fastcall TDefaultsForm::TDefaultsForm(TComponent* Owner): TForm(Owner)
{
}

//------------------------------------------------------------------------------
// Constructor. Sets the controls depending on the passed configuration data.
//------------------------------------------------------------------------------
__fastcall TDefaultsForm::TDefaultsForm(TComponent* Owner, ServiceParams* aCfg): TForm(Owner)
{
  CfgData = aCfg;
  // Set defaults
  ExeNameEdit->Text = CfgData->ExeFrom;
  IniNameEdit->Text = CfgData->JbiniFrom;
  // Set manual inifiles
  ManualBlockfileEdit->Text = CfgData->Sblockini;
  ManualAclFileEdit->Text = CfgData->Saclfileini;
  ManualCookieFileEdit->Text = CfgData->Scookieini;
  ManualForwardFileEdit->Text = CfgData->Sforwardini;
  ManualTrustFileEdit->Text = CfgData->Strustini;
  // Set auto inifiles
  ReReadIniFile();
  RemotePathEdit->Text = CfgData->DirectoryTo;
  RemoteNameEdit->Text = CfgData->RemoteName;
  DisplayNameEdit->Text = CfgData->DisplayName;
  ServiceNameEdit->Text = CfgData->ServiceName;
  // Set caption
  Caption = "Remote Service Default setup";
  // Startup
  StartAfterInstallCheckBox->Checked = CfgData->StartOnInstall;
  if ( CfgData->StartOnBoot ) AutoRadioButton->Checked = true;
  else ManualRadioButton->Checked = true;
  // Which inifiles
  if ( CfgData->useAutoIniFiles ) AutoInifileCheckBox->Checked = true;
  else AutoInifileCheckBox->Checked = false;
  // Position the form
  if ( Owner ) {
    Top = ((TForm*)Owner)->Top + (((TForm*)Owner)->Height - Height);
    if ( Top < 0 ) Top = 0;
    Left = ((TForm*)Owner)->Left + 0.5 * (((TForm*)Owner)->Width - Width);
  } else Position = poScreenCenter;
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::OKButtonClick(TObject* Sender)
{
  CopySettings();
  Close();
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::CancelButtonClick(TObject* Sender)
{
  Close();
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::SetTitle(AnsiString aTitle)
{
  Caption = aTitle;
}

//------------------------------------------------------------------------------
// Save the form data in the configuration data.
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::CopySettings()
{
  strncpy(CfgData->ExeFrom, ExeNameEdit->Text.c_str(), sizeof(CfgData->ExeFrom) - 1);
  strncpy(CfgData->JbiniFrom, IniNameEdit->Text.c_str(), sizeof(CfgData->JbiniFrom) - 1);
  if ( AutoInifileCheckBox->Checked ) {
    strncpy(CfgData->Sblockini, AutoBlockfileEdit->Text.c_str(), sizeof(CfgData->Sblockini) - 1);
    strncpy(CfgData->Saclfileini, AutoAclFileEdit->Text.c_str(), sizeof(CfgData->Saclfileini) - 1);
    strncpy(CfgData->Scookieini, AutoCookieFileEdit->Text.c_str(), sizeof(CfgData->Sforwardini) - 1);
    strncpy(CfgData->Sforwardini, AutoForwardFileEdit->Text.c_str(), sizeof(CfgData->Sblockini) - 1);
    strncpy(CfgData->Strustini, AutoTrustFileEdit->Text.c_str(), sizeof(CfgData->Strustini) - 1);
  } else {
    strncpy(CfgData->Sblockini, ManualBlockfileEdit->Text.c_str(), sizeof(CfgData->Sblockini) - 1);
    strncpy(CfgData->Saclfileini, ManualAclFileEdit->Text.c_str(), sizeof(CfgData->Saclfileini) - 1);
    strncpy(CfgData->Scookieini, ManualCookieFileEdit->Text.c_str(), sizeof(CfgData->Sforwardini) - 1);
    strncpy(CfgData->Sforwardini, ManualForwardFileEdit->Text.c_str(), sizeof(CfgData->Sblockini) - 1);
    strncpy(CfgData->Strustini, ManualTrustFileEdit->Text.c_str(), sizeof(CfgData->Strustini) - 1);
  }
  strncpy(CfgData->DirectoryTo, RemotePathEdit->Text.c_str(), sizeof(CfgData->DirectoryTo) - 1);
  strncpy(CfgData->RemoteName, RemoteNameEdit->Text.c_str(), sizeof(CfgData->RemoteName) - 1);
  strncpy(CfgData->DisplayName, DisplayNameEdit->Text.c_str(), sizeof(CfgData->DisplayName) - 1);
  strncpy(CfgData->ServiceName, ServiceNameEdit->Text.c_str(), sizeof(CfgData->ServiceName) - 1);
  // Startup data
  CfgData->StartOnInstall = StartAfterInstallCheckBox->Checked;
  CfgData->StartOnBoot = AutoRadioButton->Checked;
  // Which inifiles
  CfgData->useAutoIniFiles = AutoInifileCheckBox->Checked;
}

//------------------------------------------------------------------------------
// Browse for the default exe file
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::BrowseExeButtonClick(TObject* Sender)
{
  FileOpenDialog->Filter = "Executable files (*.exe)|*.exe";
  FileOpenDialog->FileName = "";
  FileOpenDialog->Options.Clear();
  FileOpenDialog->Options << ofFileMustExist << ofPathMustExist;
  if ( FileOpenDialog->Execute() ) {
    if ( FileExists(FileOpenDialog->FileName) ) ExeNameEdit->Text = FileOpenDialog->FileName;
  }
}

//------------------------------------------------------------------------------
// Browse for an ini file. Returns tru if the resulting file exists.
//------------------------------------------------------------------------------
bool __fastcall TDefaultsForm::BrowseIniFile(TEdit* destinationEdit)
{
  FileOpenDialog->Filter = "Inifiles (*.ini)|*.ini";
  FileOpenDialog->FileName = "";
  FileOpenDialog->Options.Clear();
  FileOpenDialog->Options << ofFileMustExist << ofPathMustExist;
  if ( FileOpenDialog->Execute() ) {
    if ( FileExists(FileOpenDialog->FileName) ) {
      destinationEdit->Text = FileOpenDialog->FileName;
      return true;
    }
  }
  return false;
}

//------------------------------------------------------------------------------
// Edit a inifile
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::EditIniFile(TEdit* fileNameEdit)
{
  if ( fileNameEdit->Text.Length() ) {
    TEditForm* EditForm = new TEditForm(this, fileNameEdit->Text);
    if ( EditForm ) {
      EditForm->ShowModal();
      delete EditForm;
    }
  } else
    Application->MessageBox("No inifile defined.", Application->Title.c_str(), MB_OK);
}

//------------------------------------------------------------------------------
// Browse for the default ini file
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::BrowseIniButtonClick(TObject* Sender)
{
  if ( BrowseIniFile(IniNameEdit) )
    ReReadIniFile();
}

//------------------------------------------------------------------------------
// Edit a new inifile
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::EditIniButtonClick(TObject* Sender)
{
  EditIniFile(IniNameEdit);
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::ManualBlockFileBrowseButtonClick(TObject* Sender)
{
  BrowseIniFile(ManualBlockfileEdit);
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::ManualAclFileBrowseButtonClick(TObject* Sender)
{
  BrowseIniFile(ManualAclFileEdit);
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::ManualCookieFileBrowseButtonClick(TObject* Sender)
{
  BrowseIniFile(ManualCookieFileEdit);
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::ManualForwardFileBrowseButtonClick(TObject* Sender)
{
  BrowseIniFile(ManualForwardFileEdit);
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::ManualTrustFileBrowseButtonClick(TObject* Sender)
{
  BrowseIniFile(ManualTrustFileEdit);
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::ManualBlockFileEditButtonClick(TObject* Sender)
{
  EditIniFile(ManualBlockfileEdit);
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::ManualAclFileEditButtonClick(TObject* Sender)
{
  EditIniFile(ManualAclFileEdit);
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::ManualCookieFileEditButtonClick(TObject* Sender)
{
  EditIniFile(ManualCookieFileEdit);
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::ManualForwardFileEditButtonClick(TObject* Sender)
{
  EditIniFile(ManualForwardFileEdit);
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::ManualTrustFileEditButtonClick(TObject* Sender)
{
  EditIniFile(ManualTrustFileEdit);
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::AutoBlockFileEditButtonClick(TObject* Sender)
{
  EditIniFile(AutoBlockfileEdit);
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::AutoAclFileEditButtonClick(TObject* Sender)
{
  EditIniFile(AutoAclFileEdit);
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::AutoCookieFileEditButtonClick(TObject* Sender)
{
  EditIniFile(AutoCookieFileEdit);
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::AutoForwardFileEditButtonClick(TObject* Sender)
{
  EditIniFile(AutoForwardFileEdit);
}

//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::AutoTrustFileEditButtonClick(TObject* Sender)
{
  EditIniFile(AutoTrustFileEdit);
}

//------------------------------------------------------------------------------
// Browse for the default directory on the remote system
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::BrowsePathButtonClick(TObject* Sender)
{
  TModalResult mrRes;

  TDirSelForm* DirSelForm = new TDirSelForm(this, RemotePathEdit->Text);
  if ( DirSelForm ) {
    mrRes = DirSelForm->ShowModal();
    if ( mrRes == mrOk ) {
      RemotePathEdit->Text = DirSelForm->DirectoryListBox1->Directory;
      if ( RemotePathEdit->Text.c_str()[strlen(RemotePathEdit->Text.c_str()) - 1] != '\\' )
        RemotePathEdit->Text = RemotePathEdit->Text + "\\";
    }
    delete DirSelForm;
  }
}

//------------------------------------------------------------------------------
// Make sure the entered path is correct
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::RemotePathEditExit(TObject *Sender)
{
  // Assures the remote path ends with a '\'
  if ( RemotePathEdit->Text.c_str()[strlen(RemotePathEdit->Text.c_str()) - 1] != '\\' )
    RemotePathEdit->Text = RemotePathEdit->Text + "\\";

  if ( RemotePathEdit->Text.c_str()[1] != ':' ) {
    Application->MessageBox("Path should be of the form <driveletter>:\\directory", Application->Title.c_str(), MB_OK);
    RemotePathEdit->SetFocus();
  }
}

//------------------------------------------------------------------------------
// Allow editing of the service name
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::EditNameCheckBoxClick(TObject* Sender)
{
  if ( EditNameCheckBox->Checked ) {
    Application->MessageBox("Warning: changing the service name can result in a disfunctioning setup!", Application->Title.c_str(), MB_OK|MB_ICONWARNING);
    ServiceNameEdit->Enabled = true;
  } else
    ServiceNameEdit->Enabled = false;
}

//------------------------------------------------------------------------------
// Re-read the other inifiles from the changed inifile
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::IniNameEditExit(TObject* Sender)
{
  ReReadIniFile();
}

//------------------------------------------------------------------------------
// Re-read the other inifiles from the changed inifile
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::ReReadIniFile()
{
  char Sblockini[MAX_PATH];
  char Saclfileini[MAX_PATH];
  char Scookieini[MAX_PATH];
  char Sforwardini[MAX_PATH];
  char Strustini[MAX_PATH];
  Sblockini[0] = 0;
  Saclfileini[0] = 0;
  Scookieini[0] = 0;
  Sforwardini[0] = 0;
  Strustini[0] = 0;

  MainForm->ParseMainIniFile(IniNameEdit->Text.c_str(), Sblockini, Saclfileini,
                             Scookieini, Sforwardini, Strustini, NULL, NULL, NULL);
  AutoBlockfileEdit->Text   = Sblockini;
  AutoAclFileEdit->Text     = Saclfileini;
  AutoCookieFileEdit->Text  = Scookieini;
  AutoForwardFileEdit->Text = Sforwardini;
  AutoTrustFileEdit->Text   = Strustini;
}

//------------------------------------------------------------------------------
// Switch between which inifiles we want to see
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::AutoInifileCheckBoxClick(TObject *Sender)
{
  if ( AutoInifileCheckBox->Checked ) {
    ManualIniFilesPanel->Visible = false;
    AutoIniFilesPanel->Visible = true;
    ManualButtonPanel->Visible = false;
  } else {
    AutoIniFilesPanel->Visible = false;
    ManualIniFilesPanel->Visible = true;
    ManualButtonPanel->Visible = true;
  }
}

//------------------------------------------------------------------------------
// Resize the form. We move the buttons and make the edit controls wider.
//------------------------------------------------------------------------------
void __fastcall TDefaultsForm::FormResize(TObject* Sender)
{
  BrowseExeButton->Left   = Panel3->Width - 4 - BrowseExeButton->Width;
  BrowseIniButton->Left   = BrowseExeButton->Left;
  EditIniButton->Left     = BrowseExeButton->Left + 42;
  BrowsePathButton->Left  = BrowseExeButton->Left;
  ExeNameEdit->Width      = BrowseExeButton->Left - ExeNameEdit->Left - 4;
  IniNameEdit->Width      = ExeNameEdit->Width;
  RemotePathEdit->Width   = ExeNameEdit->Width;
  AutoRadioButton->Top    = StartupRadioGroup->Top + 20;
  ManualRadioButton->Top  = AutoRadioButton->Top;
  StartAfterInstallCheckBox->Top = AutoRadioButton->Top;
  ManualIniFilesPanel->Width   = IniFilesGroupBox->Width - 205;
  ManualBlockfileEdit->Width   = ManualIniFilesPanel->Width - 9;
  ManualAclFileEdit->Width     = ManualBlockfileEdit->Width;
  ManualCookieFileEdit->Width  = ManualBlockfileEdit->Width;
  ManualForwardFileEdit->Width = ManualBlockfileEdit->Width;
  ManualTrustFileEdit->Width   = ManualBlockfileEdit->Width;
  AutoIniFilesPanel->Width     = ManualIniFilesPanel->Width;
  AutoBlockfileEdit->Width     = ManualBlockfileEdit->Width;
  AutoAclFileEdit->Width       = ManualBlockfileEdit->Width;
  AutoCookieFileEdit->Width    = ManualBlockfileEdit->Width;
  AutoForwardFileEdit->Width   = ManualBlockfileEdit->Width;
  AutoTrustFileEdit->Width     = ManualBlockfileEdit->Width;
  AutoBlockFileEditButton->Left   = EditIniButton->Left - 2;
  AutoAclFileEditButton->Left     = EditIniButton->Left - 2;
  AutoCookieFileEditButton->Left  = EditIniButton->Left - 2;
  AutoForwardFileEditButton->Left = EditIniButton->Left - 2;
  AutoTrustFileEditButton->Left   = EditIniButton->Left - 2;
}

//------------------------------------------------------------------------------
