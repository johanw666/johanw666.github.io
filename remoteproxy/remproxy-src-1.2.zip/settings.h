//------------------------------------------------------------------------------
// This file is part of Remote Proxy Controller by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: settings.h
//------------------------------------------------------------------------------
#ifndef settingsH
#define settingsH
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>

#include "sccclass.h"
//------------------------------------------------------------------------------
class TSettingsForm: public TForm
{
__published:
  TPanel* Panel1;
  TPanel* Panel2;
  TGroupBox* GUIGroupBox;
  TGroupBox* SettingsGroupBox;
  TLabel* Label1;
  TLabel* Label2;
  TLabel* Label3;
  TLabel* Label4;
  TEdit* WaitTimeEdit;
  TEdit* LogRefreshEdit;
  TButton* OKButton;
  TButton* CancelButton;
  TCheckBox* FindComputers1;
  TCheckBox* UpdateStatusOnStart1;
  TCheckBox* Minimizetosystray1;
  TCheckBox* ScanOnlyForNT;
  TCheckBox* DebugCheckBox;
  TCheckBox* DefaultPasswordCheckBox;
  TCheckBox* Selectline1;
  TCheckBox* AutoRefreshLogs1;
  void __fastcall WaitTimeEditExit(TObject* Sender);
  void __fastcall LogRefreshEditExit(TObject* Sender);
  void __fastcall CancelButtonClick(TObject* Sender);
  void __fastcall OKButtonClick(TObject* Sender);
  void __fastcall AutoRefreshLogs1Click(TObject* Sender);
private:
  __fastcall TSettingsForm(TComponent* Owner);
  ProgramCfg* newPcfg;
public:
  __fastcall TSettingsForm(TComponent* Owner, ProgramCfg* pcfg);
};
//------------------------------------------------------------------------------
#endif

