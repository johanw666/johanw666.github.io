//------------------------------------------------------------------------------
// This file is part of Remote Proxy Controller by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: password.h
//------------------------------------------------------------------------------
#ifndef passwordH
#define passwordH
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//------------------------------------------------------------------------------
class TPasswordForm: public TForm
{
__published:
  TPanel* Panel1;
  TPanel* Panel2;
  TPanel* Panel3;
  TButton* OKButton;
  TLabel* PwdLabel;
  TEdit* PwdMaskEdit;
  TButton* CancelButton;
  TLabel* RetryLabel;
  TEdit* ReenterMaskEdit;
  void __fastcall OKButtonClick(TObject* Sender);
  void __fastcall PwdEditKeyPress(TObject* Sender, char& Key);
  void __fastcall FormShow(TObject* Sender);
  void __fastcall ReenterEditKeyPress(TObject* Sender, char& Key);
private:
  char* fPwd;
  size_t fMaxLen;
  bool fReenter;
  __fastcall TPasswordForm(TComponent* Owner);
public:
  __fastcall TPasswordForm(TComponent* Owner, char* pwd, size_t maxLen, bool reenter);
};
//------------------------------------------------------------------------------
#endif
