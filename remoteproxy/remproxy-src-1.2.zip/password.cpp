//------------------------------------------------------------------------------
// This file is part of Remote Proxy Controller by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: password.cpp
//
// Contains the code for the form that asks for the password protection of
// the NT login data.
//------------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "password.h"
#include "scc.h"
//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
//------------------------------------------------------------------------------
// Default constructor, private so it can't be used
//------------------------------------------------------------------------------
__fastcall TPasswordForm::TPasswordForm(TComponent* Owner): TForm(Owner)
{
}

//------------------------------------------------------------------------------
// Constructor. Save the pointer to the program password in a private variable
// and position the form.
//------------------------------------------------------------------------------
__fastcall TPasswordForm::TPasswordForm(TComponent* Owner, char* pwd, size_t maxLen, bool reenter): TForm(Owner)
{
  fPwd = pwd;
  fMaxLen = maxLen;
  fReenter = reenter;
  if ( Owner ) {
    // Position the form
    Top = MainForm->Top + 0.5 * (MainForm->Height - Height);
    Left = MainForm->Left + 0.5 * (MainForm->Width - Width);
  } else Position = poScreenCenter;
}

//------------------------------------------------------------------------------
// OK button is pressed. Check if the passwords are the same (if this applies),
// and if it was non-empty.
//------------------------------------------------------------------------------
void __fastcall TPasswordForm::OKButtonClick(TObject* Sender)
{
  bool cnt = true;

  if ( fReenter ) {
    if ( PwdMaskEdit->Text != ReenterMaskEdit->Text ) {
      Application->MessageBox("The passwords were not the same. Please retry.", Application->Title.c_str(), MB_OK);
      PwdMaskEdit->SetFocus();
      cnt = false;
    }
  }
  if ( cnt && !PwdMaskEdit->Text.Length() ) {
    if ( Application->MessageBox("The password was empty. Continue anyway?", Application->Title.c_str(), MB_YESNO) == ID_NO )
      cnt = false;
      PwdMaskEdit->SetFocus();
  }
  if ( cnt && (size_t)PwdMaskEdit->Text.Length() > fMaxLen ) {
    Application->MessageBox(AnsiString("The password is too long, max = " + IntToStr(fMaxLen) + "chars.\nTruncated to " + IntToStr(fMaxLen) + "characters.").c_str(), Application->Title.c_str(), MB_OK);
    cnt = true;
  }
  if ( cnt ) {
    strncpy(fPwd, PwdMaskEdit->Text.c_str(), fMaxLen);
    ModalResult = mrOk;
  }
}

//------------------------------------------------------------------------------
// Enter means password is entered.
//------------------------------------------------------------------------------
void __fastcall TPasswordForm::PwdEditKeyPress(TObject* Sender, char& Key)
{
  if ( Key == VK_RETURN ) {
    if ( ReenterMaskEdit->Visible ) {
      ReenterMaskEdit->SetFocus();
    }
    else {
      OKButtonClick(Sender);
    }
  }
}

//------------------------------------------------------------------------------
// Enter means password is entered.
//------------------------------------------------------------------------------
void __fastcall TPasswordForm::ReenterEditKeyPress(TObject* Sender, char& Key)
{
  if ( Key == VK_RETURN )
    OKButtonClick(Sender);
}

//------------------------------------------------------------------------------
// See if we need to set the re-enter controls visible.
//------------------------------------------------------------------------------
void __fastcall TPasswordForm::FormShow(TObject* Sender)
{
  if ( !fReenter ) {
    RetryLabel->Visible = false;
    ReenterMaskEdit->Visible = false;
  }
}
//------------------------------------------------------------------------------

