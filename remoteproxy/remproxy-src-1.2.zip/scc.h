//------------------------------------------------------------------------------
// This file is part of Remote Proxy Controller by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: scc.h
//------------------------------------------------------------------------------
#ifndef sccH
#define sccH
//------------------------------------------------------------------------------
#include <stdarg.h>
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <inifiles.hpp>
#include <ExtCtrls.hpp>
#include <Mask.hpp>
#include <Menus.hpp>
#include <ComCtrls.hpp>

#include "sccclass.h"
//------------------------------------------------------------------------------
// Program constants
//------------------------------------------------------------------------------
// How did the program exit (used for saving its settings)
const int PRG_CLOSE_OTHER  = 0; // Other close command (like the caption bar button)
const int PRG_CLOSE_EXIT   = 1; // Exit button pressed
const int PRG_CLOSE_CANCEL = 2; // Cancel button pressed
// User defined message
const UINT WM_SCAN_THREAD_READY   = WM_USER + 1;
const UINT WM_TRAYNOTIFY          = WM_USER + 2;
const UINT WM_CLOSE_VIEW_LOGFILE  = WM_USER + 3; // logfile view form close notification
// Update status
const WPARAM DO_NOT_UPDATE_STATUS = 0;
const WPARAM DO_UPDATE_STATUS     = 1;
// System tray
const int IDC_TRAY1 = 1005;
// Service name
extern const char* ServiceName;

//------------------------------------------------------------------------------
// generic error message handler
void __fastcall ShowErrorMessage(char aHeaderText[], DWORD* errCode);
void __fastcall GetErrormessage(DWORD* errCode, char* buffer, size_t buffSize);
// Get the type of a remote server
long __fastcall GetRemotePlatformType(char* servername);
// Conversion to- and from unicode (required for GetRemotePlatformType).
const char* UnicodeToAnsi(const void* ustr);
LPCWSTR AnsiToUnicode(const char* astr);

// Debug functions.
void __fastcall WriteDebugString(char* fileName, char* msg);
extern AnsiString tracefile;

// The main form and all its functionality
class TMainForm: public TForm
{
__published:
  TPanel* ButtonPanel;
  TListView* ComputersListView;
  TButton* InstallButton;
  TButton* RemoveButton;
  TButton* StartButton;
  TButton* StopButton;
  TButton* AddPCButton;
  TButton* RemPCButton;
  TButton* ConfigButton;
  TButton* UpdateButton;
  TButton* DefaultButton;
  TButton* NetworkButton;
  TMainMenu* RsccMainMenu;
  TPopupMenu* RsccPopupMenu;
  TMenuItem* File1;
  TMenuItem* Exit1;
  TMenuItem* Service1;
  TMenuItem* Installservice1;
  TMenuItem* Removeservice1;
  TMenuItem* Stopservice1;
  TMenuItem* Addcomputer1;
  TMenuItem* Removecomputers1;
  TMenuItem* Configure1;
  TMenuItem* Updatestatus1;
  TMenuItem* Defaultsetup1;
  TMenuItem* Addnetworkedcomputers1;
  TMenuItem* Help1;
  TMenuItem* About1;
  TMenuItem* Help2;
  TMenuItem* Startservice1;
  TMenuItem* Cancel1;
  TMenuItem* Installservice2;
  TMenuItem* Removeservice2;
  TMenuItem* Startservice2;
  TMenuItem* Stopservice2;
  TMenuItem* Computername1;
  TMenuItem* N1;
  TMenuItem* Configureservice2;
  TMenuItem* Computers1;
  TMenuItem* Inifiles2;
  TButton*   SwitchAccountButton;
  TMenuItem* AccountItem1;
  TMenuItem* Preferences1;
  TMenuItem* Logfile2;
  TMenuItem* Logfile1;
  TMenuItem* BAR0;
  TMenuItem* BAR1;
  TMenuItem* BAR2;
  TMenuItem* BAR4;
  TButton* LogfileButton;
  TPopupMenu* TrayPopupMenu;
  TMenuItem* Closeprogram3;
  TMenuItem* Exitprogram3;
  TMenuItem* Restore3;
  TMenuItem* N2;
  TMenuItem* Progname3;
  TMenuItem* Savesettings1;
  TMenuItem* DefaultPassword1;
  TMenuItem* Password1;
  TMenuItem* ShowButtons1;
  TMenuItem* settings1;
  TPanel* WaitThreadPanel;
  TLabel* WaitThreadLabel;
  TLabel* InfoThreadLabel;
  TButton* MinimizeButton;
  TMenuItem* ViewDebugFile1;
  TMenuItem* Pauseservice1;
  TMenuItem* Continueservice1;
  TMenuItem* Viewjunkbstrini1;
  TMenuItem* Inifiles1;
  TMenuItem* Blockfile1;
  TButton* ExitButton;
  TButton* CancelButton;
  TMenuItem* Saclfileini1;
  TMenuItem* Cookiefile1;
  TMenuItem* Forwardfile1;
  TMenuItem* Trustfile1;
  TMenuItem *Viewjunkbstrini2;
  TMenuItem* Blockfile2;
  TMenuItem* Saclfileini2;
  TMenuItem* Cookiefile2;
  TMenuItem* Forwardfile2;
  TMenuItem* Trustfile2;
  TMenuItem* Window1;
  TPanel* WaitUpdatePanel;
  TLabel* WaitUpdateLabel;
  TLabel* InfoUpdateLabel;
  TButton* AboutButton;
  TButton* HelpButton;
  TMenuItem* Continueservice2;
  TMenuItem* Pauseservice2;
  void __fastcall FormShow(TObject* Sender);
  void __fastcall FormClose(TObject* Sender, TCloseAction &Action);
  void __fastcall DefaultButtonClick(TObject* Sender);
  void __fastcall ExitButtonClick(TObject* Sender);
  void __fastcall AddPCButtonClick(TObject* Sender);
  void __fastcall RemPCButtonClick(TObject* Sender);
  void __fastcall InstallButtonClick(TObject* Sender);
  void __fastcall UpdateButtonClick(TObject* Sender);
  void __fastcall AboutButtonClick(TObject* Sender);
  void __fastcall ConfigButtonClick(TObject* Sender);
  void __fastcall RemoveButtonClick(TObject* Sender);
  void __fastcall StopButtonClick(TObject* Sender);
  void __fastcall StartButtonClick(TObject* Sender);
  void __fastcall CancelButtonClick(TObject* Sender);
  void __fastcall NetworkButtonClick(TObject* Sender);
  void __fastcall ComputersListViewKeyDown(TObject* Sender, WORD& Key, TShiftState Shift);
  void __fastcall HelpButtonClick(TObject* Sender);
  void __fastcall RsccPopupMenuPopup(TObject* Sender);
  void __fastcall ComputersListViewMouseDown(TObject* Sender, TMouseButton Button, TShiftState Shift, int X, int Y);
  void __fastcall ComputersListViewClick(TObject* Sender);
  void __fastcall EditCommandButtonClick(TObject* Sender);
  void __fastcall SwitchAccountButtonClick(TObject* Sender);
  void __fastcall ComputersListViewColumnClick(TObject* Sender, TListColumn* Column);
  void __fastcall ComputersListViewCompare(TObject* Sender, TListItem* Item1, TListItem* Item2, int Data, int& Compare);
  void __fastcall Logfile1Click(TObject* Sender);
  void __fastcall Restore3Click(TObject* Sender);
  void __fastcall Savesettings1Click(TObject* Sender);
  void __fastcall DefaultPassword1Click(TObject* Sender);
  void __fastcall Password1Click(TObject* Sender);
  void __fastcall ShowButtons1Click(TObject* Sender);
  void __fastcall settings1Click(TObject* Sender);
  void __fastcall MinimizeButtonClick(TObject* Sender);
  void __fastcall ViewDebugFile1Click(TObject* Sender);
  void __fastcall Pauseservice1Click(TObject* Sender);
  void __fastcall Continueservice1Click(TObject* Sender);
  void __fastcall ViewIniClick(TObject* Sender);
  void __fastcall WindowClick(TObject* Sender);
private:
  DWORD __fastcall GetWin32Platform(char* versionText, size_t buffSize);
  void __fastcall ReadDefaultsFromIni(ServiceParams* aCfg);
  void __fastcall ReadComputerNames(void);
  bool __fastcall IsServiceManagerInstalled(char aComputername[]);
  bool __fastcall IsServiceInstalled(char aComputerName[]);
  bool __fastcall IsServiceRunning(char aComputername[]);
  bool __fastcall IsServicePaused(char aComputername[]);
  void __fastcall GetNetworkComputerNames(bool aRunUpdateAfterwards);
  bool __fastcall NameIsDouble(char* name);
  bool __fastcall WaitForServiceToReachStatus(SC_HANDLE aHService, DWORD aServiceStatus, int max_wait_seconds, char aMachineName[]);
  void __fastcall ReadIniSettings(void);
  void __fastcall SaveIniSettings(void);
  DWORD __fastcall GetServiceStatus(char aComputerName[]);
  void __fastcall GetServicePath(char computerName[], char* servicePathBuffer, size_t buffSize);
  void __fastcall GetExecutableName(char aComputerName[], char aPathName[], char networkPath[]);
  void __fastcall UpdateStatus(int index, bool updateAll);
  void __fastcall StoreComputerNames(void);
  char* __fastcall ExtractFileNameWithoutExt(const char* aFileName, char* buffer, size_t buffSize);
  AnsiString __fastcall ServiceStateDescription(DWORD serviceState);
  AnsiString __fastcall ControlcodeDescription(DWORD dwControl);
  DWORD __fastcall GetResultingStatusFromControlCode(DWORD dwControl);
  void __fastcall SendSignalToRemoteService(DWORD dwControl);
  void __fastcall AddNode(TList* l, TObject* o, AnsiString caption);
  class TViewLogFileForm* __fastcall CheckForDoubleFile(AnsiString caption);  
  // Default info when starting up rscc
  void __fastcall SetServiceDataDefaults(void);
  bool __fastcall SetServiceDefaults();
  void __fastcall GetRemoteIniFileName(char computername[], char buffer[], size_t buffsize);
  // Infocreen when lengthy network or update stuff is in progress
  void __fastcall ShowThreadWaitInfo(void);
  void __fastcall HideThreadWaitInfo(void);
  void __fastcall ShowUpdateWaitInfo(void);
  void __fastcall HideUpdateWaitInfo(void);
  void __fastcall SetUpdateWaitText(AnsiString label, AnsiString info);
  // Functions that offer debug options
  BOOL RSCC_ControlService(SC_HANDLE hService, DWORD dwControl, LPSERVICE_STATUS lpServiceStatus, bool writedebuginfo, char* computername);
  BOOL RSCC_StartService(SC_HANDLE hService, DWORD dwNumServiceArgs, LPCTSTR* lpServiceArgVectors, bool writedebuginfo, char* computername);
  BOOL RSCC_CopyFile(LPCTSTR lpExistingFileName, LPCTSTR lpNewFileName, BOOL bFailIfExists, bool writedebuginfo);
  BOOL RSCC_DeleteFile(LPCTSTR lpFileName, bool writedebuginfo);
  BOOL RSCC_MoveFileEx(LPCTSTR lpExistingFileName, LPCTSTR lpNewFileName, DWORD dwFlags, bool writedebuginfo);
  // For browsing the network neighbourhood
  DWORD ListType, ResourceType;
  // Default settings
  ServiceParams serviceData;
  ServiceParams orgServiceData;
  ProgramCfg orgpcfg; // Program configuration data that was read at program start
  ProgramCfg pcfg; // Current program configuration data
  TListItem* CurrActiveItem; // Used to carry selected item info
  int ColumnClicked; // Used to see on which column in the listview is clicked
  // Store default settings
  TIniFile* ProgramSettingsFile;
  AnsiString iniFileName;
  int prgCloseReason; // How did the program reach its FormClose handler
  bool NetworkScanThreadIsRunning; // True if the network is being scanned
  // Used to gain more priviliges if required
  HANDLE hToken;
  // Used for minimize to systray methods
  Graphics::TIcon* TrayIcon;
  TList* viewLogFilesChildren;
  void __fastcall WMCloseViewLog(TMessage& Message);
  void __fastcall WMTrayNotify(TMessage& Msg);
  void __fastcall RemoveIcon();
  void __fastcall AddIcon();
  void __fastcall AppOnMinimize(TObject* Sender);
  void __fastcall AppOnRestore(TObject* Sender);
public:
  __fastcall TMainForm(TComponent* Owner);
  __fastcall ~TMainForm();
  TListItem* fNewItem;
  bool __fastcall AddOnlyNTMachinesInView(void);
  void __fastcall SetThreadWaitText(AnsiString label, AnsiString info);
  void __fastcall ParseMainIniFile(char mainIniFilename[],
                                   char fBlock[],
                                   char fAcl[],
                                   char fCookie[],
                                   char fForward[],
                                   char fTrust[],
                                   char fLog[],
                                   bool* bLog,
                                   char listen_addr[]);
protected:
  void __fastcall CMScanThreadReady(TMessage& Message);

  BEGIN_MESSAGE_MAP
    MESSAGE_HANDLER(WM_SCAN_THREAD_READY, TMessage, CMScanThreadReady)
    MESSAGE_HANDLER(WM_TRAYNOTIFY, TMessage, WMTrayNotify)
    MESSAGE_HANDLER(WM_CLOSE_VIEW_LOGFILE, TMessage, WMCloseViewLog)
  END_MESSAGE_MAP(TControl)
};

//------------------------------------------------------------------------------
// The thread that reads the network computer names
//------------------------------------------------------------------------------
class TNetworkScanThread: public TThread
{
public:
  __fastcall TNetworkScanThread(bool createSuspended,  // true = start after Resume method called
                                bool aRunUpdateAfterwards,
                                TMainForm* Owner);     // Owning form
  __fastcall ~TNetworkScanThread();
  void __fastcall Execute(void);

private:
  TMainForm* OwnerForm;
  bool fRunUpdateAfterwards;
  bool __fastcall NameIsDouble(char* name);
  void __fastcall FindNetworkComputerNames(LPNETRESOURCE lpnr);
};

//---------------------------------------------------------------------------
extern PACKAGE TMainForm* MainForm;
//---------------------------------------------------------------------------
#endif

