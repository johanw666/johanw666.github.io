//------------------------------------------------------------------------------
// This file is part of Remote Proxy Controller by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: help.cpp
//
// Contains the helpform.
//------------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "help.h"
//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

//------------------------------------------------------------------------------
// Constructor. Positions the form.
//------------------------------------------------------------------------------
__fastcall THelpForm::THelpForm(TComponent* Owner): TForm(Owner)
{
  if ( Owner ) {
    Top = ((TForm*)Owner)->Top + (((TForm*)Owner)->Height - Height);
    if ( Top < 0 ) Top = 0;
    Left = ((TForm*)Owner)->Left;
  } else Position = poScreenCenter;
}

//------------------------------------------------------------------------------
// Close the form when escape or enter is pressed.
//------------------------------------------------------------------------------
void __fastcall THelpForm::CloseButtonKeyDown(TObject* Sender, WORD& Key, TShiftState Shift)
{
  if ( (Key == VK_ESCAPE) || (Key == VK_RETURN) ) Close();
}

//------------------------------------------------------------------------------
void __fastcall THelpForm::CloseButtonClick(TObject* Sender)
{
  Close();
}

//------------------------------------------------------------------------------

