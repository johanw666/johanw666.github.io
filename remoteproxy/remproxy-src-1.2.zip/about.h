//------------------------------------------------------------------------------
// This file is part of Remote Proxy Controller by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: about.h
//------------------------------------------------------------------------------
#ifndef aboutH
#define aboutH
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//------------------------------------------------------------------------------
class TAboutForm: public TForm
{
__published:
  TButton* OKButton;
  TPanel* Panel1;
  TPanel* Panel2;
  TPanel* Panel3;
  TPanel* Panel4;
  TLabel* MailLabel;
  TLabel* VersionLabel;
  TLabel* WindowsVersionLabel;
  TLabel* WebsiteLabel;
  TLabel* UpdateLabel;
  TLabel* GPLLabel;
  TLabel* Label2;
  TLabel* Label4;
  TLabel* Label5;
  TLabel* Label6;
  TLabel* Label7;
  TLabel* Label8;
    TLabel *Label1;
    TLabel *Label3;
  void __fastcall OKButtonClick(TObject* Sender);
  void __fastcall MailLabelClick(TObject* Sender);
  void __fastcall FormKeyDown(TObject* Sender, WORD& Key, TShiftState Shift);
  void __fastcall FormShow(TObject* Sender);
  void __fastcall WebsiteLabelClick(TObject* Sender);
  void __fastcall Label7Click(TObject* Sender);
private:

public:
  __fastcall TAboutForm(TComponent* Owner);
};
//------------------------------------------------------------------------------
extern PACKAGE TAboutForm* AboutForm;
//------------------------------------------------------------------------------
#endif

