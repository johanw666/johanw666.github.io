// Borland C++ Builder
// Copyright (c) 1995, 1998 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'SHA1.pas' rev: 3.00

#ifndef SHA1HPP
#define SHA1HPP
#include <DCPcrypt.hpp>
#include <SysUtils.hpp>
#include <Classes.hpp>
#include <SysInit.hpp>
#include <System.hpp>

//-- user supplied -----------------------------------------------------------

namespace Sha1
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TDCP_sha1;
class PASCALIMPLEMENTATION TDCP_sha1 : public Dcpcrypt::TDCP_hash 
{
	typedef Dcpcrypt::TDCP_hash inherited;
	
protected:
	int LenHi;
	int LenLo;
	int Index;
	int CurrentHash[5];
	Byte HashBuffer[64];
	void __fastcall Compress(void);
	void __fastcall UpdateLen(int Len);
	
public:
	virtual void __fastcall Init(void);
	virtual void __fastcall Burn(void);
	virtual void __fastcall Update(const void *Buffer, int Size);
	virtual void __fastcall Final(void *Digest);
	__fastcall virtual TDCP_sha1(Classes::TComponent* AOwner);
public:
	/* TDCP_hash.Destroy */ __fastcall virtual ~TDCP_sha1(void) { }
	
};

//-- var, const, procedure ---------------------------------------------------

}	/* namespace Sha1 */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Sha1;
#endif
//-- end unit ----------------------------------------------------------------
#endif	// SHA1
