//------------------------------------------------------------------------------
// This file is part of Remote Proxy Controller by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: defsetup.h
//------------------------------------------------------------------------------
#ifndef defsetupH
#define defsetupH
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>

#include "scc.h"
#include <Mask.hpp>
//------------------------------------------------------------------------------
class TDefaultsForm: public TForm
{
__published:
  TPanel* Panel1;
  TPanel* Panel2;
  TPanel* Panel3;
  TButton* OKButton;
  TButton* CancelButton;
  TEdit* RemotePathEdit;
  TLabel* DestPathLabel;
  TLabel* RemotenameLabel;
  TEdit* RemoteNameEdit;
  TOpenDialog* FileOpenDialog;
  TLabel* DisplayLabel;
  TEdit* DisplayNameEdit;
  TButton* BrowsePathButton;
  TLabel* ServiceNameLabel;
  TEdit* ServiceNameEdit;
  TCheckBox* EditNameCheckBox;
  TPanel* Panel4;
  TRadioGroup* StartupRadioGroup;
  TRadioButton* AutoRadioButton;
  TRadioButton* ManualRadioButton;
  TCheckBox* StartAfterInstallCheckBox;
  TGroupBox* IniFilesGroupBox;
  TPanel* AutoIniFilesPanel;
  TEdit* AutoTrustFileEdit;
  TEdit* AutoForwardFileEdit;
  TEdit* AutoCookieFileEdit;
  TEdit* AutoAclFileEdit;
  TEdit* AutoBlockfileEdit;
  TPanel* ManualButtonPanel;
  TPanel* ManualIniFilesPanel;
  TEdit* ManualBlockfileEdit;
  TEdit* ManualAclFileEdit;
  TEdit* ManualCookieFileEdit;
  TEdit* ManualForwardFileEdit;
  TEdit* ManualTrustFileEdit;
  TLabel* Label1;
  TLabel* Label2;
  TLabel* Label3;
  TLabel* Label4;
  TLabel* Label5;
  TButton* ManualBlockFileBrowseButton;
  TButton* ManualBlockFileEditButton;
  TButton* ManualAclFileBrowseButton;
  TButton* ManualAclFileEditButton;
  TButton* ManualCookieFileBrowseButton;
  TButton* ManualCookieFileEditButton;
  TButton* ManualForwardFileBrowseButton;
  TButton* ManualForwardFileEditButton;
  TButton* ManualTrustFileBrowseButton;
  TButton* ManualTrustFileEditButton;
  TCheckBox* AutoInifileCheckBox;
  TPanel* TopPanel;
  TLabel* ExeLabel;
  TEdit* ExeNameEdit;
  TLabel* IniLabel;
  TEdit* IniNameEdit;
  TButton* BrowseIniButton;
  TButton* EditIniButton;
  TButton* BrowseExeButton;
  TButton* AutoBlockFileEditButton;
  TButton* AutoAclFileEditButton;
  TButton* AutoCookieFileEditButton;
  TButton* AutoForwardFileEditButton;
  TButton* AutoTrustFileEditButton;
  void __fastcall OKButtonClick(TObject* Sender);
  void __fastcall CancelButtonClick(TObject* Sender);
  void __fastcall BrowseExeButtonClick(TObject* Sender);
  void __fastcall BrowseIniButtonClick(TObject* Sender);
  void __fastcall BrowsePathButtonClick(TObject* Sender);
  void __fastcall RemotePathEditExit(TObject* Sender);
  void __fastcall EditNameCheckBoxClick(TObject* Sender);
  void __fastcall FormResize(TObject* Sender);
  void __fastcall EditIniButtonClick(TObject* Sender);
  void __fastcall IniNameEditExit(TObject* Sender);
  void __fastcall AutoInifileCheckBoxClick(TObject* Sender);
  void __fastcall ManualBlockFileBrowseButtonClick(TObject* Sender);
  void __fastcall ManualAclFileBrowseButtonClick(TObject* Sender);
  void __fastcall ManualCookieFileBrowseButtonClick(TObject* Sender);
  void __fastcall ManualForwardFileBrowseButtonClick(TObject* Sender);
  void __fastcall ManualTrustFileBrowseButtonClick(TObject* Sender);
  void __fastcall ManualBlockFileEditButtonClick(TObject* Sender);
  void __fastcall ManualAclFileEditButtonClick(TObject* Sender);
  void __fastcall ManualCookieFileEditButtonClick(TObject* Sender);
  void __fastcall ManualForwardFileEditButtonClick(TObject* Sender);
  void __fastcall ManualTrustFileEditButtonClick(TObject* Sender);
  void __fastcall AutoBlockFileEditButtonClick(TObject* Sender);
  void __fastcall AutoAclFileEditButtonClick(TObject* Sender);
  void __fastcall AutoCookieFileEditButtonClick(TObject* Sender);
  void __fastcall AutoForwardFileEditButtonClick(TObject* Sender);
  void __fastcall AutoTrustFileEditButtonClick(TObject* Sender);
private:
  ServiceParams* CfgData;
  __fastcall TDefaultsForm(TComponent* Owner); // Hide default constructor
  void __fastcall ReReadIniFile(void);
  void __fastcall CopySettings(void);
  bool __fastcall BrowseIniFile(TEdit* destinationEdit);
  void __fastcall EditIniFile(TEdit* fileNameEdit);
public:
  __fastcall TDefaultsForm(TComponent* Owner, ServiceParams* aCfg);
  void __fastcall SetTitle(AnsiString aTitle);
};
//------------------------------------------------------------------------------
#endif

  