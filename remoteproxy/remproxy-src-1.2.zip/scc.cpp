//------------------------------------------------------------------------------
// This file is part of Remote Proxy Controller by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: scc.cpp
//
// Contains the code for the main form and the network scan thread. It also
// contains all service manager code.
//------------------------------------------------------------------------------
#include <vcl.h>
#include <FileCtrl.hpp>
#include <shellapi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <lm.h>  // LAN manager API for NetServerGetInfo
#pragma hdrstop

#include "scc.h"
#include "defsetup.h"
#include "addpc.h"
#include "config.h"
#include "about.h"
#include "help.h"
#include "edit.h"
#include "account.h"
#include "logfile.h"
#include "password.h"
#include "settings.h"
//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMainForm* MainForm;

//------------------------------------------------------------------------------
// Program constants
//------------------------------------------------------------------------------
// Listview indices
const int lStatusIndex   = 0; // Service status
const int lPathIndex     = 1; // Service path
const int lListenIndex   = 2; // Listen address
const int lLogIndex      = 3; // If proxy uses logfile
// Error constant
const int NO_SERVICEMANAGER_FOUND = 0x21;
// The following is standard in Win2000 but does not work in NT4
#ifndef SERVICE_CONTROL_PARAMCHANGE
const DWORD SERVICE_CONTROL_PARAMCHANGE = 0x06;
#endif
// Service name
const char* ServiceName = "junkbuster";
//------------------------------------------------------------------------------
// Default column sizes
const int defaultNameColumnWidth   = 110;
const int defaultStatusColumnWidth = 150;
const int defaultPathColumnWidth   = 350;
const int defaultListenColumnWidth = 100;
const int defaultLogColumnWidth    =  30;
// Default form sizes
const int defaultTopPos     = 0;
const int defaultLeftPos    = 0;
const int defaultFormHeight = 300;
const int defaultFormWidth  = 765;
// Name of the logfile, if used
AnsiString tracefile;

//------------------------------------------------------------------------------
// Show error string. This method is either passed the address of an error code
// or, when NULL is passed, will call GetLastError().
//------------------------------------------------------------------------------
void __fastcall ShowErrorMessage(char aHeaderText[], DWORD* errCode)
{
  LPVOID lpMsgBuf; // For error info text
  DWORD errorCode; // For error code if required.
  // If pointer is NULL, get errorcode from windows
  if ( !errCode ) errorCode = GetLastError();
  else errorCode = *errCode;

  FormatMessage(
    FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
    NULL,
    errorCode,
    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
    (LPTSTR)&lpMsgBuf, 0, NULL);
  // Display the message.
  Application->MessageBox((char*)lpMsgBuf, aHeaderText, MB_OK|MB_ICONWARNING);
  // Free the buffer.
  LocalFree(lpMsgBuf);
}

//------------------------------------------------------------------------------
// Get the errormessage and return it in buffer.
//------------------------------------------------------------------------------
void __fastcall GetErrormessage(DWORD* errCode, char* buffer, size_t buffSize)
{
  LPVOID lpMsgBuf; // For error info text
  DWORD errorCode; // For error code if required.
  // If pointer is NULL, get errorcode from windows
  if ( !errCode ) errorCode = GetLastError();
  else errorCode = *errCode;

  FormatMessage(
    FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
    NULL,
    errorCode,
    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
    (LPTSTR)&lpMsgBuf, 0, NULL);

  strncpy(buffer, (char*)lpMsgBuf, buffSize);
  strcat(buffer, "\n");
  // Free the buffer.
  LocalFree(lpMsgBuf);
}

//------------------------------------------------------------------------------
// Returns the type of a remote machine. NetServerGetInfo called on level 101
// rewuires no special privileges.
// returns 400 for win95, 410 for win98, 490 for WinME,
// 2000+350 for NT3.5, 2000+400 for NT4, 2000+500 for NT 5 etc.
// Returns 0 if machine is neither WinNT or Win9x.
//------------------------------------------------------------------------------
long __fastcall GetRemotePlatformType(char* servername)
{
  long ver = 0;
  LPSERVER_INFO_101 si = NULL;
  // Function NetServerGetInfo() requires unicode input.
  LPCWSTR uServerName = AnsiToUnicode(servername);

  if ( !NetServerGetInfo((LPTSTR)uServerName, 101, (LPBYTE*)&si) ) {
    if ((si->sv101_type & (SV_TYPE_NT | SV_TYPE_WINDOWS)) != 0 ) {
      ver = (si->sv101_version_major * 100) + (si->sv101_version_minor);
      if ( (si->sv101_type & SV_TYPE_NT) != 0 ) ver += 2000;
    }
  }
  if ( si ) NetApiBufferFree(si);
  return ver;
}

//------------------------------------------------------------------------------
// Converts the unicode string ustr to ANSI. The string may not contain more
// than 511 unicode characters.
//------------------------------------------------------------------------------
const char* UnicodeToAnsi(const void* ustr)
{
  static char outbuf[512];
  if (ustr) {
    if (WideCharToMultiByte(CP_ACP, 0, (LPCWSTR)ustr, -1, outbuf, sizeof(outbuf), NULL, NULL) > 0) {
      outbuf[sizeof(outbuf)-1] = '\0';
      return outbuf;
    }
  }
  return "";
}

//------------------------------------------------------------------------------
// Converts the ANSI string astr to unicode. The string may not contain more
// than 511 ANSI characters.
//------------------------------------------------------------------------------
LPCWSTR AnsiToUnicode(const char* astr)
{
  static char outbuf[2*512];
  if (astr) {
    if (MultiByteToWideChar( CP_ACP, 0, (LPCSTR)astr, -1, (LPWSTR)&outbuf[0], sizeof(outbuf)>>1 ) > 0) {
      outbuf[sizeof(outbuf)-2] = 0;
      outbuf[sizeof(outbuf)-1] = 0;
      return (LPCWSTR)&outbuf[0];
    }
  }
  return L"";
}

//------------------------------------------------------------------------------
// Debug functions. if writedebuginfo == true they write debug info to the logfile.
//------------------------------------------------------------------------------
// Debug version of ControlService()
//------------------------------------------------------------------------------
BOOL TMainForm::RSCC_ControlService(SC_HANDLE hService, DWORD dwControl, LPSERVICE_STATUS lpServiceStatus, bool writedebuginfo, char* computername)
{
  BOOL retVal = ControlService(hService, dwControl, lpServiceStatus);
  // Store old errorcode in case something gets wrong here
  DWORD errCode = GetLastError();

  if ( writedebuginfo ) {
    char msgStr[2048];
    sprintf(msgStr, "Controlservice() call to %s.\nSent code %s (0x%x).\nSERVICE_STATUS after call:\ndwServiceType:\t\t%d\ndwCurrentState:\t\t%d\ndwControlsAccepted:\t%d\ndwWin32ExitCode:\t\t%d\ndwServiceSpecificExitCode:\t%d\ndwCheckPoint:\t\t%d\ndwWaitHint:\t\t%d\nReturn code: %s",
            computername,
            ControlcodeDescription(dwControl).c_str(),
            dwControl,
            lpServiceStatus->dwServiceType,
            lpServiceStatus->dwCurrentState,
            lpServiceStatus->dwControlsAccepted,
            lpServiceStatus->dwWin32ExitCode,
            lpServiceStatus->dwServiceSpecificExitCode,
            lpServiceStatus->dwCheckPoint,
            lpServiceStatus->dwWaitHint,
            retVal == TRUE? "TRUE" : "FALSE");
    if ( !retVal ) {
      char errStr[512];
      GetErrormessage(NULL, errStr, sizeof(errStr));
      strcat(msgStr, "; Error message: ");
      strncat(msgStr, errStr, sizeof(msgStr) - strlen(msgStr) - 2);
      strcat(msgStr, "\n");
    } else
      strcat(msgStr, "\n");

    WriteDebugString(tracefile.c_str(), msgStr);
  }
  // Set the last errorcode back
  SetLastError(errCode);
  return retVal;
}

//------------------------------------------------------------------------------
// Debug version of StartService()
//------------------------------------------------------------------------------
BOOL TMainForm::RSCC_StartService(SC_HANDLE hService, DWORD dwNumServiceArgs, LPCTSTR* lpServiceArgVectors, bool writedebuginfo, char* computername)
{
  BOOL retVal = StartService(hService, dwNumServiceArgs, lpServiceArgVectors);
  // Store old errorcode in case something gets wrong here
  DWORD errCode = GetLastError();

  if ( writedebuginfo ) {
    char msgStr[128];
    sprintf(msgStr, "StartService call to %s\nReturn code: %s", computername, retVal == TRUE? "TRUE" : "FALSE");
    if ( !retVal ) {
      char errStr[512];
      GetErrormessage(NULL, errStr, sizeof(errStr));
      strcat(msgStr, "; Error message: ");
      strncat(msgStr, errStr, sizeof(msgStr) - strlen(msgStr) - 2);
      strcat(msgStr, "\n");
    } else
      strcat(msgStr, "\n");

    WriteDebugString(tracefile.c_str(), msgStr);
  }
  // Set the last errorcode back
  SetLastError(errCode);
  return retVal;
}

//------------------------------------------------------------------------------
// Debug version of CopyFile()
//------------------------------------------------------------------------------
BOOL TMainForm::RSCC_CopyFile(LPCTSTR lpExistingFileName, LPCTSTR lpNewFileName, BOOL bFailIfExists, bool writedebuginfo)
{
  BOOL retVal = CopyFile(lpExistingFileName, lpNewFileName, bFailIfExists);
  // Store old errorcode in case something gets wrong here
  DWORD errCode = GetLastError();

  if ( writedebuginfo ) {
    char msgStr[128];
    sprintf(msgStr, "CopyFile(%s, %s, %s)\nReturn code: %s",
            lpExistingFileName, lpNewFileName,
            bFailIfExists == TRUE? "TRUE" : "FALSE",
            retVal == TRUE? "TRUE" : "FALSE");
    if ( !retVal ) {
      char errStr[512];
      GetErrormessage(NULL, errStr, sizeof(errStr));
      strcat(msgStr, "; Error message: ");
      strncat(msgStr, errStr, sizeof(msgStr) - strlen(msgStr) - 2);
      strcat(msgStr, "\n");
    } else
      strcat(msgStr, "\n");

    WriteDebugString(tracefile.c_str(), msgStr);
  }
  // Set the last errorcode back
  SetLastError(errCode);
  return retVal;
}

//------------------------------------------------------------------------------
// Debug version of DeleteFile()
//------------------------------------------------------------------------------
BOOL TMainForm::RSCC_DeleteFile(LPCTSTR lpFileName, bool writedebuginfo)
{
  BOOL retVal = DeleteFile(lpFileName);
  // Store old errorcode in case something gets wrong here
  DWORD errCode = GetLastError();

  if ( writedebuginfo ) {
    char msgStr[128];
    sprintf(msgStr, "DeleteFile(%s)\nReturn code: %s", lpFileName, retVal == TRUE? "TRUE" : "FALSE");
    if ( !retVal ) {
      char errStr[512];
      GetErrormessage(NULL, errStr, sizeof(errStr));
      strcat(msgStr, "; Error message: ");
      strncat(msgStr, errStr, sizeof(msgStr) - strlen(msgStr) - 2);
      strcat(msgStr, "\n");
    } else
      strcat(msgStr, "\n");

    WriteDebugString(tracefile.c_str(), msgStr);
  }
  // Set the last errorcode back
  SetLastError(errCode);
  return retVal;
}

//------------------------------------------------------------------------------
// Debug version of MoveFileEx()
//------------------------------------------------------------------------------
BOOL TMainForm::RSCC_MoveFileEx(LPCTSTR lpExistingFileName, LPCTSTR lpNewFileName, DWORD dwFlags, bool writedebuginfo)
{
  BOOL retVal = MoveFileEx(lpExistingFileName, lpNewFileName, dwFlags);
  // Store old errorcode in case something gets wrong here
  DWORD errCode = GetLastError();

  if ( writedebuginfo ) {
    char msgStr[128];
    sprintf(msgStr, "MoveFileEx(%s, %s, 0x%x)\nReturn code: %s",
            lpExistingFileName, lpNewFileName, dwFlags,
            retVal == TRUE? "TRUE" : "FALSE");
    if ( !retVal ) {
      char errStr[512];
      GetErrormessage(NULL, errStr, sizeof(errStr));
      strcat(msgStr, "; Error message: ");
      strncat(msgStr, errStr, sizeof(msgStr) - strlen(msgStr) - 2);
      strcat(msgStr, "\n");
    } else
      strcat(msgStr, "\n");

    WriteDebugString(tracefile.c_str(), msgStr);
  }
  // Set the last errorcode back
  SetLastError(errCode);
  return retVal;
}

//------------------------------------------------------------------------------
// Write the message in the logfile.
//------------------------------------------------------------------------------
void __fastcall WriteDebugString(char* fileName, char* msg)
{
  FILE* file = fopen(fileName, "at");
  if ( file ) {
    DWORD ms = GetTickCount();
    SYSTEMTIME timeStruct;
    GetSystemTime(&timeStruct); // Get time in UTC
    fprintf(file, "%04d-%02d-%02d %02d:%02d:%02d:%03d (%05d.%03d): %s",
                  timeStruct.wYear,
                  timeStruct.wMonth,
                  timeStruct.wDay,
                  timeStruct.wHour,
                  timeStruct.wMinute,
                  timeStruct.wSecond,
                  timeStruct.wMilliseconds,
                  (int)ms/1000, (int)(ms%1000), msg);
    fflush(file);
    fclose(file);
  }
}

//------------------------------------------------------------------------------
//  Constructor.
//------------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner): TForm(Owner)
{
  char* p;

  // System tray icon
  TrayIcon = new Graphics::TIcon;
  TrayIcon->Handle = LoadImage(HInstance, "MAINICON", IMAGE_ICON, 0, 0, 0);
  // Set the event handlers for minimizing/restoring from the system tray
  Application->OnMinimize = AppOnMinimize;
  Application->OnRestore  = AppOnRestore;
  // Find inifilename
  iniFileName = ParamStr(0);
  p = strrchr(iniFileName.c_str(), '.');
  if ( p ) *p = 0;
  strcat(iniFileName.c_str(), ".ini");
  // Create inifile for settings
  ProgramSettingsFile = new TIniFile(iniFileName);
  // Find logfilename
  tracefile = ParamStr(0);
  p = strrchr(tracefile.c_str(), '.');
  if ( p ) *p = 0;
  strcat(tracefile.c_str(), ".log");
  viewLogFilesChildren = new TList();  
}

//------------------------------------------------------------------------------
//  Set program defaults.
//------------------------------------------------------------------------------
void __fastcall TMainForm::FormShow(TObject* Sender)
{
  char* domainName;
  AnsiString versionString;
  char versionNr[256];
  DWORD errCode;
  char errMsg[512], msg[1024];

  // Default reason why FormClose is called
  prgCloseReason = PRG_CLOSE_OTHER;
  // Get the windows type. The program only runs on winNT.
  if ( GetWin32Platform(versionNr, sizeof(versionNr)) != VER_PLATFORM_WIN32_NT ) {
    versionString = "Windows " + AnsiString(versionNr) + " detected.\nThis program requires Windows NT or 2000.";
    Application->MessageBox(versionString.c_str(), "Incorrect windows version", MB_OK|MB_ICONSTOP);
    Application->Terminate();
  }
  AboutForm->WindowsVersionLabel->Caption = "Running on Windows " + AnsiString(versionNr);
  // Read inifile settings
  ReadIniSettings();
  // Login as specified user and get its priviliges
  if ( pcfg.SwitchUserID && strlen(pcfg.Username) ) {
    // Domain name need not be specified
    if ( pcfg.Domain && strlen(pcfg.Domain) ) domainName = pcfg.Domain;
    else domainName = NULL;

    if ( !LogonUser(pcfg.Username, domainName, pcfg.Password,
                    LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, &hToken) ) {
      errCode = GetLastError();
      GetErrormessage(&errCode, errMsg, sizeof(errMsg));
      strcpy(msg, "Remote Commander wanted to login as another user but failed. The error was:\n");
      strcat(msg, errMsg);
      strcat(msg, "\nDo you want to edit the login data now?");
      if ( MessageBox(NULL, msg, Application->Title.c_str(), MB_YESNO) == IDYES ) {
        SwitchAccountButtonClick(Sender);
        // Don't try to login now, probably the required privilege was not found
        // so a logoff/logon is necessary anyway.
      }
    }
    if ( hToken ) {
      if ( !ImpersonateLoggedOnUser(hToken) )
        ShowErrorMessage("ImpersonateLoggedOnUser", NULL);
    }
  }
  // No thread is currently running
  NetworkScanThreadIsRunning = false;
  // Read the computer names stored in the inifile and scan the network if
  // this is configured:
  ComputersListView->Items->Clear();
  ReadComputerNames();
  // Store the computer names so we can see if the configuration has changed
  // when we close.
  StoreComputerNames();
  // Select the first computer in the list:
  if ( ComputersListView->Items->Count > 0 )
    ComputersListView->Items->Item[0]->Selected = true;
}

//------------------------------------------------------------------------------
// Destructor.
//------------------------------------------------------------------------------
__fastcall TMainForm::~TMainForm()
{
  // Remove the system tray icon
  RemoveIcon();
  delete TrayIcon;
  // Delete settingsfile
  delete ProgramSettingsFile;
  // Delete list of logfiles.
  delete viewLogFilesChildren;
}

//------------------------------------------------------------------------------
// Saves the settings and deletes the inifile. Doing this in the destructor
// gives access violations so we do it in the OnClose event.
//------------------------------------------------------------------------------
void __fastcall TMainForm::FormClose(TObject* Sender, TCloseAction& Action)
{
  int i;
  bool saveSettings = false;

  // Make sure the computernames in pcfg and the GUI match.
  StoreComputerNames();
  // Save settings if necessary.
  switch ( prgCloseReason ) {
    case PRG_CLOSE_CANCEL:
         saveSettings = false;
         break;
    case PRG_CLOSE_EXIT:
         saveSettings = true;
         break;
    default:
      if ((orgpcfg != pcfg) || (orgServiceData != serviceData) ) {
        switch ( Application->MessageBox("Settings have changed, save changes?", Application->Title.c_str(), MB_YESNOCANCEL) ) {
          case IDYES: // Save
               saveSettings = true;
               break;
          case IDCANCEL: // Don't close the form
               Action = caNone;
               prgCloseReason = PRG_CLOSE_OTHER; // Reset reason
               saveSettings = false;
               break;
          default: break; // Don't save
        }

      }
  }
  if ( Action != caNone ) {
    // Drop priviliges. This is done here to prevent access right errors writing
    // the config files. It is assumed that the calling user has the right to
    // write to the program's ini file.
    if (hToken && !CloseHandle(hToken) ) ShowErrorMessage("CloseHandle", NULL);
    if ( pcfg.SwitchUserID && !RevertToSelf() ) ShowErrorMessage("RevertToSelf", NULL);
    // run through the list of open logfile viewer child windows,
    // Close all and free memory.
    // The childlist itself is deleted in the destructor.
    for (i = 0; i < viewLogFilesChildren->Count; i++) {
      TViewLogFileForm* f = (TViewLogFileForm*)viewLogFilesChildren->Items[i];
      // prevent the child form to send its WM_CLOSE_VIEW_LOGFILE notification,
      // since we are already closing and freeing it and dont need it here
      f->mainForm = NULL;
      // Delete the menuitem
      delete f->windowMenuItem;
      f->Close();
      delete f;
    }
  }
  if ( saveSettings ) SaveIniSettings();
}

//------------------------------------------------------------------------------
// Save settings and close the form
//------------------------------------------------------------------------------
void __fastcall TMainForm::ExitButtonClick(TObject* Sender)
{
  prgCloseReason = PRG_CLOSE_EXIT;
  Close();
}

//------------------------------------------------------------------------------
// Close without saving.
//------------------------------------------------------------------------------
void __fastcall TMainForm::CancelButtonClick(TObject* Sender)
{
  prgCloseReason = PRG_CLOSE_CANCEL;
  Close();
}

//------------------------------------------------------------------------------
// Save the program settings to the inifile.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Savesettings1Click(TObject* Sender)
{
  SaveIniSettings();
}

//------------------------------------------------------------------------------
// Store the computer names so we can see if the configuration has changed
//------------------------------------------------------------------------------
void __fastcall TMainForm::StoreComputerNames()
{
  int i;
  pcfg.computerNameList->Clear();
  for (i = 0; i < ComputersListView->Items->Count; i++) {
    pcfg.computerNameList->Add(ComputersListView->Items->Item[i]->Caption);
    pcfg.computerNameList->Objects[i] = (TObject*)ComputersListView->Items->Item[i]->Checked;
  }
}

//------------------------------------------------------------------------------
// Read the settings from the inifile.
//------------------------------------------------------------------------------
void __fastcall TMainForm::ReadIniSettings()
{
  // Required data, not to be changed by the user interface
  strcpy(serviceData.IniSection, "Service");
  // Read program settings
  pcfg.ReadSettings(ProgramSettingsFile);
  // Store old settings so we can later check if they have changed.
  orgpcfg = pcfg;
  // Read the defaults for service data. If the inifile does not exist it will return defaults.
  serviceData.ReadSettings(ProgramSettingsFile);
  // Store old settings so we can later check if they have changed.
  orgServiceData = serviceData;
  // See if we want to see the buttons and settings panel
  ShowButtons1->Checked = pcfg.showButtons;
  ButtonPanel->Visible = pcfg.showButtons;
  ComputersListView->RowSelect = pcfg.selectWholeLine;
  // Set defaults if not filled.
  SetServiceDataDefaults();
  // Read the form position and sizes
  Top  = ProgramSettingsFile->ReadInteger(ProgramIniSection, TopPos, defaultTopPos);
  Left = ProgramSettingsFile->ReadInteger(ProgramIniSection, LeftPos, defaultLeftPos);
  Height = ProgramSettingsFile->ReadInteger(ProgramIniSection, FormHeight, defaultFormHeight);
  Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, FormWidth, defaultFormWidth);
  ComputersListView->Columns->Items[0]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, NameColumnWidth, defaultNameColumnWidth);
  ComputersListView->Columns->Items[1]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, StatusColumnWidth, defaultStatusColumnWidth);
  ComputersListView->Columns->Items[2]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, PathColumnWidth, defaultPathColumnWidth);
  ComputersListView->Columns->Items[3]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, ListenColumnWidth, defaultListenColumnWidth);
  ComputersListView->Columns->Items[4]->Width = ProgramSettingsFile->ReadInteger(ProgramIniSection, LogColumnWidth, defaultLogColumnWidth);
  // See if we want to switch to another accocunt. Default is we don't.
  hToken = NULL;
  // See how we want to encrypt the login data
  DefaultPassword1->Checked = !pcfg.useSecureCipher;
  Password1->Enabled = pcfg.useSecureCipher;
}

//------------------------------------------------------------------------------
// Default service info when starting up remproxy. We first try to read it from
// the inifile, if there is no configuration information found we check if the
// service is installed on the local system and copy the information from the
// SCM database. If Junkbusters is not installed on the local system we use
// hard-coded default values.
//------------------------------------------------------------------------------
void __fastcall TMainForm::SetServiceDataDefaults()
{
  // First set the service name. If this one is not read from the inifile
  // we need a hard-coded value to connect with the local machine.
  if ( !strlen(serviceData.ServiceName) )
    strcpy(serviceData.ServiceName, ServiceName);
  // If the other info is not known, obtain them rom the SCM database:
  if ( !strlen(serviceData.ExeFrom) || !strlen(serviceData.DirectoryTo) )
    if ( SetServiceDefaults() )
      Application->MessageBox("Copied default service configuration data from the locally installed Junkbuster Proxy", Application->Title.c_str(), MB_OK | MB_ICONINFORMATION);
  // Set these values if they are not yet set.
  if ( !strlen(serviceData.DisplayName) )
    strcpy(serviceData.DisplayName, "Junkbuster Filtering Proxy Server");
  if ( !strlen(serviceData.RemoteName) )
    strcpy(serviceData.RemoteName, "junkbstr");
  if ( !strlen(serviceData.DirectoryTo) )
    strcpy(serviceData.DirectoryTo, "C:\\WINNT\\Junkbust\\");
  // Check if directories last char is "\\", add it if not so:
  if ( serviceData.DirectoryTo[strlen(serviceData.DirectoryTo) - 1] != '\\' )
    strcat(serviceData.DirectoryTo, "\\");
}

//------------------------------------------------------------------------------
// Get default service settings from the local SCM database, if present.
//------------------------------------------------------------------------------
bool __fastcall TMainForm::SetServiceDefaults()
{
  char buffer[2048];
  unsigned int i, n;
  char* c;
  char remoteMachineName[MAX_COMPUTERNAME_LENGTH + 1];
  char unquotedCommand[2*MAX_PATH + 3]; // 3 for space and 2 \"
  DWORD remoteMachineNameSize = sizeof(remoteMachineName);
  // Config params
  DWORD dwStartType;
  DWORD bytesNeeded;
  char lpBinaryPathName[2*MAX_PATH + 3];
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  bool retVal = false;

  if ( GetComputerName(remoteMachineName, &remoteMachineNameSize) ) {
    if ( (hscManager = OpenSCManager(remoteMachineName, NULL, SC_MANAGER_CONNECT)) == 0 )
      hscManager = NULL;

    if ( hscManager ) {
      if ( (hService = OpenService(hscManager, serviceData.ServiceName, SERVICE_QUERY_CONFIG)) == NULL )
        hService = NULL;

      if ( hService ) {
        if ( QueryServiceConfig(hService, (QUERY_SERVICE_CONFIG*)buffer, sizeof(buffer), &bytesNeeded) )
          retVal = true; // We got information
        // Save the data
        dwStartType = ((QUERY_SERVICE_CONFIG*)buffer)->dwStartType;
        if ( dwStartType == SERVICE_AUTO_START )
          serviceData.StartOnBoot = true;
        else
          serviceData.StartOnBoot = false;

        strcpy(lpBinaryPathName, ((QUERY_SERVICE_CONFIG*)buffer)->lpBinaryPathName);
        // Remove quotes from the name
        for (n = 0, i = 0; i < strlen(lpBinaryPathName); i++) {
          if ( lpBinaryPathName[i] != '\"' ) {
            unquotedCommand[n] = lpBinaryPathName[i];
            n++;
          }
        }
        unquotedCommand[n] = 0;
        // Find the executable
        c = strstr(unquotedCommand, ".exe");
        if ( c ) *(c + 4) = 0; // Split it in a exe and ini filename part
        strncpy(serviceData.ExeFrom, unquotedCommand, sizeof(serviceData.ExeFrom));
        // The directory the service files should be copied to
        strncpy(serviceData.DirectoryTo, ExtractFilePath(unquotedCommand).c_str(), sizeof(serviceData.DirectoryTo) - 1);
        // The inifile. We first look for it in the command (where it should be),
        // but if it isn't there we guess the name.
        if ( strstr(c + 5, ".ini") ) {
          strcpy(serviceData.JbiniFrom, c + 5);
        } else {
          strcpy(serviceData.JbiniFrom, serviceData.DirectoryTo);
          if ( serviceData.JbiniFrom[strlen(serviceData.JbiniFrom)-1] != '\\' )
            strcat(serviceData.JbiniFrom, "\\");

          strcat(serviceData.JbiniFrom, "junkbstr.ini");
        }
        // Get the other inifiles.
        ParseMainIniFile(serviceData.JbiniFrom, serviceData.Sblockini, serviceData.Saclfileini, serviceData.Scookieini, serviceData.Sforwardini, serviceData.Strustini, NULL, NULL, NULL);
        // Display name
        strcpy(serviceData.DisplayName, ((QUERY_SERVICE_CONFIG*)buffer)->lpDisplayName);
        if ( !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
      }
      if ( !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
    }
  }
  return retVal;
}

//------------------------------------------------------------------------------
// Finds the names of the other inifiles from the main inifile junkbstr.ini.
// These names are copied in the other strings. If a value is NULL we don't
// store the corresponding information.
//------------------------------------------------------------------------------
void __fastcall TMainForm::ParseMainIniFile(char mainIniFilename[],
                                            char fBlock[],
                                            char fAcl[],
                                            char fCookie[],
                                            char fForward[],
                                            char fTrust[],
                                            char fLog[],
                                            bool* bLog,
                                            char listen_addr[])
{
  char* p;
  char* q;
  int debug = 0;
  FILE* configfp;
  char buf[BUFSIZ];

  if ( FileExists(mainIniFilename) ) {
    configfp = fopen(mainIniFilename, "r");
    if ( !configfp ) {
      strcpy(fBlock, "");
      strcpy(fAcl, "");
      strcpy(fCookie, "");
      strcpy(fForward, "");
      strcpy(fTrust, "");
    } else {
    while (fgets(buf, sizeof(buf), configfp)) { // Code from Junkbusters code jcc.c
      char cmd[BUFSIZ];
      char arg[BUFSIZ];
      char tmp[BUFSIZ];
      strcpy(tmp, buf);

      if ( (p = strpbrk(tmp, "#\r\n")) != NULL ) *p = 0;
      p = tmp;
      // leading skip whitespace
      while (*p && ((*p == ' ') || (*p == '\t'))) p++;
      q = cmd;
      while (*p && (*p != ' ') && (*p != '\t')) *q++ = *p++;
      *q = '\0';
      while (*p && ((*p == ' ') || (*p == '\t'))) p++;
      strcpy(arg, p);
      p = arg + strlen(arg) - 1;
      // ignore trailing whitespace
      while(*p && ((*p == ' ') || (*p == '\t'))) *p-- = '\0';
      if (*cmd == '\0') continue;
      // insure the command field is lower case
      for (p=cmd; *p; p++) if(isupper(*p)) *p = (char)tolower(*p);

      if( !strcmp(cmd, "trustfile") ) {
        if ( fTrust ) strcpy(fTrust, arg);
        continue;
      }
      if ( !strcmp(cmd, "debug") ) {
        debug |= atoi(arg);
        if ( bLog ) { // See if logging is included in the debug options
          if ( debug != 0 ) *bLog = true;
          else *bLog = false;
        }
        continue;
      }
      if ( !strcmp(cmd, "cookiefile") ) {
        if ( fCookie ) strcpy(fCookie, arg);
        continue;
      }
      if ( !strcmp(cmd, "logfile") ) {
        if ( fLog ) strcpy(fLog, arg);
        continue;
      }
      if ( !strcmp(cmd, "blockfile") ) {
        if ( fBlock ) strcpy(fBlock, arg);
        continue;
      }
      if ( !strcmp(cmd, "forwardfile") ) {
        if ( fForward ) strcpy(fForward, arg);
        continue;
      }
      if ( !strcmp(cmd, "aclfile") ) {
        if ( fAcl ) strcpy(fAcl, arg);
        continue;
      }
      if ( !strcmp(cmd, "listen-address") ) {
        if ( listen_addr ) strcpy(listen_addr, arg);
        continue;
      }
    } // while
    fclose(configfp);
    }
  }
}

//------------------------------------------------------------------------------
// Save the program settings to the inifile.
//------------------------------------------------------------------------------
void __fastcall TMainForm::SaveIniSettings()
{
  serviceData.SaveSettings(ProgramSettingsFile);
  // Write program settings. Store current computernames first.
  StoreComputerNames();
  pcfg.SaveSettings(ProgramSettingsFile);
  // Save the form position
  ProgramSettingsFile->WriteInteger(ProgramIniSection, TopPos, Top);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, LeftPos, Left);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, FormHeight, Height);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, MaxWaitTime, pcfg.MaxWaitTime);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, LogRefreshTime, pcfg.LogRefreshTime);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, FormWidth, Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, NameColumnWidth, ComputersListView->Columns->Items[0]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, StatusColumnWidth, ComputersListView->Columns->Items[1]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, PathColumnWidth, ComputersListView->Columns->Items[2]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, ListenColumnWidth, ComputersListView->Columns->Items[3]->Width);
  ProgramSettingsFile->WriteInteger(ProgramIniSection, LogColumnWidth, ComputersListView->Columns->Items[4]->Width);
  // Set the stored settings to the saved ones
  orgpcfg = pcfg;
  orgServiceData = serviceData;
}

//------------------------------------------------------------------------------
// Restore on double click on the tray icon.
//------------------------------------------------------------------------------
void __fastcall TMainForm::WMTrayNotify(TMessage& Msg)
{
  POINT p;
  // The LPARAM of the message identifies the type of mouse message.
  if ( Msg.LParam == WM_LBUTTONDBLCLK ) Application->Restore();
  // Right button pressed: show popup menu
  else if ( Msg.LParam == WM_RBUTTONDOWN ) {
    SetForegroundWindow(Handle);
    GetCursorPos(&p);
    TrayPopupMenu->Popup(p.x, p.y);
    PostMessage(Handle, WM_NULL, 0, 0); // Done to bypass a bug in windows
  }
}

//------------------------------------------------------------------------------
// this method is called on WM_CLOSE_VIEW_LOGFILE sent by the
// TViewLogFileForm when closing.
//------------------------------------------------------------------------------
void __fastcall TMainForm::WMCloseViewLog(TMessage& Message)
{
  // find the window in the child list by pointer
  int i = viewLogFilesChildren->IndexOf((TObject*)Message.WParam);

  if (i >= 0) {
    TViewLogFileForm* f = (TViewLogFileForm*)viewLogFilesChildren->Items[i];
    viewLogFilesChildren->Delete(i);
    // Delete corresponding menuitem
    delete (TMenuItem*)Message.LParam;
    // Delete the logfile form
    delete f;
  }
}

//------------------------------------------------------------------------------
// Use the Shell_NotifyIcon API function to add the icon to the system tray.
//------------------------------------------------------------------------------
void __fastcall TMainForm::AddIcon()
{
  NOTIFYICONDATA IconData;
  IconData.cbSize = sizeof(NOTIFYICONDATA);
  IconData.uID    = IDC_TRAY1;
  IconData.hWnd   = Handle;
  IconData.uFlags = NIF_MESSAGE|NIF_ICON|NIF_TIP;
  IconData.uCallbackMessage = WM_TRAYNOTIFY;
  lstrcpy(IconData.szTip, "Remote commander");
  IconData.hIcon  = TrayIcon->Handle;
  Shell_NotifyIcon(NIM_ADD, &IconData);
}

//------------------------------------------------------------------------------
// Remove the icon from the system tray
//------------------------------------------------------------------------------
void __fastcall TMainForm::RemoveIcon()
{
  NOTIFYICONDATA IconData;
  IconData.cbSize = sizeof(NOTIFYICONDATA);
  IconData.uID    = IDC_TRAY1;
  IconData.hWnd   = Handle;
  IconData.hIcon  = TrayIcon->Handle;
  Shell_NotifyIcon(NIM_DELETE, &IconData);
}

//------------------------------------------------------------------------------
// Minimize to the system tray if required
//------------------------------------------------------------------------------
void __fastcall TMainForm::AppOnMinimize(TObject* Sender)
{
  if ( pcfg.minimizeToSystray ) {
    AddIcon();
    ShowWindow(Application->Handle, SW_HIDE);
  }
}

//------------------------------------------------------------------------------
// Restore from the system tray if required
//------------------------------------------------------------------------------
void __fastcall TMainForm::AppOnRestore(TObject* Sender)
{
  if ( pcfg.minimizeToSystray ) {
    RemoveIcon();
    ShowWindow(Application->Handle, SW_SHOW);
    SetForegroundWindow(Application->Handle);
  }
}

//------------------------------------------------------------------------------
// Restore from the system tray if the restore popup menu item clicked.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Restore3Click(TObject* Sender)
{
  Application->Restore();
}

//------------------------------------------------------------------------------
// The delete button also deletes computers from the list
//------------------------------------------------------------------------------
void __fastcall TMainForm::ComputersListViewKeyDown(TObject* Sender, WORD& Key, TShiftState Shift)
{
  if ( Key == VK_DELETE ) RemPCButtonClick(Sender);
  CurrActiveItem = NULL;
}

//------------------------------------------------------------------------------
// See if we want to hide the buttons
//------------------------------------------------------------------------------
void __fastcall TMainForm::ShowButtons1Click(TObject* Sender)
{
  ShowButtons1->Checked = !ShowButtons1->Checked;
  pcfg.showButtons = ShowButtons1->Checked;
  ButtonPanel->Visible = pcfg.showButtons;
}

//------------------------------------------------------------------------------
// If checked, use a default password for the RC5 encryption for login data.
// Else use a user-supplied password.
//------------------------------------------------------------------------------
void __fastcall TMainForm::DefaultPassword1Click(TObject* Sender)
{
  DefaultPassword1->Checked = !DefaultPassword1->Checked;
  pcfg.useSecureCipher = !DefaultPassword1->Checked;
  Password1->Enabled = !DefaultPassword1->Checked;
  // Set default password if not secure
  if ( !pcfg.useSecureCipher ) strcpy(pcfg.ProgramPassword, DefaultPassword);
  // Ask for password if none set or password == defaultpassword
  if ( pcfg.useSecureCipher && (!strlen(pcfg.ProgramPassword) || !strcmp(pcfg.ProgramPassword, DefaultPassword)) )
    Password1Click(Sender);
}

//------------------------------------------------------------------------------
// Set the program password used to encrypt the login information with RC5.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Password1Click(TObject* Sender)
{
  TModalResult mrRes;
  char OldProgramPassword[128];

  strcpy(OldProgramPassword, pcfg.ProgramPassword);
  TPasswordForm* PwdForm = new TPasswordForm(this, pcfg.ProgramPassword, sizeof(pcfg.ProgramPassword) - 1, true);
  if ( PwdForm ) {
    // We ask to save the settings if the password is changed AND used.
    mrRes = PwdForm->ShowModal();
    if (!strlen(pcfg.ProgramPassword) || (mrRes != mrOk)) { // Empty password means use insecure cipher
      pcfg.useSecureCipher = false;
      DefaultPassword1->Checked = true;
      Password1->Enabled = false;
      strcpy(pcfg.ProgramPassword, DefaultPassword); // Set default password
    } else if (mrRes == mrOk) {
      pcfg.useSecureCipher = true;
      DefaultPassword1->Checked = false;
      Password1->Enabled = true;
    }
    if ( (mrRes == mrOk) && strcmp(OldProgramPassword, pcfg.ProgramPassword) ) {
      if ( Application->MessageBox("Password has changed, save settings?", Application->Title.c_str(), MB_YESNO) == ID_YES)
        SaveIniSettings();
    }
    delete PwdForm;
    // Remove password from memory
    memset(OldProgramPassword, 0, sizeof(OldProgramPassword));
  }
}

//------------------------------------------------------------------------------
// Shows the settings form.
//------------------------------------------------------------------------------
void __fastcall TMainForm::settings1Click(TObject* Sender)
{
  bool lineSelect = ComputersListView->RowSelect;

  TSettingsForm* SettingsForm = new TSettingsForm(this, &pcfg);
  if ( SettingsForm ) {
    SettingsForm->ShowModal();
    delete SettingsForm;
  }
  // Secure cipher options:
  DefaultPassword1->Checked = !pcfg.useSecureCipher;
  Password1->Enabled = pcfg.useSecureCipher;
  // Set default password if not secure
  if ( !pcfg.useSecureCipher ) strcpy(pcfg.ProgramPassword, DefaultPassword);
  // Ask for password if none set or password == defaultpassword
  if ( pcfg.useSecureCipher && (!strlen(pcfg.ProgramPassword) || !strcmp(pcfg.ProgramPassword, DefaultPassword)) )
    Password1Click(Sender);
  // GUI
  if ( pcfg.selectWholeLine != lineSelect )
    ComputersListView->RowSelect = pcfg.selectWholeLine;
}

//------------------------------------------------------------------------------
// Shows the stored computernames in the listview.
//------------------------------------------------------------------------------
void __fastcall TMainForm::ReadComputerNames()
{
  int i;
  TListItem* L;

  // Add the listitems and see which ones need to be checked
  for (i = 0; i < pcfg.computerNameList->Count; i++) {
    L = ComputersListView->Items->Add();
    L->Caption = pcfg.computerNameList->Strings[i];
    if ( (int)pcfg.computerNameList->Objects[i] == 1 ) {
      L->Checked = true;
    }
    // Add item for status info
    L->SubItems->Add("");
    // Add item for service path
    L->SubItems->Add("");
    // Add subitem for listen address
    L->SubItems->Add("");
    // Add subitem for logging
    L->SubItems->Add("");
  }
  // Add all other computers from Network Neighborhood to the list and
  // update the status.
  if ( pcfg.readNetworkNamesAfterStart )
    GetNetworkComputerNames(pcfg.readNetworkNamesAfterStart);
  else if ( pcfg.updateStatusAfterStart )
    UpdateStatus(0, true);
}

//------------------------------------------------------------------------------
// Create the thread to find the network computer names. If aRunUpdateAfterwards
// is true, the status information will be updated afterwards.
//------------------------------------------------------------------------------
void __fastcall TMainForm::GetNetworkComputerNames(bool aRunUpdateAfterwards)
{
  TNetworkScanThread* NetworkScanThread;

  // This prevents errors with indices
  ComputersListView->SortType = stNone;
  // We don't start the thread twice. We also don't start the update status
  // thread when scanning the network.
  if ( !NetworkScanThreadIsRunning ) {
    NetworkScanThreadIsRunning = true;
    try {
      // Show a form to indicate we're doing something. This form will be deleted
      // by the readthread
      // Create the readthread. This thread will delete itself when ready and
      // notice when the wait info panel can be hided.
      NetworkScanThread = new TNetworkScanThread(true, aRunUpdateAfterwards, this);
      ShowThreadWaitInfo();
      if ( NetworkScanThread ) {
        NetworkScanThread->Resume();
      } else {
        ShowErrorMessage("Error creating network scan thread", NULL);
        HideThreadWaitInfo();
        NetworkScanThreadIsRunning = false;
      }
    }
    catch (...) {
      HideThreadWaitInfo();
      NetworkScanThreadIsRunning = false;
    }
  }
}

//------------------------------------------------------------------------------
// Shows the wait info panel for the network scan thread.
//------------------------------------------------------------------------------
void __fastcall TMainForm::ShowThreadWaitInfo()
{
  WaitThreadPanel->Width = 300;
  WaitThreadPanel->Height = 110;
  WaitThreadPanel->Color = (TColor)0x00E1C00A;
  WaitThreadPanel->Left = (ComputersListView->Width - WaitThreadPanel->Width) / 2;
  WaitThreadPanel->Top = (ComputersListView->Height - WaitThreadPanel->Height) / 2;
  InfoThreadLabel->Caption = "";
  WaitThreadLabel->Caption = "";
  WaitThreadPanel->Visible = true;
}

//------------------------------------------------------------------------------
// Shows the wait info panel for the status update .
//------------------------------------------------------------------------------
void __fastcall TMainForm::ShowUpdateWaitInfo()
{
  WaitUpdatePanel->Width = 300;
  WaitUpdatePanel->Height = 110;
//  WaitUpdatePanel->Color = (TColor)0x00E1C00A;
  WaitUpdatePanel->Left = (ComputersListView->Width - WaitUpdatePanel->Width) / 2;
  WaitUpdatePanel->Top = (ComputersListView->Height - WaitUpdatePanel->Height) / 2;
  InfoUpdateLabel->Caption = "";
  WaitUpdateLabel->Caption = "";
  WaitUpdatePanel->Visible = true;
}

//------------------------------------------------------------------------------
// Hides the wait info panel for the network scan thread.
//------------------------------------------------------------------------------
void __fastcall TMainForm::HideThreadWaitInfo()
{
  InfoThreadLabel->Caption = "";
  WaitThreadLabel->Caption = "";
  WaitThreadPanel->Visible = false;
}

//------------------------------------------------------------------------------
// Hides the wait info panel for the status update .
//------------------------------------------------------------------------------
void __fastcall TMainForm::HideUpdateWaitInfo()
{
  InfoUpdateLabel->Caption = "";
  WaitUpdateLabel->Caption = "";
  WaitUpdatePanel->Visible = false;
}

//------------------------------------------------------------------------------
// Sets the label captions in the network scan thread wait info panel.
//------------------------------------------------------------------------------
void __fastcall TMainForm::SetThreadWaitText(AnsiString label, AnsiString info)
{
  WaitThreadLabel->Caption = label;
  InfoThreadLabel->Caption = info;
}

//------------------------------------------------------------------------------
// Sets the label captions in the status update wait info panel.
//------------------------------------------------------------------------------
void __fastcall TMainForm::SetUpdateWaitText(AnsiString label, AnsiString info)
{
  WaitUpdateLabel->Caption = label;
  InfoUpdateLabel->Caption = info;
}

//------------------------------------------------------------------------------
// Updates the status information for the selected computer and the executable
// path info. We can't do this in a separate thread: since we need access to
// network resources we would have to call the method synchronized (the TThread
// class does not pass security descriptors in its CreateThread call). This
// however can cause a deadlock when we waitfor the result. If we don't wait
// for the the thread to finish we can as well do it in the main thread.
//------------------------------------------------------------------------------
void __fastcall TMainForm::UpdateStatus(int index, bool updateAll)
{
  int i, beginindex, endindex;
  char servicePath[MAX_PATH];
  // Client inifile variables
  char mainIniFile[MAX_PATH];
  char listen_address[128];
  bool log;
  AnsiString formCaption = Caption;

  Screen->Cursor = crHourGlass;
  // Show the wait info panel
  ShowUpdateWaitInfo();
  SetUpdateWaitText("Updating status information...", "");
  // See which info we need to update
  if ( updateAll ) {
    beginindex = 0;
    endindex = ComputersListView->Items->Count - 1;
  } else {
    beginindex = index;
    endindex = index;
  }
  // Clear the fields
  for (i = beginindex; i <= endindex; i++) {
    ComputersListView->Items->Item[i]->SubItems->Strings[lStatusIndex] = "";
    ComputersListView->Items->Item[i]->SubItems->Strings[lListenIndex] = "";
    ComputersListView->Items->Item[i]->SubItems->Strings[lPathIndex] = "";
  }
  Application->ProcessMessages(); // Make the changes visible
  // Get the new status info
  for (i = beginindex; i <= endindex; i++) {
    if ( ComputersListView->Items->Item[i]->Checked ) {
      // Show computername in caption
      SetUpdateWaitText("Updating status information...", ComputersListView->Items->Item[i]->Caption);
      memset(servicePath, 0, sizeof(servicePath));
      // Get service status and show it
      DWORD returnCode = GetServiceStatus(ComputersListView->Items->Item[i]->Caption.c_str());
      ComputersListView->Items->Item[i]->SubItems->Strings[lStatusIndex] = ServiceStateDescription(returnCode);
      // Get service path
      if ( (returnCode != ERROR_SERVICE_DOES_NOT_EXIST) && (returnCode != NO_SERVICEMANAGER_FOUND) ) {
        GetServicePath(ComputersListView->Items->Item[i]->Caption.c_str(), servicePath, sizeof(servicePath));
        if ( servicePath )
          ComputersListView->Items->Item[i]->SubItems->Strings[lPathIndex] = AnsiString(servicePath);
      } else
        ComputersListView->Items->Item[i]->SubItems->Strings[lPathIndex] = "";
      // Update the listen address and log info.
      ComputersListView->Items->Item[i]->SubItems->Strings[lLogIndex] = "";
      ComputersListView->Items->Item[i]->SubItems->Strings[lListenIndex] = "";
      if ( (returnCode != ERROR_SERVICE_DOES_NOT_EXIST) && (returnCode != NO_SERVICEMANAGER_FOUND) ) {
        GetRemoteIniFileName(ComputersListView->Items->Item[i]->Caption.c_str(), mainIniFile, sizeof(mainIniFile));
        listen_address[0] = 0;
        log = false;
        ParseMainIniFile(mainIniFile, NULL, NULL, NULL, NULL, NULL, NULL, &log, listen_address);
        if ( log )
          ComputersListView->Items->Item[i]->SubItems->Strings[lLogIndex] = "Yes";
        else
          ComputersListView->Items->Item[i]->SubItems->Strings[lLogIndex] = "No";
        if ( strlen(listen_address) )
          ComputersListView->Items->Item[i]->SubItems->Strings[lListenIndex] = listen_address;
        else // default value from Junkbusters
          ComputersListView->Items->Item[i]->SubItems->Strings[lListenIndex] = "127.0.0.1:8000";
      }
    }
    Application->ProcessMessages();
  }
  Caption = formCaption;
  Screen->Cursor = crDefault;
  HideUpdateWaitInfo();
}

//------------------------------------------------------------------------------
// Returns the name of the main proxy inifile in UNC format
//------------------------------------------------------------------------------
void __fastcall TMainForm::GetRemoteIniFileName(char computername[], char buffer[], size_t buffsize)
{
  unsigned int n, i, j;
  char* c;
  char command[2*MAX_PATH + 3], unquotedCommand[2*MAX_PATH];
  command[0] = 0;
  // Get the lpBinaryPathName from the SCM
  GetServicePath(computername, command, sizeof(command));

  // Remove quotes from the name
  for (n = 0, i = 0; i < strlen(command); i++) {
    if ( command[i] != '\"' ) {
      unquotedCommand[n] = command[i];
      n++;
    }
  }
  unquotedCommand[n] = 0;

  if ( strlen(unquotedCommand) ) {
    strcpy(buffer, "\\\\");
    strcat(buffer, computername);
    strcat(buffer, "\\");
    c = strstr(unquotedCommand, ".exe");
    if ( strstr(c + 5, ".ini") ) strcat(buffer, c + 5);
    // Replace first : by $ to get network name
    for (j = 0; j < strlen(buffer); j++) {
      if ( buffer[j] == ':' ) {
        buffer[j] = '$';
        break;
      }
    }
  }
}

//------------------------------------------------------------------------------
// Returns the string that belongs to a service state.
//------------------------------------------------------------------------------
AnsiString __fastcall TMainForm::ServiceStateDescription(DWORD serviceState)
{
  AnsiString Result;

  switch ( serviceState ) {
    case SERVICE_STOPPED:
         Result = "Service not running";
         break;
    case SERVICE_START_PENDING:
         Result = "Service starting";
         break;
    case SERVICE_STOP_PENDING:
         Result = "Service stopping";
         break;
    case SERVICE_RUNNING:
         Result = "Service is running";
         break;
    case SERVICE_CONTINUE_PENDING:
         Result = "Continue pending";
         break;
    case SERVICE_PAUSE_PENDING:
         Result = "Pause pending";
         break;
    case SERVICE_PAUSED:
         Result = "Service paused";
         break;
    case ERROR_SERVICE_DOES_NOT_EXIST:
         Result = "Service is not installed";
         break;
    case NO_SERVICEMANAGER_FOUND:
         Result = "No service manager found";
         break;
    default:
         Result = "Unknown status";
  }
  return Result;
}

//------------------------------------------------------------------------------
// Gets the service executable name.
// The parameter servicePath contains a buffer to receive the service path. The
// size of this buffer is given by buffSize.
//------------------------------------------------------------------------------
void __fastcall TMainForm::GetServicePath(char computerName[], char* servicePathBuffer, size_t buffSize)
{
  char buffer[2048];
  DWORD bytesNeeded, errCode;
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;

  Screen->Cursor = crHourGlass;

  if ( (hscManager = OpenSCManager(computerName, NULL, GENERIC_READ)) != 0 ) {
    // We only need to query the service so we need to open it with only
    // SERVICE_QUERY_CONFIG rights. This does not require admin access to
    // the service.
    if ( (hService = OpenService(hscManager, serviceData.ServiceName, SERVICE_QUERY_CONFIG)) == NULL ) {
      errCode = GetLastError();
      if ( errCode == ERROR_ACCESS_DENIED)
        strncpy(servicePathBuffer, "Access denied", buffSize);
      else
        ShowErrorMessage(computerName, &errCode);
    }
    // First stop the service. We check the return value separately because
    // we don't want an errormessage when the service is already stopped.
    if ( hService) {
      // Find out what executable the service uses
      QueryServiceConfig(hService, (QUERY_SERVICE_CONFIG*)buffer, sizeof(buffer), &bytesNeeded);
      strncpy(servicePathBuffer, ((QUERY_SERVICE_CONFIG*)buffer)->lpBinaryPathName, buffSize);
    }
    if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(computerName, NULL);
    if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(computerName, NULL);
  } else {
    errCode = GetLastError();
    if ( errCode == ERROR_ACCESS_DENIED)
      strncpy(servicePathBuffer, "Access denied", buffSize);
    else
      ShowErrorMessage(computerName, &errCode);
  }
  Screen->Cursor = crDefault;
}

//------------------------------------------------------------------------------
// Finds the network name of a executable name from a computername and a
// pathname. The result is stored in networkPath.
//------------------------------------------------------------------------------
void __fastcall TMainForm::GetExecutableName(char aComputerName[], char aPathName[], char networkPath[])
{
  unsigned int i;
  int n;
  char* p;
  char tempFileName[MAX_PATH];

  // Remove the option part from the executable name
  // Make it lowercase
  strcpy(tempFileName, "\\\\");
  // Add computer name
  strcat(tempFileName, aComputerName);
  strcat(tempFileName, "\\");
  strcat(tempFileName, aPathName);
  for (i = 0; i < strlen(tempFileName); i++) tempFileName[i] = (char)tolower(tempFileName[i]);
  p = strrchr(tempFileName, '.');
  if ( p ) *p = 0; // Remove commandline args
  strcat(tempFileName, ".exe");
  // Replace first : by $ to get network name
  for (i = 0; i < strlen(tempFileName); i++) {
    if ( tempFileName[i] == ':' ) {
      tempFileName[i] = '$';
      break;
    }
  }
  // Remove possible quotes from the name (could happen on existing installs)
  for (n = 0, i = 0; i < strlen(tempFileName); i++) {
    if ( tempFileName[i] != '\"' ) {
      networkPath[n] = tempFileName[i];
      n++;
    }
  }
  networkPath[n] = 0;
}

//------------------------------------------------------------------------------
// The read network names thread is ready, close the message window. If the
// message indicates so, update the status.
//------------------------------------------------------------------------------
void __fastcall TMainForm::CMScanThreadReady(TMessage& Message)
{
  HideThreadWaitInfo();
  NetworkScanThreadIsRunning = false;
  if ( Message.WParam == DO_UPDATE_STATUS )
    UpdateStatus(0, true);
}

//------------------------------------------------------------------------------
// Returns true if a name already exists in the list, otherwise false, and
// converts the name to lowercase.
//------------------------------------------------------------------------------
bool __fastcall TMainForm::NameIsDouble(char* name)
{
  int i, j;
  char temp[64];

  for (i = 0; i < (int)strlen(name); i++) name[i] = (char)tolower(name[i]);
  for (i = 0; i < ComputersListView->Items->Count; i++) {
    strncpy(temp, ComputersListView->Items->Item[i]->Caption.c_str(), sizeof(temp) - 1);
    for (j = 0; j < (int)strlen(temp); j++) temp[j] = (char)tolower(temp[j]);
    if ( !strcmp(temp, name) )
      return true;
  }
  return false;
}

//------------------------------------------------------------------------------
// Get the windows version. Returns the windows type it runs on.
//------------------------------------------------------------------------------
DWORD __fastcall TMainForm::GetWin32Platform(char* versionText, size_t buffSize)
{
  OSVERSIONINFO PlatformVersion;

  PlatformVersion.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
  GetVersionEx(&PlatformVersion);
  if ( PlatformVersion.dwPlatformId == VER_PLATFORM_WIN32s ) {
    strcpy(versionText, "Win32s");
  }
  if ( PlatformVersion.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS ) {
    if ( PlatformVersion.dwMajorVersion <= 4 )
      strcpy(versionText, "95 ");
    else if ( PlatformVersion.dwMajorVersion > 4 )
      strcpy(versionText, "98 ");

    strcat(versionText, IntToStr(PlatformVersion.dwMajorVersion).c_str());
    strcat(versionText, ".");
    strcat(versionText, IntToStr(PlatformVersion.dwMinorVersion).c_str());
    strcat(versionText, " build ");
    strcat(versionText, IntToStr(LOWORD(PlatformVersion.dwBuildNumber)).c_str());
    strcat(versionText, " ");
    strcat(versionText, PlatformVersion.szCSDVersion);
  }
  if ( PlatformVersion.dwPlatformId == VER_PLATFORM_WIN32_NT ) {
    if ( PlatformVersion.dwMajorVersion <= 4 )
      strcpy(versionText, "NT ");
    else
      strcpy(versionText, "2000 ");

    strcat(versionText, IntToStr(PlatformVersion.dwMajorVersion).c_str());
    strcat(versionText, ".");
    strcat(versionText, IntToStr(PlatformVersion.dwMinorVersion).c_str());
    strcat(versionText, " build ");
    strcat(versionText, IntToStr(PlatformVersion.dwBuildNumber).c_str());
    strcat(versionText, " ");
    strcat(versionText, PlatformVersion.szCSDVersion);
  }
  return PlatformVersion.dwPlatformId;
}

//------------------------------------------------------------------------------
// Returns true if we only want NT machines in the view, false otherwise
//------------------------------------------------------------------------------
bool __fastcall TMainForm::AddOnlyNTMachinesInView()
{
  return pcfg.addOnlyNTMachines;
}

//------------------------------------------------------------------------------
// Updates the statusinfo if a computer checkbox gets checked
//------------------------------------------------------------------------------
void __fastcall TMainForm::ComputersListViewClick(TObject* Sender)
{
  if ( CurrActiveItem ) {
    if ( CurrActiveItem->Checked )
      UpdateStatus(CurrActiveItem->Index, false);
    else {
      CurrActiveItem->SubItems->Strings[lStatusIndex] = "";
      CurrActiveItem->SubItems->Strings[lPathIndex] = "";
      CurrActiveItem->SubItems->Strings[lListenIndex] = "";
      CurrActiveItem->SubItems->Strings[lLogIndex] = "";
    }
  }
  CurrActiveItem = NULL;
}

//------------------------------------------------------------------------------
// Minimizes the form to the system tray
//------------------------------------------------------------------------------
void __fastcall TMainForm::MinimizeButtonClick(TObject *Sender)
{
  // Set default to minimize to system tray
  pcfg.minimizeToSystray = true;
  Application->Minimize();
}

//------------------------------------------------------------------------------
// Returns the current status of the service. A computername is passed. If
//------------------------------------------------------------------------------
DWORD __fastcall TMainForm::GetServiceStatus(char computerName[])
{
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  SERVICE_STATUS serviceStatus;
  DWORD result;

  // Now open the service manager and query the service
  if ( (hscManager = OpenSCManager(computerName, NULL, SC_MANAGER_CONNECT)) != 0 ) {
    if ( (hService = OpenService(hscManager, serviceData.ServiceName, SERVICE_QUERY_STATUS)) != NULL ) {
      QueryServiceStatus(hService, &serviceStatus);
      result = serviceStatus.dwCurrentState;
    }
    else
      result = ERROR_SERVICE_DOES_NOT_EXIST;

    if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(computerName, NULL);
  } else { // Probably a win95 PC
    result = NO_SERVICEMANAGER_FOUND;
  }
  if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(computerName, NULL);
  return result;
}

//------------------------------------------------------------------------------
// Returns true if the service exists, false if not or the status could
// not be obtained
//------------------------------------------------------------------------------
bool __fastcall TMainForm::IsServiceInstalled(char aComputername[])
{
  if ( GetServiceStatus(aComputername) != ERROR_SERVICE_DOES_NOT_EXIST )
    return true;
  else
    return false;
}

//------------------------------------------------------------------------------
// Checks if the service manager on the remote computer can be contacted. In
// practice this is kind of asking if the remote computer runs NT.
//------------------------------------------------------------------------------
bool __fastcall TMainForm::IsServiceManagerInstalled(char aComputername[])
{
  if ( GetServiceStatus(aComputername) != NO_SERVICEMANAGER_FOUND )
    return true;
  else
    return false;
}

//------------------------------------------------------------------------------
// Returns true if the service is running, false if not or the status could
// not be obtained
//------------------------------------------------------------------------------
bool __fastcall TMainForm::IsServiceRunning(char aComputername[])
{
  if ( GetServiceStatus(aComputername) == SERVICE_RUNNING )
    return true;
  else
    return false;
}

//------------------------------------------------------------------------------
// Returns true if the service is running, false if not or the status could
// not be obtained
//------------------------------------------------------------------------------
bool __fastcall TMainForm::IsServicePaused(char aComputername[])
{
  if ( GetServiceStatus(aComputername) == SERVICE_PAUSED )
    return true;
  else
    return false;
}

//------------------------------------------------------------------------------
// Wait for the status to reach the desired status. We assume that the SC manager
// and service handles are valid handles. This method returns true if the service
// reached the desired status, and false if a time-out occurred.
//------------------------------------------------------------------------------
bool __fastcall TMainForm::WaitForServiceToReachStatus(SC_HANDLE aHService, DWORD aServiceStatus, int max_wait_seconds, char aMachineName[])
{
  const int sleepTime = 100; // milliseconds
  int waitTime = 1000 * max_wait_seconds; // Time left to wait
  SERVICE_STATUS serviceStatus;

  QueryServiceStatus(aHService, &serviceStatus);
  while ( (serviceStatus.dwCurrentState != aServiceStatus) && (waitTime >= 0) ) {
    Sleep(sleepTime); // Non-busy sleep
    waitTime -= sleepTime;
    QueryServiceStatus(aHService, &serviceStatus);
  }
  if ( waitTime >= 0 ) return true;
  else {
    Application->MessageBox("Timed out waiting for status to reach state", aMachineName, MB_OK);
    return false;
  }
}

//------------------------------------------------------------------------------
// Installs the service on a remote computer. It only installs if this computer
// is both selected and checked.
//------------------------------------------------------------------------------
void __fastcall TMainForm::InstallButtonClick(TObject* Sender)
{
  int i;
  DWORD startType;
  bool cont; // Set to false if we don't continue after an error
  char errMsg[256];
  char RemoteSystemShare[3];
  char RemoteCommand[MAX_PATH];
  char remoteMachineName[MAX_PATH];
  char remoteMachineDir[MAX_PATH];
  char remoteMachineBasePath[MAX_PATH];
  char remotePath[MAX_PATH];
  char buffer[MAX_PATH];
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  char dependencies[7];

  // Set dependency to TCP/IP service
  memset(dependencies, 0, sizeof(dependencies));
  strcpy(dependencies, "Tcpip");

  if ( !ComputersListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    // We first check if sufficient data is available
    if ( serviceData.IsSufficientDataAvailable() ) {
      Screen->Cursor = crHourGlass;
      // We convert the dir to network shares without the machine name:
      // c:\temp becomes c$\temp.
      RemoteSystemShare[0] = serviceData.DirectoryTo[0];
      RemoteSystemShare[1] = '$';
      RemoteSystemShare[2] = 0;

      // The command to execute on the remote machine to start the service
      strcpy(RemoteCommand, serviceData.DirectoryTo);
      if ( RemoteCommand[strlen(RemoteCommand) - 1] != '\\' ) strcat(RemoteCommand, "\\");
      strcat(RemoteCommand, ExtractFileNameWithoutExt(serviceData.RemoteName, buffer, sizeof(buffer)));
      strcat(RemoteCommand, ".exe \"");
      strcat(RemoteCommand, serviceData.DirectoryTo);
      if ( RemoteCommand[strlen(RemoteCommand) - 1] != '\\' ) strcat(RemoteCommand, "\\");
      strcat(RemoteCommand, ExtractFileNameWithoutExt(serviceData.RemoteName, buffer, sizeof(buffer)));
      strcat(RemoteCommand, ".ini\"");

      for (i = 0; i < ComputersListView->Items->Count; i++) {
        // We only install if this computer is both selected and checked
        if ( ComputersListView->Items->Item[i]->Selected && ComputersListView->Items->Item[i]->Checked ) {
          cont = true;
          // Selected computer name
          strncpy(remoteMachineName, ComputersListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
          // Full path on remote computer. We can do this because exe and ini file
          // always reside in the same dir
          strcpy(remoteMachineDir, "\\\\");
          strncat(remoteMachineDir, ComputersListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineDir));
          strcat(remoteMachineDir, "\\");
          strcat(remoteMachineDir, RemoteSystemShare);
          // Check if we can access the system share.
          if ( DirectoryExists(remoteMachineDir) ) {
            strcat(remoteMachineDir, serviceData.DirectoryTo + 2); // +2 to skip the drive and ":"
            // Store the path
            strcpy(remoteMachineBasePath, remoteMachineDir);
            // Check if the directory exists, create it if not
            if ( !DirectoryExists(remoteMachineDir) ) {
              ForceDirectories(AnsiString(remoteMachineDir));
              if ( !DirectoryExists(remoteMachineDir) ) {
                strcpy(errMsg, "Computer: ");
                strcat(errMsg, remoteMachineName);
                strcat(errMsg, "\nUnable to create destination directory.\nThe service is not installed.");
                Application->MessageBox(errMsg, Application->Title.c_str(), MB_OK|MB_ICONWARNING);
                cont = false;
              }
              strcat(remoteMachineDir, "\\");
            }
            if ( cont ) {
              // Add the name of the remote executable
              strcat(remoteMachineBasePath, ExtractFileNameWithoutExt(serviceData.RemoteName, buffer, sizeof(buffer)));
              // First copy the files to the destination directory. We add the computer
              // names here.
              if ( FileExists(serviceData.ExeFrom) ) {
                strcpy(remotePath, remoteMachineBasePath);
                strcat(remotePath, ".exe");
                RSCC_CopyFile(serviceData.ExeFrom, remotePath, FALSE, pcfg.writeDebugMessages);
              } else {
                Application->MessageBox("The proxy executable could not be found.", Application->Title.c_str(), MB_OK);
              }
              if ( FileExists(serviceData.JbiniFrom) ) {
                strcpy(remotePath, ExtractFilePath(remoteMachineBasePath).c_str());
                strcat(remotePath, ExtractFileName(serviceData.JbiniFrom).c_str());
                RSCC_CopyFile(serviceData.JbiniFrom, remotePath, FALSE, pcfg.writeDebugMessages);
              } else {
                Application->MessageBox("The proxy inifile could not be found.", Application->Title.c_str(), MB_OK);
              }
              if ( strlen(serviceData.Sblockini) && FileExists(serviceData.Sblockini) ) {
                strcpy(remotePath, ExtractFilePath(remoteMachineBasePath).c_str());
                strcat(remotePath, ExtractFileName(serviceData.Sblockini).c_str());
                RSCC_CopyFile(serviceData.Sblockini, remotePath, FALSE, pcfg.writeDebugMessages);
              } else if (strlen(serviceData.Sblockini)) {
                Application->MessageBox("The proxy blockfile could not be found.", Application->Title.c_str(), MB_OK);
              }
              if ( strlen(serviceData.Saclfileini) && FileExists(serviceData.Saclfileini) ) {
                strcpy(remotePath, ExtractFilePath(remoteMachineBasePath).c_str());
                strcat(remotePath, ExtractFileName(serviceData.Saclfileini).c_str());
                RSCC_CopyFile(serviceData.Saclfileini, remotePath, FALSE, pcfg.writeDebugMessages);
              } else if (strlen(serviceData.Saclfileini)) {
                Application->MessageBox("The proxy access control file could not be found.", Application->Title.c_str(), MB_OK);
              }
              if ( strlen(serviceData.Scookieini) && FileExists(serviceData.Scookieini) ) {
                strcpy(remotePath, ExtractFilePath(remoteMachineBasePath).c_str());
                strcat(remotePath, ExtractFileName(serviceData.Scookieini).c_str());
                RSCC_CopyFile(serviceData.Scookieini, remotePath, FALSE, pcfg.writeDebugMessages);
              } else if (strlen(serviceData.Scookieini)) {
                Application->MessageBox("The proxy cookie could not be found.", Application->Title.c_str(), MB_OK);
              }
              if ( strlen(serviceData.Sforwardini) && FileExists(serviceData.Sforwardini) ) {
                strcpy(remotePath, ExtractFilePath(remoteMachineBasePath).c_str());
                strcat(remotePath, ExtractFileName(serviceData.Sforwardini).c_str());
                RSCC_CopyFile(serviceData.Sforwardini, remotePath, FALSE, pcfg.writeDebugMessages);
              } else if (strlen(serviceData.Sforwardini)) {
                Application->MessageBox("The proxy forward file could not be found.", Application->Title.c_str(), MB_OK);
              }
              if ( strlen(serviceData.Strustini) && FileExists(serviceData.Strustini) ) {
                strcpy(remotePath, ExtractFilePath(remoteMachineBasePath).c_str());
                strcat(remotePath, ExtractFileName(serviceData.Strustini).c_str());
                RSCC_CopyFile(serviceData.Strustini, remotePath, FALSE, pcfg.writeDebugMessages);
              } else if (strlen(serviceData.Strustini)) {
                Application->MessageBox("The proxy trust file could not be found.", Application->Title.c_str(), MB_OK);
              }
              // Now open the service manager and install the service
              if ( (hscManager = OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
                // Start type
                if ( serviceData.StartOnBoot ) startType = SERVICE_AUTO_START;
                else startType = SERVICE_DEMAND_START;

                hService = CreateService(hscManager,
                                         serviceData.ServiceName,
                                         serviceData.DisplayName,
                                         SERVICE_ALL_ACCESS,
                                         SERVICE_WIN32_OWN_PROCESS,
                                         startType,
                                         SERVICE_ERROR_IGNORE,
                                         RemoteCommand,
                                         NULL, NULL,
                                         (LPCTSTR)dependencies,
                                         NULL, NULL);

                if ( !hService ) ShowErrorMessage(remoteMachineName, NULL);
                else {
                  if ( serviceData.StartOnInstall )
                    RSCC_StartService(hService, 0, NULL, pcfg.writeDebugMessages, remoteMachineName);
                  // If only one computer selected, update view immediately
                  if ( ComputersListView->SelCount == 1 ) {
                    UpdateStatus(i, false);
                    if ( serviceData.StartOnInstall ) {
                      WaitForServiceToReachStatus(hService, SERVICE_RUNNING, pcfg.MaxWaitTime, remoteMachineName);
                      UpdateStatus(i, false);
                    }
                  } else {
                    if ( serviceData.StartOnInstall )
                      WaitForServiceToReachStatus(hService, SERVICE_RUNNING, pcfg.MaxWaitTime, remoteMachineName);
                  }
                }
                if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
                if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
              } else {
                ShowErrorMessage(remoteMachineName, NULL);
              }
            }
          } else { // Could not access system share
            strcpy(errMsg, "Computer: ");
            strcat(errMsg, remoteMachineName);
            strcat(errMsg, "\nUnable to access system share, you probably have insufficient access rights.\nThe service is not installed.");
            Application->MessageBox(errMsg, Application->Title.c_str(), MB_OK|MB_ICONWARNING);
          }
        }
      }
    }
    // Update view if more computers are selected
    if ( ComputersListView->SelCount > 1 ) UpdateStatus(0, true);
    Screen->Cursor = crDefault;
  }
}

//------------------------------------------------------------------------------
// Skips a possible file extension, including the separating dot.
//------------------------------------------------------------------------------
char* __fastcall TMainForm::ExtractFileNameWithoutExt(const char* aFileName, char* buffer, size_t buffSize)
{
  strncpy(buffer, aFileName, buffSize - 1);
  buffer[buffSize] = 0;
  char* c = strrchr(buffer, '.');
  if ( c ) *c = 0;
  return buffer;
}

//------------------------------------------------------------------------------
// Removes the service from the selected computer. This method only removes
// the service from the selected computer if its chekcbox is also checked.
// The corresponding executable and ini file are also deleted.
//------------------------------------------------------------------------------
void __fastcall TMainForm::RemoveButtonClick(TObject* Sender)
{
  int i, n;
  unsigned int j;
  char* c;
  char UNCdir[MAX_PATH];
  char unquotedCommand[MAX_PATH], tempFileName[MAX_PATH], remoteMachineName[MAX_PATH];
  char ExePathName[MAX_PATH], fJBini[MAX_PATH], fBlock[MAX_PATH], fAcl[MAX_PATH];
  char fCookie[MAX_PATH], fForward[MAX_PATH], fTrust[MAX_PATH], LogPathName[MAX_PATH];
  BOOL retVal;
  DWORD errCode;
  char errStr[256];
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  SERVICE_STATUS serviceStatus;

  if ( !ComputersListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    Screen->Cursor = crHourGlass;
    for (i = 0; i < ComputersListView->Items->Count; i++) {
      if ( ComputersListView->Items->Item[i]->Selected && ComputersListView->Items->Item[i]->Checked ) {
        strncpy(remoteMachineName, ComputersListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
        if ( (hscManager = OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
          if ( (hService = OpenService(hscManager, serviceData.ServiceName, SERVICE_ALL_ACCESS)) == NULL ) {
            hService = NULL; // Reset hService
            ShowErrorMessage(remoteMachineName, NULL);
          }
          // First stop the service. We check the return value separately because
          // we don't want an errormessage when the service is already stopped.
          if ( hService) {
            strcpy(tempFileName, ComputersListView->Items->Item[i]->SubItems->Strings[lPathIndex].c_str());
            strcpy(UNCdir, "\\\\");
            strcat(UNCdir, remoteMachineName);
            strcat(UNCdir, "\\");
            // Remove quotes from the name
            for (n = 0, j = 0; j < strlen(tempFileName); j++) {
              if ( tempFileName[j] != '\"' ) {
                unquotedCommand[n] = tempFileName[j];
                n++;
              }
            }
            unquotedCommand[n] = 0;
            // Find the executable
            c = strstr(unquotedCommand, ".exe");
            if ( c ) *(c + 4) = 0; // Split it in a exe and ini filename part
            strncpy(ExePathName, unquotedCommand, sizeof(ExePathName) - 1);
            // The inifile. We first look for it in the command (where it should be),
            // but if it isn't there we guess the name.
            if ( strstr(c + 5, ".ini") )
              strcpy(fJBini, c + 5);
            else {
              strcpy(fJBini, ExtractFilePath(ExePathName).c_str());
              strcat(fJBini, "junkbstr.ini");
            }
            // Now convert all filenames to UNC
            strcpy(tempFileName, UNCdir);
            strcat(tempFileName, ExePathName);
            strcpy(ExePathName, tempFileName);

            strcpy(tempFileName, UNCdir);
            strcat(tempFileName, fJBini);
            strcpy(fJBini, tempFileName);
            // Replace first : by $ to get network name
            for (j = 0; j < strlen(fJBini); j++) {
              if ( fJBini[j] == ':' ) {
                fJBini[j] = '$';
                break;
              }
            }
            // Now get the files of the other inifiles
            // Set initial path length to 0
            fBlock[0] = 0;
            fAcl[0] = 0;
            fCookie[0] = 0;
            fForward[0] = 0;
            fTrust[0] = 0;
            LogPathName[0] = 0;
            ParseMainIniFile(fJBini, fBlock, fAcl, fCookie, fForward, fTrust, LogPathName, NULL, NULL);
            if ( strlen(fBlock) ) {
              strcpy(tempFileName, UNCdir);
              strcat(tempFileName, fBlock);
              strcpy(fBlock, tempFileName);
            }
            if ( strlen(fAcl) ) {
              strcpy(tempFileName, UNCdir);
              strcat(tempFileName, fAcl);
              strcpy(fAcl, tempFileName);
            }
            if ( strlen(fCookie) ) {
              strcpy(tempFileName, UNCdir);
              strcat(tempFileName, fCookie);
              strcpy(fCookie, tempFileName);
            }
            if ( strlen(fForward) ) {
              strcpy(tempFileName, UNCdir);
              strcat(tempFileName, fForward);
              strcpy(fForward, tempFileName);
            }
            if ( strlen(fTrust) ) {
              strcpy(tempFileName, UNCdir);
              strcat(tempFileName, fTrust);
              strcpy(fTrust, tempFileName);
            }
            if ( strlen(LogPathName) ) {
              strcpy(tempFileName, UNCdir);
              strcat(tempFileName, LogPathName);
              strcpy(LogPathName, tempFileName);
            }
            // Replace first : by $ to get network name. Since all names start
            // with the same machine name the ':' is on the same location.
            for (j = 0; j < strlen(ExePathName); j++) {
              if ( ExePathName[j] == ':' ) {
                ExePathName[j] = '$';
                fBlock[j] = '$';
                fAcl[j] = '$';
                fCookie[j] = '$';
                fForward[j] = '$';
                fTrust[j] = '$';
                LogPathName[j] = '$';
                break;
              }
            }
            // Now stop the service if it runs.
            retVal= RSCC_ControlService(hService, SERVICE_CONTROL_STOP, &serviceStatus, pcfg.writeDebugMessages, remoteMachineName);
            if ( !retVal) {
              errCode = GetLastError();
              if ( errCode != ERROR_SERVICE_NOT_ACTIVE )
                ShowErrorMessage(remoteMachineName, &errCode);
            }
          }
          // Wait until it has stopped
          WaitForServiceToReachStatus(hService, SERVICE_STOPPED, pcfg.MaxWaitTime, remoteMachineName);
          // Then delete the service entry
          if ( hService && !DeleteService(hService) ) ShowErrorMessage(remoteMachineName, NULL);
          if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
          if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
          // Now remove the executable, ini file, logfile and extra file
          if ( !RSCC_DeleteFile(fJBini, pcfg.writeDebugMessages) ) {
            strcpy(errStr, "Error deleting inifile on machine: ");
            strcat(errStr, remoteMachineName);
            ShowErrorMessage(errStr, NULL);
          }
          if ( FileExists(fBlock) ) {
            if ( !RSCC_DeleteFile(fBlock, pcfg.writeDebugMessages) ) {
              strcpy(errStr, "Error deleting blockfile on machine: ");
              strcat(errStr, remoteMachineName);
              ShowErrorMessage(errStr, NULL);
            }
          }
          if ( FileExists(fAcl) ) {
            if ( !RSCC_DeleteFile(fAcl, pcfg.writeDebugMessages) ) {
              strcpy(errStr, "Error deleting access control file on machine: ");
              strcat(errStr, remoteMachineName);
              ShowErrorMessage(errStr, NULL);
            }
          }
          if ( FileExists(fCookie) ) {
            if ( !RSCC_DeleteFile(fCookie, pcfg.writeDebugMessages) ) {
              strcpy(errStr, "Error deleting cookie file on machine: ");
              strcat(errStr, remoteMachineName);
              ShowErrorMessage(errStr, NULL);
            }
          }
          if ( FileExists(fForward) ) {
            if ( !RSCC_DeleteFile(fForward, pcfg.writeDebugMessages) ) {
              strcpy(errStr, "Error deleting forward file on machine: ");
              strcat(errStr, remoteMachineName);
              ShowErrorMessage(errStr, NULL);
            }
          }
          if ( FileExists(fTrust) ) {
            if ( !RSCC_DeleteFile(fTrust, pcfg.writeDebugMessages) ) {
              strcpy(errStr, "Error deleting trust file on machine: ");
              strcat(errStr, remoteMachineName);
              ShowErrorMessage(errStr, NULL);
            }
          }
          if ( FileExists(LogPathName) ) {
            if ( !RSCC_DeleteFile(LogPathName, pcfg.writeDebugMessages) ) {
              strcpy(errStr, "Error deleting logfile on machine: ");
              strcat(errStr, remoteMachineName);
              ShowErrorMessage(errStr, NULL);
            }
          }
          Sleep(100); // Required to prevent access denied errors.
          if ( !RSCC_DeleteFile(ExePathName, pcfg.writeDebugMessages) ) {
            strcpy(errStr, "Error deleting old executable on machine: ");
            strcat(errStr, remoteMachineName);
            ShowErrorMessage(errStr, NULL);
          }
        } else {
          ShowErrorMessage(remoteMachineName, NULL);
        }
        if ( ComputersListView->SelCount == 1 ) UpdateStatus(i, false);
      }
    }
    if ( ComputersListView->SelCount > 1 ) UpdateStatus(0, true);
    Screen->Cursor = crDefault;
  }
}

//------------------------------------------------------------------------------
// View the inifile
//------------------------------------------------------------------------------
void __fastcall TMainForm::ViewIniClick(TObject* Sender)
{
  int i;
  unsigned int  j;
  char* p;
  char mainIniFile[MAX_PATH];
  char iniFileName[MAX_PATH], tempFileName[MAX_PATH];
  char errMsg[MAX_PATH + 16];
  TEditForm* EditForm;

  if ( !ComputersListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    for (i = 0; i < ComputersListView->Items->Count; i++) {
      tempFileName[0] = 0;
      iniFileName[0] = 0;

      if ( ComputersListView->Items->Item[i]->Selected && ComputersListView->Items->Item[i]->Checked ) {
        GetRemoteIniFileName(ComputersListView->Items->Item[i]->Caption.c_str(), mainIniFile, sizeof(mainIniFile));
        if ( (((TMenuItem*)Sender)->Name == "Viewjunkbstrini1") || (((TMenuItem*)Sender)->Name == "Viewjunkbstrini2") )
          strcpy(iniFileName, mainIniFile);

        else if ( (((TMenuItem*)Sender)->Name == "Blockfile1") || (((TMenuItem*)Sender)->Name == "Blockfile2") )
          ParseMainIniFile(mainIniFile, tempFileName, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

        else if ( (((TMenuItem*)Sender)->Name == "Saclfileini1") || (((TMenuItem*)Sender)->Name == "Saclfileini2") )
          ParseMainIniFile(mainIniFile, NULL, tempFileName, NULL, NULL, NULL, NULL, NULL, NULL);

        else if ( (((TMenuItem*)Sender)->Name == "Cookiefile1") || (((TMenuItem*)Sender)->Name == "Cookiefile2") )
          ParseMainIniFile(mainIniFile, NULL, NULL, tempFileName, NULL, NULL, NULL, NULL, NULL);

        else if ( (((TMenuItem*)Sender)->Name == "Forwardfile1") || (((TMenuItem*)Sender)->Name == "Forwardfile2") )
          ParseMainIniFile(mainIniFile, NULL, NULL, NULL, tempFileName, NULL, NULL, NULL, NULL);

        else if ( (((TMenuItem*)Sender)->Name == "Trustfile1") || (((TMenuItem*)Sender)->Name == "Trustfile2") )
          ParseMainIniFile(mainIniFile, NULL, NULL, NULL, NULL, tempFileName, NULL, NULL, NULL);

        // Make UNC path
        if ( strlen(iniFileName) || strlen(tempFileName) ) {
          if ( (((TMenuItem*)Sender)->Name != "Viewjunkbstrini1") && (((TMenuItem*)Sender)->Name != "Viewjunkbstrini2") ) {
            strcpy(iniFileName, "\\\\");
            // Add computer name
            strcat(iniFileName, ComputersListView->Items->Item[i]->Caption.c_str());
            strcat(iniFileName, "\\");
            // Add filename part
            strcat(iniFileName, tempFileName);
            // Replace .exe by .ini. This also removes the bootparams part.
            p = strrchr(iniFileName, '.');
            if ( p ) *p = 0;
            strcat(iniFileName, ".ini");
            // Replace first : by $ to get network name
            for (j = 0; j < strlen(iniFileName); j++) {
              if ( iniFileName[j] == ':' ) {
                iniFileName[j] = '$';
                break;
              }
            }
          }
          if ( FileExists(iniFileName) ) {
            EditForm = new TEditForm(this, iniFileName);
            if ( EditForm ) {
              EditForm->ShowModal();
              delete EditForm;
            }
          } else {
            // Only warn if the service manager is present, the service is
            // installed and we STILL can't open the inifile.
            if ( IsServiceInstalled(ComputersListView->Items->Item[i]->Caption.c_str()) &&
                  IsServiceManagerInstalled(ComputersListView->Items->Item[i]->Caption.c_str()) ) {
              strcpy(errMsg, "File not found: ");
              strcat(errMsg, iniFileName);
              Application->MessageBox(errMsg, Application->Title.c_str(), MB_OK);
            }
          }
        } else {
          Application->MessageBox("This file is not defined in the main inifile.", Application->Title.c_str(), MB_OK);
        }
      }
    }
    UpdateStatus(0, true);
  }
}

//------------------------------------------------------------------------------
// Starts the service on the selected computer. The service is assumed to be
// already installed.
//------------------------------------------------------------------------------
void __fastcall TMainForm::StartButtonClick(TObject* Sender)
{
  int i;
  char remoteMachineName[MAX_PATH];
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;

  if ( !ComputersListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    Screen->Cursor = crHourGlass;
    for (i = 0; i < ComputersListView->Items->Count; i++) {
      if ( ComputersListView->Items->Item[i]->Selected && ComputersListView->Items->Item[i]->Checked ) {
        strncpy(remoteMachineName, ComputersListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
        if ( (hscManager = OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
          if ( (hService = OpenService(hscManager, serviceData.ServiceName, SERVICE_ALL_ACCESS)) == NULL ) {
            hService = NULL; // Reset hService
            ShowErrorMessage(remoteMachineName, NULL);
          } else { // Service != NULL
            if ( !RSCC_StartService(hService, 0, NULL, pcfg.writeDebugMessages, remoteMachineName) )
              ShowErrorMessage(remoteMachineName, NULL);
            else {
              // Show service status
              if ( ComputersListView->SelCount == 1 ) {
                UpdateStatus(i, false);
                WaitForServiceToReachStatus(hService, SERVICE_RUNNING, pcfg.MaxWaitTime, remoteMachineName);
                UpdateStatus(i, false);
              } else {
                WaitForServiceToReachStatus(hService, SERVICE_RUNNING, pcfg.MaxWaitTime, remoteMachineName);
              }
            }
          }
          if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
          if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
        } else {
          ShowErrorMessage(remoteMachineName, NULL);
        }
      }
    }
    if ( ComputersListView->SelCount > 1 ) UpdateStatus(0, true);
    Screen->Cursor = crDefault;
  }
}

//------------------------------------------------------------------------------
// Stops the service on the selected computer(s)
//------------------------------------------------------------------------------
void __fastcall TMainForm::StopButtonClick(TObject* Sender)
{
  SendSignalToRemoteService(SERVICE_CONTROL_STOP);
}

//------------------------------------------------------------------------------
// Pauses the service on the selected computer(s)
//------------------------------------------------------------------------------
void __fastcall TMainForm::Pauseservice1Click(TObject* Sender)
{
  SendSignalToRemoteService(SERVICE_CONTROL_PAUSE);
}

//------------------------------------------------------------------------------
// Continues the service on the selected computer(s)
//------------------------------------------------------------------------------
void __fastcall TMainForm::Continueservice1Click(TObject* Sender)
{
  SendSignalToRemoteService(SERVICE_CONTROL_CONTINUE);
}

//------------------------------------------------------------------------------
// Sends a standard control code to a remote service.
//------------------------------------------------------------------------------
void __fastcall TMainForm::SendSignalToRemoteService(DWORD dwControl)
{
  int i;
  char remoteMachineName[MAX_PATH];
  bool retVal;
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  SERVICE_STATUS serviceStatus;
  DWORD endStatus = GetResultingStatusFromControlCode(dwControl);

  if ( !ComputersListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    Screen->Cursor = crHourGlass;
    for (i = 0; i < ComputersListView->Items->Count; i++) {
      if ( ComputersListView->Items->Item[i]->Selected && ComputersListView->Items->Item[i]->Checked ) {
        strncpy(remoteMachineName, ComputersListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
        if ( (hscManager = OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) != 0 ) {
          if ( (hService = OpenService(hscManager, serviceData.ServiceName, SERVICE_ALL_ACCESS)) == NULL ) {
            hService = NULL; // Reset hService
            ShowErrorMessage(remoteMachineName, NULL);
          } else { // Service != NULL
            retVal = RSCC_ControlService(hService, dwControl, &serviceStatus, pcfg.writeDebugMessages, remoteMachineName);
            if ( !retVal ) ShowErrorMessage(remoteMachineName, NULL);
            // Show service status. We only do this if endStatus != 0.
            if ( ComputersListView->SelCount == 1 && retVal && endStatus ) {
              UpdateStatus(i, false);
              WaitForServiceToReachStatus(hService, endStatus, pcfg.MaxWaitTime, remoteMachineName);
              UpdateStatus(i, false);
            } else if (retVal && endStatus) {
              WaitForServiceToReachStatus(hService, endStatus, pcfg.MaxWaitTime, remoteMachineName);
            }
          }
          if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
          if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
        } else {
          ShowErrorMessage(remoteMachineName, NULL);
        }
      }
    }
    if ( (ComputersListView->SelCount > 1) && retVal && endStatus ) UpdateStatus(0, true);
    Screen->Cursor = crDefault;
  }
}

//------------------------------------------------------------------------------
// Returns the string that belongs to a service action.
//------------------------------------------------------------------------------
AnsiString __fastcall TMainForm::ControlcodeDescription(DWORD dwControl)
{
  AnsiString Result;
  switch ( dwControl ) {
    // Standard control codes
    case SERVICE_CONTROL_STOP:
         Result = "SERVICE_CONTROL_STOP";
         break;
    case SERVICE_CONTROL_PAUSE:
         Result = "SERVICE_CONTROL_PAUSE";
         break;
    case SERVICE_CONTROL_CONTINUE:
         Result = "SERVICE_CONTROL_CONTINUE";
         break;
    case SERVICE_CONTROL_INTERROGATE:
         Result = "SERVICE_CONTROL_INTERROGATE";
         break;
    case SERVICE_CONTROL_SHUTDOWN:
         Result = "SERVICE_CONTROL_SHUTDOWN";
         break;
    // Windows 2000 specific code
    case SERVICE_CONTROL_PARAMCHANGE:
         Result = "SERVICE_CONTROL_PARAMCHANGE";
         break;
    default:
      Result = "Unknown code";
  }
  return Result;
}

//------------------------------------------------------------------------------
// Gets the resulting status code that should result from the action dwControl.
//------------------------------------------------------------------------------
DWORD __fastcall TMainForm::GetResultingStatusFromControlCode(DWORD dwControl)
{
  switch ( dwControl ) {
    // Standard control codes
    case SERVICE_CONTROL_STOP:
         return SERVICE_STOPPED;
    case SERVICE_CONTROL_PAUSE:
         return SERVICE_PAUSED;
    case SERVICE_CONTROL_CONTINUE:
         return SERVICE_RUNNING;
    case SERVICE_CONTROL_INTERROGATE:
         return 0;
    case SERVICE_CONTROL_SHUTDOWN:
         return SERVICE_STOPPED;
    // Windows 2000 specific code
    case SERVICE_CONTROL_PARAMCHANGE:
         return 0;
    default:
      return 0;
    }
}

//------------------------------------------------------------------------------
// Shows the add computer form where a name can be entered.
//------------------------------------------------------------------------------
void __fastcall TMainForm::AddPCButtonClick(TObject* Sender)
{
  TListItem* L;
  bool addAnyWay = true; // Add a non-NT machine if add only NT machines is selected?
  char newName[64];
  TModalResult mrRes;
  TAddComputerForm* AddComputerForm;

  memset(newName, 0, sizeof(newName));
  AddComputerForm = new TAddComputerForm(this, newName, sizeof(newName));
  if ( AddComputerForm ) {
    mrRes = AddComputerForm->ShowModal();
    if ( mrRes == mrOk ) {
      // See if it is an NT machine if we want to add only NT machines
      if ( pcfg.addOnlyNTMachines ) {
        if ( GetRemotePlatformType((LPTSTR)newName) < 2000 ) {
          if ( Application->MessageBox("This machine appears not to be running windows NT or 2000, add anyway?", Application->Title.c_str(), MB_YESNO | MB_ICONWARNING) == ID_NO) {
            addAnyWay = false;
          }
        }
      }
      if ( addAnyWay ) {
        if ( !NameIsDouble(newName) ) {
          // This prevents errors with indices
          ComputersListView->SortType = stNone;
          // Computername in listitem
          L = ComputersListView->Items->Add();
          L->Caption = AnsiString(newName);
          // Add subitem for status
          L->SubItems->Add("");
          // Add subitem for service path
          L->SubItems->Add("");
          // Add subitem for listen address
          L->SubItems->Add("");
          // Add subitem for logging
          L->SubItems->Add("");
          // We check the new computer after adding
          L->Checked = true;
          // Update the status
          UpdateStatus(ComputersListView->Items->IndexOf(L), false);
        }
      }
    }
  }
  // Store the names in the configuration
  StoreComputerNames();
}

//------------------------------------------------------------------------------
// Removes the selected PC from the list.
//------------------------------------------------------------------------------
void __fastcall TMainForm::RemPCButtonClick(TObject* Sender)
{
  int i;

  for(i = 0; i < ComputersListView->Items->Count; i++) {
    if ( ComputersListView->Items->Item[i]->Selected ) {
      ComputersListView->Items->Item[i]->SubItems->Delete(lLogIndex); // Delete service logging
      ComputersListView->Items->Item[i]->SubItems->Delete(lPathIndex); // Delete service path
      ComputersListView->Items->Item[i]->SubItems->Delete(lStatusIndex); // Delete statusline
      ComputersListView->Items->Delete(i);                    // Delete computername
      // Go back since the ListBox count has now decreased
      i--;
    }
  }
  // Store the names in the configuration
  StoreComputerNames();
}

//------------------------------------------------------------------------------
// Get the status of the selected computer
//------------------------------------------------------------------------------
void __fastcall TMainForm::ConfigButtonClick(TObject* Sender)
{
  int i;
  char buffer[2048];
  char remoteMachineName[MAX_PATH];
  // Config params
  DWORD dwServiceType;
  DWORD dwStartType;
  char lpBinaryPathName[MAX_PATH];
  char lpServiceStartName[MAX_PATH];
  char lpDisplayName[MAX_PATH];
  char* lpServiceAccountName1;
  char* lpPassword1;
  DWORD bytesNeeded;
  TConfigForm* ConfigForm;
  bool doChangeConfig = false; // Is set to true when the config should be changed
  bool canChangeConfig; // Is set to false when we can't change the config
  ChangeServiceConfigData serviceConfigData;
  // Service manager variables
  SC_HANDLE hscManager;
  SC_HANDLE hService;
  char dependencies[7];

  // Set dependency to TCP/IP service
  memset(dependencies, 0, sizeof(dependencies));
  strcpy(dependencies, "Tcpip");

  if ( !ComputersListView->SelCount ) {
    Application->MessageBox("No computers are selected.", Application->Title.c_str(), MB_OK);
  } else {
    for (i = 0; i < ComputersListView->Items->Count; i++) {
      if ( ComputersListView->Items->Item[i]->Selected && ComputersListView->Items->Item[i]->Checked ) {
        strncpy(remoteMachineName, ComputersListView->Items->Item[i]->Caption.c_str(), sizeof(remoteMachineName) - 1);
        Screen->Cursor = crHourGlass;
        if ( (hscManager = OpenSCManager(remoteMachineName, NULL, SC_MANAGER_ALL_ACCESS)) == 0 ) {
          // We can't get SC_MANAGER_ALL_ACCESS, try SC_MANAGER_CONNECT for read only access.
          canChangeConfig = false;
          if ( (hscManager = OpenSCManager(remoteMachineName, NULL, SC_MANAGER_CONNECT)) == 0 ) {
            // Set it explicitly to NULL since the OpenSCManager doesn't reset ir if it fails.
            hscManager = NULL;
          }
        } else canChangeConfig = true;
        if ( hscManager ) {
          if ( canChangeConfig ) { // Try to get a service handle with ALL_ACCESS
            if ( (hService = OpenService(hscManager, serviceData.ServiceName, SERVICE_ALL_ACCESS)) == NULL )
              hService = NULL; // Reset value. This is necessary since the OpenService calls does not reset it if it fails.
          } else { // Try to get a read-only service handle.
            if ( (hService = OpenService(hscManager, serviceData.ServiceName, SERVICE_QUERY_CONFIG)) == NULL )
              hService = NULL;
          }
          if ( hService ) {
            memset(serviceConfigData.lpPassword, 0, sizeof(serviceConfigData.lpPassword));
            QueryServiceConfig(hService, (QUERY_SERVICE_CONFIG*)buffer, sizeof(buffer), &bytesNeeded);
            // Save the data
            dwServiceType = ((QUERY_SERVICE_CONFIG*)buffer)->dwServiceType;
            dwStartType = ((QUERY_SERVICE_CONFIG*)buffer)->dwStartType;
            strcpy(lpBinaryPathName, ((QUERY_SERVICE_CONFIG*)buffer)->lpBinaryPathName);
            strcpy(lpServiceStartName, ((QUERY_SERVICE_CONFIG*)buffer)->lpServiceStartName);
            strcpy(lpDisplayName, ((QUERY_SERVICE_CONFIG*)buffer)->lpDisplayName);
            // Show configurationform
            ConfigForm = new TConfigForm(this,
                                         canChangeConfig,
                                         dwServiceType,
                                         dwStartType,
                                         lpBinaryPathName,
                                         lpServiceStartName,
                                         lpDisplayName,
                                         remoteMachineName,
                                         &doChangeConfig,
                                         &serviceConfigData);
            if ( ConfigForm ) {
              ConfigForm->ShowModal();
              delete ConfigForm;
            } else {
              ShowErrorMessage("Error creating form", NULL);
            }
            if ( doChangeConfig ) {
              // Check account data. NULL means no change in account.
              if ( strlen(serviceConfigData.lpServiceStartName) > 0 )
                lpServiceAccountName1 = serviceConfigData.lpServiceStartName;
              else
                lpServiceAccountName1 = NULL;
              // Check password data. NULL means no change.
              if ( strlen(serviceConfigData.lpPassword) > 0 )
                lpPassword1 = serviceConfigData.lpPassword;
              else if ( lpServiceAccountName1 )
                lpPassword1 = ""; // Empty password, we can't use NULL here
              else
                lpPassword1 = NULL;
              // Change the config
              if ( !ChangeServiceConfig(hService,
                                        serviceConfigData.dwServiceType,
                                        serviceConfigData.dwStartType,
                                        serviceConfigData.dwErrorControl,
                                        serviceConfigData.lpBinaryPathName,
                                        NULL, NULL, (LPCTSTR)dependencies,
                                        lpServiceAccountName1,
                                        lpPassword1,
                                        serviceConfigData.lpDisplayName) )
                ShowErrorMessage(remoteMachineName, NULL);
                // Update service status (interaction parameter could have changed)
                if ( ComputersListView->SelCount == 1 )
                  UpdateStatus(i, false);
            }
            Screen->Cursor = crDefault;
          } else {
            Screen->Cursor = crDefault;
            ShowErrorMessage(remoteMachineName, NULL);
          }
          if ( hService && !CloseServiceHandle(hService) ) ShowErrorMessage(remoteMachineName, NULL);
          if ( hscManager && !CloseServiceHandle(hscManager) ) ShowErrorMessage(remoteMachineName, NULL);
        } else {
          ShowErrorMessage(remoteMachineName, NULL);
        }
      }
    }
  }
  if ( ComputersListView->SelCount > 1) UpdateStatus(0, true);
  Screen->Cursor = crDefault;
}

//------------------------------------------------------------------------------
// Edit the inifile on the selected remote computer(s)
//------------------------------------------------------------------------------
void __fastcall TMainForm::EditCommandButtonClick(TObject* Sender)
{
  int i;
  unsigned int  j, k, n;
  char* p;
  char iniFileName[MAX_PATH], tempFileName[MAX_PATH], tempFileName2[MAX_PATH];
  char errMsg[MAX_PATH + 16];
  TEditForm* EditForm;

  if ( !ComputersListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    for (i = 0; i < ComputersListView->Items->Count; i++) {
      if ( ComputersListView->Items->Item[i]->Selected && ComputersListView->Items->Item[i]->Checked ) {
        // We already have the exe name, now derive the ini filename:
        strncpy(tempFileName, ComputersListView->Items->Item[i]->SubItems->Strings[lPathIndex].c_str(), sizeof(tempFileName) - 1);
        // Make filename lowercase
        for (k = 0; k < strlen(tempFileName); k++) tempFileName[k] = (char)tolower(tempFileName[k]);
        // Remove possible quotes from the name (could happen on existing installs)
        memset(tempFileName2, 0, sizeof(tempFileName2));
        for (n = 0, k = 0; k < strlen(tempFileName); k++) {
          if ( tempFileName[k] != '\"' ) {
            tempFileName2[n] = tempFileName[k];
            n++;
          }
        }
        strcpy(iniFileName, "\\\\");
        // Add computer name
        strcat(iniFileName, ComputersListView->Items->Item[i]->Caption.c_str());
        strcat(iniFileName, "\\");
        // Add filename part
        strcat(iniFileName, tempFileName2);
        // Replace .exe by .ini. This also removes the bootparams part.
        p = strrchr(iniFileName, '.');
        if ( p ) *p = 0;
        strcat(iniFileName, ".ini");
        // Replace first : by $ to get network name
        for (j = 0; j < strlen(iniFileName); j++) {
          if ( iniFileName[j] == ':' ) {
            iniFileName[j] = '$';
            break;
          }
        }
        if ( FileExists(iniFileName) ) {
          EditForm = new TEditForm(this, iniFileName);
          if ( EditForm ) {
            if ( EditForm->ShowModal() == mrOk ) UpdateStatus(i, false);
            delete EditForm;
          }
        } else {
          // Only warn if the service manager is present, the service is
          // installed and we STILL can't open the inifile.
          if ( IsServiceInstalled(ComputersListView->Items->Item[i]->Caption.c_str()) &&
                IsServiceManagerInstalled(ComputersListView->Items->Item[i]->Caption.c_str()) ) {
            strcpy(errMsg, "File not found: ");
            strcat(errMsg, iniFileName);
            Application->MessageBox(errMsg, Application->Title.c_str(), MB_OK);
          }
        }
      }
    }
  }
}

//------------------------------------------------------------------------------
// Update the status information for all computers which are checked
//------------------------------------------------------------------------------
void __fastcall TMainForm::UpdateButtonClick(TObject* Sender)
{
  UpdateStatus(0, true);
}

//------------------------------------------------------------------------------
//Creates and shows the settings form
//------------------------------------------------------------------------------
void __fastcall TMainForm::DefaultButtonClick(TObject* Sender)
{
  TDefaultsForm* DefaultsForm = new TDefaultsForm(this, &serviceData);
  DefaultsForm->ShowModal();
  delete DefaultsForm;
}

//------------------------------------------------------------------------------
// Add (new) network computers
//------------------------------------------------------------------------------
void __fastcall TMainForm::NetworkButtonClick(TObject* Sender)
{
  int i;
  int initialCount = ComputersListView->Items->Count;

  GetNetworkComputerNames(false);
  // See which checkboxes need to be checked
  for (i = initialCount; i < ComputersListView->Items->Count; i++) {
    if ( ProgramSettingsFile->ReadInteger(ComputerNamesIniSection, ComputersListView->Items->Item[i]->Caption, 0) == 1 )
      ComputersListView->Items->Item[i]->Checked = true;
  }
}

//------------------------------------------------------------------------------
// Edit the use account under which the program tries to run
//------------------------------------------------------------------------------
void __fastcall TMainForm::SwitchAccountButtonClick(TObject* Sender)
{
  char* domainName;
  bool Change = false;  

  TAccountForm* AccountForm = new TAccountForm(this,
                                               pcfg.Username,
                                               pcfg.Domain,
                                               pcfg.Password,
                                               sizeof(pcfg.Username),
                                               sizeof(pcfg.Domain),
                                               sizeof(pcfg.Password),
                                               &pcfg.SwitchUserID,
                                               &Change);
  if ( AccountForm ) {
    AccountForm->ShowModal();
    delete AccountForm;
  }
  if ( Change ) {
    // Drop priviliges
    if (hToken && !CloseHandle(hToken) ) ShowErrorMessage("CloseHandle", NULL);
    if ( pcfg.SwitchUserID && !RevertToSelf() ) ShowErrorMessage("RevertToSelf", NULL);
    // Domain name need not be specified
    if ( pcfg.Domain && strlen(pcfg.Domain) ) domainName = pcfg.Domain;
    else domainName = NULL;

    // The SE_TCB_NAME privilige is required for this call to work.
    if ( !LogonUser(pcfg.Username, domainName, pcfg.Password,
                    LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, &hToken) )
      ShowErrorMessage("LogonUser", NULL);

    if ( hToken ) {
      if ( !ImpersonateLoggedOnUser(hToken) ) {
        ShowErrorMessage("ImpersonateLoggedOnUser", NULL);
      } else
        UpdateStatus(0, true);
    }
  }
}

//------------------------------------------------------------------------------
// Show the helpform
//------------------------------------------------------------------------------
void __fastcall TMainForm::HelpButtonClick(TObject* Sender)
{
  THelpForm* HelpForm = new THelpForm(this);
  if ( HelpForm ) {
    HelpForm->ShowModal();
    delete HelpForm;
  }
}

//------------------------------------------------------------------------------
// Show program information
//------------------------------------------------------------------------------
void __fastcall TMainForm::AboutButtonClick(TObject* Sender)
{
  AboutForm->ShowModal();
}

//------------------------------------------------------------------------------
// See which computer is selected, store this in the computername menuitem caption.
//------------------------------------------------------------------------------
void __fastcall TMainForm::ComputersListViewMouseDown(TObject* Sender, TMouseButton Button, TShiftState Shift, int X, int Y)
{
  // Find the computer on which the mouse button was downed
  CurrActiveItem = ComputersListView->GetItemAt(X, Y);
  // Store this in the popup menu upper caption.
  if ( CurrActiveItem )
    Computername1->Caption = CurrActiveItem->Caption;
  else
    Computername1->Caption = "No computer selected";
}

//------------------------------------------------------------------------------
// Adapt the listbox: select ONLY the computer that is clicked on so all
// methods only work on this one.
//------------------------------------------------------------------------------
void __fastcall TMainForm::RsccPopupMenuPopup(TObject* Sender)
{
  int i;
  bool found = false;
  // Find out which computer is clicked on and select only that item
  for (i = 0; i < ComputersListView->Items->Count; i++) {
    if ( ComputersListView->Items->Item[i]->Caption != Computername1->Caption )
      ComputersListView->Items->Item[i]->Selected = false;
    else {
      ComputersListView->Items->Item[i]->Selected = true;
      found = true; // Fount at least one match
      break;
    }
  }
  // No computers selected
  if ( !found || !ComputersListView->Items->Item[i]->Checked ) {
    Installservice2->Enabled = false;
    Removeservice2->Enabled = false;
    Startservice2->Enabled = false;
    Stopservice2->Enabled = false;
    Pauseservice2->Enabled = false;
    Continueservice2->Enabled = false;
    Configureservice2->Enabled = false;
    Inifiles2->Enabled = false;
    Logfile2->Enabled = false;
  // No service manager found
  } else if ( !IsServiceManagerInstalled(Computername1->Caption.c_str()) ) {
    Installservice2->Enabled = false;
    Removeservice2->Enabled = false;
    Startservice2->Enabled = false;
    Stopservice2->Enabled = false;
    Pauseservice2->Enabled = false;
    Continueservice2->Enabled = false;
    Configureservice2->Enabled = false;
    Inifiles2->Enabled = false;
    Logfile2->Enabled = false;
  } else {
    // Not installed
    if ( !IsServiceInstalled(Computername1->Caption.c_str()) ) {
      Installservice2->Enabled = true;
      Removeservice2->Enabled = false;
      Startservice2->Enabled = false;
      Stopservice2->Enabled = false;
      Pauseservice2->Enabled = false;
      Continueservice2->Enabled = false;
      Configureservice2->Enabled = false;
      Inifiles2->Enabled = false;
      Logfile2->Enabled = false;
    // Installed but not running or paused
    } else if ( !IsServiceRunning(Computername1->Caption.c_str()) && !IsServicePaused(Computername1->Caption.c_str())) {
      Installservice2->Enabled = false;
      Removeservice2->Enabled = true;
      Startservice2->Enabled = true;
      Stopservice2->Enabled = false;
      Pauseservice2->Enabled = false;
      Continueservice2->Enabled = false;
      Configureservice2->Enabled = true;
      Inifiles2->Enabled = true;
      Logfile2->Enabled = true;
    // Installed and running or paused
    } else {
      Installservice2->Enabled = false;
      Removeservice2->Enabled = true;
      Startservice2->Enabled = false;
      Stopservice2->Enabled = true;
      if ( IsServicePaused(Computername1->Caption.c_str()) ) {
        Pauseservice2->Enabled = false;
        Continueservice2->Enabled = true;
      } else {
        Pauseservice2->Enabled = true;
        Continueservice2->Enabled = false;
      }
      Configureservice2->Enabled = true;
      Inifiles2->Enabled = true;
      Logfile2->Enabled = true;
    }
  }
}

//------------------------------------------------------------------------------
// Sort the list depending on which column is clicked
//------------------------------------------------------------------------------
void __fastcall TMainForm::ComputersListViewColumnClick(TObject* Sender, TListColumn* Column)
{
  ColumnClicked = Column->Index;
  // Set to stNone to assure that the sorting routine will be called
  ComputersListView->SortType = stNone;
  ComputersListView->SortType = stText;
}

//------------------------------------------------------------------------------
// Compare 2 listview items
//------------------------------------------------------------------------------
void __fastcall TMainForm::ComputersListViewCompare(TObject* Sender, TListItem* Item1, TListItem* Item2, int Data, int& Compare)
{
  AnsiString s1, s2;

  // Alphabetical sorting
  if ( !ColumnClicked )
    Compare = strcmp(Item1->Caption.c_str(), Item2->Caption.c_str());
  else {
    s1 = Item1->SubItems->Strings[ColumnClicked - 1];
    s2 = Item2->SubItems->Strings[ColumnClicked - 1];
    Compare = strcmp(s1.c_str(), s2.c_str());
  }
}

//------------------------------------------------------------------------------
// Shows the logfile.
//------------------------------------------------------------------------------
void __fastcall TMainForm::Logfile1Click(TObject* Sender)
{
  int i;
  unsigned int  j;
  bool log;
  char iniFileName[MAX_PATH];
  char logFileName[MAX_PATH], tempFileName[MAX_PATH];
  TViewLogFileForm* ViewLogFileForm;
  TViewLogFileForm* l;

  if ( !ComputersListView->SelCount ) {
    Application->MessageBox("No computers selected.", Application->Title.c_str(), MB_OK);
  } else {
    for (i = 0; i < ComputersListView->Items->Count; i++) {
      // We only try to find logfiles if the computer is both selected AND checked.
      if ( ComputersListView->Items->Item[i]->Selected && ComputersListView->Items->Item[i]->Checked ) {
        tempFileName[0] = 0;
        // Get main inifile
        GetRemoteIniFileName(ComputersListView->Items->Item[i]->Caption.c_str(), iniFileName, sizeof(iniFileName));
        // Find logfile
        ParseMainIniFile(iniFileName, NULL, NULL, NULL, NULL, NULL, tempFileName, &log, NULL);
        if ( strlen(tempFileName) ) { // If logfile defined
          // Make UNC path
          strcpy(logFileName, "\\\\");
          // Add computer name
          strcat(logFileName, ComputersListView->Items->Item[i]->Caption.c_str());
          strcat(logFileName, "\\");
          // Add filename part
          strcat(logFileName, tempFileName);
          // Replace first : by $ to get network name
          for (j = 0; j < strlen(logFileName); j++) {
            if ( logFileName[j] == ':' ) {
              logFileName[j] = '$';
              break;
            }
          }
          if ( FileExists(AnsiString(logFileName)) ) { // Find the logfile
            l = CheckForDoubleFile(logFileName);
            if ( !l ) {
              ViewLogFileForm = new TViewLogFileForm(
                      this,
                      logFileName,
                      1000 * pcfg.LogRefreshTime, // milliseconds
                      pcfg.autoRefreshLogs);
              if ( ViewLogFileForm ) {
                // Add new window to child list for closing and deleting on app termination
                AddNode(viewLogFilesChildren, ViewLogFileForm, logFileName);
                // Set main form for beeing able to call SendMessage there
                ViewLogFileForm->mainForm = this;
                // Show the window non-modal
                ViewLogFileForm->Show();
              }
            } else {
              if ( l->WindowState == wsMinimized ) l->WindowState = wsNormal;
              l->SetFocus();
            }
          } else {
            AnsiString errorMsg = "Could not find logfile " + AnsiString(logFileName);
            Application->MessageBox(errorMsg.c_str(), Application->Title.c_str(), MB_OK | MB_ICONWARNING);
          }
        } else {
          AnsiString errorMsg = "No logfile defined in main inifile for computer " + ComputersListView->Items->Item[i]->Caption;
          Application->MessageBox(errorMsg.c_str(), Application->Title.c_str(), MB_OK | MB_ICONINFORMATION);
        }
      }
    }
  }
}

//------------------------------------------------------------------------------
// View the debug file
//------------------------------------------------------------------------------
void __fastcall TMainForm::ViewDebugFile1Click(TObject* Sender)
{
  if ( FileExists(tracefile) ) {
    TViewLogFileForm* l = CheckForDoubleFile(tracefile);
    if ( !l ) {
      TViewLogFileForm* ViewLogFileForm = new TViewLogFileForm(this, tracefile, 10000, false);
      if ( ViewLogFileForm ) {
        // Add new window to child list for closing and deleting on app termination
        AddNode(viewLogFilesChildren, ViewLogFileForm, tracefile);
        // Set main form for beeing able to call SendMessage there
        ViewLogFileForm->mainForm = this;
        // Show the window non-modal
        ViewLogFileForm->Show();
      }
    } else {
      if ( l->WindowState == wsMinimized ) l->WindowState = wsNormal;
      l->SetFocus();
    }
  } else {
    AnsiString errMsg = "File \"" + tracefile + "\" with debug information not found";
    Application->MessageBox(errMsg.c_str(), Application->Title.c_str(), MB_OK);
  }
}

//------------------------------------------------------------------------------
// Adds a pointer to a form to the list of open screens, and adds a menuitem
// to the window menu. This is only done if the file is not yet opened. If it
// is already open, the open window is shown.
//------------------------------------------------------------------------------
void __fastcall TMainForm::AddNode(TList* l, TObject* o, AnsiString caption)
{
  TMenuItem* item = new TMenuItem(RsccMainMenu);
  ((TViewLogFileForm*)o)->windowMenuItem = item;
  item->Caption = caption;
  item->OnClick = WindowClick;
  item->Tag = (int)o; // Store the pointer to the form so we can easily access
                      // it when the menuitem is clicked.
  Window1->Add(item);
  l->Add(o);
}

//------------------------------------------------------------------------------
// A menuitem in the window menu is clicked. Bring the corresponding form to
// the foreground.
//------------------------------------------------------------------------------
void __fastcall TMainForm::WindowClick(TObject* Sender)
{
  TViewLogFileForm* l = (TViewLogFileForm*)((TMenuItem*)Sender)->Tag;
  if ( l ) {
    if ( l->WindowState == wsMinimized ) l->WindowState = wsNormal;
    l->SetFocus();
  }
}

//------------------------------------------------------------------------------
// Checks is a logfileform with the given caption already exists in the list.
// If it does, it returns a pointer to it. Else it returns NULL.
//------------------------------------------------------------------------------
TViewLogFileForm* __fastcall TMainForm::CheckForDoubleFile(AnsiString caption)
{
  for (int i = 0; i < viewLogFilesChildren->Count; i++) {
    if ( ((TViewLogFileForm*)viewLogFilesChildren->Items[i])->windowMenuItem->Caption == caption )
      return (TViewLogFileForm*)viewLogFilesChildren->Items[i];
  }
  return NULL;
}

//------------------------------------------------------------------------------
// TNetworkScanThread methods
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Constructor. Stores the owner.
//------------------------------------------------------------------------------
__fastcall TNetworkScanThread::TNetworkScanThread(bool createSuspended,
                                                  bool aRunUpdateAfterwards,
                                                  TMainForm* Owner): TThread(createSuspended)
{
  OwnerForm = Owner;
  fRunUpdateAfterwards = aRunUpdateAfterwards;
  FreeOnTerminate = true; // So we don't have to delete the thread explicitly
}

//------------------------------------------------------------------------------
// Destructor
//------------------------------------------------------------------------------
__fastcall TNetworkScanThread::~TNetworkScanThread()
{
}

//------------------------------------------------------------------------------
// Execute method. Tries to run the thread.
//------------------------------------------------------------------------------
void __fastcall TNetworkScanThread::Execute()
{
  AnsiString errText;

  try {
    OwnerForm->SetThreadWaitText("Initializing...", "");
    FindNetworkComputerNames(NULL);
    if ( fRunUpdateAfterwards )
      SendMessage(OwnerForm->Handle, WM_SCAN_THREAD_READY, DO_UPDATE_STATUS, 0);
    else
      SendMessage(OwnerForm->Handle, WM_SCAN_THREAD_READY, DO_NOT_UPDATE_STATUS, 0);
  }
  catch (Exception& exception) {
    errText = "Error running network scan thread: " + exception.Message;
    MessageBox(NULL, errText.c_str(), Application->Title.c_str(), MB_OK);
  }
}

//------------------------------------------------------------------------------
// Find the network computer names and add them to the listview.
//------------------------------------------------------------------------------
void __fastcall TNetworkScanThread::FindNetworkComputerNames(LPNETRESOURCE lpnr)
{
  DWORD ResultEnum;
  HANDLE hEnum;
  DWORD cbBuffer = 16384;        // 16K is a good size
  DWORD i, entries = 0xFFFFFFFF; // enumerate all possible entries
  LPNETRESOURCE lpnrLocal;       // pointer to enumerated structures
  char ComputerName[64];
  bool addMachine;
  TListItem* L;

  if ( WNetOpenEnum(RESOURCE_GLOBALNET, RESOURCETYPE_ANY, 0, lpnr, &hEnum) != NO_ERROR ) {
    ShowErrorMessage("WNetOpenEnum", NULL);
    return;
  }

  do {
    // Allocate memory for NETRESOURCE structures.
    lpnrLocal = (LPNETRESOURCE)GlobalAlloc(GPTR, cbBuffer);
    if ( !lpnrLocal ) {
      ShowErrorMessage("GlobalAlloc", NULL);
    } else {
      ResultEnum = WNetEnumResource(hEnum, &entries, lpnrLocal, &cbBuffer);
      if (ResultEnum == NO_ERROR) {
        for (i = 0; i < entries; i++) {
          // We add only computer names
          if ( (lpnrLocal[i].lpRemoteName) && (lpnrLocal[i].lpRemoteName[0] == '\\') ) {
            strncpy(ComputerName, lpnrLocal[i].lpRemoteName + 2, sizeof(ComputerName) - 1);
            OwnerForm->SetThreadWaitText("Reading computer names...", AnsiString(ComputerName).LowerCase());
            if ( !NameIsDouble(ComputerName) ) {
              if ( OwnerForm->AddOnlyNTMachinesInView() ) {
                addMachine = ( GetRemotePlatformType((LPTSTR)ComputerName) >= 2000 );
              } else {
                addMachine = true;
              }
              if ( addMachine ) {
                // Add the computer name listitem
                L = OwnerForm->ComputersListView->Items->Add();
                L->Caption = AnsiString(ComputerName);
                // Add subitem for status
                L->SubItems->Add("");
                // Add subitem for service path
                L->SubItems->Add("");
                // Add subitem for listen address
                L->SubItems->Add("");
                // Add subitem for logging
                L->SubItems->Add("");
              }
            }
          }
          // If this NETRESOURCE is a container AND it is not a directory,
          // call the function recursively. We also check on the existence
          // of lpnrLocal[i].lpRemoteName - it is sometimes NULL.
          if ( (RESOURCEUSAGE_CONTAINER == (lpnrLocal[i].dwUsage & RESOURCEUSAGE_CONTAINER)) &&
               (lpnrLocal[i].lpRemoteName) && (lpnrLocal[i].lpRemoteName[0] != '\\') ) {
            FindNetworkComputerNames(&lpnrLocal[i]);
          }
        }
      }
      else if (ResultEnum != ERROR_NO_MORE_ITEMS) {
        ShowErrorMessage("WNetEnumResource", NULL);
        GlobalFree((HGLOBAL)lpnrLocal);
        break;
      }
      GlobalFree((HGLOBAL)lpnrLocal);
    }
  }
  while( ResultEnum != ERROR_NO_MORE_ITEMS && !Terminated );

  if ( WNetCloseEnum(hEnum) != NO_ERROR ) ShowErrorMessage("WNetCloseEnum", NULL);
  return;
}

//------------------------------------------------------------------------------
// Returns true if a name already exists in the list, otherwise false, and
// converts the name to lowercase.
//------------------------------------------------------------------------------
bool __fastcall TNetworkScanThread::NameIsDouble(char* name)
{
  int i, j;
  char temp[64];

  for (i = 0; i < (int)strlen(name); i++) name[i] = (char)tolower(name[i]);
  for (i = 0; i < OwnerForm->ComputersListView->Items->Count; i++) {
    strncpy(temp, OwnerForm->ComputersListView->Items->Item[i]->Caption.c_str(), sizeof(temp) - 1);
    for (j = 0; j < (int)strlen(temp); j++) temp[j] = (char)tolower(temp[j]);
    if ( !strcmp(temp, name) )
      return true;
  }
  return false;
}

//------------------------------------------------------------------------------

