//------------------------------------------------------------------------------
// This file is part of Remote Proxy Controller by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: base64.cpp
//
// base64 encode and decode functions.
//------------------------------------------------------------------------------
#include <vcl.h>
#include <mem.h>
#pragma hdrstop

#include "Base64.h"

//------------------------------------------------------------------------------

static char B64Table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

//------------------------------------------------------------------------------
// Writes in outS a BASE64 encoded version of inS. inS can have any content,
// including \0.
//------------------------------------------------------------------------------
void Base64Encode(const char inS[], char outS[], size_t inbuff_size, size_t outbuff_size)
{
  unsigned int i, length;
  unsigned char InBuf[3];
  char OutBuf[4];

  length = ((inbuff_size + 2) / 3) * 4;
  if ( length > outbuff_size )
    throw Exception("Base64Encode: Output buffer too small");

  for (i = 0; i < ((inbuff_size + 2) / 3); i++) {
    if ( inbuff_size < (i*3) )
      memcpy(InBuf, &inS[i*3], inbuff_size - i * 3);
    else
      memcpy(InBuf, &inS[i*3], 3);

    OutBuf[0] = B64Table[((InBuf[0] & 0xFC) >> 2)];
    OutBuf[1] = B64Table[(((InBuf[0] & 0x03) << 4) | ((InBuf[1] & 0xF0) >> 4))];
    OutBuf[2] = B64Table[(((InBuf[1] & 0x0F) << 2) | ((InBuf[2] & 0xC0) >> 6))];
    OutBuf[3] = B64Table[(InBuf[2] & 0x3F)];
    memcpy(&outS[i*4], OutBuf, 4);
  }
  if ((inbuff_size % 3) == 1) {
    outS[length - 2] = '=';
    outS[length - 1] = '=';
  }
  else if ((inbuff_size % 3) == 2) {
    outS[length - 1] = '=';
  }
  outS[length] = 0; // Terminate output buffer
}

//------------------------------------------------------------------------------
// Writes in outS a BASE64 decoded version of inS.
//------------------------------------------------------------------------------
void Base64Decode(const char inS[], char outS[], size_t inbuff_size, size_t outbuff_size)
{
  unsigned int i, outlength, inlength;
  unsigned char  InBuf[4];
  unsigned char  OutBuf[3];

  inlength = strlen(inS); // We can use strlen since base64 input is always ASCII
  if ( inlength )
    outlength = ((inlength / 4) - 1) * 3;
  else
    outlength = 0;

  if ( inlength % 4)
    throw Exception("Base4Decode: Incorrect input string format");

  if ( outlength > outbuff_size )
    throw Exception("Base64Decode: output buffer too small");

  memset(outS, 0, outbuff_size);

  for (i = 0; i < (inbuff_size / 4); i++) {
    memcpy(InBuf, &inS[i * 4], 4);
    if ((InBuf[0] > 64) && (InBuf[0] < 91))
      InBuf[0] -= 'A';
    else if ((InBuf[0] > 96) && (InBuf[0] < 123))
      InBuf[0] -= 'G';
    else if ((InBuf[0] > 47) && (InBuf[0] < 58))
      InBuf[0] += (char)4;
    else if (InBuf[0] == 43) // +
      InBuf[0] = 62;
    else // '/'
      InBuf[0] = 63;

    if ((InBuf[1] > 64) && (InBuf[1] < 91))
      InBuf[1] -= 'A';
    else if ((InBuf[1] > 96) && (InBuf[1] < 123))
      InBuf[1] -= 'G';
    else if ((InBuf[1] > 47) && (InBuf[1] < 58))
      InBuf[1] += (char)4;
    else if (InBuf[1] == 43)
      InBuf[1] = 62;
    else
      InBuf[1] = 63;

    if ((InBuf[2] > 64) && (InBuf[2] < 91))
      InBuf[2] -= 'A';
    else if ((InBuf[2] > 96) && (InBuf[2]< 123))
      InBuf[2] -= 'G';
    else if ((InBuf[2] > 47) && (InBuf[2] < 58))
      InBuf[2] += (char)4;
    else if (InBuf[2] == 43)
      InBuf[2] = 62;
    else
      InBuf[2] = 63;

    if ((InBuf[3] > 64) && (InBuf[3]< 91))
      InBuf[3] -= 'A';
    else if ((InBuf[3] > 96) && (InBuf[3] < 123))
      InBuf[3] -= 'G';
    else if ((InBuf[3] > 47) && (InBuf[3] < 58))
      InBuf[3] += (char)4;
    else if (InBuf[3] == 43)
      InBuf[3] = 62;
    else
      InBuf[3] = 63;

    OutBuf[0] = (unsigned char )((InBuf[0] << 2) | ((InBuf[1] >> 4) & 0x03));
    OutBuf[1] = (unsigned char )((InBuf[1] << 4) | ((InBuf[2] >> 2) & 0x0F));
    OutBuf[2] = (unsigned char )((InBuf[2] << 6) | (InBuf[3] & 0x3F));
    memcpy(&outS[3*i], OutBuf, 3);
  }
  if ( inlength ) {
    memcpy(InBuf, &inS[inlength - 4], 4);
    if ( InBuf[2] == '=' ) {
      if ((InBuf[0] > 64) && (InBuf[0] < 91))
        InBuf[0] -= 'A';
      else if ((InBuf[0] > 96) && (InBuf[0] < 123))
        InBuf[0] -= 'G';
      else if ((InBuf[0] > 47) && (InBuf[0] < 58))
        InBuf[0] += (char)4;
      else if (InBuf[0] == 43)
        InBuf[0] = 62;
      else
        InBuf[0] = 63;

      if ((InBuf[1] > 64) && (InBuf[1] < 91))
        InBuf[1] -= 'A';
      else if ((InBuf[1] > 96) && (InBuf[1] < 123))
        InBuf[1] -= 'G';
      else if ((InBuf[1] > 47) && (InBuf[1] < 58))
        InBuf[1] += (char)4;
      else if (InBuf[1] == 43)
        InBuf[1] = 62;
      else
        InBuf[1] = 63;

      OutBuf[0] = (unsigned char )((InBuf[0] << 2) | ((InBuf[1] >> 4) & 0x03));
      outS[i*3] = OutBuf[0];
    } else if ( InBuf[3] == '=' ) {
      if ((InBuf[0] > 64) && (InBuf[0] < 91))
        InBuf[0] -= 'A';
      else if ((InBuf[0] > 96) && (InBuf[0] < 123))
        InBuf[0] -= 'G';
      else if ((InBuf[0] > 47) && (InBuf[0] < 58))
        InBuf[0] += (char)4;
      else if (InBuf[0] == 43)
        InBuf[0] = 62;
      else
        InBuf[0] = 63;

      if ((InBuf[1] > 64) && (InBuf[1] < 91))
        InBuf[1] -= 'A';
      else if ((InBuf[1] > 96) && (InBuf[1] < 123))
        InBuf[1] -=  'G';
      else if ((InBuf[1] > 47) && (InBuf[1] < 58))
        InBuf[1] += (char)4;
      else if (InBuf[1] == 43)
        InBuf[1] = 62;
      else
        InBuf[1] = 63;

      if ((InBuf[2] > 64) && (InBuf[2] < 91))
        InBuf[2] -= 'A';
      else if ((InBuf[2] > 96) && (InBuf[2] < 123))
        InBuf[2] -= 'G';
      else if ((InBuf[2] > 47) && (InBuf[2] < 58))
        InBuf[2] += (char)4;
      else if (InBuf[2] == 43)
        InBuf[2] = 62;
      else
        InBuf[2] = 63;

      OutBuf[0] = (unsigned char )((InBuf[0] << 2) | ((InBuf[1] >> 4) & 0x03));
      OutBuf[1] = (unsigned char )((InBuf[1] << 4) | ((InBuf[2] >> 2) & 0x0F));

      outS[3*i] = OutBuf[0];
      outS[(3*i)+1] = OutBuf[1];
    } else {
      if ((InBuf[0] > 64) && (InBuf[0] < 91))
        InBuf[0] -= 'A';
      else if ((InBuf[0] > 96) && (InBuf[0] < 123))
        InBuf[0] -= 'G';
      else if ((InBuf[0] > 47) && (InBuf[0] < 58))
        InBuf[0] += (char)4;
      else if (InBuf[0] == 43)
        InBuf[0] = 62;
      else
        InBuf[0] = 63;

      if ((InBuf[1] > 64) && (InBuf[1] < 91))
        InBuf[1] -= 'A';
      else if ((InBuf[1] > 96) && (InBuf[1] < 123))
        InBuf[1] -= 'G';
      else if ((InBuf[1] > 47) && (InBuf[1] < 58))
        InBuf[1] += (char)4;
      else if (InBuf[1] == 43)
        InBuf[1] = 62;
      else
        InBuf[1] = 63;

      if ((InBuf[2] > 64) && (InBuf[2] < 91))
        InBuf[2] -= 'A';
      else if ((InBuf[2] > 96) && (InBuf[2] < 123))
        InBuf[2] -= 'G';
      else if ((InBuf[2] > 47) && (InBuf[2] < 58))
        InBuf[2] += (char)4;
      else if (InBuf[2] == 43)
        InBuf[2] = 62;
      else
        InBuf[2] = 63;

      if ((InBuf[3] > 64) && (InBuf[3] < 91))
        InBuf[3] -= 'A';
      else if ((InBuf[3] > 96) && (InBuf[3] < 123))
        InBuf[3] -= 'G';
      else if ((InBuf[3] > 47) && (InBuf[3] < 58))
        InBuf[3] += (char)4;
      else if (InBuf[3] == 43)
        InBuf[3] = 62;
      else
        InBuf[3] = 63;

      OutBuf[0] = (unsigned char )((InBuf[0] << 2) | ((InBuf[1] >> 4) & 0x03));
      OutBuf[1] = (unsigned char )((InBuf[1] << 4) | ((InBuf[2] >> 2) & 0x0F));
      OutBuf[2] = (unsigned char )((InBuf[2] << 6) | (InBuf[3] & 0x3F));

      outS[3*i] = OutBuf[0];
      outS[(3*i)+1] = OutBuf[1];
      outS[(3*i)+2] = OutBuf[2];
    }
  }
}

//------------------------------------------------------------------------------

