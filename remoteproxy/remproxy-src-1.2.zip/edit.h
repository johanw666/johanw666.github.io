//------------------------------------------------------------------------------
// This file is part of Remote Proxy Controller by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: edit.h
//------------------------------------------------------------------------------
#ifndef editH
#define editH
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//------------------------------------------------------------------------------
class TEditForm: public TForm
{
__published:
  TPanel* Panel1;
  TPanel* Panel2;
  TButton* SaveButton;
  TButton* CancelButton;
  TMemo* IniFileMemo;
  void __fastcall CancelButtonClick(TObject* Sender);
  void __fastcall SaveButtonClick(TObject* Sender);
private:
  AnsiString fFileName;
  __fastcall TEditForm(TComponent* Owner);
public:
  __fastcall TEditForm(TComponent* Owner, AnsiString aFileName);
};
//------------------------------------------------------------------------------
#endif

