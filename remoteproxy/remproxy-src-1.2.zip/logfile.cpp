//------------------------------------------------------------------------------
// This file is part of Remote Proxy Controller by J.C.A. Wevers
// Distributed under the GNU general public license.
//
// File: logfile.cpp
//
// Contains the form to show a logfile.
//------------------------------------------------------------------------------
#include <vcl.h>
#include <stdlib.h>
#pragma hdrstop

#include <stdio.h>
#include "logfile.h"
//------------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

//------------------------------------------------------------------------------
// Standard constructor. Private, not to be used.
//------------------------------------------------------------------------------
__fastcall TViewLogFileForm::TViewLogFileForm(TComponent* Owner): TForm(Owner)
{
}

//------------------------------------------------------------------------------
// Constructor. Reads data from the specified logfile.
//------------------------------------------------------------------------------
__fastcall TViewLogFileForm::TViewLogFileForm(TComponent* Owner,
                                              AnsiString aLogFileName,
                                              int aLogRefreshTime,
                                              bool autoRefresh): TForm(Owner)
{
  LogFileName = aLogFileName;
   RefreshTimer->Interval = aLogRefreshTime;
  // See if the timer should be enabled
  if ( autoRefresh ) RefreshTimer->Enabled = true;
  if ( FileExists(aLogFileName) )
    RefreshText(NULL);
  else {
    AnsiString errorMsg = "Could not find logfile " + aLogFileName;
    Application->MessageBox(errorMsg.c_str(), Application->Title.c_str(), MB_OK);
  }
  Caption = aLogFileName;
  if ( Owner ) {
    Top = ((TForm*)Owner)->Top + (((TForm*)Owner)->Height - Height);
    if ( Top < 0 ) Top = 0;
    Left = ((TForm*)Owner)->Left;
  } else
    Position = poScreenCenter;
  // Safe defaults
  mainForm = NULL;
  windowMenuItem = NULL;
}

//------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------
void __fastcall TViewLogFileForm::CloseButtonClick(TObject* Sender)
{
  Close();
}

//------------------------------------------------------------------------------
// Refresh the logfile contents.
//------------------------------------------------------------------------------
void __fastcall TViewLogFileForm::RefreshText(TObject* Sender)
{
  FILE* f;
  char* p;
  char buf[BUFSIZ];
  LogFileMemo->Lines->Clear();
  // Show all loglines. We can't use LoadFromFile() because this method
  // crashes on open files and the logfile is kept open by Junkbusters.
  f = fopen(LogFileName.c_str(), "r");
  if ( f ) {
    while (fgets(buf, sizeof(buf), f)) {
      if ( (p = strpbrk(buf, "\r\n")) != NULL ) *p = 0; // Remove EOL markers
      LogFileMemo->Lines->Add(buf);
    }
    fclose(f);
  }
  SetCursorPos();
}

//------------------------------------------------------------------------------
// Set the cursor to the end of the loaded text.
//------------------------------------------------------------------------------
void __fastcall TViewLogFileForm::SetCursorPos()
{
  int i, j;

  for (j = 0, i = 0; i < LogFileMemo->Lines->Count; i++)
    j += LogFileMemo->Lines->Strings[i].Length() + 2; // 2 for \r\n

  LogFileMemo->SelStart = j;
  LogFileMemo->SelLength = 1;
}

//------------------------------------------------------------------------------
// Close the form when escape or enter is pressed.
//------------------------------------------------------------------------------
void __fastcall TViewLogFileForm::CloseButtonKeyDown(TObject* Sender, WORD& Key, TShiftState Shift)
{
  if ( (Key == VK_ESCAPE) || (Key == VK_RETURN) ) Close();
}

//------------------------------------------------------------------------------
// Set the cursor to the bottom of the text the first time the form is shown.
// Disable the timer afterwards.
//------------------------------------------------------------------------------
void __fastcall TViewLogFileForm::SetCursorTimerTimer(TObject* Sender)
{
  SetCursorTimer->Enabled = false;
  SetCursorPos();
}

//------------------------------------------------------------------------------
// Notify parent form (TMainForm) that the window is closed,
// to remove the pointer from the childlist and delete allocated memory.
//------------------------------------------------------------------------------
void __fastcall TViewLogFileForm::FormClose(TObject* Sender, TCloseAction& Action)
{
  if ( mainForm ) {
    // PostMessage!!! since we cannot let the receive method execute its code here
    // (which is deleting the object we're just running in :)
    PostMessage(mainForm->Handle, WM_CLOSE_VIEW_LOGFILE, (WPARAM)this, (LPARAM)windowMenuItem);
  }
}

//------------------------------------------------------------------------------

